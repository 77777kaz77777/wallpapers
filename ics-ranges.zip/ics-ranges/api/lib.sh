#!/usr/bin/env bash
# lib.sh - Proxmox API helpers for the ICS Ranges container (no software on the nodes)
#
#   PVE_API_URL     https://192.168.77.77:8006 https://192.168.77.78:8006   (tried in order)
#   PVE_API_TOKEN   user@realm!tokenid=secret   (or the file $PVE_API_TOKEN_FILE)
#   PVE_API_CA      CA file to check the node certificate (default: none = accept self-signed)
PVE_DATA=${PVE_RANGE_DATA:-/data}
PVE_API_TOKEN_FILE=${PVE_API_TOKEN_FILE:-$PVE_DATA/priv/pve-api-token}
PVE_API_CA=${PVE_API_CA:-$PVE_DATA/priv/pve-root-ca.pem}

set -o pipefail   # a failing API call is never hidden by a pipe
die() { echo "error: $*" >&2; exit 1; }

# In an add-on, ICS Ranges hands over the course's guests (ICS_GUESTS_FILE: "vmid node type name" lines)
# and ICS_SCOPE (their VMIDs): commands find a guest's node without asking Proxmox, and only the
# course's guests can be touched.
in_scope() { [[ -z ${ICS_SCOPE:-} || " $ICS_SCOPE " == *" $1 "* ]]; }
need_scope() {
    in_scope "$1" || die "guest $1 isn't in ${COURSE:-this course} - an add-on only works on the guests of its course${COURSE:+ ($COURSE)}"
}

api_token() {
    if [[ -n ${PVE_API_TOKEN:-} ]]; then printf '%s' "$PVE_API_TOKEN"
    else tr -d '\r\n ' <"$PVE_API_TOKEN_FILE" 2>/dev/null; fi
}

# api METHOD PATH [key=value ...]   -> prints the "data" part of the answer as JSON
api() {
    local m=$1 p=$2 tok url out code err kv msg
    shift 2
    tok=$(api_token)
    [[ -n $tok ]] || { echo "error: no Proxmox API token (PVE_API_TOKEN or $PVE_API_TOKEN_FILE)" >&2; return 1; }
    [[ -n ${PVE_API_URL:-} ]] || { echo "error: PVE_API_URL is not set" >&2; return 1; }
    local -a a=(-sS --connect-timeout 5 --max-time 120 -H "Authorization: PVEAPIToken=$tok" -w '\n%{http_code}')
    if [[ -s $PVE_API_CA ]]; then a+=(--cacert "$PVE_API_CA"); else a+=(-k); fi
    [[ $m == GET || $m == DELETE ]] && a+=(-G)
    [[ $m == GET ]] || a+=(-X "$m")
    for kv in "$@"; do a+=(--data-urlencode "$kv"); done
    err=$(mktemp)
    for url in ${PVE_API_URL//,/ }; do
        out=$(curl "${a[@]}" "${url%/}/api2/json$p" 2>"$err") || continue   # node down -> next one
        code=${out##*$'\n'} out=${out%$'\n'*}
        rm -f "$err"
        if [[ $code == 2* ]]; then
            jq -c '.data' <<<"$out" 2>/dev/null || echo null
            return 0
        fi
        msg=$(jq -r '[.message // empty, ((.errors // {}) | to_entries[] | "\(.key): \(.value)")] | join(" ")' <<<"$out" 2>/dev/null)
        echo "error: $m $p -> HTTP $code ${msg:-$out}" >&2
        return 1
    done
    echo "error: can't reach the Proxmox API ($PVE_API_URL): $(tail -1 "$err")" >&2
    rm -f "$err"
    return 1
}

# Wait for a task (UPID) to finish; print its log if it failed
wait_task() {
    local upid=$1 node st es enc
    node=$(cut -d: -f2 <<<"$upid")
    enc=$(jq -rn --arg u "$upid" '$u | @uri')
    local polls=0
    while :; do
        st=$(api GET "/nodes/$node/tasks/$enc/status") || return 1
        [[ $(jq -r '.status' <<<"$st") == stopped ]] && break
        # most tasks end within 2 seconds: look often at first, then every second
        if ((polls++ < 8)); then sleep 0.25; else sleep 1; fi
    done
    es=$(jq -r '.exitstatus // ""' <<<"$st")
    case $es in
        OK) ;;
        WARNINGS:*)   # finished, but Proxmox logged warnings - show them, it still worked
            api GET "/nodes/$node/tasks/$enc/log" limit=500 2>/dev/null | jq -r '.[].t' | grep -i 'warn' | tail -5 >&2
            ;;
        *)
            api GET "/nodes/$node/tasks/$enc/log" limit=500 2>/dev/null | jq -r '.[].t' | tail -8 >&2
            echo "task failed: ${es:-unknown}" >&2
            return 1
            ;;
    esac
}
# If an API answer is a task id, wait for it
maybe_wait() { if [[ $1 == '"UPID:'* ]]; then wait_task "$(jq -r '.' <<<"$1")"; fi; }

# locate VMID -> sets NODE and GTYPE (qemu / lxc): from the add-on's guest table, else one API call
# shellcheck disable=SC2034   # GTYPE is used by qm / pct, which source this file
locate() {
    local line
    NODE="" GTYPE=""
    if [[ -n ${ICS_GUESTS_FILE:-} && -f $ICS_GUESTS_FILE ]]; then
        line=$(awk -v id="$1" '$1 == id { print $2, $3; exit }' "$ICS_GUESTS_FILE")
        [[ -n $line ]] && { NODE=${line% *} GTYPE=${line#* }; }
    fi
    if [[ -z $NODE ]]; then
        line=$(api GET /cluster/resources type=vm | jq -r --arg id "$1" '.[] | select(.vmid == ($id | tonumber)) | "\(.node) \(.type)"' | head -1) || return 1
        [[ -n $line ]] && { NODE=${line% *} GTYPE=${line#* }; }
    fi
    [[ -n ${PVE_TARGET_NODE:-} ]] && NODE=$PVE_TARGET_NODE
    [[ -n $NODE ]]
}
# Node a guest lives on (PVE_TARGET_NODE wins)
node_of() { locate "$1" && echo "$NODE"; }
# after a migration: the guest table follows
moved() { [[ -n ${ICS_GUESTS_FILE:-} && -w $ICS_GUESTS_FILE ]] && sed -i "s/^$1 [^ ]* /$1 $2 /" "$ICS_GUESTS_FILE"; return 0; }

# IP of a node (for the optional ovs-vsctl SSH)
node_ip() {
    api GET /cluster/status | jq -r --arg n "$1" '.[] | select(.type == "node" and .name == $n) | .ip' | head -1
}

# Split CLI-style arguments: POS=(positional) KV=(key=value) ; --flag value / --flag=value
parse_args() {
    set -- "${@%$'\r'}"   # scripts saved on Windows: no hidden carriage returns in the arguments
    POS=() KV=()
    while (($#)); do
        case $1 in
            --*=*) KV+=("${1#--}") ;;
            --*)
                if [[ $# -gt 1 && $2 != --* ]]; then KV+=("${1#--}=$2"); shift; else KV+=("${1#--}=1"); fi
                ;;
            *) POS+=("$1") ;;
        esac
        shift
    done
}
