#!/usr/bin/env bash
# NAME: EFI Enroll-keys
# DESC: Enroll Secure Boot keys on the selected UEFI VMs (they must be off)
# GUESTS: yes
#
# Needs the node key line from Settings, Node key (it allows qm enroll-efi-keys).
# Skips containers, VMs that don't use UEFI, running VMs and VMs that already have the keys.
ok=0 skipped=0 failed=0
for id in $GUESTS; do
    cfg=$(qm config "$id" 2>/dev/null) || { echo "== $id: a container or not found - skipped"; skipped=$((skipped + 1)); continue; }
    name=$(sed -n 's/^name: //p' <<<"$cfg")
    if ! grep -q '^bios: ovmf' <<<"$cfg"; then
        echo "== $id $name: uses SeaBIOS, not UEFI - skipped"; skipped=$((skipped + 1)); continue
    fi
    if ! grep -q '^efidisk0:' <<<"$cfg"; then
        echo "== $id $name: has no EFI disk - use Build, EFI keys, 'New EFI disk with the keys'"; skipped=$((skipped + 1)); continue
    fi
    if grep -q '^efidisk0:.*pre-enrolled-keys=1' <<<"$cfg"; then
        echo "== $id $name: already has the keys - skipped"; skipped=$((skipped + 1)); continue
    fi
    if [[ $(qm status "$id") != "status: stopped" ]]; then
        echo "== $id $name: is running - switch it off first"; skipped=$((skipped + 1)); continue
    fi
    echo "== $id $name: enrolling the keys"
    if qm enroll-efi-keys "$id"; then ok=$((ok + 1)); else failed=$((failed + 1)); fi
done
echo
echo "$ok enrolled, $skipped skipped, $failed failed"
((failed == 0))
