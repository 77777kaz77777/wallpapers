#!/usr/bin/env bash
# release.sh - add a new ICS Ranges version to your Gitea, and publish it as a release
# that kits can install from "Software updates" - it asks before publishing.
#
#   ./release.sh /path/to/ics-ranges.zip   a new version you were sent as a zip
#   ./release.sh                           a new version from your changes in the source folder
#   ./release.sh publish v2.4.2            publish a version that is already in Gitea - or add
#                                          what its release is missing (e.g. the .sha256 file)
#   ./release.sh list                      versions in Gitea and whether kits can install them
#   ./release.sh setup                     change the repository, user name or token
#
# Needs: git, curl, unzip, sha256sum. The first run asks for the repository and a token
# that may WRITE to it (Gitea: Settings -> Applications -> repository: Read and Write);
# they are kept in ~/.config/ics-ranges/release.conf (only you can read it).
set -u
CONF=${ICS_RELEASE_CONF:-$HOME/.config/ics-ranges/release.conf}
OUT=${ICS_RELEASE_DIR:-$HOME/ics-ranges-releases}
if [[ -t 1 ]]; then B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'; else B="" G="" R="" Y="" Z=""; fi
die() { echo "${R}$*${Z}" >&2; exit 1; }
ask() { local a; read -rp "$1 [$2] " a; echo "${a:-$2}"; }
yes_no() { local a; read -rp "$1 [y/N] " a; [[ $a == [yY]* ]]; }
yes_No() { local a; read -rp "$1 [Y/n] " a; [[ $a != [nN]* ]]; }
for c in git curl unzip sha256sum; do command -v $c >/dev/null || die "$c is missing - install it first (apt-get install -y $c / dnf -y install $c)"; done

# ------------------------------------------------------------------ settings
REPO="" USER_="" TOKEN="" INSECURE=0 SRC="$HOME/ics-ranges-src" GIT_URL=""
load_conf() { [[ -r $CONF ]] && . "$CONF"; GIT_URL=${GIT_URL:-$REPO.git}; }
derive() { BASE=${REPO%/*/*}; OWNER_REPO=${REPO#"$BASE"/}; API="$BASE/api/v1/repos/$OWNER_REPO"; }
CURL=(curl -sS --connect-timeout 15 --max-time 900)
code="" body=""
api() {   # METHOD PATH [curl args...] -> $code, $body
    local m=$1 p=$2 out
    shift 2
    local -a k=()
    [[ $INSECURE == 1 ]] && k=(-k)
    out=$("${CURL[@]}" "${k[@]}" -X "$m" -H "Authorization: token $TOKEN" -H "Accept: application/json" "$@" -w $'\n%{http_code}' "$API$p") || out=$'\n000'
    code=${out##*$'\n'}
    body=${out%$'\n'*}
}
git_() { git -c http.extraHeader="Authorization: Basic $(printf '%s:%s' "$USER_" "$TOKEN" | base64 -w0)" \
             -c http.sslVerify="$([[ $INSECURE == 1 ]] && echo false || echo true)" "$@"; }

setup() {
    load_conf
    echo "${B}Where the ICS Ranges versions go${Z} (the same repository kits update from)"
    REPO=$(ask "Repository address" "${REPO:-http://192.168.77.93:3000/kaz/ics-ranges-app}"); REPO=${REPO%/}; REPO=${REPO%.git}
    [[ $REPO =~ ^https?://[^[:space:]/]+(/[^[:space:]/]+)*/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || die "That isn't a repository address."
    USER_=$(ask "Your user name there" "${USER_:-${USER:-kaz}}")
    local t
    read -rsp "Token that may WRITE to the repository (Enter keeps the saved one): " t; echo
    [[ -n $t ]] && TOKEN=$t
    [[ -n $TOKEN ]] || die "A token is needed."
    INSECURE=0
    [[ $REPO == https://* ]] && ! yes_No "Check the server's HTTPS certificate? (no for a self-signed Gitea)" && INSECURE=1
    SRC=$(ask "Source folder (a Git copy of the repository, made if missing)" "$SRC")
    GIT_URL=$REPO.git
    derive
    api GET ""
    [[ $code == 200 ]] || die "The repository answered HTTP $code - check the address and the token."
    grep -Eq '"push": *true' <<<"$body" || die "That token may read but not WRITE to the repository - give it repository: Read and Write."
    mkdir -p "$(dirname "$CONF")"
    (umask 077; printf 'REPO=%q\nUSER_=%q\nTOKEN=%q\nINSECURE=%q\nSRC=%q\n' "$REPO" "$USER_" "$TOKEN" "$INSECURE" "$SRC" >"$CONF")
    echo "${G}Saved${Z} in $CONF"
}
ready() {
    load_conf
    [[ -n $REPO && -n $TOKEN ]] || setup
    load_conf; derive
}

# ------------------------------------------------------------------ the Git copy
ensure_src() {
    if [[ -d $SRC/.git ]]; then
        git_ -C "$SRC" fetch -q origin --tags 2>/dev/null || echo "${Y}Couldn't fetch from Gitea - working with the local copy.${Z}"
        return 0
    fi
    if [[ -n $(git_ ls-remote "$GIT_URL" 2>/dev/null) ]]; then
        echo "Making the source folder $SRC from Gitea ..."
        git_ clone -q "$GIT_URL" "$SRC" || die "couldn't clone $GIT_URL"
    else
        echo "The repository is empty - starting the source folder $SRC."
        mkdir -p "$SRC" && git -C "$SRC" init -q -b main && git -C "$SRC" remote add origin "$GIT_URL"
    fi
    [[ -f $SRC/.gitignore ]] || printf '.env\n*.zip\n__pycache__/\nupdates/\nupdater.conf\n' >"$SRC/.gitignore"
}
version_in() { sed -n 's/^VERSION = "\(.*\)"$/\1/p' "$1" 2>/dev/null | head -1; }
ver_ok() { [[ $1 =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)?$ ]]; }
tag_exists() { git -C "$SRC" rev-parse -q --verify "refs/tags/v$1" >/dev/null || [[ -n $(git_ ls-remote --tags "$GIT_URL" "refs/tags/v$1" 2>/dev/null) ]]; }
latest_tag() { git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname | head -1; }
next_patch() { local v=${1#v}; [[ $v =~ ^([0-9]+)\.([0-9]+)\.([0-9]+) ]] && echo "${BASH_REMATCH[1]}.${BASH_REMATCH[2]}.$((BASH_REMATCH[3] + 1))" || echo "1.0.0"; }

commit_tag_push() {   # version
    local v=$1 n
    git -C "$SRC" add -A
    n=$(git -C "$SRC" status --porcelain | wc -l)
    echo "Changed files: $n"
    git -C "$SRC" status --short | head -15 | sed 's/^/   /'
    ((n > 15)) && echo "   ... and $((n - 15)) more"
    yes_No "Add version $v to Gitea (commit, tag v$v, push)?" || { git -C "$SRC" reset -q; die "Nothing was changed in Gitea."; }
    git -C "$SRC" -c user.name="${GIT_AUTHOR_NAME:-$USER_}" -c user.email="${GIT_AUTHOR_EMAIL:-$USER_@ics-ranges.local}" \
        commit -q -m "ICS Ranges $v" --allow-empty || die "commit failed"
    git -C "$SRC" -c user.name="$USER_" -c user.email="$USER_@ics-ranges.local" tag -a "v$v" -m "ICS Ranges $v" || die "tag failed"
    git_ -C "$SRC" push -q origin HEAD:main || die "push to Gitea failed"
    git_ -C "$SRC" push -q origin "v$v" || die "pushing the tag failed"
    echo "${G}Version $v is in Gitea${Z} (tag v$v)."
}
sha_file() { (cd "$1" && sha256sum ics-ranges.zip >ics-ranges.zip.sha256); }

# ------------------------------------------------------------------ publish (or complete) a release
asset_names() { grep -oE '"name": *"[^"]*"' <<<"$1" | sed -E 's/"name": *"(.*)"/\1/'; }
asset_url() { tr -d '\n' <<<"$1" | grep -oE "\"name\": *\"$2\"[^}]*\"browser_download_url\": *\"[^\"]*\"" | head -1 | sed -E 's/.*"browser_download_url": *"([^"]*)"/\1/'; }
json_str() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\t'/\\t}; s=${s//$'\r'/}; s=${s//$'\n'/\\n}; printf '"%s"' "$s"; }

publish() {   # vX.Y.Z
    local tag=v${1#v} v rid rel dir url notes prev have
    v=${tag#v}
    ver_ok "$v" || die "usage: ./release.sh publish v2.4.2"
    ensure_src
    tag_exists "$v" || die "There is no tag $tag in Gitea - add the version first: ./release.sh <zip>"
    dir=$OUT/$tag
    mkdir -p "$dir"
    api GET "/releases/tags/$tag"
    if [[ $code == 200 ]]; then
        rel=$body
        echo "Release $tag exists - checking its files."
    elif [[ $code == 404 ]]; then
        prev=$(git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname | grep -A1 -x "$tag" | sed -n 2p)
        notes=$(git -C "$SRC" log --pretty='- %s' ${prev:+"$prev..$tag"} 2>/dev/null | grep -v "^- ICS Ranges $v\$" | head -20)
        echo "Release notes - what's new in $v. One line, or Enter for: ${notes:-"ICS Ranges $v"}"
        read -rp "> " url
        [[ -n $url ]] && notes=$url
        api POST "/releases" -H "Content-Type: application/json" \
            --data "{\"tag_name\":\"$tag\",\"name\":\"ICS Ranges $v\",\"body\":$(json_str "${notes:-ICS Ranges $v}"),\"draft\":false,\"prerelease\":false}"
        [[ $code == 201 || $code == 200 ]] || die "Gitea refused to make the release (HTTP $code): ${body:0:200}"
        rel=$body
        echo "Release $tag made."
    else
        die "Gitea answered HTTP $code for $tag - check the token."
    fi
    rid=$(grep -oE '"id": *[0-9]+' <<<"$rel" | head -1 | grep -oE '[0-9]+$')
    have=$(asset_names "$rel")

    # the zip: the one already attached (so the checksum matches it), else ours, else built from the tag
    if grep -qx 'ics-ranges.zip' <<<"$have"; then
        url=$(asset_url "$rel" ics-ranges.zip)
        local -a k=(); [[ $INSECURE == 1 ]] && k=(-k)
        "${CURL[@]}" "${k[@]}" -f -H "Authorization: token $TOKEN" -o "$dir/ics-ranges.zip" "$url" ||
            "${CURL[@]}" "${k[@]}" -f -u "$USER_:$TOKEN" -o "$dir/ics-ranges.zip" "$url" ||
            die "couldn't download the attached ics-ranges.zip to make its checksum"
    elif [[ ! -s $dir/ics-ranges.zip ]]; then
        echo "Building ics-ranges.zip from tag $tag ..."
        git -C "$SRC" archive --format=zip --prefix=ics-ranges/ -o "$dir/ics-ranges.zip" "$tag" || die "git archive failed"
    fi
    unzip -tq "$dir/ics-ranges.zip" >/dev/null || die "$dir/ics-ranges.zip is damaged"
    [[ $(unzip -p "$dir/ics-ranges.zip" ics-ranges/app/server.py | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1) == "$v" ]] ||
        die "the zip for $tag doesn't contain version $v"
    sha_file "$dir"

    local f up=0
    for f in ics-ranges.zip ics-ranges.zip.sha256; do
        if grep -qx "$f" <<<"$have"; then
            echo "  $f: already attached"
            continue
        fi
        api POST "/releases/$rid/assets?name=$f" -F "attachment=@$dir/$f"
        [[ $code == 201 || $code == 200 ]] || die "uploading $f failed (HTTP $code): ${body:0:200}"
        echo "  $f: attached"
        up=1
    done
    api GET "/releases/tags/$tag"
    have=$(asset_names "$body")
    grep -qx 'ics-ranges.zip' <<<"$have" && grep -qx 'ics-ranges.zip.sha256' <<<"$have" ||
        die "the release still lacks a file - check it in Gitea: $REPO/releases/tag/$tag"
    ((up)) && echo
    echo "${G}Release $tag is published${Z}: $REPO/releases/tag/$tag"
    echo "Kits: Software updates -> Check again -> Update to $tag"
    echo "The files are also in $dir (for a USB stick)."
}

ask_publish() {   # version
    local v=$1
    echo
    if yes_no "Publish v$v as a release now, so kits can install it?"; then
        publish "v$v"
    else
        echo "Not published - kits don't see v$v yet. Publish it any time with:  ./release.sh publish v$v"
        echo "Its files are in $OUT/v$v."
    fi
}

# ------------------------------------------------------------------ new versions
from_zip() {   # zip
    local zip=$1 v t dir
    [[ -f $zip ]] || die "no such file: $zip"
    unzip -tq "$zip" >/dev/null || die "$zip is damaged - copy it again"
    unzip -l "$zip" | grep -q ' ics-ranges/app/server.py$' || die "$zip isn't an ICS Ranges zip"
    v=$(unzip -p "$zip" ics-ranges/app/server.py | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1)
    ver_ok "$v" || die "can't read the version in $zip"
    echo "${B}ICS Ranges $v${Z} from $zip"
    ensure_src
    tag_exists "$v" && die "v$v is already in Gitea. To publish (or complete) its release: ./release.sh publish v$v"
    t=$(mktemp -d)
    unzip -q "$zip" -d "$t" || die "unzip failed"
    find "$SRC" -mindepth 1 -maxdepth 1 ! -name .git ! -name .gitignore -exec rm -rf {} +
    cp -a "$t/ics-ranges/." "$SRC/" && rm -rf "$t"
    commit_tag_push "$v"
    dir=$OUT/v$v; mkdir -p "$dir"; cp "$zip" "$dir/ics-ranges.zip"; sha_file "$dir"
    ask_publish "$v"
}

from_folder() {
    local cur last v dir
    ensure_src
    [[ -f $SRC/app/server.py ]] || die "$SRC has no ICS Ranges files yet - start with a zip: ./release.sh /path/to/ics-ranges.zip"
    last=$(latest_tag)
    if [[ -n $last && -z $(git -C "$SRC" status --porcelain) && $(git -C "$SRC" rev-parse HEAD) == "$(git -C "$SRC" rev-list -n1 "$last")" ]]; then
        die "Nothing changed in $SRC since $last. Change files there first, or use: ./release.sh /path/to/ics-ranges.zip"
    fi
    cur=$(version_in "$SRC/app/server.py")
    echo "${B}A new version from your changes in $SRC${Z} (last version in Gitea: ${last:-none}, the files say ${cur:-?})"
    v=$(ask "Version number for it" "$(next_patch "${last:-$cur}")")
    ver_ok "$v" || die "versions look like 2.4.2"
    tag_exists "$v" && die "v$v is already in Gitea - pick another number"
    sed -i "s/^VERSION = \".*\"$/VERSION = \"$v\"/" "$SRC/app/server.py"
    commit_tag_push "$v"
    dir=$OUT/v$v; mkdir -p "$dir"
    git -C "$SRC" archive --format=zip --prefix=ics-ranges/ -o "$dir/ics-ranges.zip" "v$v" || die "git archive failed"
    sha_file "$dir"
    ask_publish "$v"
}

list() {
    ensure_src
    api GET "/releases?limit=50"
    [[ $code == 200 ]] || die "Gitea answered HTTP $code"
    local tags t
    tags=$(git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname)
    echo "${B}Versions in Gitea${Z}"
    for t in $tags; do
        api GET "/releases/tags/$t"
        if [[ $code != 200 ]]; then echo "  $t   ${Y}not published${Z} - ./release.sh publish $t"
        elif asset_names "$body" | grep -qx ics-ranges.zip.sha256 && asset_names "$body" | grep -qx ics-ranges.zip; then echo "  $t   ${G}published - kits can install it${Z}"
        else echo "  $t   ${Y}published, but missing a file${Z} - ./release.sh publish $t"
        fi
    done
    [[ -n $tags ]] || echo "  none yet"
}

case ${1:-} in
    setup) setup ;;
    publish) ready; publish "${2:-}" ;;
    list) ready; list ;;
    -h|--help|help) sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//' ;;
    "") ready; from_folder ;;
    *) ready; from_zip "$1" ;;
esac
