# ControlYard – Setup guide

For ControlYard 4.1.0 (formerly ICS Ranges). How to install ControlYard on a Proxmox VM or LXC container, connect it to
Proxmox, keep it up to date, and publish new versions. For using it, see [USER-GUIDE.md](USER-GUIDE.md).


*Formerly **ICS Ranges**.* New installs are called `controlyard` throughout – the folder
`/opt/controlyard`, the release file `controlyard.zip`, the container and its data volume. A kit from
before keeps its old names (`ics-ranges`) and works as it is, until it is renamed once with
`sudo ./setup.sh rename` (SETUP-GUIDE.md, section 11b).

- [1. What you need](#1-what-you-need)
- [2. Create the host – VM or LXC container](#2-create-the-host--vm-or-lxc-container)
- [3. Install Docker](#3-install-docker)
- [4. Firewall](#4-firewall)
- [5. The Proxmox API token](#5-the-proxmox-api-token)
- [6. Install ControlYard](#6-install-controlyard)
- [7. First sign-in and users](#7-first-sign-in-and-users)
- [8. The node key – port mirroring, IGMP snooping, host add-ons, EFI keys](#8-the-node-key--port-mirroring-igmp-snooping-host-add-ons-efi-keys)
- [8a. TrueNAS – for the Health page](#8a-truenas--for-the-health-page)
- [8b. One GitHub repository – versions and each kit's content](#8b-one-github-repository--versions-and-each-kits-content)
- [9. Software updates from the web page](#9-software-updates-from-the-web-page)
- [10. Publishing a new version](#10-publishing-a-new-version)
- [11. Updating by hand and going back](#11-updating-by-hand-and-going-back)
- [11a. Kit backup – rebuild or swap a kit](#11a-kit-backup--rebuild-or-swap-a-kit)
- [11b. Renaming a kit from before ControlYard](#11b-renaming-a-kit-from-before-controlyard)
- [12. Testing a kit](#12-testing-a-kit)
- [13. Commands and names](#13-commands-and-names)
- [14. Troubleshooting](#14-troubleshooting)

---

## 1. What you need

| Item | Details |
|---|---|
| A host | A Proxmox **VM** or **LXC container** with Debian 12 / 13 or Rocky Linux 9 – 2 CPU cores, 2 GB RAM, 8–16 GB disk |
| Network | The host reaches every Proxmox node on port **8006** (API), and on **22** for the node key. People reach the host on port **8443** |
| Proxmox | Root on one node once – for the API token and the node key (or someone who has it) |
| The package | `controlyard.zip` and its SHA-256 checksum |
| Optional | A GitHub (or Gitea) repository for software updates and for keeping add-ons, guides and settings – section 8b |

Nothing is installed on the Proxmox nodes – ControlYard talks to them through the Proxmox API.

**VM or LXC container?**

| | VM | LXC container |
|---|---|---|
| Setup | Install the OS from an ISO | Quick, from a Proxmox template |
| Resources | A little more RAM and disk | Very light |
| Docker inside | Works as on any server | Needs *nesting* and *keyctl* |

Both work the same once Docker runs.

---

## 2. Create the host – VM or LXC container

### Option A – a VM

1. Upload the installer ISO to a node: *node → local → ISO Images → Download from URL* (Debian netinst
   or Rocky Linux 9 minimal).
2. **Create VM**: a VMID **below 100000** (it then shows under *Management*), name `controlyard`,
   the ISO, *Qemu Agent* ticked, 16 GB disk, 2 cores (type *host*), 2048 MB, the bridge of the
   nodes' management network.
3. Install the OS – Debian: no desktop, tick *SSH server* and *standard system utilities*;
   Rocky: *Minimal Install*.
4. Give it a **fixed IP address** – the nodes only accept the node key from this address.
5. Add the guest agent:

```bash
sudo apt-get install -y qemu-guest-agent && sudo systemctl start qemu-guest-agent   # Debian
sudo dnf -y install qemu-guest-agent && sudo systemctl start qemu-guest-agent       # Rocky
```

### Option B – an LXC container

1. Download a template: *node → local → CT Templates → Templates* → **debian-12-standard**
   (or 13) or **rockylinux-9-default**.
2. **Create CT**: a CT ID **below 100000**, hostname `controlyard`, *Unprivileged container* and
   *Nesting* ticked, 8–16 GB disk, 2 cores, 2048 MB, a **fixed IPv4 address** and gateway.
3. Before starting it, turn on what Docker needs – on the node (example CT 105):

```bash
pct set 105 --features nesting=1,keyctl=1
```

4. Start it and make a normal user with sudo:

```bash
apt-get update && apt-get install -y sudo && adduser kaz && usermod -aG sudo kaz      # Debian
dnf -y install sudo && adduser kaz && passwd kaz && usermod -aG wheel kaz             # Rocky
```

---

## 3. Install Docker

### Debian 12 / 13

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl unzip git
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER        # then log out and back in
```

Without access to download.docker.com: `sudo apt-get install -y docker.io docker-compose unzip`
(on Debian 13 the compose package may be called `docker-compose-v2`).

### Rocky Linux 9

```bash
sudo dnf -y install dnf-plugins-core unzip git
sudo dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
sudo dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER        # then log out and back in
```

If Podman is installed, remove it first (`sudo dnf -y remove podman buildah`) – or use Podman
instead: `sudo dnf -y install podman podman-compose`; every `docker compose` below becomes
`podman compose`. SELinux stays on.

**Check:** `docker --version` and `docker compose version`.

**Clock:** the host must keep the right time (NTP) – 2FA codes fail otherwise. Check with `timedatectl`.

---

## 4. Firewall

| Host | Command |
|---|---|
| Rocky Linux (firewalld) | `sudo firewall-cmd --permanent --add-port=8443/tcp && sudo firewall-cmd --reload` |
| Debian with ufw | `sudo ufw allow 8443/tcp` |
| Debian without a firewall | Nothing to do |
| Proxmox firewall on the VM / CT | *VM or CT → Firewall → Add*: in, tcp, port 8443 |

---

## 5. The Proxmox API token

ControlYard signs in to Proxmox as **`icsranges@pve`** with a token called **`gui`**. `setup.sh`
can create it for you (step 6, answer **2**) – or create it now, as root **on any one node**:

```bash
pveum user add icsranges@pve --comment "ControlYard"
pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser
pveum user token add icsranges@pve gui --privsep 0
```

The last command shows the secret **once**. The whole token looks like
`icsranges@pve!gui=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`.

**Use this dedicated account, not a personal one.** A token made in the web UI has *Privilege
Separation* on by default; such a token only gets rights that **both** it and its user have, so
ControlYard may see no guests at all. `--privsep 0` gives the token exactly its user's rights.

**What the rights are for** – if you prefer a role of your own:

| Privilege | Needed for |
|---|---|
| `VM.Audit` | Seeing guests at all – without it nothing shows |
| `Sys.Audit` | Nodes, cluster status, bridges |
| `VM.PowerMgmt` | Start, shut down, power off |
| `VM.Snapshot.Rollback` | Restoring snapshots – End class, Start class (admins) |
| `VM.Snapshot` | Taking and deleting snapshots |
| `VM.Config.Network` + `SDN.Use` (on `/sdn/zones`) | Network settings; activating a mirror add-on turns its sensor NIC's firewall off |
| `VM.Config.Disk` + `Datastore.AllocateSpace` | Moving / converting disks, a new EFI disk, snapshots with memory |
| `Datastore.Audit` | Storage and disks |
| `VM.Migrate` | Migration |
| `VM.GuestAgent.Audit` (Proxmox 9) / `VM.Monitor` (Proxmox 8) | IP addresses in add-ons |

```bash
pveum role add ICSRanges --privs "VM.Audit,Sys.Audit,VM.PowerMgmt,VM.Snapshot,VM.Snapshot.Rollback,VM.Config.Network,VM.Config.Disk,VM.Migrate,VM.GuestAgent.Audit,Datastore.Audit,Datastore.AllocateSpace,SDN.Use"
pveum acl modify / --users icsranges@pve --roles ICSRanges
pveum acl modify /sdn/zones --users icsranges@pve --roles ICSRanges
```

---

## 6. Install ControlYard

**1. Copy the zip to the host as a file** – `scp` or WinSCP (binary), never copy and paste its contents:

```bash
scp controlyard.zip kaz@<host>:/tmp/
```

For an LXC container you can also push it from its node: `pct push 105 controlyard.zip /tmp/controlyard.zip`.

**2. Check that it arrived whole** – the checksum must match the one given with the zip:

```bash
sha256sum /tmp/controlyard.zip
```

**3. Unpack it in `/opt`** (it makes `/opt/controlyard`):

```bash
cd /opt
sudo unzip -o /tmp/controlyard.zip
sudo chown -R $USER: /opt/controlyard
cd /opt/controlyard
```

**4. Run the setup:**

```bash
./setup.sh
```

It asks – Enter keeps the value in brackets:

1. **Proxmox addresses** – every node, separated by spaces, e.g. `192.168.77.77 192.168.77.78`.
2. **API token** – *1* paste it, *2* create `icsranges@pve!gui` on a node over SSH, *3* keep the
   current one. It is tested against every node at once.
3. **This host's IP** – the fixed address of the VM / container.
4. **Port** – 8443.
5. **Build and start it now?** – **Y**. The first build takes a few minutes and needs internet.

It ends with the address to open. Check the start-up messages – the last ones should say
**ControlYard 4.1.0 on https://…** and **Proxmox API OK**:

```bash
sudo docker compose logs controlyard | grep -E 'ControlYard [0-9]|Proxmox API' | tail -2
```

The folder can be renamed later – the container (`controlyard`) and its data volume
(`controlyard_controlyard-data`) keep their names. Never run `entrypoint.sh` yourself; it runs
inside the container.

---

## 7. First sign-in and users

1. Open `https://<host>:8443` and accept the certificate warning once (each kit makes its own
   certificate).
2. The first visit asks for the **first admin** – a name and a password of at least 10 characters.
3. Add everyone else under **Users → Add a user**: role, courses, and a generated password shown once.

Lost the admin password: `sudo docker compose exec controlyard pvr users passwd <name>`.

---

## 8. The node key – port mirroring, IGMP snooping, host add-ons, EFI keys

The Proxmox API can't change Open vSwitch, set IGMP snooping on a Linux bridge or enroll EFI keys,
so ControlYard uses one SSH key for these that may run **only** `ovs-vsctl …`,
`ics-mcsnoop <bridge> 0|1|show` (that bridge's `multicast_snooping`, nothing else) and
`qm enroll-efi-keys <vmid>` – with checked arguments, never handed to a shell – and only from the
ControlYard host's IP. Put it on a node once – the cluster shares it:

```bash
cd /opt/controlyard
./setup.sh node-key 192.168.77.77        # any node's IP; asks for its root password once
```

Or as admin in ControlYard: **Settings → Node key → Copy** (or **Download**), and run the lines as
root on one node. They replace the older ControlYard key line.

**After updating from a version before 3.1.4, put the key on a node again** – the newer line also
allows `ics-mcsnoop`. Until then, `mcsnoop` on a Linux bridge says *the node key on … is from before
ICS Ranges 3.1.4*.

| Uses the node key | For |
|---|---|
| Mirror add-ons (Add-ons → Port mirroring) | Creating and removing the Open vSwitch mirrors, reading their packet counts |
| Host add-ons | `ovs-vsctl …` and `mcsnoop <bridge> on\|off\|show` (IGMP snooping on Linux or Open vSwitch bridges) |
| EFI keys | *Network, disks & more… → EFI keys → Enroll the keys*, and `qm enroll-efi-keys` in add-ons |

For port mirroring, the sensors' bridge (e.g. `vmbr2`) must be an **Open vSwitch** bridge:
*node → System → Network → Create → OVS Bridge* (if missing: `apt-get install -y openvswitch-switch`
on the node). Then in the course: **Add-ons → Port mirroring → New mirror…** – each sensor becomes a
button instructors switch on and off.

---

## 8a. TrueNAS – for the Health page

ControlYard can read the health of your TrueNAS – pools, alerts, version – for the **Health** page
and *Ready for class?*. It reads only; a **read-only** API key is all it needs:

1. In TrueNAS: **Credentials → Users → Add** – a user, e.g. `icsranges`, without password login,
   role **Read-only Administrator**.
2. **API key:** the user menu (top right) → **My API Keys**, or the user's **API Keys** → **Add** –
   copy the key, it is shown only once.
3. In ControlYard: **Settings → TrueNAS** – address `https://<truenas>` (HTTPS: TrueNAS revokes keys
   sent over HTTP), the user, the key; untick *Check its certificate* for TrueNAS' own self-signed
   certificate. **Save**, **Test**.

ControlYard talks to TrueNAS 25.04 and later through its WebSocket API (JSON-RPC – the REST API is
deprecated there and removed in TrueNAS 26), and to older TrueNAS through REST. The ControlYard host
needs to reach TrueNAS on port 443.

---

## 8b. One GitHub repository – versions and each kit's content

One repository can hold everything, each on its **own branch** – no branch name is fixed anywhere,
and more branches can be added later:

| Branch (your names) | Holds | Written by |
|---|---|---|
| e.g. `main` | The program's code; its **tags** and **Releases** (zip + checksum) are the versions | `release.sh` |
| e.g. `kit-config` (one per kit if you like: `kit-lab1`, `kit-lab2` …) | A kit's content: course map, guides, add-ons, mirror add-ons, settings | **Save & share** |

1. On GitHub: **New repository**, **private** (add-ons and course maps describe your lab).
2. Two **fine-grained tokens** (*Settings → Developer settings → Fine-grained tokens*), each for
   **this repository only**:
   - **read** – *Contents: Read-only* – for **Software updates** on the kits;
   - **write** – *Contents: Read and write* – for `release.sh` and **Save & share**.
3. Versions: `./release.sh setup` – address `https://github.com/<you>/<repo>`, your user name, the
   write token, and the branch for the code (the repository's default is suggested) – section 10.
4. Updates on each kit: `sudo ./setup.sh updater` – the same address and the **read** token – section 9.
5. Content of each kit: **Save & share** – the same address with `.git`, the write token, and the
   kit's **own branch**, e.g. `kit-config`; it is made by the first save.

Save & share **refuses a branch that holds the program's code** (any branch with `app/server.py`),
so a kit's content can never end up on the code branch. **Never stored on GitHub:** users and
passwords, 2FA, the node key, the Proxmox and TrueNAS tokens – Save & share leaves them out. The
**kit backup** (everything, encrypted with its password) is better kept elsewhere.

Moving from Gitea keeps the history and tags:

```bash
git clone --mirror http://<gitea>/<owner>/<repo>.git && cd <repo>.git
git push --mirror https://github.com/<you>/<repo>.git
./release.sh setup          # the GitHub address; then, for the versions kits should see:
./release.sh publish v3.5.0 # makes the release and attaches the files (once per version)
```

---

## 9. Software updates from the web page

Admins install newer – or older – versions under **Software updates**, from the releases of a
GitHub or Gitea repository (section 8b). Turn it on **once per kit** – one command sets up both
the host and the web page:

```bash
cd /opt/controlyard
sudo ./setup.sh updater
```

It asks for the repository address, your user name and a **read-only** token (GitHub: a
fine-grained token for that repository, *Contents: Read-only*; Gitea: *Settings → Applications*,
*repository: Read*). A private GitHub repository works: the host downloads through GitHub's API with
the token. Without questions:

```bash
sudo ./setup.sh updater --repo https://github.com/<you>/<repo> --user <you> --token-file token.txt --yes
sudo ./setup.sh updater status       # what it allows, the releases, the last update
sudo ./setup.sh updater remove       # off again
```

**How it works:** the web page can only **ask** for a version – it has no access to Docker, on
purpose. A small updater on the host (a systemd unit) then downloads that release itself, only from
the repository allowed on the host, checks the checksum, that it is an ControlYard zip and its
version, installs it, and goes back to the previous version if the new one doesn't start.

**Updating:** **Software updates → Versions → Check again → Update to v…** – about a minute.
Everyone stays signed in; pages open elsewhere show a bar and reload at their next click.

**Kept versions:** the updater keeps the last 5 installed versions in `updates/cache/<version>`
(`./setup.sh update <zip>` adds its version too). Going back to one of them needs no download, also
offline – the checksum is checked again before installing.

---

## 10. Publishing a new version

Kits can only install **releases**: a tag like `v3.1.4` with **both** `controlyard.zip` and
`controlyard.zip.sha256` attached.

### With release.sh (recommended)

On the machine you publish from (e.g. the ControlYard host), once:

```bash
/opt/controlyard/release.sh setup
```

It asks for the repository, your user name and a token that may **write** to it
(*repository: Read and Write*), and keeps them in `~/.config/controlyard/release.conf`.

Then for every version:

```bash
sha256sum /tmp/controlyard.zip                     # must match the checksum given with it
/opt/controlyard/release.sh /tmp/controlyard.zip    # adds it to the repository (commit + tag on its branch), then asks:
                                                  # "Publish v3.1.4 as a release now?"  -> y
```

| Command | Does |
|---|---|
| `release.sh <zip>` | A zip you were sent: commit, tag, push – then asks whether to publish |
| `release.sh` | A version from your own changes in `~/controlyard-src` – suggests the next number |
| `release.sh publish v3.1.4` | Publish later – or add what a release is missing (e.g. the `.sha256`) |
| `release.sh list` | Every version and whether kits can install it |
| `release.sh notes` | Release notes from `CHANGELOG.md` for releases that have none (e.g. older ones) |

When publishing, `release.sh` takes the release notes from the version's section in `CHANGELOG.md`
(it shows them; Enter publishes them, or type one line instead). Releases published earlier without
notes get theirs with `release.sh notes`.

The release files are also kept in `~/controlyard-releases/<version>/`, for USB sticks.

### In the GitHub or Gitea web page

1. Make the checksum file next to the zip – called exactly `controlyard.zip.sha256`:

| Computer | Command |
|---|---|
| Linux | `sha256sum controlyard.zip > controlyard.zip.sha256` |
| macOS | `shasum -a 256 controlyard.zip > controlyard.zip.sha256` |
| Windows (PowerShell) | `$h=(Get-FileHash .\controlyard.zip -Algorithm SHA256).Hash.ToLower(); "$h  controlyard.zip" \| Out-File -Encoding ascii -NoNewline controlyard.zip.sha256` |

2. **Releases → New Release** (GitHub: *Draft a new release*) → tag `v3.1.4` (target: the code's
   branch) → title `ControlYard 4.0.0` →
   attach **both** files (check the names – no `(1)`) → leave *draft* and *pre-release* unticked →
   **Publish Release**.

A release with a problem: **Edit → Mark as draft** hides it from the kits.

---

## 11. Updating by hand and going back

Without the web page (e.g. from a USB stick, or a kit without the updater):

```bash
cd /tmp && sha256sum -c controlyard.zip.sha256          # must say: controlyard.zip: OK
cd /opt/controlyard && sudo ./setup.sh update /tmp/controlyard.zip
```

It puts the new files in place (your `.env` stays), rebuilds and restarts. Users, courses, add-ons,
guides, settings and backups are in the data volume and stay. Works without internet – Docker
reuses the packages it downloaded before. Going back: the same with the older version's zip.

---

## 11a. Kit backup – rebuild or swap a kit

One encrypted file holds the whole kit: users (with passwords and 2FA), roles, settings, the course
map, mixed courses, mirrors, groups, themes, class guides, add-ons, the history, the activity log,
the HTTPS certificate, the node key and the Proxmox settings (addresses and token).

**Make one** – on the kit (or in the page: *Backups → Kit backup → Download kit file*):

```bash
cd /opt/controlyard
./setup.sh export                      # asks for a password, saves controlyard-kit-<date>.icskit
```

**Put it on a new host** – install ControlYard there (sections 2–4 and 6, steps 1–3), then instead of
`./setup.sh`:

```bash
cp .env.example .env                   # or run ./setup.sh once
./setup.sh import controlyard-kit-20261112-1653.icskit
```

It asks for the password, puts everything back, and offers to use the kit's Proxmox settings on this
host (answer **y** for a replacement kit). The state before is kept as a kit file in the backups.
Everyone signs in again with the kit's users. Afterwards, if the new host has another IP address,
put the node key on a node again: `./setup.sh node-key <node IP>`.

Keep kit files and their passwords apart, like any backup that contains passwords and keys.

---

---

## 11b. Renaming a kit from before ControlYard

A kit installed as ICS Ranges keeps working with its old names – folder `/opt/ics-ranges`, container
`ics-ranges`, data volume `ics-ranges_ics-ranges-data`, host services `ics-ranges-updater`. Once it
runs **4.1.0 or newer**, one command gives everything the new name:

```bash
cd /opt/ics-ranges && sudo ./setup.sh rename
```

| Step | What happens |
|---|---|
| Checks | The old data is there, nothing in the way, enough free space for a copy and a backup |
| 1 | A **backup of the data** as a file next to the folder (`controlyard-rename-backup-<date>.tgz`, root only) |
| 2–3 | The old container stops; the new one (`controlyard`) is built, not started yet |
| 4 | The data is **copied** into the new volume `controlyard_controlyard-data` and compared (files and size) – the old volume is **not touched** |
| 5 | The folder moves to `/opt/controlyard` – `/opt/ics-ranges` stays as a **link**, so old paths, bookmarks and scripts keep working – and the host services become `controlyard-updater` |
| 6 | ControlYard starts and is checked: the new version answers, **with the same users** |

ControlYard is off for about a minute; signed-in users stay signed in. **If any step fails, everything
is put back** – the old folder, container, host services and data, as they were – and it says which
step failed. Run it again any time; on a renamed kit it says *nothing to do*.

**Afterwards:**
- Commands name the new container: `docker compose logs controlyard`, `docker compose exec controlyard pvr …`.
- Add-ons keep working: the commands are in `/usr/local/lib/controlyard` (the old path still works), and
  add-ons get `CY_GUESTS_FILE`, `CY_SCOPE`, `CY_NODE`, `CY_KIND` – and the old `ICS_…` names too.
- Software updates works as before. Versions **before 4.1.0 can't be installed** on a renamed kit any
  more – they would start the old container with the data from before the rename – the page says so.
- Kit backup files are marked ControlYard; ones made before can still be imported.
- `release.sh` keeps its settings in `~/.config/controlyard/` (moved there by itself). Every release it
  publishes carries **both** `controlyard.zip` and `ics-ranges.zip`, so kits not renamed yet – and those
  still on a version before 4.1 – keep updating.

**Tidy up, once you are happy** – removes the old data volume and image (the backup file stays):

```bash
cd /opt/controlyard && sudo ./setup.sh rename --cleanup
```

The Proxmox user of the API token (e.g. `icsranges@pve`) keeps its name – renaming it would need a new
token, so it is left alone.

---

## 12. Testing a kit

```bash
cd /opt/controlyard
./gui-test.sh 613 --check     # checks only - nothing is started, stopped or snapshotted
./gui-test.sh                 # also real actions - only on guests tagged fake-range
```

It checks the container, HTTPS, sign-in, roles, 2FA, guides, add-ons, backups, bad requests, the
readiness check and kit files, and – on test guests only – Start class, power, End class and
snapshots. It ends with `N passed, 0 failed`, makes its own test users and removes them again.
Full output: `/tmp/gui-test.out`.

**Add-on test** – everything about add-ons: the commands (`qm`/`pct list` like on a node, status,
config, `pvesh`, `pvesm`, `qm wait`), the course rules (other courses' guests refused – also clones
and fixed VMIDs), roles (instructors run their course's buttons only), scripts (Windows line ends,
long output, exit codes), host add-ons (`ovs-vsctl`, `mcsnoop show` – skipped without a node key)
and mirror add-on definitions. Safe on a real kit: it only reads guests, never switches a mirror on,
and removes its test add-ons and test instructor again. Needs only Python:

```bash
cd /opt/controlyard
./tests/addon-test.sh https://127.0.0.1:8443 kaz --course 613      # asks for the password
```

It ends with `N passed, 0 failed`; full output in `/tmp/addon-test.out`.

**Browser test** – opens every page and window in a real browser and checks that each shows what it
should (no script errors, no `[object …]`, `undefined` or `NaN`). It only opens and closes windows –
nothing is started, stopped or changed. It can run on the ControlYard host or any Linux machine:

```bash
sudo apt-get install -y python3-venv chromium          # once (Debian 12 / 13)
cd /opt/controlyard
./tests/ui-test.sh https://127.0.0.1:8443 kaz          # asks for the password
```

The first run sets up Playwright in its own Python environment (`~/.cache/controlyard-ui-test`) –
the system's Python stays untouched, so Debian's *externally-managed-environment* error doesn't
apply. It uses the system's Chromium.

Options: `--course 613` (one course), `--headed` (watch it, needs a desktop), `--shots DIR` (a
picture of every window). Pictures of problems go to `/tmp/ui-test-fail-*.png`.

---

## 13. Commands and names

**On the host, in `/opt/controlyard`:**

| Command | Does |
|---|---|
| `./setup.sh` | Set up step by step |
| `./setup.sh token` · `./setup.sh test` | Change / test the Proxmox token |
| `./setup.sh node-key <node IP>` | Put the node key on a node |
| `sudo ./setup.sh updater` · `status` · `remove` | Software updates from the web page |
| `sudo ./setup.sh update <zip>` | Install a version by hand |
| `./setup.sh export [FILE]` · `./setup.sh import FILE` | The whole kit in one encrypted file, and back (section 12a) |
| `release.sh …` | Publish versions (section 10) |
| `sudo docker compose logs controlyard` | The log |
| `sudo docker compose exec controlyard pvr help` | The command line inside (users, courses, run, update …) |

**Names:**

| What | Name |
|---|---|
| Folder | `/opt/controlyard` (any name works) |
| Container / image | `controlyard` / `controlyard:latest` (`ics-ranges` on kits not renamed yet) |
| Data volume | `controlyard_controlyard-data` (`ics-ranges_ics-ranges-data` on kits not renamed yet) |
| Settings | `/opt/controlyard/.env` (Proxmox addresses, token, port) – never put it in Git |
| Proxmox user and token | `icsranges@pve!gui` |
| Updater | `controlyard-updater.path` / `.service` (systemd), allowed repository in `updater.conf` |
| Release settings | `~/.config/controlyard/release.conf` |

---

## 14. Troubleshooting

| You see | Fix |
|---|---|
| Courses are empty / *There are no guests* | The token sees no guests: `curl -sk -H "Authorization: PVEAPIToken=<token>" https://<node>:8006/api2/json/cluster/resources?type=vm` – `{"data":[]}` means no rights. Use `icsranges@pve` with `--privsep 0` (section 5) |
| Red box *Proxmox isn't answering* | The nodes are off or unreachable. ControlYard shows the last known guests and the admin pages work; it reconnects by itself every 15 seconds |
| LXC: Docker fails to start | Turn on *nesting* and *keyctl* for the CT and reboot it |
| `permission denied … docker.sock` | `sudo`, or `sudo usermod -aG docker $USER` and log in again |
| `'compose' is not a docker command` | Install `docker-compose-plugin` (Debian 13 packages: `docker-compose-v2`) |
| `End-of-central-directory signature not found` | The zip is incomplete – copy it again and compare the checksum |
| `can't open file '/app/server.py'` | You ran `entrypoint.sh` by hand – use `./setup.sh` |
| `The container name "/controlyard" is already in use` | `sudo docker rm -f controlyard`, then `sudo docker compose up -d` (the data is in the volume) |
| The page doesn't open from another machine | Open port 8443 (section 4); check the fixed IP and bridge |
| *HTTP 403 … SDN.Use* | `pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser` |
| Software updates: a version is missing in the list | It isn't published – `release.sh publish v…`, or it lacks a file (the list says which) |
| Software updates stays on *Waiting for the host's updater* | `sudo ./setup.sh updater status`, then `sudo ./setup.sh updater`. On kits that had 2.5.0 / 2.5.1: `sudo chmod 755 *.sh && sudo systemctl reset-failed controlyard-updater.service controlyard-updater.path && sudo systemctl start controlyard-updater.path` |
| An update stops with *couldn't download* or HTTP 404 | Kits older than 2.5.0: install a newer version by hand once (section 11). Otherwise the token can't read the repository |
| *the host only allows updates from …* | Run `sudo ./setup.sh updater` again for the new repository |
| *the key line … only allows ovs-vsctl* | Run `./setup.sh node-key <node IP>` again |
| The page looks old after an update | Versions from 2.7.3 reload by themselves; older ones once with **Ctrl + Shift + R** |
| *v… is already in GitHub / Gitea* from `release.sh`, but there is no such release | Look at the repository's **Tags**: if the tag is there, `release.sh publish v…`. If not, it was a leftover in `~/controlyard-src` – `release.sh` from 3.0.4 clears it by itself; older ones: `git -C ~/controlyard-src tag -d v…`, then run it again |
| 2FA codes are refused | The host's clock is off – check NTP with `timedatectl` |
| `error: externally-managed-environment` (pip, browser test) | Use `./tests/ui-test.sh` – it installs Playwright in its own environment (needs `python3-venv`) |

The log: `sudo docker compose logs controlyard`. Everything that ran, with names: **Activity** in ControlYard.
