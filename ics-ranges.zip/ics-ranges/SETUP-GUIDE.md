# ICS Ranges – Setup guide

For ICS Ranges 3.0.1. How to install ICS Ranges on a Proxmox VM or LXC container, connect it to
Proxmox, keep it up to date, and publish new versions. For using it, see [USER-GUIDE.md](USER-GUIDE.md).

- [1. What you need](#1-what-you-need)
- [2. Create the host – VM or LXC container](#2-create-the-host--vm-or-lxc-container)
- [3. Install Docker](#3-install-docker)
- [4. Firewall](#4-firewall)
- [5. The Proxmox API token](#5-the-proxmox-api-token)
- [6. Install ICS Ranges](#6-install-ics-ranges)
- [7. First sign-in and users](#7-first-sign-in-and-users)
- [8. The node key – port mirroring and EFI keys](#8-the-node-key--port-mirroring-and-efi-keys)
- [9. Software updates from the web page](#9-software-updates-from-the-web-page)
- [10. Publishing a new version](#10-publishing-a-new-version)
- [11. Updating by hand and going back](#11-updating-by-hand-and-going-back)
- [12. Moving from pve-range-gui](#12-moving-from-pve-range-gui)
- [12a. Kit backup – rebuild or swap a kit](#12a-kit-backup--rebuild-or-swap-a-kit)
- [13. Testing a kit](#13-testing-a-kit)
- [14. Commands and names](#14-commands-and-names)
- [15. Troubleshooting](#15-troubleshooting)

---

## 1. What you need

| Item | Details |
|---|---|
| A host | A Proxmox **VM** or **LXC container** with Debian 12 / 13 or Rocky Linux 9 – 2 CPU cores, 2 GB RAM, 8–16 GB disk |
| Network | The host reaches every Proxmox node on port **8006** (API), and on **22** for the node key. People reach the host on port **8443** |
| Proxmox | Root on one node once – for the API token and the node key (or someone who has it) |
| The package | `ics-ranges.zip` and its SHA-256 checksum |
| Optional | A Gitea (or GitHub) for software updates and for keeping add-ons, guides and settings |

Nothing is installed on the Proxmox nodes – ICS Ranges talks to them through the Proxmox API.

**VM or LXC container?**

| | VM | LXC container |
|---|---|---|
| Setup | Install the OS from an ISO | Quick, from a Proxmox template |
| Resources | A little more RAM and disk | Very light |
| Docker inside | Works as on any server | Needs *nesting* and *keyctl* |

Both work the same once Docker runs.

---

## 2. Create the host – VM or LXC container

### Option A – a VM

1. Upload the installer ISO to a node: *node → local → ISO Images → Download from URL* (Debian netinst
   or Rocky Linux 9 minimal).
2. **Create VM**: a VMID **below 100000** (it then shows under *Management*), name `ics-ranges`,
   the ISO, *Qemu Agent* ticked, 16 GB disk, 2 cores (type *host*), 2048 MB, the bridge of the
   nodes' management network.
3. Install the OS – Debian: no desktop, tick *SSH server* and *standard system utilities*;
   Rocky: *Minimal Install*.
4. Give it a **fixed IP address** – the nodes only accept the node key from this address.
5. Add the guest agent:

```bash
sudo apt-get install -y qemu-guest-agent && sudo systemctl start qemu-guest-agent   # Debian
sudo dnf -y install qemu-guest-agent && sudo systemctl start qemu-guest-agent       # Rocky
```

### Option B – an LXC container

1. Download a template: *node → local → CT Templates → Templates* → **debian-12-standard**
   (or 13) or **rockylinux-9-default**.
2. **Create CT**: a CT ID **below 100000**, hostname `ics-ranges`, *Unprivileged container* and
   *Nesting* ticked, 8–16 GB disk, 2 cores, 2048 MB, a **fixed IPv4 address** and gateway.
3. Before starting it, turn on what Docker needs – on the node (example CT 105):

```bash
pct set 105 --features nesting=1,keyctl=1
```

4. Start it and make a normal user with sudo:

```bash
apt-get update && apt-get install -y sudo && adduser kaz && usermod -aG sudo kaz      # Debian
dnf -y install sudo && adduser kaz && passwd kaz && usermod -aG wheel kaz             # Rocky
```

---

## 3. Install Docker

### Debian 12 / 13

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl unzip git
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER        # then log out and back in
```

Without access to download.docker.com: `sudo apt-get install -y docker.io docker-compose unzip`
(on Debian 13 the compose package may be called `docker-compose-v2`).

### Rocky Linux 9

```bash
sudo dnf -y install dnf-plugins-core unzip git
sudo dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
sudo dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER        # then log out and back in
```

If Podman is installed, remove it first (`sudo dnf -y remove podman buildah`) – or use Podman
instead: `sudo dnf -y install podman podman-compose`; every `docker compose` below becomes
`podman compose`. SELinux stays on.

**Check:** `docker --version` and `docker compose version`.

**Clock:** the host must keep the right time (NTP) – 2FA codes fail otherwise. Check with `timedatectl`.

---

## 4. Firewall

| Host | Command |
|---|---|
| Rocky Linux (firewalld) | `sudo firewall-cmd --permanent --add-port=8443/tcp && sudo firewall-cmd --reload` |
| Debian with ufw | `sudo ufw allow 8443/tcp` |
| Debian without a firewall | Nothing to do |
| Proxmox firewall on the VM / CT | *VM or CT → Firewall → Add*: in, tcp, port 8443 |

---

## 5. The Proxmox API token

ICS Ranges signs in to Proxmox as **`icsranges@pve`** with a token called **`gui`**. `setup.sh`
can create it for you (step 6, answer **2**) – or create it now, as root **on any one node**:

```bash
pveum user add icsranges@pve --comment "ICS Ranges"
pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser
pveum user token add icsranges@pve gui --privsep 0
```

The last command shows the secret **once**. The whole token looks like
`icsranges@pve!gui=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`.

**Use this dedicated account, not a personal one.** A token made in the web UI has *Privilege
Separation* on by default; such a token only gets rights that **both** it and its user have, so
ICS Ranges may see no guests at all. `--privsep 0` gives the token exactly its user's rights.

**What the rights are for** – if you prefer a role of your own:

| Privilege | Needed for |
|---|---|
| `VM.Audit` | Seeing guests at all – without it nothing shows |
| `Sys.Audit` | Nodes, cluster status, bridges |
| `VM.PowerMgmt` | Start, shut down, power off |
| `VM.Snapshot.Rollback` | Restoring snapshots – End class, Start class (admins) |
| `VM.Snapshot` | Taking and deleting snapshots |
| `VM.Config.Network` + `SDN.Use` (on `/sdn/zones`) | Network settings; activating a mirror add-on turns its sensor NIC's firewall off |
| `VM.Config.Disk` + `Datastore.AllocateSpace` | Moving / converting disks, a new EFI disk, snapshots with memory |
| `Datastore.Audit` | Storage and disks |
| `VM.Migrate` | Migration |
| `VM.GuestAgent.Audit` (Proxmox 9) / `VM.Monitor` (Proxmox 8) | IP addresses in add-ons |

```bash
pveum role add ICSRanges --privs "VM.Audit,Sys.Audit,VM.PowerMgmt,VM.Snapshot,VM.Snapshot.Rollback,VM.Config.Network,VM.Config.Disk,VM.Migrate,VM.GuestAgent.Audit,Datastore.Audit,Datastore.AllocateSpace,SDN.Use"
pveum acl modify / --users icsranges@pve --roles ICSRanges
pveum acl modify /sdn/zones --users icsranges@pve --roles ICSRanges
```

---

## 6. Install ICS Ranges

**1. Copy the zip to the host as a file** – `scp` or WinSCP (binary), never copy and paste its contents:

```bash
scp ics-ranges.zip kaz@<host>:/tmp/
```

For an LXC container you can also push it from its node: `pct push 105 ics-ranges.zip /tmp/ics-ranges.zip`.

**2. Check that it arrived whole** – the checksum must match the one given with the zip:

```bash
sha256sum /tmp/ics-ranges.zip
```

**3. Unpack it in `/opt`** (it makes `/opt/ics-ranges`):

```bash
cd /opt
sudo unzip -o /tmp/ics-ranges.zip
sudo chown -R $USER: /opt/ics-ranges
cd /opt/ics-ranges
```

**4. Run the setup:**

```bash
./setup.sh
```

It asks – Enter keeps the value in brackets:

1. **Proxmox addresses** – every node, separated by spaces, e.g. `192.168.77.77 192.168.77.78`.
2. **API token** – *1* paste it, *2* create `icsranges@pve!gui` on a node over SSH, *3* keep the
   current one. It is tested against every node at once.
3. **This host's IP** – the fixed address of the VM / container.
4. **Port** – 8443.
5. **Build and start it now?** – **Y**. The first build takes a few minutes and needs internet.

It ends with the address to open. Check the start-up messages – the last ones should say
**ICS Ranges 2.7.5 on https://…** and **Proxmox API OK**:

```bash
sudo docker compose logs ics-ranges | grep -E 'ICS Ranges [0-9]|Proxmox API' | tail -2
```

The folder can be renamed later – the container (`ics-ranges`) and its data volume
(`ics-ranges_ics-ranges-data`) keep their names. Never run `entrypoint.sh` yourself; it runs
inside the container.

---

## 7. First sign-in and users

1. Open `https://<host>:8443` and accept the certificate warning once (each kit makes its own
   certificate).
2. The first visit asks for the **first admin** – a name and a password of at least 10 characters.
3. Add everyone else under **Users → Add a user**: role, courses, and a generated password shown once.

Lost the admin password: `sudo docker compose exec ics-ranges pvr users passwd <name>`.

---

## 8. The node key – port mirroring and EFI keys

The Proxmox API can't change Open vSwitch or enroll EFI keys, so ICS Ranges uses one SSH key for
these that may run **only** `ovs-vsctl …` and `qm enroll-efi-keys <vmid>`, and only from the
host's IP. Put it on a node once – the cluster shares it:

```bash
cd /opt/ics-ranges
./setup.sh node-key 192.168.77.77        # any node's IP; asks for its root password once
```

Or as admin in ICS Ranges: **Settings → Node key → Copy** (or **Download**), and run the lines as
root on one node.

For port mirroring, the sensors' bridge (e.g. `vmbr2`) must be an **Open vSwitch** bridge:
*node → System → Network → Create → OVS Bridge* (if missing: `apt-get install -y openvswitch-switch`
on the node). Then in the course: **Add-ons → Port mirroring → New mirror…** – each sensor becomes a
button instructors switch on and off. Host add-ons use the node key too: their `ovs-vsctl` runs on the host.

---

## 9. Software updates from the web page

Admins install newer – or older – versions under **Software updates**, from the releases of a
Gitea repository (e.g. `ics-ranges-app`). Turn it on **once per kit** – one command sets up both
the host and the web page:

```bash
cd /opt/ics-ranges
sudo ./setup.sh updater
```

It asks for the repository address, your Gitea user name and a **read-only** token
(Gitea: *Settings → Applications → Generate New Token*, *repository: Read*). Without questions:

```bash
sudo ./setup.sh updater --repo http://192.168.77.93:3000/kaz/ics-ranges-app --user kaz --token-file token.txt --yes
sudo ./setup.sh updater status       # what it allows, the releases, the last update
sudo ./setup.sh updater remove       # off again
```

**How it works:** the web page can only **ask** for a version – it has no access to Docker, on
purpose. A small updater on the host (a systemd unit) then downloads that release itself, only from
the repository allowed on the host, checks the checksum, that it is an ICS Ranges zip and its
version, installs it, and goes back to the previous version if the new one doesn't start.

**Updating:** **Software updates → Versions → Check again → Update to v…** – about a minute.
Everyone stays signed in; pages open elsewhere show a bar and reload at their next click.

**Kept versions:** the updater keeps the last 5 installed versions in `updates/cache/<version>`
(`./setup.sh update <zip>` adds its version too). Going back to one of them needs no download, also
offline – the checksum is checked again before installing.

---

## 10. Publishing a new version

Kits can only install **releases**: a tag like `v2.7.5` with **both** `ics-ranges.zip` and
`ics-ranges.zip.sha256` attached.

### With release.sh (recommended)

On the machine you publish from (e.g. the ICS Ranges host), once:

```bash
/opt/ics-ranges/release.sh setup
```

It asks for the repository, your user name and a token that may **write** to it
(*repository: Read and Write*), and keeps them in `~/.config/ics-ranges/release.conf`.

Then for every version:

```bash
sha256sum /tmp/ics-ranges.zip                     # must match the checksum given with it
/opt/ics-ranges/release.sh /tmp/ics-ranges.zip    # adds it to Gitea (commit + tag), then asks:
                                                  # "Publish v2.7.5 as a release now?"  -> y
```

| Command | Does |
|---|---|
| `release.sh <zip>` | A zip you were sent: commit, tag, push – then asks whether to publish |
| `release.sh` | A version from your own changes in `~/ics-ranges-src` – suggests the next number |
| `release.sh publish v2.7.5` | Publish later – or add what a release is missing (e.g. the `.sha256`) |
| `release.sh list` | Every version and whether kits can install it |
| `release.sh notes` | Release notes from `CHANGELOG.md` for releases that have none (e.g. older ones) |

When publishing, `release.sh` takes the release notes from the version's section in `CHANGELOG.md`
(it shows them; Enter publishes them, or type one line instead). Releases published earlier without
notes get theirs with `release.sh notes`.

The release files are also kept in `~/ics-ranges-releases/<version>/`, for USB sticks.

### In the Gitea web page

1. Make the checksum file next to the zip – called exactly `ics-ranges.zip.sha256`:

| Computer | Command |
|---|---|
| Linux | `sha256sum ics-ranges.zip > ics-ranges.zip.sha256` |
| macOS | `shasum -a 256 ics-ranges.zip > ics-ranges.zip.sha256` |
| Windows (PowerShell) | `$h=(Get-FileHash .\ics-ranges.zip -Algorithm SHA256).Hash.ToLower(); "$h  ics-ranges.zip" \| Out-File -Encoding ascii -NoNewline ics-ranges.zip.sha256` |

2. **Releases → New Release** → tag `v2.7.5` (Target `main`) → title `ICS Ranges 2.7.5` →
   attach **both** files (check the names – no `(1)`) → leave *draft* and *pre-release* unticked →
   **Publish Release**.

A release with a problem: **Edit → Mark as draft** hides it from the kits.

---

## 11. Updating by hand and going back

Without the web page (e.g. from a USB stick, or a kit without the updater):

```bash
cd /tmp && sha256sum -c ics-ranges.zip.sha256          # must say: ics-ranges.zip: OK
cd /opt/ics-ranges && sudo ./setup.sh update /tmp/ics-ranges.zip
```

It puts the new files in place (your `.env` stays), rebuilds and restarts. Users, courses, add-ons,
guides, settings and backups are in the data volume and stay. Works without internet – Docker
reuses the packages it downloaded before. Going back: the same with the older version's zip.

---

## 12. Moving from pve-range-gui

Versions before 2.3.0 were called pve-range-gui (container `pve-range-gui`, volume
`pve-range-gui_pve-range-gui-data`):

```bash
cd /opt && sudo unzip -o /tmp/ics-ranges.zip
sudo cp /opt/pve-range-gui/.env /opt/ics-ranges/.env
sudo chown -R $USER: /opt/ics-ranges && cd /opt/ics-ranges
./setup.sh migrate
```

It copies users, roles, add-ons, guides, settings and history into the new volume, removes the old
container and starts `ics-ranges`. The old volume stays until you remove it:
`docker volume rm pve-range-gui_pve-range-gui-data`.

---

## 12a. Kit backup – rebuild or swap a kit

One encrypted file holds the whole kit: users (with passwords and 2FA), roles, settings, the course
map, mixed courses, mirrors, groups, themes, class guides, add-ons, the history, the activity log,
the HTTPS certificate, the node key and the Proxmox settings (addresses and token).

**Make one** – on the kit (or in the page: *Settings → Kit backup → Download kit file*):

```bash
cd /opt/ics-ranges
./setup.sh export                      # asks for a password, saves ics-ranges-kit-<date>.icskit
```

**Put it on a new host** – install ICS Ranges there (sections 2–4 and 6, steps 1–3), then instead of
`./setup.sh`:

```bash
cp .env.example .env                   # or run ./setup.sh once
./setup.sh import ics-ranges-kit-20261112-1653.icskit
```

It asks for the password, puts everything back, and offers to use the kit's Proxmox settings on this
host (answer **y** for a replacement kit). The state before is kept as a kit file in the backups.
Everyone signs in again with the kit's users. Afterwards, if the new host has another IP address,
put the node key on a node again: `./setup.sh node-key <node IP>`.

Keep kit files and their passwords apart, like any backup that contains passwords and keys.

---

## 13. Testing a kit

```bash
cd /opt/ics-ranges
./gui-test.sh 613 --check     # checks only - nothing is started, stopped or snapshotted
./gui-test.sh                 # also real actions - only on guests tagged fake-range
```

It checks the container, HTTPS, sign-in, roles, 2FA, guides, add-ons, backups, bad requests, the
readiness check and kit files, and – on test guests only – Start class, power, End class and
snapshots. It ends with `N passed, 0 failed`, makes its own test users and removes them again.
Full output: `/tmp/gui-test.out`.

**Browser test** – opens every page and window in a real browser and checks that each shows what it
should (no script errors, no `[object …]`, `undefined` or `NaN`). It only opens and closes windows –
nothing is started, stopped or changed. It can run on the ICS Ranges host or any Linux machine:

```bash
sudo apt-get install -y python3-venv chromium          # once (Debian 12 / 13)
cd /opt/ics-ranges
./tests/ui-test.sh https://127.0.0.1:8443 kaz          # asks for the password
```

The first run sets up Playwright in its own Python environment (`~/.cache/ics-ranges-ui-test`) –
the system's Python stays untouched, so Debian's *externally-managed-environment* error doesn't
apply. It uses the system's Chromium.

Options: `--course 613` (one course), `--headed` (watch it, needs a desktop), `--shots DIR` (a
picture of every window). Pictures of problems go to `/tmp/ui-test-fail-*.png`.

---

## 14. Commands and names

**On the host, in `/opt/ics-ranges`:**

| Command | Does |
|---|---|
| `./setup.sh` | Set up step by step |
| `./setup.sh token` · `./setup.sh test` | Change / test the Proxmox token |
| `./setup.sh node-key <node IP>` | Put the node key on a node |
| `sudo ./setup.sh updater` · `status` · `remove` | Software updates from the web page |
| `sudo ./setup.sh update <zip>` | Install a version by hand |
| `./setup.sh migrate` | Move from pve-range-gui |
| `./setup.sh export [FILE]` · `./setup.sh import FILE` | The whole kit in one encrypted file, and back (section 12a) |
| `release.sh …` | Publish versions (section 10) |
| `sudo docker compose logs ics-ranges` | The log |
| `sudo docker compose exec ics-ranges pvr help` | The command line inside (users, courses, run, update …) |

**Names:**

| What | Name |
|---|---|
| Folder | `/opt/ics-ranges` (any name works) |
| Container / image | `ics-ranges` / `ics-ranges:latest` |
| Data volume | `ics-ranges_ics-ranges-data` |
| Settings | `/opt/ics-ranges/.env` (Proxmox addresses, token, port) – never put it in Git |
| Proxmox user and token | `icsranges@pve!gui` |
| Updater | `ics-ranges-updater.path` / `.service` (systemd), allowed repository in `updater.conf` |
| Release settings | `~/.config/ics-ranges/release.conf` |

---

## 15. Troubleshooting

| You see | Fix |
|---|---|
| Courses are empty / *There are no guests* | The token sees no guests: `curl -sk -H "Authorization: PVEAPIToken=<token>" https://<node>:8006/api2/json/cluster/resources?type=vm` – `{"data":[]}` means no rights. Use `icsranges@pve` with `--privsep 0` (section 5) |
| Red box *Proxmox isn't answering* | The nodes are off or unreachable. ICS Ranges shows the last known guests and the admin pages work; it reconnects by itself every 15 seconds |
| LXC: Docker fails to start | Turn on *nesting* and *keyctl* for the CT and reboot it |
| `permission denied … docker.sock` | `sudo`, or `sudo usermod -aG docker $USER` and log in again |
| `'compose' is not a docker command` | Install `docker-compose-plugin` (Debian 13 packages: `docker-compose-v2`) |
| `End-of-central-directory signature not found` | The zip is incomplete – copy it again and compare the checksum |
| `can't open file '/app/server.py'` | You ran `entrypoint.sh` by hand – use `./setup.sh` |
| `The container name "/ics-ranges" is already in use` | `sudo docker rm -f ics-ranges`, then `sudo docker compose up -d` (the data is in the volume) |
| The page doesn't open from another machine | Open port 8443 (section 4); check the fixed IP and bridge |
| *HTTP 403 … SDN.Use* | `pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser` |
| Software updates: a version is missing in the list | It isn't published – `release.sh publish v…`, or it lacks a file (the list says which) |
| Software updates stays on *Waiting for the host's updater* | `sudo ./setup.sh updater status`, then `sudo ./setup.sh updater`. On kits that had 2.5.0 / 2.5.1: `sudo chmod 755 *.sh && sudo systemctl reset-failed ics-ranges-updater.service ics-ranges-updater.path && sudo systemctl start ics-ranges-updater.path` |
| An update stops with *couldn't download* or HTTP 404 | Kits older than 2.5.0: install a newer version by hand once (section 11). Otherwise the token can't read the repository |
| *the host only allows updates from …* | Run `sudo ./setup.sh updater` again for the new repository |
| *the key line … only allows ovs-vsctl* | Run `./setup.sh node-key <node IP>` again |
| The page looks old after an update | Versions from 2.7.3 reload by themselves; older ones once with **Ctrl + Shift + R** |
| 2FA codes are refused | The host's clock is off – check NTP with `timedatectl` |
| `error: externally-managed-environment` (pip, browser test) | Use `./tests/ui-test.sh` – it installs Playwright in its own environment (needs `python3-venv`) |

The log: `sudo docker compose logs ics-ranges`. Everything that ran, with names: **Activity** in ICS Ranges.
