# ICS Ranges

**ICS Ranges** is a web console for running the Proxmox training ranges – a real web application, separate
from pve-range's terminal menu. It talks to Proxmox only through the API with a token;
nothing is installed on the nodes.

Everything pve-range does, in a browser:

| Area | What you get |
|---|---|
| **Courses** | Found from the VMIDs (AABCDD: 50 = 612, 51 = 613, 52 = NetWars …; below 100000 = Management); one course at a time |
| **Class** | Start class / End class: restore the class snapshot, then power on or switch off. The class guide is shown first; every step is reviewed before it runs and shown live |
| **Guests** | Grouped by sub-group with live status lamps and snapshots. Select by ticking, VMID range, group, tag, name, node or a saved group |
| **Power and snapshots** | Power on / off (graceful or hard); take snapshots (leave running, shut down first or after, with memory, replace); restore, then leave them, power on or switch off; delete |
| **Sensors** | Mirror status with packet counts, Re-apply mirrors, Set up and remove mirrors |
| **Class guides** | Read, write, upload, import from GitHub / Gitea, download |
| **Add-ons** | Scripts per course or for all courses: run with live output on the selected guests, write, upload, import, download, move. `qm`, `pct`, `pvesh` work in them, so pve-range's add-ons run unchanged |
| **Build** | Network settings (bridge, VLAN, firewall, NIC model – MAC kept), move / convert disks, migrate to one node or spread over several (round-robin or blocks), EFI keys for Secure Boot |
| **Storage and disks** | Storages and every disk with its format and size |
| **Save & share** | Every change goes into a history and – once connected – to your Gitea / GitHub; Get latest; backups after every change, download and restore |
| **Users and roles** | admin, instructor, viewer – change what each may do, make new roles; courses per user; generated passwords; 2FA; lock-out after 5 wrong tries |
| **Settings** | Class snapshot, protected guests, shutdown timeout, steps at once, pause between starts, sensor names, backups to keep, saved groups, colour themes |
| **Help** | Only explains what your role can do |
| **Activity** | Every sign-in and every step that ran, with the user's name |

Instructors see only what their role allows (by default: Start / End class, power on / off,
mirror status and Re-apply mirrors) in their own courses.

Not possible here: `qm unlock` (use the node's shell).

## Set up

Needs a Linux host with Docker or Podman that reaches the nodes on port 8006 (in the
lab: CT 105).

```bash
cd /opt && unzip -o ics-ranges.zip && cd ics-ranges
./setup.sh
```

It asks for the node addresses and the **API token**, tests it, builds and starts the
container. Then open `https://<docker-host>:8443` – the first visit creates the first
admin. Admins add everyone else under **Users**.

**The token** – the one pve-range-docker uses works. To make a new one by hand, on any node:

```bash
pveum user add icsranges@pve --comment "ICS Ranges"
pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser
pveum user token add icsranges@pve gui --privsep 0
```

## Port mirroring and EFI keys (optional)

The Proxmox API can't change Open vSwitch or enroll EFI keys, so both use one SSH key that
may run **only** `ovs-vsctl …` and `qm enroll-efi-keys <vmid>` – the command is never handed
to a shell, so nothing else can be added to it. Admins copy the lines from the GUI
(**Settings → Node key**) or from the start-up log:

```bash
docker compose logs ics-ranges | sed -n '/Node key\|port mirroring and EFI/,/nothing else/p'
```

Run them once, as root, on any one node. They replace an older ics-ranges line.

- **Port mirroring:** the bridge (e.g. `vmbr2`) must be an **OVS bridge**. Then, as admin:
  course → **Sensors → Set up** → pick the bridge and the sensor NICs.
- **EFI keys:** select switched-off UEFI VMs → **Build… → EFI keys**:
  - *Enroll the keys* – keeps the VM's boot entries; needs the node key.
  - In add-ons, `qm enroll-efi-keys <vmid>` works too (with the node key).
    `examples/efi-enroll-keys.sh` is a ready add-on – upload it on the Add-ons tab.
  - *New EFI disk with the keys* – works without the node key; the new EFI disk starts
    without boot entries (most systems boot through the default path) and the old one stays
    on the VM as *unused*, so you can switch back.

## Everyday

| Task | Command |
|---|---|
| Start / stop | `docker compose up -d` / `docker compose down` |
| Log | `docker compose logs ics-ranges` |
| Update | `./setup.sh update /path/to/ics-ranges.zip` – unpacks it in the right place, rebuilds, restarts |
| Change the token | `./setup.sh token` |
| Command line | `docker compose exec ics-ranges pvr help` |

**Command line** (`pvr`) – for scripts and emergencies:

```bash
docker compose exec ics-ranges pvr list --course 613             # guests, status, snapshots
docker compose exec ics-ranges pvr mirror-status                 # are the mirrors running?
docker compose exec ics-ranges pvr users                         # list
docker compose exec ics-ranges pvr users add amy --role instructor --courses 613,NetWars
docker compose exec ics-ranges pvr users passwd kaz               # forgot the admin password
docker compose exec ics-ranges pvr run class_start --course 612 --yes
docker compose exec ics-ranges pvr save "before the exam"
```

All data – users, roles, course map, saved mirrors, add-ons, class guides, the history,
backups, the activity log, the certificate – lives in the `ics-ranges-data` volume, so
updates keep it.

**Bringing over pve-range's add-ons and class guides:** connect the same repository under
**Save & share** and press **Get latest** – or upload them one by one on the Add-ons and
Class guide tabs.

## Testing

`gui-test.sh` tests everything end to end, from the Docker host:

```bash
./gui-test.sh                 # course 613 - including real actions on the fake range
./gui-test.sh NetWars         # another course
./gui-test.sh 613 --check     # only checks: nothing is started, stopped or snapshotted
```

| Part | Checks |
|---|---|
| Container | Running and healthy, the page answers over HTTPS only, security headers, "Proxmox API OK" in the log |
| Sign-in | Wrong password refused, lock-out after 6 tries and unlock, 2FA with a real code, cross-site requests refused |
| Roles | A test instructor sees only their course and can't take snapshots, manage users, change settings, the network or Save & share; a new role can be made, and one still in use can't be deleted |
| Plans | Network, migration and bad-input checks (bad snapshot name, qcow2 on raw-only storage) – reviewed, not run |
| Features | Class guide written and put back; an add-on saved, run on the test guests (with qm / pct) and deleted; mirror status, storage and disks, settings, a backup and a save |
| Real actions | On guests tagged `fake-range` only: take a snapshot, Start class, power off, power on, End class, restore, delete the snapshot – checking every guest's state after each |

It makes its own test users (`gt-…`) and removes them again, also after an interrupted run.
Make the fake range first with `range-seed.sh create <node>` on a node (from pve-range).
Full output: `/tmp/gui-test.out`.

## How it's built

- `app/server.py` – the server, Python standard library only (no packages to download).
  Passwords are stored as PBKDF2-SHA256 hashes, sessions are HTTP-only cookies that end
  after 15 minutes idle, and every change needs the page's own request header.
- `api/` – `qm`, `pct`, `pvesh`, `pvesm` that work through the API, for add-ons.
- `app/static/` – the page: plain JavaScript, no framework, the Barlow typeface bundled
  so it works without internet. Light and dark follow the computer (or Account → Colours).
- Runs as an unprivileged user with all Linux capabilities dropped.

## Coming from pve-range-gui

Versions before 2.3.0 were called pve-range-gui (container `pve-range-gui`, volume
`pve-range-gui_pve-range-gui-data`). Unpack `ics-ranges.zip` in `/opt`, copy your `.env`
into `/opt/ics-ranges`, and run `./setup.sh migrate`: it copies your users, roles, add-ons,
guides, settings and history to the new volume, removes the old container and starts
`ics-ranges`. The old volume is kept until you remove it.
