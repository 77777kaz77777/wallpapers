# ICS Ranges

**Guides:** [SETUP-GUIDE.md](SETUP-GUIDE.md) – install, Proxmox token, node key, updates, publishing
versions · [USER-GUIDE.md](USER-GUIDE.md) – using it · [CHANGELOG.md](CHANGELOG.md) – what's new.

**ICS Ranges** is a web console for running the Proxmox training ranges. It talks to Proxmox
through the API with a token – and, for a few host-level jobs, one tightly restricted SSH key.
Nothing is installed on the nodes.

| Area | What you get |
|---|---|
| **Courses** | Found from the VMIDs (AABCDD: 40 = SANS, 50 = 612, 51 = 613, 52 = NetWars, 53 = 727; below 100000 = Management) – plus **mixed courses** made of guests from several courses |
| **Class** | **Ready for class?** (snapshots, locks, storage, nodes, network, mirrors – green / amber / red with what to do), **Start class** and **End class** with the guests by group; every action shows its steps for review, then runs live |
| **Guests** | Grouped, with live status and snapshots. Tick them – or **Select…** by range, group, tag, name, node or saved group – then **Power on / off**, **Snapshots…**, **Network, disks & more…** (network settings, disks, migration, EFI keys) or **Run an add-on…** |
| **Add-ons** | A **button per add-on** for instructors. **VM add-ons** (on the course's guests – from examples, from steps, or a pasted script), **host add-ons** (`ovs-vsctl` and `mcsnoop` on a Proxmox host) and **port mirroring** – each sensor's mirror built from drop-downs, with **Activate / Deactivate** and whether the traffic arrives |
| **Network** | Per NIC, or per group at once: Proxmox firewall, connected (the virtual cable) and VLAN tag; disconnected NICs with **Connect them…** |
| **Class guides** | One per course – write, upload, import from Gitea / GitHub; shown before class |
| **Users and roles** | admin, instructor, viewer – change what each may do, make new roles; courses per user; 2FA; lock-out after 5 wrong tries |
| **Save & share, Backups** | Every change into a history and your Gitea / GitHub. The **Backups** page: automatic backups to undo a mistake, and the **whole kit in one encrypted file** |
| **Software updates** | Install or go back from the web page; the last 5 versions kept on the kit; nobody signed out by an update |
| **Health** | The cluster at a glance – quorum, nodes, guests running and stopped, nearly full storage – and **TrueNAS**: pools, alerts, version; a dot in the left bar |
| **When Proxmox is off** | The page still opens with the last known guests; admin pages work |

Instructors see only their courses and what their role allows (by default: Ready for class?,
Start / End class, power on / off, the class guide, and the add-on buttons).

## Set up

Needs a Linux host – a VM or LXC container – with Docker or Podman that reaches the nodes on
port 8006. Full steps: [SETUP-GUIDE.md](SETUP-GUIDE.md).

```bash
cd /opt && sudo unzip -o /tmp/ics-ranges.zip && sudo chown -R $USER: ics-ranges && cd ics-ranges
./setup.sh                                  # node addresses, API token, host IP, port - builds and starts
./setup.sh node-key 192.168.77.77           # optional: port mirroring, IGMP snooping, host add-ons, EFI keys
sudo ./setup.sh updater                     # optional: software updates from the web page
```

Then open `https://<host>:8443` – the first visit creates the first admin.

**The Proxmox token** – a dedicated user with `--privsep 0`, on any node:

```bash
pveum user add icsranges@pve --comment "ICS Ranges"
pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser
pveum user token add icsranges@pve gui --privsep 0
```

**The node key** may run **only** `ovs-vsctl …`, `ics-mcsnoop <bridge> 0|1|show` and
`qm enroll-efi-keys <vmid>` – checked arguments, never handed to a shell – and only from the ICS
Ranges host. After updating from a version before 3.1.4, put it on a node again.

## Everyday

| Task | Command (in `/opt/ics-ranges`) |
|---|---|
| Start / stop | `sudo docker compose up -d` / `sudo docker compose down` |
| Log | `sudo docker compose logs ics-ranges` |
| Update | **Software updates** in the page – or `sudo ./setup.sh update /path/to/ics-ranges.zip` |
| Publish a version | `./release.sh /path/to/ics-ranges.zip` (notes from `CHANGELOG.md`) |
| The whole kit in one file | `./setup.sh export` / `./setup.sh import FILE` |
| Command line | `sudo docker compose exec ics-ranges pvr help` |

```bash
sudo docker compose exec ics-ranges pvr list --course 613              # guests, status, snapshots
sudo docker compose exec ics-ranges pvr mirror-status                  # mirror add-ons: active? copy arriving?
sudo docker compose exec ics-ranges pvr run class_start --course 612 --yes
sudo docker compose exec ics-ranges pvr run mirror_on --course 612 --id 612-sensor
sudo docker compose exec ics-ranges pvr users passwd kaz               # forgot the admin password
```

All data – users, roles, course map, mirror add-ons, add-ons, class guides, the history, backups,
the activity log, the certificate, the node key – lives in the `ics-ranges_ics-ranges-data` volume,
so updates keep it.

## Testing

```bash
./gui-test.sh 613 --check                               # API checks only - nothing is changed
./gui-test.sh                                           # also real actions, only on guests tagged fake-range
./tests/addon-test.sh https://127.0.0.1:8443 kaz        # add-ons: commands, course rules, roles, host, mirrors - reads only
./tests/ui-test.sh https://127.0.0.1:8443 kaz           # every page and window in a real browser - changes nothing
```

`gui-test.sh` checks the container, HTTPS, sign-in, roles, 2FA, guides, add-ons, mirror add-ons,
readiness, kit files, backups and bad requests (about 80 checks). `addon-test.sh` checks add-ons in
depth (about 45 checks) and removes what it makes. `ui-test.sh` opens every page and
window and checks for script errors and broken text (about 160 checks); it sets up its own Python
environment – on Debian first `sudo apt-get install -y python3-venv chromium`.

## How it's built

- `app/server.py` – starts the server (or `pvr` with arguments) and holds the version. The code is in
  `app/ics/`, one module per topic: `core` (Proxmox API, guests, users, settings), `content`
  (guides, add-on files), `share` (history, backups), `netops`, `addons` (running them), `updates`,
  `mirrors` (mirror add-ons), `plans` (review → run), `readiness`, `health`, `truenas`, `kit`, `web` (the page's
  endpoints), `cli` (`pvr`). Python standard library only. Passwords as PBKDF2-SHA256 hashes;
  HTTP-only session cookies that end after 15 minutes idle; every change needs the page's own
  request header.
- `api/` – `qm`, `pct`, `pvesh`, `pvesm`, `ovs-vsctl` and `mcsnoop` for add-ons, working through
  the API and the node key, limited to the add-on's course.
- `app/static/` – the page: plain JavaScript, no framework; the Barlow typeface bundled, so it
  works without internet; light and dark themes.
- Runs as an unprivileged user with all Linux capabilities dropped; Docker or Podman.
