"use strict";
/* ICS Ranges - part 2: class guides, add-ons, picking guests, build actions,
   save & share, settings, help. Uses the helpers from app.js. */

/* ---------- files to and from the computer ---------- */
function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type: type || "text/plain" }));
  const a = h("a", { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function pickFile(accept) {
  return new Promise((ok, no) => {
    const i = h("input", { type: "file", accept: accept || "" });
    i.addEventListener("change", () => {
      const f = i.files[0];
      if (!f) return no(new Error("no file"));
      if (f.size > 1000000) return no(new Error("The file is larger than 1 MB."));
      const r = new FileReader();
      r.onload = () => ok({ name: f.name, text: String(r.result) });
      r.onerror = () => no(new Error("Couldn't read the file."));
      r.readAsText(f);
    });
    i.click();
  });
}
function askText(title, label, value, hint) {
  return new Promise(ok => {
    dialog((d, close) => {
      const inp = h("input", { type: "text", value: value || "", autofocus: true });
      d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); ok(inp.value.trim()); } },
        h("header", {}, h("h2", {}, title)),
        h("div", { class: "content" }, h("label", { class: "field" }, label, hint ? h("span", { class: "hint" }, hint) : null, inp)),
        h("footer", {}, h("button", { class: "btn", type: "button", onclick: () => { close(); ok(null); } }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "OK"))));
    });
  });
}

/* ---------- class guide: shown as simple formatted text ---------- */
function renderGuide(text) {
  const out = [];
  let list = null, para = [];
  const flush = () => { if (para.length) { out.push(h("p", {}, para.join(" "))); para = []; } if (list) { out.push(list); list = null; } };
  for (const raw of (text || "").split("\n")) {
    const line = raw.replace(/\s+$/, "");
    let m;
    if (!line.trim()) { flush(); continue; }
    if ((m = line.match(/^(#{1,3})\s+(.*)$/))) { flush(); out.push(h(m[1].length === 1 ? "h2" : "h3", {}, m[2])); continue; }
    if ((m = line.match(/^\s*(?:[-*]|\d+[.)])\s+(.*)$/))) { if (para.length) { out.push(h("p", {}, para.join(" "))); para = []; } if (!list) list = h(/^\s*\d/.test(line) ? "ol" : "ul"); list.append(h("li", {}, m[1])); continue; }
    if (list) { out.push(list); list = null; }
    para.push(line.trim());
  }
  flush();
  return out;
}
function guidePanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading the class guide…")));
  const show = text => {
    const edit = can("guide_edit");
    const head = h("header", {}, h("h2", {}, "Class guide – " + c.name),
      text != null ? h("button", { class: "btn quiet", type: "button", onclick: () => download(c.name + ".md", text) }, "Download") : null,
      edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { try { const f = await pickFile(".md,.txt,text/*"); await save(f.text); } catch (e) { if (e.message !== "no file") fail(e); } } }, "Upload") : null,
      edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { const u = await askText("Import a class guide", "Web address", "", "A raw file on GitHub or Gitea – a normal page address works too"); if (u) save(null, u); } }, "Import") : null,
      edit && text != null ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Delete the class guide for " + c.name + "?")) api("DELETE", "/api/guide/" + encodeURIComponent(c.name)).then(() => show(null)).catch(fail); } }, "Delete") : null,
      edit ? h("button", { class: "btn primary", type: "button", onclick: () => editor(text) }, text != null ? "Edit" : "Write a guide") : null);
    p.replaceChildren(head, h("div", { class: "body guidetext" }, text != null ? renderGuide(text) :
      h("p", { class: "muted" }, edit ? "No class guide yet. Write down how this course is run: the steps, what to keep, which add-ons to use." : "No class guide for this course yet.")));
  };
  const save = async (text, url) => {
    try { const r = await api("PUT", "/api/guide/" + encodeURIComponent(c.name), url ? { url } : { text }); toast("Class guide saved."); show(r.text); } catch (e) { fail(e); }
  };
  const editor = text => dialog((d, close) => {
    const ta = h("textarea", { "aria-label": "Class guide", spellcheck: "true" });
    ta.value = text != null ? text : "# " + c.name + " – how this class is run\n\n## Before class\n- \n\n## Start class\n- Snapshot: ClassStart\n- Keep as they are: \n\n## During class\n- \n\n## End class\n- \n";
    d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); save(ta.value); } },
      h("header", {}, h("h2", {}, "Class guide – " + c.name), h("p", { class: "muted small" }, "# for headings, - for lists. Paste text in here too.")),
      h("div", { class: "content" }, ta),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save guide"))));
  });
  api("GET", "/api/guide/" + encodeURIComponent(c.name)).then(r => show(r.text)).catch(fail);
  return p;
}

/* ---------- add-ons ---------- */
function addonPanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading add-ons…")));
  const edit = can("addons_edit");
  let last = null;   // the add-ons listed now - a new one gets a file name that's free
  const load = () => api("GET", "/api/addons?course=" + encodeURIComponent(c.name)).then(r => {
    const sel = [...S.selected];
    last = r;
    const rows = r.addons.map(a => h("tr", {},
      h("td", {}, h("b", {}, a.name), h("div", { class: "muted small" }, a.desc || a.file)),
      h("td", { class: "small" }, a.scope === "_all" ? "All courses" : a.scope),
      h("td", { class: "small" }, a.guests ? (sel.length ? "on " + plural(sel.length, "selected guest") : "needs selected guests") : "no guests"),
      h("td", {}, h("div", { class: "actions" },
        h("button", { class: "btn", type: "button", disabled: a.guests && !sel.length,
          onclick: () => planDialog({ action: "addon_run", course: c.name, scope: a.scope, file: a.file, ids: a.guests ? sel : [], title: a.name + " – " + c.name }) }, "Run"),
        h("button", { class: "btn quiet", type: "button", onclick: () => api("GET", "/api/addons/" + a.scope + "/" + a.file).then(x => download(a.file, x.text)).catch(fail) }, "Download"),
        edit ? h("button", { class: "btn quiet", type: "button", onclick: () => api("GET", "/api/addons/" + a.scope + "/" + a.file).then(x => editor(a.scope, a.file, x.text)).catch(fail) }, "Edit") : null,
        edit ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Delete the add-on " + a.name + "?")) api("DELETE", "/api/addons/" + a.scope + "/" + a.file).then(load).catch(fail); } }, "Delete") : null))));
    p.replaceChildren(
      h("header", {}, h("h2", {}, "Add-ons – " + c.name),
        edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { try { const f = await pickFile(".sh,text/*"); editor(c.name, f.name.replace(/[^A-Za-z0-9_.-]/g, "-").replace(/(\.sh)?$/, ".sh"), f.text, true); } catch (e) { if (e.message !== "no file") fail(e); } } }, "Upload") : null,
        edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { const u = await askText("Import an add-on", "Web address of the script", "", "A raw file on GitHub or Gitea"); if (!u) return; const n = (u.split("/").pop() || "addon").replace(/[^A-Za-z0-9_.-]/g, "-").replace(/(\.sh)?$/, ".sh"); api("PUT", "/api/addons/" + encodeURIComponent(c.name) + "/" + n, { url: u }).then(x => editor(c.name, n, x.text)).catch(fail); } }, "Import") : null,
        edit ? h("button", { class: "btn primary", type: "button", onclick: () => editor(c.name, "", "", true) }, "New add-on") : null),
      r.addons.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Add-on", "For", "Runs on", ""].map(x => h("th", {}, x)))), h("tbody", {}, rows))) :
        h("div", { class: "body" }, h("p", { class: "muted" }, edit ? "No add-ons yet. An add-on is a script that runs here with the Proxmox API – qm, pct and pvesh work in it." : "No add-ons for this course.")),
      h("div", { class: "body muted small" }, "Select guests on the Guests tab first for add-ons that work on guests."));
  }).catch(fail);
  const taken = () => (last ? last.addons.map(x => x.file) : []);
  const editor = (scope, file, text, isNew) => addonEditor(c.name, scope, file, text, isNew, taken(), load);
  load();
  return p;
}

/* ---------- picking guests: range, tag, name, node, saved group ---------- */
async function selectDialog(c) {
  let groups = {};
  try { groups = await api("GET", "/api/groups"); } catch (e) { /* none */ }
  const gs = S.data.guests;
  const tags = [...new Set(gs.flatMap(g => g.tags))].sort(), nodes = [...new Set(gs.map(g => g.node))].sort();
  const subs = [...new Set(gs.map(g => g.group))];
  const ranges = text => { const out = new Set(); for (const part of (text || "").split(/[\s,]+/)) { const m = part.match(/^(\d+)(?:-(\d+))?$/); if (m) for (let v = +m[1]; v <= +(m[2] || m[1]) && v - m[1] < 100000; v++) out.add(v); } return out; };
  dialog((d, close) => {
    const how = h("select", {}, [["range", "VMID range"], ["sub", "Group (from the VMID)"], ["tag", "Proxmox tag"], ["name", "Name pattern"], ["node", "Node"], ["saved", "Saved group"], ["running", "Running guests"], ["off", "Guests that are off"], ["all", "Every guest"], ["none", "Nothing (clear)"]]
      .filter(([k]) => k !== "saved" || Object.keys(groups).length).filter(([k]) => k !== "tag" || tags.length).map(([v, t]) => h("option", { value: v }, t)));
    const add = h("input", { type: "checkbox" });
    const val = h("div");
    let input = null;
    const draw = () => {
      const k = how.value;
      input = k === "range" ? h("input", { type: "text", placeholder: "510400-510430, 510500" }) :
        k === "name" ? h("input", { type: "text", placeholder: "ews|ows" }) :
        k === "tag" ? h("select", {}, tags.map(t => h("option", {}, t))) :
        k === "node" ? h("select", {}, nodes.map(t => h("option", {}, t))) :
        k === "sub" ? h("select", {}, subs.map(t => h("option", {}, t))) :
        k === "saved" ? h("select", {}, Object.entries(groups).map(([n, r]) => h("option", { value: r }, n + " (" + r + ")"))) : null;
      val.replaceChildren(input ? h("label", { class: "field" }, "Which", input) : "");
    };
    how.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const k = how.value, v = input ? input.value : "";
      let re = null;
      if (k === "name") { try { re = new RegExp(v, "i"); } catch (ex) { toast("That name pattern isn't valid.", true); return; } }
      const r = k === "range" || k === "saved" ? ranges(v) : null;
      const match = g => k === "range" || k === "saved" ? r.has(g.vmid) : k === "name" ? re.test(g.name) : k === "tag" ? g.tags.includes(v) : k === "node" ? g.node === v :
        k === "sub" ? g.group === v : k === "running" ? g.status === "running" : k === "off" ? g.status !== "running" : k === "all";
      if (!add.checked) S.selected.clear();
      if (k !== "none") gs.filter(match).forEach(g => S.selected.add(g.vmid));
      close(); S.tab = "guests"; refill();
      toast(plural(S.selected.size, "guest") + " selected.");
    } },
      h("header", {}, h("h2", {}, "Select guests")),
      h("div", { class: "content" }, h("label", { class: "field" }, "By", how), val, h("label", { class: "check" }, add, "Add to what's already selected")),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Select"))));
  });
}

/* ---------- build: network, disks, migration ---------- */
async function buildDialog(c, gs) {
  const ids = gs.map(g => g.vmid);
  const opts = [];
  if (can("network")) opts.push(["network", "Network settings – bridge, VLAN, firewall, NIC model"]);
  if (can("disks")) opts.push(["disks", "Move / convert disks"]);
  if (can("migrate")) opts.push(["migrate", "Migrate to another node"]);
  if (can("efi")) opts.push(["efi", "EFI keys for Secure Boot"]);
  let bridges = {}, storages = [];
  try {
    if (can("network")) bridges = await api("GET", "/api/bridges");
    if (can("disks")) storages = await api("GET", "/api/storages");
  } catch (e) { fail(e); }
  dialog((d, close) => {
    const what = h("select", {}, opts.map(([v, t]) => h("option", { value: v }, t)));
    const box = h("div");
    let collect = null;
    const draw = () => {
      if (what.value === "network") {
        const allBr = [...new Set(Object.values(bridges).flat())].sort();
        const nic = h("select", {}, h("option", { value: "all" }, "Every NIC"), [0, 1, 2, 3, 4, 5].map(n => h("option", { value: "net" + n }, "net" + n)));
        const br = h("select", {}, h("option", { value: "" }, "Keep as it is"), allBr.map(b => h("option", {}, b)));
        const vlanKeep = h("input", { type: "checkbox", checked: true }), vlan = h("input", { type: "text", placeholder: "e.g. 20 – empty removes the tag", disabled: true });
        vlanKeep.addEventListener("change", () => { vlan.disabled = vlanKeep.checked; });
        const fw = h("select", {}, [["", "Keep as it is"], ["on", "On"], ["off", "Off"]].map(([v, t]) => h("option", { value: v }, t)));
        const model = h("select", {}, [["", "Keep as it is"], ["virtio", "VirtIO"], ["e1000", "Intel E1000"], ["e1000e", "Intel E1000E"], ["vmxnet3", "VMware vmxnet3"], ["rtl8139", "Realtek RTL8139"]].map(([v, t]) => h("option", { value: v }, t)));
        box.replaceChildren(h("label", { class: "field" }, "NIC", nic), h("label", { class: "field" }, "Bridge", br),
          h("div", { class: "field" }, h("span", {}, "VLAN tag"), h("label", { class: "check" }, vlanKeep, "Keep as it is"), vlan),
          h("label", { class: "field" }, "Proxmox firewall", fw), h("label", { class: "field" }, "NIC model (VMs)", h("span", { class: "hint" }, "The MAC address is kept"), model));
        collect = () => ({ action: "network", nic: nic.value, change: { bridge: br.value || null, vlan: vlanKeep.checked ? null : vlan.value, firewall: fw.value || null, model: model.value || null }, title: "Network settings – " + plural(ids.length, "guest") });
      } else if (what.value === "disks") {
        const st = h("select", {}, storages.map(s => h("option", { value: s.storage }, s.storage + " (" + s.type + (s.raw_only ? ", raw only" : "") + ")")));
        const fmt = h("select", {}, [["keep", "Keep the format"], ["qcow2", "qcow2 – snapshots on directory storage"], ["raw", "raw"]].map(([v, t]) => h("option", { value: v }, t)));
        const del = h("input", { type: "checkbox", checked: true });
        box.replaceChildren(h("label", { class: "field" }, "To storage", st), h("label", { class: "field" }, "Format", h("span", { class: "hint" }, "Storages marked raw only keep raw"), fmt),
          h("label", { class: "check" }, del, "Delete the old disk after a successful move"),
          h("p", { class: "muted small gap-top" }, "Running VMs move live. Containers have to be off."));
        collect = () => ({ action: "disk_move", storage: st.value, format: fmt.value, delete: del.checked, title: "Move disks to " + st.value + " – " + plural(ids.length, "guest") });
      } else if (what.value === "efi") {
        const enroll = h("input", { type: "radio", name: "efim", checked: true }), recreate = h("input", { type: "radio", name: "efim" });
        const again = h("input", { type: "checkbox" });
        box.replaceChildren(
          h("div", { class: "field" }, h("span", {}, "How"), h("div", { class: "radio-row stacked" },
            h("label", { class: "check" }, enroll, "Enroll the keys – keeps the VM's boot entries (needs the node key from Settings)"),
            h("label", { class: "check" }, recreate, "New EFI disk with the keys – no node key needed; boot entries start empty, the old EFI disk is kept as unused"))),
          h("label", { class: "check" }, again, "Also VMs that already have the keys (e.g. to add newer certificates)"),
          h("p", { class: "muted small gap-top" }, "Only VMs that use UEFI (OVMF) and are switched off. Containers are skipped."));
        collect = () => ({ action: "efi_keys", method: recreate.checked ? "recreate" : "enroll", again: again.checked, title: "EFI keys – " + plural(ids.length, "guest") });
      } else {
        const nodes = S.data.nodes || [];
        const boxes = nodes.map((n, i) => h("input", { type: "checkbox", value: n, checked: i === 0 }));
        const one = h("input", { type: "radio", name: "spread", checked: true }), round = h("input", { type: "radio", name: "spread" }), blocks = h("input", { type: "radio", name: "spread" });
        box.replaceChildren(
          h("div", { class: "field" }, h("span", {}, "To node(s)"), h("div", { class: "radio-row" }, nodes.map((n, i) => h("label", { class: "check" }, boxes[i], n)))),
          h("div", { class: "field" }, h("span", {}, "With several nodes"), h("div", { class: "radio-row stacked" },
            h("label", { class: "check" }, round, "Round-robin – one each in turn"),
            h("label", { class: "check" }, blocks, "Blocks – the first part to the first node, and so on"),
            h("label", { class: "check" }, one, "All to the first ticked node"))),
          h("p", { class: "muted small" }, "Running VMs move live with their disks; running containers restart on the new node."));
        collect = () => {
          const t = boxes.filter(b => b.checked).map(b => b.value);
          return { action: "migrate", nodes: t, spread: t.length > 1 ? (round.checked ? "round" : blocks.checked ? "blocks" : "one") : "one", title: "Migrate to " + t.join(", ") + " – " + plural(ids.length, "guest") };
        };
      }
    };
    what.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => { e.preventDefault(); const b = collect(); b.course = c.name; b.ids = ids; close(); planDialog(b); } },
      h("header", {}, h("h2", {}, "Build – " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("label", { class: "field" }, "What", what), box),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- save & share ---------- */
function pageShare() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Save & share"),
    h("div", { class: "sub" }, "Add-ons, class guides, roles, the course map, mirrors, groups and themes are saved after every change."))));
  const body = h("div");
  main.append(body);
  const run = async (fn, label) => { try { const r = await fn(); toast(r.report || label); draw(); } catch (e) { fail(e); } };
  const draw = () => api("GET", "/api/git").then(g => {
    const url = h("input", { type: "text", value: g.url, placeholder: "https://gitea.lab/team/ics-ranges.git" });
    const user = h("input", { type: "text", value: g.user, autocomplete: "off" });
    const tok = h("input", { type: "password", placeholder: g.has_token ? "saved – leave empty to keep it" : "token with write access", autocomplete: "new-password" });
    const branch = h("input", { type: "text", value: g.branch || "main" });
    const insecure = h("input", { type: "checkbox", checked: g.insecure });
    body.replaceChildren(
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "Your repository"), g.url ? h("span", { class: "muted small" }, "connected") : null),
        h("form", { class: "body", onsubmit: e => { e.preventDefault(); run(() => api("PUT", "/api/git/connect", { url: url.value, user: user.value, token: tok.value, branch: branch.value, insecure: insecure.checked })); } },
          h("p", { class: "muted small" }, "Gitea, GitHub or GitLab. Make an empty repository and a token that may write to it, then connect. The connection is tested first – if it fails, nothing changes."),
          h("div", { class: "cols" }, h("label", { class: "field" }, "Repository address", url), h("label", { class: "field" }, "Branch", branch)),
          h("div", { class: "cols" }, h("label", { class: "field" }, "User name", user), h("label", { class: "field" }, "Token", tok)),
          h("label", { class: "check" }, insecure, "Don't check the server's HTTPS certificate (self-signed Gitea in the lab)"),
          g.ssh_key ? h("div", { class: "gap-top" }, h("p", { class: "small" }, "For an SSH address, add this key to the repository as a deploy key with write access:"), h("div", { class: "pw small" }, g.ssh_key)) : null,
          h("div", { class: "actions gap-top" },
            g.url ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Disconnect the repository? Nothing is deleted.")) run(() => api("PUT", "/api/git/connect", { url: "" })); } }, "Disconnect") : null,
            h("button", { class: "btn primary", type: "submit" }, g.url ? "Save connection" : "Connect and upload")))),
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "History"),
          h("button", { class: "btn", type: "button", onclick: async () => { const m = await askText("Save now", "What changed?", "Saved from the GUI"); if (m) run(() => api("POST", "/api/git/save", { message: m })); } }, "Save now"),
          g.url ? h("button", { class: "btn", type: "button", onclick: () => { if (confirm("Load the add-ons, class guides and settings from the repository? What isn't saved there yet is replaced.")) run(() => api("POST", "/api/git/pull")); } }, "Get latest") : null),
        g.history.length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, g.history.map(x => h("tr", {}, h("td", {}, x.what), h("td", { class: "small" }, x.who), h("td", { class: "muted small" }, x.when)))))) :
          h("div", { class: "body muted" }, "Nothing saved yet.")),
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "Backups"), h("button", { class: "btn", type: "button", onclick: () => run(() => api("POST", "/api/git/backup")) }, "Make a backup")),
        g.backups.length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, g.backups.map(b => h("tr", {}, h("td", {}, b.replace(/^backup-(\d{4})(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d).*$/, "$1-$2-$3 $4:$5:$6")),
          h("td", {}, h("div", { class: "actions" },
            h("a", { class: "btn quiet", href: "/api/git/backup/" + b, download: b }, "Download"),
            h("button", { class: "btn quiet", type: "button", onclick: () => { if (confirm("Restore this backup? A backup of the state now is made first.")) run(() => api("POST", "/api/git/restore", { name: b })); } }, "Restore")))))))) :
          h("div", { class: "body muted" }, "No backups yet. One is made after every change; how many are kept is under Settings.")));
  }).catch(fail);
  draw();
  return main;
}

/* ---------- settings: settings, saved groups, colour themes ---------- */
function pageSettings() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Settings"), h("div", { class: "sub" }, "For everyone who uses ICS Ranges."))));
  const a = h("div"), b = h("div"), t = h("div"), k = h("div");
  main.append(a, b, t, k);
  api("GET", "/api/nodekey").then(r => {
    k.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Node key"), h("span", { class: "muted small" }, "For port mirroring and EFI keys"),
        r.text ? h("button", { class: "btn", type: "button", onclick: () => download("node-key.sh", "#!/bin/sh\n# Run as root on any one Proxmox node:  bash node-key.sh\n" + r.text) }, "Download") : null,
        r.text ? h("button", { class: "btn", type: "button", onclick: () => navigator.clipboard.writeText(r.text).then(() => toast("Copied - paste it into a root shell on a node.")).catch(() => toast("Select the text and copy it.", true)) }, "Copy") : null),
      h("div", { class: "body" },
        h("p", { class: "small" }, "The Proxmox API can't change Open vSwitch or enroll EFI keys, so these use one SSH key that may run only ovs-vsctl and qm enroll-efi-keys <vmid>, and only from this host. Add it once, on any one node – the cluster shares it:"),
        h("ul", { class: "small" },
          h("li", {}, "Easiest – on the ICS Ranges host: ", h("code", {}, "./setup.sh node-key <node IP>"), " (asks for the node's root password once)."),
          h("li", {}, "Or ", h("b", {}, "Copy"), " and paste the lines into a root shell on a node."),
          h("li", {}, "Or ", h("b", {}, "Download"), " node-key.sh, copy it to a node and run ", h("code", {}, "bash node-key.sh"), " as root.")),
        r.text ? h("pre", { class: "log" }, r.text) : h("p", { class: "muted" }, "No key yet – it's made when the container starts."))));
  }).catch(() => {});
  api("GET", "/api/settings").then(r => {
    const s = r.settings;
    const f = {
      default_snapshot: h("input", { type: "text", value: s.default_snapshot }),
      shutdown_timeout: h("input", { type: "text", inputmode: "numeric", value: s.shutdown_timeout }),
      max_parallel: h("input", { type: "text", inputmode: "numeric", value: s.max_parallel }),
      protected: h("input", { type: "text", value: s.protected, placeholder: "100-105, 9001" }),
      sensor_pattern: h("input", { type: "text", value: s.sensor_pattern }),
      backup_keep: h("input", { type: "text", inputmode: "numeric", value: s.backup_keep }),
      start_delay: h("input", { type: "text", inputmode: "numeric", value: s.start_delay }),
      show_guide: h("input", { type: "checkbox", checked: s.show_guide }),
    };
    a.replaceChildren(h("section", { class: "panel" }, h("header", {}, h("h2", {}, "Running classes")),
      h("form", { class: "body", onsubmit: e => { e.preventDefault();
        const v = {}; for (const [k, el] of Object.entries(f)) v[k] = el.type === "checkbox" ? el.checked : el.value;
        api("PUT", "/api/settings", v).then(() => { toast("Settings saved."); S.session.settings.default_snapshot = v.default_snapshot; S.session.settings.show_guide = v.show_guide; }).catch(fail); } },
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Class snapshot", h("span", { class: "hint" }, "Chosen first in the Class panel"), f.default_snapshot),
          h("label", { class: "field" }, "Protected guests", h("span", { class: "hint" }, "Never shown, never touched – e.g. this Docker host"), f.protected)),
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Graceful shutdown timeout (seconds)", h("span", { class: "hint" }, "Then the guest is forced off"), f.shutdown_timeout),
          h("label", { class: "field" }, "Steps at once", h("span", { class: "hint" }, "Starts, stops and restores in parallel"), f.max_parallel)),
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Sensor names", h("span", { class: "hint" }, "Guests with these names (or the tag sensor) are ticked when setting up mirrors"), f.sensor_pattern),
          h("label", { class: "field" }, "Backups to keep", f.backup_keep)),
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Pause between starts (seconds)", h("span", { class: "hint" }, "0 = start all at once (containers first, then VMs); more = one after another"), f.start_delay), h("span")),
        h("label", { class: "check" }, f.show_guide, "Show the class guide before Start class and End class"),
        h("div", { class: "actions gap-top" }, h("button", { class: "btn primary", type: "submit" }, "Save settings")))));
  }).catch(fail);
  api("GET", "/api/groups").then(groups => {
    const draw = () => b.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Saved groups"), h("span", { class: "muted small" }, "Pick them under Select… on the Guests tab"),
        h("button", { class: "btn", type: "button", onclick: async () => { const n = await askText("New group", "Name", ""); if (!n) return; const r = await askText("New group", "VMIDs and ranges", "", "e.g. 510400-510430, 510500"); if (!r) return; groups[n] = r; draw(); } }, "New group"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/groups", { groups }).then(() => toast("Groups saved.")).catch(fail) }, "Save groups")),
      Object.keys(groups).length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, Object.entries(groups).map(([n, r]) => h("tr", {}, h("td", {}, h("b", {}, n)), h("td", {}, r),
        h("td", {}, h("div", { class: "actions" }, h("button", { class: "btn danger", type: "button", onclick: () => { delete groups[n]; draw(); } }, "Remove")))))))) :
        h("div", { class: "body muted" }, "No saved groups.")));
    draw();
  }).catch(fail);
  api("GET", "/api/themes").then(themes => {
    const names = { canvas: "Background", panel: "Panels", ink: "Text", line: "Lines", action: "Buttons and links" };
    const draw = () => t.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Colour themes"), h("span", { class: "muted small" }, "Status colours stay the same – they mean something"),
        h("button", { class: "btn", type: "button", onclick: async () => { const n = await askText("New theme", "Name", ""); if (!n) return; themes[n] = { canvas: "#000000", panel: "#111111", ink: "#ffffff", line: "#444444", action: "#5b9be6", dark: true }; draw(); } }, "New theme"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/themes", { themes }).then(() => { toast("Themes saved."); S.session.themes = themes; applyTheme(); }).catch(fail) }, "Save themes")),
      Object.keys(themes).length ? h("div", { class: "tablewrap" }, h("table", {},
        h("thead", {}, h("tr", {}, h("th", {}, "Theme"), Object.values(names).map(x => h("th", {}, x)), h("th", {}, "Dark"), h("th", {}, ""))),
        h("tbody", {}, Object.entries(themes).map(([n, c]) => h("tr", {}, h("td", {}, h("b", {}, n)),
          Object.keys(names).map(k => h("td", {}, h("input", { type: "color", value: c[k], "aria-label": n + " " + names[k], oninput: e => { c[k] = e.target.value; } }))),
          h("td", {}, h("input", { type: "checkbox", checked: !!c.dark, "aria-label": n + " is dark", onchange: e => { c.dark = e.target.checked; } })),
          h("td", {}, h("div", { class: "actions" },
            h("button", { class: "btn quiet", type: "button", onclick: () => { S.session.themes = themes; try { localStorage.setItem("pvr-theme", n); } catch (e) { /* ignore */ } applyTheme(); } }, "Try it"),
            h("button", { class: "btn danger", type: "button", onclick: () => { delete themes[n]; draw(); } }, "Remove"))))))) ) :
        h("div", { class: "body muted" }, "No own themes. Light and dark are built in; everyone picks under Account.")));
    draw();
  }).catch(fail);
  return main;
}

/* ---------- help: only what you can use ---------- */
function pageHelp() {
  const items = [
    ["class_run", "Start class", "Restores the class snapshot on the guests you tick, then powers them on – containers first, then VMs. Guests with a memory snapshot come back running by themselves."],
    ["class_run", "End class", "Restores the snapshot and switches everything off. Restored guests go off at once; guests you keep get a graceful shutdown or are powered off."],
    ["power", "Power on / off", "For the selected guests, as they are – nothing is restored."],
    ["snap_take", "Take a snapshot", "Snapshots… on the Guests tab. Leave running guests running, shut them down first (cleanest), or after; optionally with memory."],
    ["snap_restore", "Restore a snapshot", "Snapshots… → Restore, then leave them, power them on, or make sure they're off. Guests without that snapshot are left alone."],
    ["snap_delete", "Delete a snapshot", "Snapshots… → Delete."],
    ["mirror_status", "Mirror status", "The Sensors panel shows each sensor NIC: green when its mirror runs, with the packets sent; red when the sensor runs but isn't mirrored."],
    ["mirror_apply", "Re-apply mirrors", "Mirrors disappear when a sensor restarts or a node reboots – do this after Start class."],
    ["mirror_setup", "Set up mirrors", "Sensors → Set up: pick the Open vSwitch bridge and the sensor NICs. Untick all to remove the mirrors."],
    ["guide_read", "Class guide", "The Class guide tab: how this course is run."],
    ["guide_edit", "Write the class guide", "Write, upload or import it from a web address."],
    ["addons_run", "Add-ons", "The Add-ons tab: scripts that run with the Proxmox API. Select guests first for add-ons that work on guests; the output shows live."],
    ["addons_edit", "Make add-ons", "New, upload, import, edit, move to all courses. qm, pct and pvesh work in them."],
    ["network", "Network settings", "Build… → bridge, VLAN tag, firewall, NIC model for the selected guests. The MAC address is kept."],
    ["disks", "Move / convert disks", "Build… → another storage, and qcow2 for snapshots on directory storage."],
    ["efi", "EFI keys", "Build… → EFI keys: enroll Secure Boot keys on switched-off UEFI VMs, or give them a new EFI disk with the keys."],
    ["migrate", "Migrate", "Build… → move guests to one node, or spread them over several (round-robin or in blocks); running VMs move live."],
    ["overview", "Storage and disks", "The tab with storages and every disk of the course."],
    ["save", "Save & share", "Every change is saved; connect Gitea or GitHub to keep a copy there; backups can be restored."],
    ["users", "Users", "Add people, give them a role and their courses; passwords are made for them."],
    ["software", "Software updates", "Install a newer – or an older – ICS Ranges version from your repository; the host checks and installs it, and goes back if it doesn't start."],
    ["settings", "Roles and settings", "What each role may do, the course map, protected guests, groups and colour themes."],
  ].filter(([p]) => can(p));
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Help"), h("div", { class: "sub" }, "What you can do here, as " + S.session.role + "."))),
    h("section", { class: "panel" }, h("div", { class: "body guidetext" },
      h("p", {}, "Pick a course on the left. Everything you do stays inside that course, and every action shows its steps before anything runs."),
      items.map(([, t, d]) => [h("h3", {}, t), h("p", {}, d)]),
      h("h3", {}, "Selecting guests"), h("p", {}, "Tick them, or use Select… for a VMID range, a group from the VMID, a tag, a name, a node or a saved group."),
      h("h3", {}, "Your account"), h("p", {}, "Account at the bottom left: change your password, turn on a code from an authenticator app, pick light or dark."))));
}

/* ---------- software updates: from your ics-ranges-app repository ---------- */
function pageUpdates() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Software updates"),
    h("div", { class: "sub" }, "Install a newer – or an older – version of ICS Ranges from your repository."))));
  const prog = h("div"), conn = h("div"), host = h("div"), list = h("div");
  main.append(prog, host, conn, list);
  let polling = false;
  const busy = st => st.pending || ["requested", "downloading", "checking", "installing", "rolling_back"].includes(st.state);
  const ready = u => u.updater.installed && u.updater.matches && u.updater.writable;
  const stateText = { requested: "Waiting for the host's updater", downloading: "Downloading", checking: "Checking the download",
    installing: "Installing – ICS Ranges restarts during this", rolling_back: "Going back to the previous version", done: "Done", failed: "Failed" };

  const drawProg = st => {
    if (!st.state) { prog.replaceChildren(); return; }
    const cls = busy(st) ? "busy" : st.state === "done" ? "ok" : "failed";
    prog.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Last update" + (st.version ? " – " + st.version : "")), h("span", { class: "muted small" }, (st.by ? st.by + ", " : "") + (st.at || "").replace("T", " "))),
      h("div", { class: "body" },
        h("div", { class: "result " + cls }, busy(st) ? lamp("running-step") : null, " ", stateText[st.state] || st.state, st.message && st.message !== stateText[st.state] ? " – " + st.message : ""),
        st.waiting > 45 ? h("div", { class: "notice small gap-top" }, h("b", {}, "The host hasn't started the update after " + Math.round(st.waiting) + " seconds."),
          " Its updater may be off or stuck – on the host run ", h("code", {}, "sudo ./setup.sh updater status"), ", then ", h("code", {}, "sudo ./setup.sh updater"), ". The request waits until then.") : null,
        st.log && st.state !== "requested" ? h("details", { open: busy(st) || st.state === "failed" }, h("summary", {}, "Log"), h("pre", { class: "log" }, st.log)) : null)));
  };
  const drawConn = u => {
    const url = h("input", { type: "text", value: u.url, placeholder: "http://192.168.77.93:3000/kaz/ics-ranges-app" });
    const user = h("input", { type: "text", value: u.user, autocomplete: "off" });
    const tok = h("input", { type: "password", autocomplete: "new-password", placeholder: u.has_token ? "saved – leave empty to keep it" : "read-only token" });
    const insecure = h("input", { type: "checkbox", checked: u.insecure });
    conn.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Repository"), u.url ? h("span", { class: "muted small" }, "connected") : null),
      h("form", { class: "body", onsubmit: e => { e.preventDefault();
        api("PUT", "/api/updates/connect", { url: url.value, user: user.value, token: tok.value, insecure: insecure.checked })
          .then(r => { toast("Connected – " + plural(r.releases, "release") + " found."); load(); }).catch(fail); } },
        h("p", { class: "muted small" }, "The Gitea (or GitHub) repository where ICS Ranges versions are published as releases, each with ics-ranges.zip and ics-ranges.zip.sha256 attached. A read-only token is enough."),
        h("div", { class: "cols" }, h("label", { class: "field" }, "Repository address", url), h("label", { class: "field" }, "User name", user)),
        h("div", { class: "cols" }, h("label", { class: "field" }, "Token", tok), h("label", { class: "check gap-top" }, insecure, "Don't check the HTTPS certificate (self-signed Gitea)")),
        h("div", { class: "actions" }, h("button", { class: "btn primary", type: "submit" }, u.url ? "Save and check" : "Connect")))));
  };
  // three steps to turn it on - each ticks itself off
  let relStep = null;
  const copyBox = cmd => h("div", { class: "inline gap-top" }, h("pre", { class: "log grow" }, "cd /opt/ics-ranges\n" + cmd),
    h("button", { class: "btn", type: "button", onclick: () => navigator.clipboard.writeText("cd /opt/ics-ranges\n" + cmd).then(() => toast("Copied.")).catch(() => toast("Select the text and copy it.", true)) }, "Copy"));
  const step = (done, title, ...body) => h("li", { class: done ? "done" : "todo" }, h("b", {}, (done ? "\u2713 " : "") + title), done ? null : h("div", { class: "small" }, ...body));
  const drawHost = u => {
    const up = u.updater;
    const hostOk = up.installed && up.writable && up.matches;
    relStep = h("li", { class: "todo" }, h("b", {}, "Publish a version"), h("div", { class: "small muted" }, "Reading the repository…"));
    host.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, hostOk && u.url ? "Software updates are on" : "Turn on software updates"), h("span", { class: "muted small" }, "This version: " + u.current)),
      h("div", { class: "body" }, h("ol", { class: "checklist" },
        step(!!u.url, "Connect the repository" + (u.url ? " – " + u.url : ""), "Fill in Repository below: the address of your ics-ranges-app, your user name and a read-only token."),
        step(hostOk, "Let the host install updates" + (hostOk ? " – it allows " + up.pinned : ""),
          !up.installed || !up.writable ? "Once, on the ICS Ranges host – it asks for anything that is missing, and also connects this page if you haven't yet:" :
            "The host only allows " + up.pinned + " – to allow this repository, run on the host:", copyBox(u.command || "sudo ./setup.sh updater"),
          h("p", { class: "muted small" }, "The page can't replace itself (it has no access to Docker, on purpose); the host downloads the version you pick, checks it, installs it, and goes back if it doesn't start.")),
        relStep))));
  };
  const loadReleases = u => {
    list.replaceChildren(h("section", { class: "panel" }, h("div", { class: "body muted" }, "Reading releases…")));
    api("GET", "/api/updates/releases").then(r => {
      const can = ready(u) && !busy(u.updater);
      const good = r.releases.filter(x => x.installable);
      if (relStep) relStep.replaceWith(step(good.length > 0, good.length ? "Versions to install – " + plural(good.length, "release") : "Publish a version",
        r.releases.length ? "The releases are missing files – on the machine with your source folder run ./release.sh publish <version>." :
          "No releases yet. On the machine with your source folder: ./release.sh /path/to/ics-ranges.zip – it adds the version to Gitea and asks whether to publish it."));
      const rows = r.releases.map(x => h("tr", {},
        h("td", {}, h("b", {}, x.tag), x.prerelease ? h("span", { class: "chip" }, "pre-release") : null),
        h("td", {}, x.name, x.notes ? h("details", {}, h("summary", { class: "small" }, "What's new"), h("div", { class: "guidetext small" }, renderGuide(x.notes))) : null),
        h("td", { class: "muted small" }, x.date),
        h("td", {}, x.relation === "current" ? h("span", { class: "chip" }, "this version") : x.relation === "newer" ? h("span", { class: "chip new" }, "newer") : h("span", { class: "muted small" }, "older")),
        h("td", {}, h("div", { class: "actions" }, x.relation === "current" ? null : !x.installable ? h("span", { class: "muted small", title: "./release.sh publish " + x.tag + " adds what is missing" }, "missing " + x.missing.join(" and ")) :
          h("button", { class: "btn" + (x.relation === "newer" ? " primary" : ""), type: "button", disabled: !can,
            title: can ? "" : "Set up the host's updater first (above)",
            onclick: () => {
              const msg = (x.relation === "newer" ? "Update ICS Ranges from " + u.current + " to " + x.tag : "Go back from " + u.current + " to the older " + x.tag) +
                "?\n\nICS Ranges restarts during the update (about a minute); users, courses and content stay.";
              if (!confirm(msg)) return;
              api("POST", "/api/updates/install", { tag: x.tag }).then(() => { toast("Update to " + x.tag + " requested."); window.scrollTo({ top: 0, behavior: "smooth" }); poll(); }).catch(fail);
            } }, x.relation === "newer" ? "Update to " + x.tag : "Go back to " + x.tag)))));
      list.replaceChildren(h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "Versions"), h("button", { class: "btn quiet", type: "button", onclick: () => loadReleases(u) }, "Check again")),
        r.releases.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Version", "Release", "Date", "", ""].map(t => h("th", {}, t)))), h("tbody", {}, rows))) :
          h("div", { class: "body muted" }, "No releases in this repository yet.")));
    }).catch(e => list.replaceChildren(h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "error-text" }, e.message)))));
  };
  // follow an update, also while ICS Ranges restarts
  const poll = () => {
    if (polling) return;
    polling = true;
    const was = S.session.version;
    const tick = async () => {
      if (!document.body.contains(main)) { polling = false; return; }
      let u = null;
      try { u = await api("GET", "/api/updates"); } catch (e) {
        prog.replaceChildren(h("section", { class: "panel" }, h("div", { class: "body" }, h("div", { class: "result busy" }, lamp("running-step"), " ICS Ranges is restarting with the new version…"))));
        setTimeout(tick, 3000); return;
      }
      drawProg(u.updater);
      if (busy(u.updater)) { setTimeout(tick, 2000); return; }
      polling = false;
      if (u.current !== was) { toast("ICS Ranges " + u.current + " is running – reloading the page."); setTimeout(() => location.reload(), 1500); return; }
      load();
    };
    tick();
  };
  const load = async () => {
    let u;
    try { u = await api("GET", "/api/updates"); } catch (e) { fail(e); return; }
    drawProg(u.updater); drawConn(u); drawHost(u);
    if (u.url) loadReleases(u); else list.replaceChildren();
    if (busy(u.updater)) poll();
  };
  load();
  return main;
}

/* ---------- add-ons: a form, a step builder, or the script itself ---------- */
// The steps the builder offers. Each runs on all the guests, then the next step starts.
const ADDON_STEPS = {
  start: { label: "Power on", guests: true, opts: [["gap", "Seconds between guests (0 = all straight away)", "num", 0]] },
  shutdown: { label: "Shut down", guests: true, opts: [["timeout", "Seconds to wait before forcing them off", "num", 180]] },
  stop: { label: "Power off at once", guests: true, opts: [] },
  snap_restore: { label: "Restore a snapshot", guests: true, opts: [["name", "Snapshot", "snap", "ClassStart"]] },
  snap_take: { label: "Take a snapshot", guests: true, opts: [["name", "Snapshot name ({date} = today's date)", "snap", "Before-{date}"], ["mem", "Include the memory of running VMs", "bool", false]] },
  snap_delete: { label: "Delete a snapshot", guests: true, opts: [["name", "Snapshot", "snap", "Before-{date}"]] },
  status: { label: "Show their state", guests: true, opts: [] },
  ips: { label: "Show IP addresses (VMs with the guest agent)", guests: true, opts: [] },
  efi: { label: "Enroll EFI keys (UEFI VMs that are off)", guests: true, opts: [] },
  wait: { label: "Wait", guests: false, opts: [["secs", "Seconds", "num", 30]] },
  custom: { label: "Your own commands", guests: false, opts: [["code", "Commands – $id is the guest when it runs on guests", "code", "echo \"$id\""]] },
};
const SNAP_RE = /^[A-Za-z][A-Za-z0-9_{}-]{0,39}$/;
const shq = v => "'" + String(v).replace(/'/g, "'\\''") + "'";

// the bash for a list of steps - plain, commented, and safe with VMs and containers
function addonScript(steps, onGuests) {
  const L = [];
  const snap = n => String(n).includes("{date}") ? '"' + String(n).replace(/\{date\}/g, "$(date +%Y%m%d)") + '"' : shq(n);
  const loop = (title, body, name) => { L.push("", "step " + shq(title) + (name ? " " + snap(name) : ""), "for id in $GUESTS; do", "    t=$(tool \"$id\")", ...body.map(x => "    " + x), "done"); };
  L.push("set -u", "failed=0",
    "step() { echo; echo \"== $*\"; }",
    "tool() { if qm config \"$1\" >/dev/null 2>&1; then echo qm; else echo pct; fi; }   # VM or container",
    "state() { $(tool \"$1\") status \"$1\" 2>/dev/null | sed 's/^status: //'; }",
    "has_snap() { $(tool \"$1\") listsnapshot \"$1\" 2>/dev/null | grep -qx \"$2\"; }",
    "bad() { echo \"  $1: FAILED\"; failed=$((failed + 1)); }");
  if (onGuests) L.push("[[ -n ${GUESTS// /} ]] || { echo \"No guests - select some first.\"; exit 1; }");
  for (const st of steps) {
    const o = st;
    switch (st.k) {
      case "start": loop("Power on", ["if [[ $(state \"$id\") == running ]]; then echo \"  $id: already running\"",
        "elif $t start \"$id\" >/dev/null; then echo \"  $id: started\"", "else bad \"$id\"; fi",
        ...(+o.gap > 0 ? ["sleep " + (+o.gap)] : [])]); break;
      case "shutdown": loop("Shut down", ["if [[ $(state \"$id\") != running ]]; then echo \"  $id: already off\"",
        "elif $t shutdown \"$id\" --timeout " + Math.max(10, +o.timeout || 180) + " --forceStop 1 >/dev/null; then echo \"  $id: shut down\"", "else bad \"$id\"; fi"]); break;
      case "stop": loop("Power off", ["if [[ $(state \"$id\") != running ]]; then echo \"  $id: already off\"",
        "elif $t stop \"$id\" >/dev/null; then echo \"  $id: off\"", "else bad \"$id\"; fi"]); break;
      case "snap_restore": loop("Restore", ["if ! has_snap \"$id\" " + snap(o.name) + "; then echo \"  $id: has no " + o.name + " - skipped\"",
        "elif $t rollback \"$id\" " + snap(o.name) + " >/dev/null; then echo \"  $id: restored\"", "else bad \"$id\"; fi"], o.name); break;
      case "snap_take": loop("Snapshot", ["mem=()",
        ...(o.mem ? ["[[ $t == qm && $(state \"$id\") == running ]] && mem=(--vmstate 1)"] : []),
        "if $t snapshot \"$id\" " + snap(o.name) + " \"${mem[@]}\" >/dev/null; then echo \"  $id: snapshot taken\"", "else bad \"$id\"; fi"], o.name); break;
      case "snap_delete": loop("Delete snapshot", ["if ! has_snap \"$id\" " + snap(o.name) + "; then echo \"  $id: has no " + o.name + " - skipped\"",
        "elif $t delsnapshot \"$id\" " + snap(o.name) + " >/dev/null; then echo \"  $id: deleted\"", "else bad \"$id\"; fi"], o.name); break;
      case "status": loop("State", ["echo \"  $id: $(state \"$id\")  $($t config \"$id\" 2>/dev/null | sed -n 's/^\\(name\\|hostname\\): //p')\""]); break;
      case "ips": loop("IP addresses", ["[[ $t == qm && $(state \"$id\") == running ]] || { echo \"  $id: not a running VM - skipped\"; continue; }",
        "ips=$(qm guest cmd \"$id\" network-get-interfaces 2>/dev/null | jq -r '.. | objects | select(.\"ip-address-type\"? == \"ipv4\") | .\"ip-address\"' | grep -v '^127\\.' | paste -sd' ' -)",
        "echo \"  $id: ${ips:-no answer from the guest agent}\""]); break;
      case "efi": loop("Enroll EFI keys", ["cfg=$(qm config \"$id\" 2>/dev/null) || { echo \"  $id: a container - skipped\"; continue; }",
        "grep -q '^bios: ovmf' <<<\"$cfg\" || { echo \"  $id: not UEFI - skipped\"; continue; }",
        "grep -q '^efidisk0:' <<<\"$cfg\" || { echo \"  $id: no EFI disk - skipped\"; continue; }",
        "grep -q '^efidisk0:.*pre-enrolled-keys=1' <<<\"$cfg\" && { echo \"  $id: already has the keys\"; continue; }",
        "[[ $(state \"$id\") == stopped ]] || { echo \"  $id: running - switch it off first\"; continue; }",
        "if qm enroll-efi-keys \"$id\" >/dev/null; then echo \"  $id: keys enrolled\"; else bad \"$id\"; fi"]); break;
      case "wait": L.push("", "step " + shq("Wait " + (+o.secs) + (+o.secs === 1 ? " second" : " seconds")), "sleep " + Math.max(0, +o.secs || 0)); break;
      case "custom": {
        const code = String(o.code || "").replace(/\r/g, "").split("\n");
        if (onGuests) loop("Your commands", code);
        else L.push("", "step " + shq("Your commands"), ...code);
        break;
      }
    }
  }
  L.push("", "echo", "if ((failed)); then echo \"$failed step(s) failed - see above.\"; exit 1; fi", "echo \"Done.\"");
  return L.join("\n") + "\n";
}

// "1-3, 7" -> "1 2 3 7" (at most 1000)
function vmidList(text) {
  const out = [];
  for (const part of (text || "").split(/[\s,]+/)) {
    const m = part.match(/^(\d+)(?:-(\d+))?$/);
    if (m) for (let v = +m[1]; v <= +(m[2] || m[1]) && out.length < 1000; v++) out.push(v);
  }
  return out;
}

// read an add-on file: the header (name, description, guests, steps) and the rest
function addonParse(text) {
  const meta = { name: "", desc: "", guests: "select", ids: "", steps: null, body: "" };
  const lines = (text || "").replace(/\r/g, "").split("\n");
  let i = 0;
  if (/^#!/.test(lines[0] || "")) i++;
  for (; i < lines.length; i++) {
    const l = lines[i];
    let m;
    if ((m = l.match(/^#\s*NAME:\s*(.*)$/))) meta.name = m[1].trim();
    else if ((m = l.match(/^#\s*DESC:\s*(.*)$/))) meta.desc = m[1].trim();
    else if ((m = l.match(/^#\s*GUESTS:\s*(.*)$/))) meta.guests = /^(yes|1|true)$/i.test(m[1].trim()) ? "select" : meta.guests === "fixed" ? "fixed" : "none";
    else if ((m = l.match(/^#\s*IDS:\s*(.*)$/))) { meta.ids = m[1].trim(); meta.guests = "fixed"; }
    else if ((m = l.match(/^#\s*STEPS:\s*(.*)$/))) { try { meta.steps = JSON.parse(m[1]); } catch (e) { meta.steps = null; } }
    else if (/^#\s*Made with the add-on builder/.test(l) || /^#\s*$/.test(l) && i < 8) continue;
    else break;
  }
  let rest = lines.slice(i);
  const a = rest.indexOf("#>>> guests (from the add-on's form)"), b = rest.indexOf("#<<<");
  if (a >= 0 && b > a) rest = rest.slice(0, a).concat(rest.slice(b + 1));
  while (rest.length && rest[0].trim() === "") rest.shift();
  meta.body = rest.join("\n");
  return meta;
}

// write an add-on file from the form - nobody has to type the header lines
function addonCompose(meta, body, steps) {
  const L = ["#!/usr/bin/env bash", "# NAME: " + meta.name.replace(/\n/g, " "), "# DESC: " + (meta.desc || "").replace(/\n/g, " "),
    "# GUESTS: " + (meta.guests === "select" ? "yes" : "no")];
  if (meta.guests === "fixed") L.push("# IDS: " + meta.ids.trim());
  if (steps) L.push("# STEPS: " + JSON.stringify(steps), "# Made with the add-on builder in ICS Ranges - open it there to change the steps.");
  L.push("");
  if (meta.guests === "fixed") L.push("#>>> guests (from the add-on's form)", "GUESTS=" + shq(vmidList(meta.ids).join(" ")), "#<<<", "");
  return L.join("\n") + body.replace(/^\n+/, "");
}

function addonEditor(course, scope, file, text, isNew, taken, done) {
  const meta = addonParse(text);
  if (isNew && !text) meta.steps = [{ k: "status" }];
  let mode = meta.steps ? "steps" : "script";
  let steps = meta.steps ? meta.steps.map(s => Object.assign({}, s)) : [];
  dialog((d, close) => {
    d.classList.add("wide");
    const name = h("input", { type: "text", value: meta.name || (file ? file.replace(/\.sh$/, "") : ""), required: true, maxlength: 60, placeholder: "e.g. Reset student desktops", autofocus: true });
    const desc = h("input", { type: "text", value: meta.desc, maxlength: 120, placeholder: "One line – shown in the list" });
    const where = h("select", {}, h("option", { value: course, selected: scope !== "_all" }, "Only " + course), h("option", { value: "_all", selected: scope === "_all" }, "All courses"));
    const gSel = h("input", { type: "radio", name: "ag", checked: meta.guests === "select" }), gFix = h("input", { type: "radio", name: "ag", checked: meta.guests === "fixed" }),
      gNone = h("input", { type: "radio", name: "ag", checked: meta.guests === "none" });
    const ids = h("input", { type: "text", value: meta.ids, placeholder: "510101-510105, 521001" });
    const onGuests = () => !gNone.checked;
    const runs = () => gSel.checked ? "select" : gFix.checked ? "fixed" : "none";
    const ta = h("textarea", { "aria-label": "Script", spellcheck: "false", class: "code" });
    ta.value = meta.steps ? addonScript(steps, onGuests()) : meta.body;
    const stepBox = h("div", { class: "addon-steps" }), preview = h("pre", { class: "log small" });
    const tabSteps = h("button", { type: "button", role: "tab" }, "Build it from steps"), tabScript = h("button", { type: "button", role: "tab" }, "Write the script");
    const paneSteps = h("div"), paneScript = h("div");
    const insert = s => { const p = ta.selectionStart; ta.value = ta.value.slice(0, p) + s + ta.value.slice(ta.selectionEnd); ta.focus(); ta.selectionStart = ta.selectionEnd = p + s.length; };
    const SNIPS = [["For each guest", 'for id in $GUESTS; do\n    echo "== $id"\n    \ndone\n'], ["Power on", 'qm start "$id"\n'], ["Shut down", 'qm shutdown "$id" --timeout 180 --forceStop 1\n'],
      ["Snapshot", 'qm snapshot "$id" "Before-$(date +%Y%m%d)"\n'], ["Restore", 'qm rollback "$id" ClassStart\n'], ["Only if running", 'if [[ $(qm status "$id") == "status: running" ]]; then\n    \nfi\n'],
      ["Container (pct)", 'pct start "$id"\n']];
    const drawSteps = () => {
      const kinds = Object.entries(ADDON_STEPS).filter(([, v]) => onGuests() || !v.guests);
      steps = steps.filter(s => ADDON_STEPS[s.k] && (onGuests() || !ADDON_STEPS[s.k].guests));
      stepBox.replaceChildren(...steps.map((st, i) => {
        const def = ADDON_STEPS[st.k];
        const opts = def.opts.map(([key, label, type, dflt]) => {
          if (st[key] === undefined) st[key] = dflt;
          const inp = type === "bool" ? h("input", { type: "checkbox", checked: !!st[key] }) :
            type === "code" ? h("textarea", { class: "code small-code", spellcheck: "false" }) :
            h("input", { type: type === "num" ? "number" : "text", min: 0, value: st[key], ...(type === "snap" ? { maxlength: 40, title: "Starts with a letter: letters, digits, - and _ ({date} = today)" } : {}) });
          if (type === "code") inp.value = st[key];
          inp.addEventListener(type === "bool" ? "change" : "input", () => { st[key] = type === "bool" ? inp.checked : type === "num" ? +inp.value : inp.value; drawPreview(); });
          return type === "bool" ? h("label", { class: "check" }, inp, label) : h("label", { class: "field" }, label, inp);
        });
        const move = (j) => { const x = steps.splice(i, 1)[0]; steps.splice(j, 0, x); drawSteps(); };
        return h("div", { class: "addon-step" },
          h("div", { class: "addon-step-head" }, h("span", { class: "num" }, String(i + 1)), h("b", {}, def.label),
            h("span", { class: "grow" }),
            h("button", { class: "btn quiet small", type: "button", disabled: i === 0, title: "Earlier", onclick: () => move(i - 1) }, "\u2191"),
            h("button", { class: "btn quiet small", type: "button", disabled: i === steps.length - 1, title: "Later", onclick: () => move(i + 1) }, "\u2193"),
            h("button", { class: "btn quiet small danger", type: "button", title: "Remove", onclick: () => { steps.splice(i, 1); drawSteps(); } }, "\u2715")),
          opts.length ? h("div", { class: "addon-step-opts" }, opts) : null);
      }));
      const add = h("select", { onchange: e => { if (!e.target.value) return; steps.push({ k: e.target.value }); drawSteps(); } },
        h("option", { value: "" }, "+ Add a step…"), kinds.map(([k, v]) => h("option", { value: k }, v.label)));
      stepBox.append(h("div", { class: "addon-add" }, add,
        h("span", { class: "muted small" }, steps.length ? (onGuests() ? "Each step runs on all the guests, then the next step starts." : "The steps run in this order.") : "Add the first step.")));
      drawPreview();
    };
    const drawPreview = () => { preview.textContent = addonScript(steps, onGuests()); };
    const showMode = m => {
      if (m === "script" && mode === "steps") ta.value = addonScript(steps, onGuests());   // carry the steps over as a script
      if (m === "steps" && mode === "script" && !meta.steps && ta.value.trim() && !confirm("Start from steps instead? The script below is replaced when you save.")) return;
      mode = m;
      tabSteps.setAttribute("aria-selected", m === "steps"); tabScript.setAttribute("aria-selected", m === "script");
      paneSteps.hidden = m !== "steps"; paneScript.hidden = m !== "script";
      if (m === "steps") drawSteps();
    };
    tabSteps.onclick = () => showMode("steps"); tabScript.onclick = () => showMode("script");
    [gSel, gFix, gNone].forEach(r => r.addEventListener("change", () => { ids.disabled = !gFix.checked; if (mode === "steps") drawSteps(); }));
    ids.disabled = !gFix.checked;
    paneSteps.append(stepBox, h("details", {}, h("summary", { class: "small" }, "The script these steps make"), preview));
    paneScript.append(
      h("div", { class: "snips" }, h("span", { class: "muted small" }, "Insert:"), SNIPS.map(([t, s]) => h("button", { class: "btn quiet small", type: "button", onclick: () => insert(s) }, t))),
      ta,
      h("details", { class: "small" }, h("summary", {}, "What you can use"),
        h("ul", { class: "small" },
          h("li", {}, h("code", {}, "$GUESTS"), " – the guests' VMIDs, e.g. 510101 510102 (from Runs on)"), h("li", {}, h("code", {}, "$COURSE"), " – this course"),
          h("li", {}, h("code", {}, "qm"), " (VMs) and ", h("code", {}, "pct"), " (containers): start, shutdown, stop, reboot, status, config, set, snapshot, rollback, delsnapshot, listsnapshot, migrate, guest cmd"),
          h("li", {}, h("code", {}, "qm enroll-efi-keys <vmid>"), " – with the node key; ", h("code", {}, "pvesh get …"), ", ", h("code", {}, "jq"), ", ", h("code", {}, "curl")),
          h("li", {}, "Not possible here: sudo, questions that wait for typing, files or ssh on the nodes. An add-on stops after 30 minutes."))));
    d.append(h("form", { onsubmit: async e => {
      e.preventDefault();
      const nm = name.value.trim();
      if (!nm) return;
      const m = { name: nm, desc: desc.value.trim(), guests: runs(), ids: ids.value };
      if (m.guests === "fixed" && !vmidList(ids.value).length) { toast("Give the VMIDs it runs on, e.g. 510101-510105.", true); return; }
      if (mode === "steps") {
        if (!steps.length) { toast("Add at least one step.", true); return; }
        const badSnap = steps.find(s => s.name !== undefined && !SNAP_RE.test(s.name));
        if (badSnap) { toast("Snapshot names start with a letter: letters, digits, - and _.", true); return; }
      }
      const body = mode === "steps" ? addonScript(steps, m.guests !== "none") : ta.value;
      const out = addonCompose(m, body, mode === "steps" ? steps : null);
      let f = file;
      if (isNew) {   // the file name comes from the name: "Reset student desktops" -> Reset-student-desktops.sh
        const base = nm.replace(/\s+/g, "-").replace(/[^A-Za-z0-9_.-]/g, "").replace(/^[.-]+/, "").slice(0, 55) || "addon";
        f = base + ".sh";
        for (let n = 2; taken.includes(f); n++) f = base + "-" + n + ".sh";
      }
      try {
        if (!isNew && where.value !== scope) await api("PUT", "/api/addons/" + scope + "/" + f, { text: out, move_to: where.value });
        else await api("PUT", "/api/addons/" + encodeURIComponent(where.value) + "/" + f, { text: out });
        toast("Add-on " + nm + " saved."); close(); done();
      } catch (ex) { fail(ex); }
    } },
      h("header", {}, h("h2", {}, isNew ? "New add-on" : "Add-on " + (meta.name || file)),
        h("p", { class: "muted small" }, "An add-on is a script that runs here, on the guests you pick, with the Proxmox API. Build it from steps – or write it yourself.")),
      h("div", { class: "content" },
        h("div", { class: "cols" }, h("label", { class: "field" }, "Name", name), h("label", { class: "field" }, "For", where)),
        h("label", { class: "field" }, "What it does", desc),
        h("div", { class: "field" }, h("span", {}, "Runs on"), h("div", { class: "radio-row stacked" },
          h("label", { class: "check" }, gSel, "The guests you select before pressing Run"),
          h("label", { class: "check" }, gFix, "These guests every time: ", ids),
          h("label", { class: "check" }, gNone, "No particular guests"))),
        h("div", { class: "tabs", role: "tablist" }, tabSteps, tabScript),
        paneSteps, paneScript),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save add-on"))));
    showMode(mode);
  });
}
