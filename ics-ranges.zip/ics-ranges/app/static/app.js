"use strict";
/* ICS Ranges - front end. Talks only to its own server (/api/...). */

const S = {
  session: null, courses: [], course: null, data: null, mirrors: null, overview: null,
  selected: new Set(), filter: "", tab: "guests", timer: null,
};
const can = p => S.session && S.session.perms.includes(p);

/* ---------- tiny DOM helper: text is always set as text, never as HTML ---------- */
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") throw new Error("no html");
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat(9)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}
const svg = d => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 20 20"); s.setAttribute("aria-hidden", "true"); const p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", d); s.append(p); return s; };
const ICON_START = "M6 3.5v13l11-6.5z", ICON_END = "M4.5 4.5h11v11h-11z";
const lamp = (state, label) => h("span", { class: "lamp " + state, role: "img", "aria-label": label || state });
const plural = (n, one, many) => n + " " + (n === 1 ? one : (many || one + "s"));

function toast(msg, err) {
  const t = h("div", { class: "toast" + (err ? " err" : "") }, msg);
  document.getElementById("toasts").append(t);
  setTimeout(() => t.remove(), err ? 7000 : 3500);
}

/* the version this page was loaded with - the server says on every answer which version runs */
const PAGE_VERSION = (document.querySelector('meta[name="ics-version"]') || {}).content || "";
function newVersion(v) {   // ICS Ranges was updated while this page was open
  if (S.newVersion) return;
  S.newVersion = v;
  const bar = h("div", { class: "updatebar", role: "alert" },
    h("span", {}, h("b", {}, "ICS Ranges was updated to " + v + "."), " This page still runs " + PAGE_VERSION + " – reload to get the new one."),
    h("button", { class: "btn primary small", type: "button", onclick: () => location.reload() }, "Reload now"));
  document.body.prepend(bar);
  // and it reloads by itself at the next change of page - nothing half-done is lost
  window.addEventListener("hashchange", () => location.reload(), { once: true });
}

async function api(method, path, body) {
  const r = await fetch(path, {
    method, credentials: "same-origin",
    headers: Object.assign({ "X-PVR": "1" }, body ? { "Content-Type": "application/json" } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  const sv = r.headers.get("X-ICS-Version");
  if (sv && PAGE_VERSION && sv !== PAGE_VERSION) newVersion(sv);
  let j = {};
  try { j = await r.json(); } catch (e) { /* empty */ }
  if (r.status === 401 && !path.startsWith("/api/login")) { S.session = null; render(); throw new Error(j.error || "Sign in again."); }
  if (!r.ok && !j.need_code) throw new Error(j.error || ("Request failed (" + r.status + ")"));
  return j;
}
const fail = e => toast(e.message || String(e), true);

/* ---------- dialogs ---------- */
function dialog(build) {
  const d = h("dialog");
  document.body.append(d);
  const close = () => { d.close(); d.remove(); };
  d.addEventListener("cancel", e => { if (d.dataset.busy) e.preventDefault(); else setTimeout(() => d.remove(), 0); });
  build(d, close);
  d.showModal();
  const first = d.querySelector("[autofocus]") || d.querySelector("input, select, button.primary");
  if (first) first.focus();
  return d;
}

/* ================================================================== sign-in */
function renderSignin(setup) {
  const err = h("p", { class: "error", role: "alert" });
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true, autofocus: true });
  const pw = h("input", { type: "password", name: "password", autocomplete: setup ? "new-password" : "current-password", required: true });
  const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", pattern: "[0-9 ]{6,7}" });
  const codeField = h("label", { class: "field", hidden: true }, "6-digit code from your authenticator app", code);
  const btn = h("button", { class: "btn primary", type: "submit" }, setup ? "Create admin and sign in" : "Sign in");
  const form = h("form", {
    onsubmit: async e => {
      e.preventDefault(); err.textContent = ""; btn.disabled = true;
      try {
        if (setup) {
          await api("POST", "/api/setup", { user: user.value, password: pw.value });
        } else {
          const r = await api("POST", "/api/login", { user: user.value, password: pw.value, code: code.value });
          if (r.need_code) { codeField.hidden = false; code.focus(); if (r.error) err.textContent = r.error; btn.disabled = false; return; }
        }
        await boot();
      } catch (ex) { err.textContent = ex.message; }
      btn.disabled = false;
    },
  },
    h("div", { class: "mark" }, h("img", { class: "logo", src: "/logo.png", alt: "" }), h("h1", {}, "ICS Ranges")),
    setup ? h("p", { class: "muted" }, "No users yet. Create the first admin – admins add everyone else from inside.") : null,
    h("label", { class: "field" }, "Name", user),
    h("label", { class: "field" }, "Password", setup ? h("span", { class: "hint" }, "At least 10 characters") : null, pw),
    codeField, err, btn);
  return h("div", { class: "signin" }, form);
}

/* ================================================================== frame */
function rail() {
  const route = location.hash;
  const link = (href, ...kids) => h("a", { href, "aria-current": route === href ? "page" : false }, ...kids);
  const admin = [];
  if (can("users")) admin.push(link("#/users", h("span", { class: "name" }, "Users")));
  if (can("settings")) admin.push(link("#/roles", h("span", { class: "name" }, "Roles")), link("#/map", h("span", { class: "name" }, "Course map")));
  if (can("users")) admin.push(link("#/activity", h("span", { class: "name" }, "Activity")));
  if (can("save")) admin.push(link("#/share", h("span", { class: "name" }, "Save & share")));
  if (can("settings")) admin.push(link("#/settings", h("span", { class: "name" }, "Settings")));
  if (can("software")) admin.push(link("#/updates", h("span", { class: "name" }, "Software updates",
    S.session.update_available ? h("span", { class: "chip new", title: S.session.update_available + " is available" }, "new") : null)));
  admin.push(link("#/help", h("span", { class: "name" }, "Help")));
  return h("aside", { class: "rail" },
    h("div", { class: "brand" }, h("img", { class: "logo", src: "/logo.png", alt: "" }), h("h1", {}, "ICS Ranges"), h("span", { class: "ver" }, S.session.version)),
    offlineNote(),
    h("nav", { "aria-label": "Courses" },
      h("div", { class: "group-label" }, "Courses"),
      S.courses.length ? S.courses.map(c => link("#/course/" + encodeURIComponent(c.name),
        h("span", { class: "name" }, c.name, c.mixed ? h("span", { class: "chip", title: c.expires ? "One-shot course until " + c.expires : "Mixed course" }, c.expires ? "one-shot" : "mixed") : null),
        h("span", { class: "count" }, lamp(c.running ? "running" : "", c.running + " running"), c.running + "/" + c.count),
        h("span", { class: "desc" }, c.desc || "\u00a0"))) : h("p", { class: "muted small pad-x" }, S.offline ? "Proxmox isn't answering, and no guests are known yet." : "No courses with guests for you."),
      admin.length ? [h("div", { class: "group-label" }, admin.length > 1 ? "Manage" : ""), admin.map(a => { a.classList.add("simple"); return a; })] : null),
    h("div", { class: "me" },
      h("div", { class: "who" }, h("b", {}, S.session.user), h("span", {}, S.session.role)),
      h("button", { class: "btn quiet", type: "button", onclick: accountDialog, title: "Your password and 2FA" }, "Account"),
      h("button", { class: "btn quiet", type: "button", onclick: signOut }, "Sign out")));
}

async function signOut() {
  try { await api("POST", "/api/logout"); } catch (e) { /* ignore */ }
  S.session = null; render();
}

function render() {
  const root = document.getElementById("root");
  clearInterval(S.timer);
  if (!S.session) { root.replaceChildren(renderSignin(S.setup)); return; }
  const r = location.hash.replace(/^#\//, "").split("/");
  let main;
  if (r[0] === "users" && can("users")) main = pageUsers();
  else if (r[0] === "roles" && can("settings")) main = pageRoles();
  else if (r[0] === "map" && can("settings")) main = pageMap();
  else if (r[0] === "activity" && can("users")) main = pageActivity();
  else if (r[0] === "share" && can("save")) main = pageShare();
  else if (r[0] === "settings" && can("settings")) main = pageSettings();
  else if (r[0] === "help") main = pageHelp();
  else if (r[0] === "updates" && can("software")) main = pageUpdates();
  else {
    const name = decodeURIComponent(r[1] || "");
    const c = S.courses.find(x => x.name === name) || S.courses[0];
    if (c && name !== c.name) { location.replace("#/course/" + encodeURIComponent(c.name)); return; }
    main = c ? pageCourse(c) : h("main", {}, h("p", {}, "There are no guests in any of your courses. Ask an admin to check your courses."));
  }
  root.replaceChildren(h("div", { class: "app" }, rail(), main));
}
window.addEventListener("hashchange", () => { S.selected.clear(); S.data = null; S.mirrors = null; S.netsum = null; S.overview = null; S.tab = "guests"; render(); });

/* ================================================================== course page */
function pageCourse(c) {
  const main = h("main", { "aria-busy": "true" }, h("p", { class: "muted" }, "Reading the course…"));
  if (!S.data || S.data.course !== c.name) loadCourse(c.name);
  else { fillCourse(main, c); }
  S.timer = setInterval(() => { if (!document.hidden && !document.querySelector("dialog[open]")) loadCourse(c.name, true); }, 10000);
  return main;
}

async function loadCourse(name, quiet) {
  try {
    // one request brings the course and the course list; the page is only redrawn when
    // something changed, so the 10-second refresh costs (almost) nothing when all is quiet
    const data = await api("GET", "/api/course/" + encodeURIComponent(name) + "?with=courses" + (quiet ? "" : "&fresh=1"));
    const courses = data.courses || S.courses;
    delete data.courses;
    const sig = JSON.stringify(data) + JSON.stringify(courses);
    const same = quiet && sig === S.sig;
    S.sig = sig;
    S.courses = courses;
    S.data = data;
    if (JSON.stringify(S.offline || null) !== JSON.stringify(data.offline || null)) { S.offline = data.offline || null; const n = document.getElementById("offline-note"); if (n) n.replaceWith(offlineNote()); }
    if (can("mirror_status") && (!quiet || !S.mirrors)) api("GET", "/api/mirrors?course=" + encodeURIComponent(name)).then(m => { S.mirrors = m; refill(); }).catch(() => {});
    if (can("mirror_status") && (!quiet || !S.netsum)) api("GET", "/api/netsummary?course=" + encodeURIComponent(name)).then(m => { S.netsum = m; refill(); }).catch(() => {});
    if (!same) refill();
  } catch (e) { if (!quiet) fail(e); }
}
function refill() {
  const main = document.querySelector("main");
  const c = S.courses.find(x => x.name === (S.data && S.data.course));
  if (!main || !c || /^#\/(users|roles|map|activity|share|settings|help|updates)/.test(location.hash)) return;
  const keepFocus = document.activeElement && document.activeElement.id;
  const rail_ = document.querySelector(".rail");
  if (rail_) rail_.replaceWith(rail());
  fillCourse(main, c);
  if (keepFocus) { const el = document.getElementById(keepFocus); if (el) { el.focus(); if (el.setSelectionRange && el.value) el.setSelectionRange(el.value.length, el.value.length); } }
}

function fillCourse(main, c) {
  const d = S.data, gs = d.guests;
  const running = gs.filter(g => g.status === "running").length;
  main.removeAttribute("aria-busy");
  const kids = [
    h("div", { class: "head" },
      h("div", { class: "title" }, h("h1", {}, c.name), h("div", { class: "sub" }, c.desc || "")),
      h("div", { class: "strip" },
        h("span", {}, h("b", {}, running), "running"),
        h("span", {}, h("b", {}, gs.length - running), "off"),
        h("button", { class: "btn quiet", type: "button", onclick: () => loadCourse(c.name) }, "Refresh"))),
  ];
  const top = [];
  if (can("class_run")) top.push(faceplate(c));
  if (can("mirror_status")) top.push(mirrorPanel(c));
  if (top.length) kids.push(h("div", { class: "cols" + (top.length === 1 ? " one" : "") }, top));
  const tabs = [["guests", "Guests"]];
  if (can("guide_read")) tabs.push(["guide", "Class guide"]);
  if (can("addons_run")) tabs.push(["addons", "Add-ons"]);
  if (can("overview")) tabs.push(["storage", "Storage and disks"]);
  if (tabs.length > 1) kids.push(h("div", { class: "tabs", role: "tablist" }, tabs.map(([k, t]) =>
    h("button", { role: "tab", type: "button", "aria-selected": S.tab === k ? "true" : "false", onclick: () => { S.tab = k; refill(); } }, t))));
  kids.push(S.tab === "storage" ? storagePanel(c) : S.tab === "guide" ? guidePanel(c) : S.tab === "addons" ? addonPanel(c) : guestPanel(c));
  main.replaceChildren(...kids);
}

/* ---------- the class faceplate ---------- */
function snapshotSelect(id) {
  const sel = h("select", { id });
  const list = S.data.snapshots;
  if (!list.length) sel.append(h("option", { value: "" }, "No snapshots in this course"));
  for (const s of list) sel.append(h("option", { value: s.name }, s.name + " (" + plural(s.count, "guest") + (s.ram ? ", " + s.ram + " with memory" : "") + ")"));
  const want = (S.session.settings && S.session.settings.default_snapshot) || "ClassStart";
  const pref = list.find(s => s.name === want) || list[0];
  if (pref) sel.value = pref.name;
  if (S.snap && list.find(s => s.name === S.snap)) sel.value = S.snap;
  sel.addEventListener("change", () => { S.snap = sel.value; });
  return sel;
}
function faceplate(c) {
  const sel = snapshotSelect("snap-pick");
  const none = !S.data.snapshots.length;
  return h("section", { class: "panel" },
    h("header", {}, h("h2", {}, "Class"),
      can("class_run") || can("overview") ? h("button", { class: "btn quiet", type: "button", title: "Snapshots, locks, storage, nodes and sensors - before the students arrive",
        onclick: () => readyDialog(c, sel.value) }, "Ready for class?") : null),
    h("div", { class: "body faceplate" },
      h("div", { class: "snap" }, h("label", { for: "snap-pick" }, "Class snapshot"), sel),
      h("div", { class: "big" },
        h("button", { class: "bigbtn start", type: "button", disabled: none, onclick: () => classDialog(c, "start", sel.value) },
          h("span", { class: "glyph" }, svg(ICON_START)), h("span", { class: "t" }, "Start class"),
          h("span", { class: "d" }, can("snap_restore") ? "Restore the snapshot, then power on" : "Power the guests on")),
        h("button", { class: "bigbtn end", type: "button", disabled: none, onclick: () => classDialog(c, "end", sel.value) },
          h("span", { class: "glyph" }, svg(ICON_END)), h("span", { class: "t" }, "End class"),
          h("span", { class: "d" }, "Reset to the snapshot and switch off")))));
}

/* Ready for class? - snapshots, locks, storage, nodes and sensors, each green / amber / red */
async function readyDialog(c, snap) {
  dialog((d, close) => {
    const body = h("div", { class: "content" }, h("p", { class: "muted" }, "Checking " + c.name + "…"));
    const again = h("button", { class: "btn", type: "button" }, "Check again");
    d.classList.add("wide");
    d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); } },
      h("header", {}, h("h2", {}, "Ready for class? – " + c.name), h("p", { class: "muted small" }, "Class snapshot: " + snap)),
      body, h("footer", {}, again, h("button", { class: "btn primary", type: "submit" }, "Close"))));
    const vmids = items => items.map(x => parseInt(x, 10)).filter(v => v > 0);
    const run = async () => {
      body.replaceChildren(h("p", { class: "muted" }, "Checking " + c.name + "…"));
      let r;
      try { r = await api("GET", "/api/ready/" + encodeURIComponent(c.name) + "?snapshot=" + encodeURIComponent(snap)); }
      catch (e) { body.replaceChildren(h("p", { class: "error-text" }, e.message)); return; }
      const fails = r.checks.filter(x => x.state === "fail").length, warns = r.checks.filter(x => x.state === "warn").length;
      const sum = fails ? h("div", { class: "result failed" }, h("b", {}, "Not ready"), " – " + plural(fails, "problem") + " to fix first" + (warns ? ", " + plural(warns, "warning") : ""))
        : warns ? h("div", { class: "result busy" }, h("b", {}, "Ready, with " + plural(warns, "warning")), " – check them below")
        : h("div", { class: "result ok" }, h("b", {}, "Ready for class"), " – everything checked is fine");
      body.replaceChildren(sum, h("ul", { class: "readylist" }, r.checks.map(x => {
        const lampState = { ok: "running", warn: "busy-static", fail: "failed", info: "" }[x.state];
        const acts = [];
        if (x.title === "Sensors" && x.state !== "ok" && can("mirror_apply"))
          acts.push(h("button", { class: "btn small", type: "button", onclick: () => { close(); planDialog({ action: "mirror_apply", course: c.name, title: "Re-apply mirrors – " + c.name }); } }, "Re-apply mirrors"));
        if (x.title.startsWith("Class snapshot") && x.state !== "ok" && can("snap_take") && S.data) {
          const gs = S.data.guests.filter(g => vmids(x.items).includes(g.vmid));
          if (gs.length) acts.push(h("button", { class: "btn small", type: "button", onclick: () => { close(); snapDialog(c, gs); } }, "Take a snapshot on these"));
        }
        return h("li", { class: "ready-" + x.state },
          h("div", { class: "ready-head" }, lamp(lampState, x.state), h("b", {}, x.title), h("span", { class: "muted" }, " – " + x.detail)),
          x.items.length ? (x.items.length > 6 ? h("details", {}, h("summary", { class: "small" }, plural(x.items.length, "guest") + " / item"), h("ul", { class: "small" }, x.items.map(i => h("li", {}, i))))
            : h("ul", { class: "small" }, x.items.map(i => h("li", {}, i)))) : null,
          x.fix ? h("p", { class: "small fix" }, "What to do: " + x.fix) : null,
          acts.length ? h("div", { class: "actions" }, acts) : null);
      })), h("p", { class: "muted small" }, "Checked " + r.at + "."));
    };
    again.onclick = run;
    run();
  });
}

async function classDialog(c, what, snap) {
  let guide = null;
  if (can("guide_read") && S.session.settings && S.session.settings.show_guide) {
    try { guide = (await api("GET", "/api/guide/" + encodeURIComponent(c.name))).text; } catch (e) { /* no guide */ }
  }
  const gs = S.data.guests;
  const has = g => g.snapshots.some(s => s.name === snap);
  const ram = g => g.snapshots.some(s => s.name === snap && s.ram);
  // who sees what: with "Restore snapshots" both columns; otherwise Start class only starts,
  // and End class has one tick per guest - reset it (restore + switch off)
  const full = can("snap_restore");
  const start = what === "start";
  const cols = start ? (full ? ["restore", "power"] : ["power"]) : ["reset"];   // End class: one Reset tick, for everyone
  const colName = { restore: "Restore", power: start ? "Start" : "Switch off", reset: "Reset" };
  const rows = gs.map(g => {
    const r = { g };
    for (const k of cols) r[k] = h("input", { type: "checkbox", checked: k === "restore" ? has(g) : true, disabled: k === "restore" && !has(g),
      "aria-label": colName[k] + " " + g.vmid, onchange: () => sync() });
    return r;
  });
  // the guests by group, each group with one tick for all its guests
  const groups = [];
  for (const r of rows) { let gr = groups.find(x => x.name === r.g.group); if (!gr) groups.push(gr = { name: r.g.group, rows: [] }); gr.rows.push(r); }
  const usable = (r, k) => !r[k].disabled;
  const groupBox = (gr, k) => h("input", { type: "checkbox", "aria-label": colName[k] + " all of " + gr.name, onchange: e => { gr.rows.forEach(r => { if (usable(r, k)) r[k].checked = e.target.checked; }); sync(); } });
  groups.forEach(gr => { gr.box = {}; cols.forEach(k => { gr.box[k] = groupBox(gr, k); }); gr.count = h("span", { class: "muted small" }); });
  const allBox = {};
  cols.forEach(k => { allBox[k] = h("input", { type: "checkbox", "aria-label": colName[k] + " all", onchange: e => { rows.forEach(r => { if (usable(r, k)) r[k].checked = e.target.checked; }); sync(); } }); });
  const sync = () => {   // group and "all" ticks follow the guests'
    const state = (rs, k) => { const u = rs.filter(r => usable(r, k)); const on = u.filter(r => r[k].checked).length; return { all: u.length && on === u.length, some: on > 0 && on < u.length, none: !u.length }; };
    for (const gr of groups) {
      cols.forEach(k => { const st = state(gr.rows, k); gr.box[k].checked = st.all; gr.box[k].indeterminate = st.some; gr.box[k].disabled = st.none; });
      const on = gr.rows.filter(r => cols.some(k => r[k].checked)).length;
      gr.count.textContent = on + " of " + gr.rows.length;
      gr.rows.forEach(r => r.tr && r.tr.classList.toggle("off", !cols.some(k => r[k].checked)));
    }
    cols.forEach(k => { const st = state(rows, k); allBox[k].checked = st.all; allBox[k].indeterminate = st.some; });
    if (noSnapBox) {   // End class: only when ticked guests can't be reset
      const k = cols.includes("reset") ? "reset" : "power";
      const n = rows.filter(r => r[k].checked && !has(r.g) && r.g.status === "running").length;
      noSnapBox.hidden = !n;
      noSnapText.textContent = plural(n, "ticked guest") + (n === 1 ? " doesn't" : " don't") + " have " + snap +
        ", so " + (n === 1 ? "it" : "they") + " can't be reset – only switched off. How?";
    }
  };
  const mode = !start ? [h("input", { type: "radio", name: "mode", value: "shutdown", checked: true }), h("input", { type: "radio", name: "mode", value: "stop" })] : null;
  const secs = (S.session.settings && S.session.settings.shutdown_timeout) || 180;
  const noSnapText = h("p", { class: "small" });
  const noSnapBox = !start ? h("div", { class: "nosnap gap-top", hidden: true },
    h("h3", {}, "Guests without " + snap), noSnapText,
    h("div", { class: "radio-row" },
      h("label", { class: "check" }, mode[0], "Shut down gracefully (forced off after " + secs + " seconds)"),
      h("label", { class: "check" }, mode[1], "Power off at once"))) : null;
  const snapText = g => has(g) ? (ram(g) ? "has it, with memory" : "has it") : "doesn't have it";
  dialog((d, close) => {
    d.classList.add("wide");
    const tbody = h("tbody", {}, groups.map(gr => [
      h("tr", { class: "grouprow" }, h("td", {}, h("b", {}, gr.name), " ", gr.count), h("td", {}), cols.map(k => h("td", {}, gr.box[k]))),
      gr.rows.map(r => (r.tr = h("tr", {},
        h("td", {}, lamp(r.g.status), " ", h("span", { class: "vmid" }, r.g.vmid), " ", r.g.name),
        h("td", { class: "muted small" }, snapText(r.g)),
        cols.map(k => h("td", {}, r[k])))))]));
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const pick = k => rows.filter(r => r[k] && r[k].checked).map(r => r.g.vmid);
      let restore, power;
      if (cols.includes("reset")) { power = pick("reset"); restore = power.filter(v => has(rows.find(r => r.g.vmid === v).g)); }
      else { restore = cols.includes("restore") ? pick("restore") : []; power = pick("power"); }
      if (!restore.length && !power.length) { toast("Tick at least one guest or group.", true); return; }
      const body = { action: start ? "class_start" : "class_end", course: c.name, snapshot: snap, restore,
        title: (start ? "Start class " : "End class ") + c.name };
      body[start ? "start" : "off"] = power;
      if (!start) body.mode = mode[1].checked ? "stop" : "shutdown";
      close(); planDialog(body);
    } },
      h("header", {}, h("h2", {}, (start ? "Start class" : "End class") + " – " + c.name),
        h("p", { class: "muted small" }, start
          ? (full ? "Ticked guests are restored to " + snap + " and powered on. Untick guests – or whole groups – to leave them as they are."
                  : "Ticked guests are powered on as they are – End class already reset them. Untick guests – or whole groups – to leave them off.")
          : "Ticked guests go back to " + snap + " and are switched off. Untick guests – or whole groups – to leave them as they are.")),
      h("div", { class: "content pick" },
        guide ? h("details", { class: "guidebox", open: true }, h("summary", {}, "Class guide for " + c.name), h("div", { class: "guidetext" }, renderGuide(guide))) : null,
        h("div", { class: "tablewrap" }, h("table", { class: "classpick" },
          h("thead", {}, h("tr", {}, h("th", {}, "Guest"), h("th", {}, "Snapshot " + snap),
            cols.map(k => h("th", {}, h("label", { class: "check" }, allBox[k], colName[k]))))),
          tbody)),
        !start ? noSnapBox : null),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"),
        h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
    sync();
  });
}

/* after Start class / Re-apply mirrors: each sensor - running, mirrored, packets (checked twice) */
async function sensorCheck(course, into) {
  const box = h("div", { class: "sensorcheck" }, h("h3", {}, "Sensors"), h("p", { class: "muted small" }, "Checking the sensors…"));
  into.append(box);
  const look = async n => {
    let ms;
    try { ms = await api("GET", "/api/mirrors?course=" + encodeURIComponent(course)); } catch (e) { box.replaceChildren(h("h3", {}, "Sensors"), h("p", { class: "small error-text" }, e.message)); return; }
    S.mirrors = ms;
    const lines = [];
    let good = 0, all = 0;
    for (const m of ms) {
      const live = new Map((m.mirrors || []).map(x => [x.port, x]));
      for (const e of m.entries) { all++; if (e.status === "running" && live.get(e.port)) good++; }
      lines.push(h("div", { class: "where small" }, m.bridge + " on " + m.node), h("ul", {}, m.entries.map(e => sensorLine(e, live))));
      if (m.snooping === true || m.snooping === false) lines.push(h("p", { class: "muted small" }, "IGMP snooping on " + m.bridge + ": " + (m.snooping ? "on" : "off")));
      if (m.error) lines.push(h("p", { class: "small error-text" }, m.error));
    }
    box.replaceChildren(h("h3", {}, "Sensors – " + (all && good === all ? "all " + all + " running and mirrored" : good + " of " + all + " running and mirrored")),
      ...lines, h("p", { class: "muted small" }, n ? "Packets counted again 10 seconds later – they should go up while the class runs." : "Checking again in 10 seconds…"));
    if (!n) setTimeout(() => { if (document.body.contains(box)) look(1); }, 10000);
  };
  look(0);
}

/* ---------- plan → review → run, live ---------- */
async function planDialog(body) {
  let plan;
  try { plan = await api("POST", "/api/plan", body); } catch (e) { fail(e); return; }
  dialog((d, close) => {
    const content = h("div", { class: "content" });
    const left = h("span", { class: "left" });
    const run = h("button", { class: "btn primary", type: "button", autofocus: true, disabled: !plan.count }, plan.count ? "Run " + plural(plan.count, "step") : "Nothing to do");
    const cancel = h("button", { class: "btn", type: "button", onclick: close }, "Cancel");
    const stage = (g, i, total, live) => h("div", { class: "stage" },
      total > 1 ? h("h3", {}, "Stage " + (i + 1), h("span", { class: "muted" }, g.length > 1 ? plural(g.length, "step") + " at once" : "1 step")) : null,
      h("ul", { class: "steps" }, g.map(s => h("li", { class: live ? s.state : "" },
        lamp(live ? (s.state === "running" ? "running-step" : s.state) : "waiting", live ? s.state : "waiting"),
        h("span", {}, s.label), h("span", { class: "node" }, s.node + (live && s.secs ? " " + s.secs + " s" : "")),
        live && s.msg ? h("span", { class: "msg" }, s.msg) : null,
        live && s.out ? h("pre", { class: "out" }, s.out) : null))));
    const notes = n => n && n.length ? h("ul", { class: "notes" }, n.map(x => h("li", {}, x))) : null;
    content.append(...[notes(plan.notes), ...plan.groups.map((g, i) => stage(g, i, plan.groups.length, false))].filter(Boolean));
    run.addEventListener("click", async () => {
      run.disabled = true; cancel.disabled = true; d.dataset.busy = "1";
      let job;
      try { job = (await api("POST", "/api/plan/" + plan.id + "/run")).job; } catch (e) { fail(e); delete d.dataset.busy; cancel.disabled = false; return; }
      const tick = async () => {
        let j;
        try { j = await api("GET", "/api/job/" + job); } catch (e) { setTimeout(tick, 1500); return; }
        const done = j.state === "done";
        const head = h("div", { class: "result " + (!done ? "busy" : j.failed ? "failed" : "ok") },
          !done ? "Running – " + j.ok + " of " + j.total + " done" :
            j.failed ? j.ok + " succeeded, " + j.failed + " failed. The failed steps show why." : "All " + plural(j.total, "step") + " done in " + j.secs + " s.");
        content.replaceChildren(...[head, notes(j.notes), ...j.groups.map((g, i) => stage(g, i, j.groups.length, true))].filter(Boolean));
        left.textContent = done ? "" : "You can leave this open; it updates by itself.";
        if (!done) { setTimeout(tick, 700); return; }
        delete d.dataset.busy;
        run.replaceWith(h("button", { class: "btn primary", type: "button", onclick: close }, "Close"));
        cancel.remove();
        S.selected.clear();
        if (S.data) loadCourse(S.data.course);
        if ((body.action === "mirror_apply" || (body.action === "net_addons" && (body.mirror || []).length)) && body.course) sensorCheck(body.course, content);
      };
      tick();
    });
    d.append(h("div", { class: "dlg" }, h("header", {}, h("h2", {}, plan.title)), content, h("footer", {}, left, cancel, run)));
  });
}

/* ---------- mirrors ---------- */
function sensorLine(e, live, unchecked) {   // one sensor: is it running, is it mirrored, packets
  const on = live.get(e.port);
  const running = e.status === "running";
  if (unchecked) return h("li", {}, lamp("", "not checked"), h("span", {}, e.vmid + " " + e.name + " " + e.nic), h("span", { class: "pk small muted" }, "can't be checked now"));
  const state = !running ? (e.status === "unknown" ? "state unknown" : "off – nothing to mirror to") : on ? "running · mirrored · " + on.packets.toLocaleString() + " packets" : "running · NOT mirrored";
  return h("li", {}, lamp(running && on ? "running" : running ? "failed" : "", state),
    h("span", {}, e.vmid + " " + e.name + " " + e.nic), h("span", { class: "pk small" + (running && !on ? " error-text" : "") }, state));
}

function bridgeFacts(c, m) {   // IGMP snooping (on / off) and when the mirrors were last put back
  const out = [];
  if (m.snooping === true || m.snooping === false) {
    const on = m.snooping;
    out.push(h("div", { class: "igmp small" },
      h("span", {}, "IGMP snooping: ", h("b", {}, on ? "on" : "off"),
        h("span", { class: "muted" }, on ? " – multicast (common with industrial protocols) only reaches ports that asked for it; the sensors may miss it" : " – multicast reaches every port, the sensors too")),
      can("mirror_setup") ? h("button", { class: "btn quiet small", type: "button",
        onclick: () => planDialog({ action: "igmp", course: c.name, node: m.node, bridge: m.bridge, on: !on, title: "IGMP snooping " + (on ? "off" : "on") + " – " + m.bridge }) }, on ? "Turn off" : "Turn on") : null));
    if (m.igmp && (m.igmp === "on") !== on)   // the bridge differs from what was chosen
      out.push(h("p", { class: "small notice" }, "Chosen: " + m.igmp + " – the bridge is " + (on ? "on" : "off") + " right now. Re-apply mirrors sets it " + m.igmp + " again."));
    else if (m.igmp) out.push(h("p", { class: "muted small" }, "Kept " + m.igmp + " when the mirrors are re-applied"));
  }
  if (m.applied) out.push(h("p", { class: "muted small" }, "Mirrors last put back " + m.applied.at + " by " + m.applied.by));
  return out;
}

function mirrorPanel(c) {
  const ms = S.mirrors;
  const body = h("div", { class: "body" });
  if (!ms) body.append(h("p", { class: "empty" }, "Reading the mirrors…"));
  else if (!ms.length) body.append(h("p", { class: "empty" }, can("mirror_setup") ? "Nothing set up yet. Change… sets port mirroring to the sensors, IGMP snooping, and the firewall and connection of each NIC." : "No port mirroring set up for this course."));
  for (const m of ms || []) {
    const live = new Map((m.mirrors || []).map(x => [x.port, x]));
    const ok = m.entries.filter(e => e.status === "running" && live.get(e.port)).length;
    body.append(h("div", { class: "mirror" },
      h("div", { class: "where" }, m.bridge + " on " + m.node, m.error ? null : h("span", { class: "muted small" }, " – " + ok + " of " + m.entries.length + " sensor(s) mirrored")),
      m.error ? h("p", { class: "small error-text" }, m.error) : null,
      h("ul", {}, m.entries.map(e => sensorLine(e, live, !!m.error))),
      ...bridgeFacts(c, m)));
  }
  const ns = S.netsum;
  if (ns && ns.nics) {
    if (ms && !ms.length && body.firstChild && body.firstChild.classList && body.firstChild.classList.contains("empty")) body.firstChild.remove();
    // disconnected NICs: one line per guest, and a button that plugs them back in
    const byGuest = [];
    ns.disconnected.forEach(d => { let g = byGuest.find(x => x.vmid === d.vmid && x.bridge === d.bridge); if (!g) byGuest.push(g = { vmid: d.vmid, name: d.name, bridge: d.bridge, nics: [] }); g.nics.push(d.nic); });
    const n = ns.disconnected.length;
    body.append(h("div", { class: "mirror netsum" },
      n ? h("div", { class: "disc" },
        h("div", { class: "where" }, lamp("failed", "disconnected"), " " + plural(n, "NIC") + " disconnected",
          h("span", { class: "muted small" }, " – the guest can't send or receive on " + (n === 1 ? "it" : "them"))),
        h("ul", { class: "small" }, byGuest.map(g => h("li", {}, h("span", { class: "vmid" }, g.vmid), " " + g.name + " – " + g.nics.join(", ") + " on " + g.bridge))),
        ns.disconnected.some(d => d.sensor) ? h("p", { class: "small notice" }, h("b", {}, "Sensors among them: "),
          "a sensor only sees traffic when its capture NIC is connected – and mirrored (Change… → Mirror to it). Connected NICs of a sensor don't send anything unless the sensor itself does.") : null,
        can("network") ? h("div", { class: "actions" },
          h("button", { class: "btn small", type: "button", onclick: () => connectNics(c, ns.disconnected) }, "Connect them…"),
          h("span", { class: "muted small" }, "If they're unplugged on purpose, leave them.")) : null) : null,
      h("p", { class: "muted small" }, plural(ns.nics, "NIC") + " in this course – " + (n ? n + " disconnected" : "all connected") + ", " +
        (ns.fw_off ? "firewall off on " + ns.fw_off : "firewall on on all"))));
  }
  return h("section", { class: "panel" },
    h("header", {}, h("h2", {}, "Network add-ons"),
      can("mirror_setup") ? h("button", { class: "btn quiet", type: "button", onclick: () => netAddons(c) }, "Change…") : null,
      can("mirror_apply") && ms && ms.length ? h("button", { class: "btn", type: "button", onclick: () => planDialog({ action: "mirror_apply", course: c.name, title: "Re-apply mirrors – " + c.name }) }, "Re-apply mirrors") : null),
    body);
}

/* plug disconnected NICs back in - each can be unticked first */
function connectNics(c, list) {
  dialog((d, close) => {
    const rows = list.map(x => ({ x, box: h("input", { type: "checkbox", checked: true }) }));
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const nics = rows.filter(r => r.box.checked).map(r => ({ vmid: r.x.vmid, nic: r.x.nic }));
      if (!nics.length) { toast("Tick at least one NIC.", true); return; }
      close(); planDialog({ action: "nic_connect", course: c.name, nics, title: "Connect NICs – " + c.name });
    } },
      h("header", {}, h("h2", {}, "Connect NICs – " + c.name),
        h("p", { class: "muted small" }, "Plugs the virtual cable back in – the guest sees its link come up. Untick any that should stay disconnected.")),
      h("div", { class: "content" }, h("div", { class: "picker" }, rows.map(r => h("label", { class: "check pick" }, r.box,
        h("span", { class: "vmid" }, r.x.vmid), " " + r.x.name + " – " + r.x.nic + " on " + r.x.bridge)))),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* Network add-ons: per bridge - port mirroring to sensors, IGMP snooping; per NIC - firewall, connected */
async function netAddons(c) {
  let r;
  try { r = await api("GET", "/api/nics?course=" + encodeURIComponent(c.name)); } catch (e) { fail(e); return; }
  const saved = S.mirrors || [];
  // the bridges this course's NICs are on
  const pairs = [];
  for (const n of r.nics) if (n.bridge && !pairs.some(p => p.node === n.node && p.bridge === n.bridge)) pairs.push({ node: n.node, bridge: n.bridge, ovs: n.ovs });
  pairs.sort((x, y) => (y.ovs - x.ovs) || (x.node + x.bridge).localeCompare(y.node + y.bridge));
  const start = Math.max(0, pairs.findIndex(p => p.ovs && r.nics.some(n => n.node === p.node && n.bridge === p.bridge && n.sensor)));
  dialog((d, close) => {
    d.classList.add("wide");
    if (!pairs.length) {
      d.append(h("div", {}, h("header", {}, h("h2", {}, "Network add-ons – " + c.name)),
        h("div", { class: "content" }, h("p", {}, "No guest of this course has a network card.")),
        h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close }, "Close"))));
      return;
    }
    const where = h("select", {}, pairs.map((p, i) => h("option", { value: i, selected: i === start }, p.bridge + " on " + p.node + " – " + (p.ovs ? "Open vSwitch" : "Linux bridge"))));
    const igmp = h("select", {});
    const bridgeBox = h("div"), table = h("div", { class: "tablewrap" });
    let rows = [];
    const cols = [["mirror", "Mirror to it"], ["firewall", "Firewall"], ["connected", "Connected"]];
    const filter = h("input", { type: "search", placeholder: "Filter: name, VMID, NIC, group" });
    let onlySensors = false;
    const sensorsBtn = h("button", { class: "btn quiet small", type: "button" }, "Sensors only");
    const edited = new Map();   // what was changed, kept while filtering
    const key = n => n.vmid + ":" + n.nic;
    const draw = () => {
      const p = pairs[where.value];
      const sv = saved.find(m => m.node === p.node && m.bridge === p.bridge);
      const f = filter.value.trim().toLowerCase();
      const allHere = r.nics.filter(n => n.node === p.node && n.bridge === p.bridge);
      const nics = allHere.filter(n => (!onlySensors || n.sensor) && (!f || (n.vmid + " " + n.name + " " + n.nic + " " + n.group).toLowerCase().includes(f)));
      rows.forEach(x => edited.set(key(x.n), { mirror: x.mirror.checked, firewall: x.firewall.checked, connected: x.connected.checked, tag: x.tag.value }));
      rows = nics.map(n => {
        const row = { n };
        row.mirror = h("input", { type: "checkbox", disabled: !p.ovs, "aria-label": "Mirror to " + n.vmid + " " + n.nic,
          checked: p.ovs && (sv ? sv.entries.some(e => e.vmid === n.vmid && e.nic === n.nic) : false) });
        row.firewall = h("input", { type: "checkbox", checked: n.firewall, "aria-label": "Firewall " + n.vmid + " " + n.nic });
        row.connected = h("input", { type: "checkbox", checked: n.connected, "aria-label": "Connected " + n.vmid + " " + n.nic });
        row.tag = h("input", { type: "text", inputmode: "numeric", value: n.tag || "", placeholder: "none", size: 4, class: "vlan", "aria-label": "VLAN tag " + n.vmid + " " + n.nic, title: "VLAN tag, 1-4094 - empty for none" });
        const e = edited.get(key(n));
        if (e) { row.mirror.checked = e.mirror; row.firewall.checked = e.firewall; row.connected.checked = e.connected; row.tag.value = e.tag; }
        const sync = () => { if (row.mirror.checked) row.firewall.checked = false; row.firewall.disabled = row.mirror.checked; syncGroups(); };
        row.mirror.onchange = sync; row.firewall.onchange = () => syncGroups(); row.connected.onchange = () => syncGroups();
        if (row.mirror.checked) { row.firewall.checked = false; row.firewall.disabled = true; }
        return row;
      });
      const groups = [];
      rows.forEach(rw => { let g = groups.find(x => x.name === rw.n.group); if (!g) groups.push(g = { name: rw.n.group || "Other", rows: [] }); g.rows.push(rw); });
      const syncGroups = () => groups.forEach(g => cols.forEach(([k]) => {
        const u = g.rows.filter(x => !x[k].disabled), on = u.filter(x => x[k].checked).length;
        g.box[k].checked = u.length > 0 && on === u.length; g.box[k].indeterminate = on > 0 && on < u.length; g.box[k].disabled = !u.length;
      }));
      groups.forEach(g => { g.box = {}; cols.forEach(([k]) => { g.box[k] = h("input", { type: "checkbox", "aria-label": k + " all of " + g.name,
        onchange: e => { g.rows.forEach(x => { if (!x[k].disabled) { x[k].checked = e.target.checked; if (k === "mirror") x.mirror.onchange(); } }); syncGroups(); } }); }); });
      table.replaceChildren(nics.length ? h("table", { class: "classpick" },
        h("thead", {}, h("tr", {}, h("th", {}, "Guest"), h("th", {}, "NIC"), h("th", {}, "VLAN"), cols.map(([, t]) => h("th", {}, t)))),
        h("tbody", {}, groups.map(g => [
          h("tr", { class: "grouprow" }, h("td", {}, h("b", {}, g.name)), h("td", {}), h("td", {}), cols.map(([k]) => h("td", {}, g.box[k]))),
          g.rows.map(x => h("tr", {},
            h("td", {}, lamp(x.n.status === "running" ? "running" : ""), " ", h("span", { class: "vmid" }, x.n.vmid), " " + x.n.name, x.n.sensor ? h("span", { class: "chip" }, "sensor") : null),
            h("td", { class: "small" }, x.n.nic, h("span", { class: "muted" }, x.n.mac ? " · " + x.n.mac : "")),
            h("td", {}, x.tag),
            cols.map(([k]) => h("td", {}, x[k]))))]))) : h("p", { class: "muted" }, allHere.length ? "No NIC matches the filter." : "No NIC of this course is on this bridge."));
      syncGroups();
      const live = (r.snooping || {})[p.node + "/" + p.bridge];
      igmp.replaceChildren(h("option", { value: "" }, "Leave as it is" + (live === true || live === false ? " (now " + (live ? "on" : "off") + ")" : "")),
        h("option", { value: "off", selected: sv && sv.igmp === "off" }, "Off – multicast reaches every port, the sensors too"),
        h("option", { value: "on", selected: sv && sv.igmp === "on" }, "On – multicast only reaches ports that asked for it"));
      bridgeBox.replaceChildren(p.ovs
        ? h("div", { class: "cols" }, h("label", { class: "field" }, "IGMP snooping on " + p.bridge, igmp),
            h("p", { class: "muted small" }, "Mirror to it: the NIC gets a copy of all traffic on " + p.bridge + " – for sensors. A mirrored NIC's firewall is turned off. The choices are kept and put back by Re-apply mirrors."))
        : h("p", { class: "muted small" }, p.bridge + " is a Linux bridge: port mirroring and IGMP snooping need an Open vSwitch bridge. The firewall and the connection of each NIC can be set here."));
    };
    where.addEventListener("change", () => { edited.clear(); rows = []; draw(); });
    filter.addEventListener("input", draw);
    sensorsBtn.onclick = () => { onlySensors = !onlySensors; sensorsBtn.textContent = onlySensors ? "All NICs" : "Sensors only"; draw(); };
    draw();
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const p = pairs[where.value];
      rows.forEach(x => edited.set(key(x.n), { mirror: x.mirror.checked, firewall: x.firewall.checked, connected: x.connected.checked, tag: x.tag.value }));
      const allHere = r.nics.filter(n => n.node === p.node && n.bridge === p.bridge);
      const val = n => edited.get(key(n)) || { mirror: false, firewall: n.firewall, connected: n.connected, tag: n.tag || "" };
      const bad = allHere.find(n => { const t = val(n).tag.trim(); return t && !(/^\d+$/.test(t) && +t >= 1 && +t <= 4094); });
      if (bad) { toast(bad.vmid + " " + bad.nic + ": a VLAN tag is 1-4094, or empty for none.", true); return; }
      const sv = saved.find(m => m.node === p.node && m.bridge === p.bridge);
      const wasMirror = n => !!(sv && sv.entries.some(e2 => e2.vmid === n.vmid && e2.nic === n.nic));
      const body = { action: "net_addons", course: c.name, node: p.node, bridge: p.bridge, title: "Network add-ons – " + p.bridge + " on " + p.node,
        nics: allHere.map(n => ({ vmid: n.vmid, nic: n.nic, firewall: val(n).firewall, connected: val(n).connected, tag: val(n).tag.trim() })),
        mirror: allHere.filter(n => edited.has(key(n)) ? val(n).mirror : wasMirror(n)).map(n => ({ vmid: n.vmid, nic: n.nic })), igmp: p.ovs ? igmp.value : "" };
      close(); planDialog(body);
    } },
      h("header", {}, h("h2", {}, "Network add-ons – " + c.name),
        h("p", { class: "muted small" }, "What the course's network cards need so the traffic flows: port mirroring to the sensors, IGMP snooping, the Proxmox firewall, and whether the virtual cable is plugged in. You see the steps before anything changes.")),
      h("div", { class: "content" }, h("label", { class: "field" }, "Bridge", where), bridgeBox,
        h("div", { class: "inline" }, filter, sensorsBtn), table,
        h("ul", { class: "muted small" },
          h("li", {}, h("b", {}, "Firewall"), " – the Proxmox firewall on this NIC. It often blocks multicast and industrial protocols; turn it off where traffic must flow freely."),
          h("li", {}, h("b", {}, "Connected"), " – untick to pull the virtual cable (the guest sees the link go down); tick to plug it back in."),
          h("li", {}, h("b", {}, "VLAN"), " – the VLAN tag the NIC's traffic carries on the bridge; empty for none. Guests that should talk need the same tag."))),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- guests ---------- */
function guestPanel(c) {
  const gs = S.data.guests;
  const f = S.filter.toLowerCase();
  const shown = gs.filter(g => !f || (g.vmid + " " + g.name + " " + g.label + " " + g.node + " " + g.tags.join(" ")).toLowerCase().includes(f));
  const sel = [...S.selected].filter(v => gs.some(g => g.vmid === v));
  const selG = gs.filter(g => S.selected.has(g.vmid));
  const pick = (v, on) => { if (on) S.selected.add(v); else S.selected.delete(v); refill(); };
  const allBox = h("input", { type: "checkbox", "aria-label": "Select all shown", checked: shown.length && shown.every(g => S.selected.has(g.vmid)),
    onchange: e => { shown.forEach(g => e.target.checked ? S.selected.add(g.vmid) : S.selected.delete(g.vmid)); refill(); } });
  const snapsOk = can("snap_take") || can("snap_restore") || can("snap_delete");
  const hint = can("power") && snapsOk ? "Select guests for power and snapshots" : can("power") ? "Select guests to power on or off" : snapsOk ? "Select guests for snapshots" : "";
  const tools = [h("span", { class: "sel" }, sel.length ? plural(sel.length, "guest") + " selected" : hint)];
  if (can("power")) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => planDialog({ action: "power_on", course: c.name, ids: sel, title: "Power on – " + plural(sel.length, "guest") }) }, "Power on"),
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => powerOffDialog(c, sel) }, "Power off"));
  if (snapsOk) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => snapDialog(c, selG) }, "Snapshots…"));
  if (can("network") || can("disks") || can("migrate")) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => buildDialog(c, selG) }, "Build…"));
  if (can("addons_run")) tools.push(
    h("button", { class: "btn", type: "button", onclick: () => { S.tab = "addons"; refill(); } }, "Add-ons…"));
  tools.push(h("button", { class: "btn quiet", type: "button", onclick: () => selectDialog(c) }, "Select…"));
  tools.push(h("input", { type: "search", id: "guest-filter", class: "grow", placeholder: "Filter: name, VMID, tag, node", "aria-label": "Filter guests", value: S.filter,
    oninput: e => { S.filter = e.target.value; refill(); } }));
  const groups = new Map();
  for (const g of shown) { if (!groups.has(g.group)) groups.set(g.group, []); groups.get(g.group).push(g); }
  const body = h("tbody");
  for (const [name, list] of groups) {
    const on = list.filter(g => g.status === "running").length;
    body.append(h("tr", { class: "grp" }, h("td", { colspan: 7 }, name, h("span", { class: "muted" }, on + " of " + list.length + " running"))));
    for (const g of list) {
      const box = h("input", { type: "checkbox", checked: S.selected.has(g.vmid), "aria-label": "Select " + g.vmid, onchange: e => pick(g.vmid, e.target.checked) });
      body.append(h("tr", { class: "g" + (S.selected.has(g.vmid) ? " on" : "") },
        h("td", { class: "chk" }, box),
        h("td", { class: "lampcell" }, lamp(g.status, g.status)),
        h("td", { class: "vmid num" }, g.vmid),
        h("td", {}, g.name, h("div", { class: "muted small" }, g.label)),
        h("td", { class: "kind" }, g.type === "lxc" ? "Container" : "VM"),
        h("td", {}, g.node),
        h("td", {}, h("div", { class: "chips" }, g.snapshots.map(s => h("span", { class: "chip" + (s.ram ? " mem" : ""), title: s.ram ? "with memory" : "" }, s.name + (s.ram ? " + memory" : "")))))));
    }
  }
  if (!shown.length) body.append(h("tr", {}, h("td", { colspan: 7, class: "muted" }, f ? "Nothing matches the filter." : "No guests.")));
  return h("section", { class: "panel" },
    h("div", { class: "toolbar" }, tools),
    h("div", { class: "tablewrap" }, h("table", {},
      h("thead", {}, h("tr", {}, h("th", { class: "chk" }, allBox), h("th", {}, h("span", { class: "sr" }, "")), h("th", { class: "num" }, "VMID"), h("th", {}, "Name"), h("th", {}, "Type"), h("th", {}, "Node"), h("th", {}, "Snapshots"))),
      body)));
}

function powerOffDialog(c, ids) {
  dialog((d, close) => {
    const a = h("input", { type: "radio", name: "m", checked: true }), b = h("input", { type: "radio", name: "m" });
    d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); planDialog({ action: "power_off", course: c.name, ids, mode: b.checked ? "stop" : "shutdown", title: "Power off – " + plural(ids.length, "guest") }); } },
      h("header", {}, h("h2", {}, "Power off " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("div", { class: "radio-row stacked" },
        h("label", { class: "check" }, a, "Shut down gracefully – forced off if the guest doesn't react"),
        h("label", { class: "check" }, b, "Power off at once, like pulling the plug"))),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

function snapDialog(c, gs) {
  const ids = gs.map(g => g.vmid);
  const names = [...new Set(gs.flatMap(g => g.snapshots.map(s => s.name)))].sort();
  dialog((d, close) => {
    const opts = [];
    if (can("snap_take")) opts.push(["take", "Take a new snapshot"]);
    if (can("snap_restore") && names.length) opts.push(["restore", "Restore a snapshot"]);
    if (can("snap_delete") && names.length) opts.push(["delete", "Delete a snapshot"]);
    const what = h("select", {}, opts.map(([v, t]) => h("option", { value: v }, t)));
    const name = h("input", { type: "text", value: "T" + new Date().toISOString().slice(5, 10).replace("-", ""), pattern: "[A-Za-z][A-Za-z0-9_-]{0,39}" });
    const pick = h("select", {}, names.map(n => h("option", { value: n }, n + " (" + gs.filter(g => g.snapshots.some(s => s.name === n)).length + " of " + gs.length + ")")));
    const mem = h("input", { type: "checkbox" });
    const repl = h("input", { type: "checkbox" });
    const afterLeave = h("input", { type: "radio", name: "after", checked: true }), afterStart = h("input", { type: "radio", name: "after" }), afterOff = h("input", { type: "radio", name: "after" });
    const whenRun = h("input", { type: "radio", name: "when", checked: true }), whenFirst = h("input", { type: "radio", name: "when" }), whenAfter = h("input", { type: "radio", name: "when" });
    const fields = h("div");
    const draw = () => fields.replaceChildren(...(what.value === "take"
      ? [h("label", { class: "field" }, "Name", h("span", { class: "hint" }, "Starts with a letter; letters, digits, - and _"), name),
         h("div", { class: "field" }, h("span", {}, "Running guests"), h("div", { class: "radio-row stacked" },
           h("label", { class: "check" }, whenRun, "Leave them running"),
           h("label", { class: "check" }, whenFirst, "Shut them down first – cleanest disks, they stay off"),
           h("label", { class: "check" }, whenAfter, "Shut them down after the snapshot"))),
         h("label", { class: "check" }, mem, "Include the memory of running VMs (they come back running when restored)"),
         h("label", { class: "check gap-top" }, repl, "Replace a snapshot with the same name")]
      : [h("label", { class: "field" }, "Snapshot", pick),
         what.value === "restore" ? h("div", { class: "field" }, h("span", {}, "Afterwards"), h("div", { class: "radio-row stacked" },
           h("label", { class: "check" }, afterLeave, "Leave them as the snapshot left them"),
           h("label", { class: "check" }, afterStart, "Power them on"),
           h("label", { class: "check" }, afterOff, "Make sure they're off"))) : null]).filter(Boolean));
    what.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => {
      e.preventDefault(); close();
      const w = what.value, snap = w === "take" ? name.value : pick.value;
      planDialog({ action: "snap_" + w, course: c.name, ids, snapshot: snap, ram: mem.checked && !whenFirst.checked, replace: repl.checked,
        after: afterStart.checked ? "start" : afterOff.checked ? "off" : "leave",
        when: whenFirst.checked ? "off_first" : whenAfter.checked ? "off_after" : "running",
        title: (w === "take" ? "Take snapshot " : w === "restore" ? "Restore " : "Delete snapshot ") + snap + " – " + plural(ids.length, "guest") });
    } },
      h("header", {}, h("h2", {}, "Snapshots – " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("label", { class: "field" }, "What", what), fields),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- storage and disks ---------- */
function storagePanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading storages and disks…")));
  const fill = o => {
    p.replaceChildren(
      h("header", {}, h("h2", {}, "Storages")),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Storage", "Type", "Shared", "Disk formats", "Content"].map(x => h("th", {}, x)))),
        h("tbody", {}, o.storages.map(s => h("tr", {}, h("td", {}, s.storage), h("td", {}, s.type), h("td", {}, s.shared ? "yes" : "no"), h("td", {}, s.formats), h("td", { class: "muted small" }, s.content)))))),
      h("header", {}, h("h2", {}, "Disks in " + c.name)),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["VMID", "Guest", "Disk", "Storage", "Format", "Size"].map(x => h("th", {}, x)))),
        h("tbody", {}, o.disks.map(x => h("tr", {}, h("td", { class: "vmid" }, x.vmid), h("td", {}, x.name), h("td", {}, x.disk), h("td", {}, x.storage), h("td", {}, x.format), h("td", {}, x.size)))))));
  };
  if (S.overview && S.overview.course === c.name) fill(S.overview);
  else api("GET", "/api/overview?course=" + encodeURIComponent(c.name)).then(o => { o.course = c.name; S.overview = o; fill(o); }).catch(fail);
  return p;
}

/* ================================================================== admin: users */
function courseChecks(selected) {
  const all = h("input", { type: "checkbox", checked: selected === "*" });
  const boxes = S.courses.map(c => h("input", { type: "checkbox", value: c.name, checked: selected !== "*" && (selected || []).includes(c.name) }));
  const sync = () => boxes.forEach(b => { b.disabled = all.checked; });
  all.addEventListener("change", sync); sync();
  const el = h("div", { class: "radio-row" }, h("label", { class: "check" }, all, "All courses (also new ones)"),
    S.courses.map((c, i) => h("label", { class: "check" }, boxes[i], c.name)));
  el.value = () => all.checked ? "*" : boxes.filter(b => b.checked).map(b => b.value);
  return el;
}
function roleSelect(roles, value) {
  return h("select", {}, Object.keys(roles).concat("admin").map(r => h("option", { value: r, selected: r === value }, r)));
}
function pageUsers() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Users"), h("div", { class: "sub" }, "Who may sign in, their role and their courses."))));
  const panel = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading users…")));
  main.append(panel);
  Promise.all([api("GET", "/api/users"), api("GET", "/api/roles")]).then(([us, rr]) => {
    const roles = rr.roles;
    panel.replaceChildren(
      h("header", {}, h("h2", {}, plural(us.length, "user")), h("button", { class: "btn primary", type: "button", onclick: () => userDialog(null, roles) }, "Add a user")),
      h("div", { class: "tablewrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Name", "Role", "Courses", "2FA", ""].map(x => h("th", {}, x)))),
        h("tbody", {}, us.map(u => h("tr", {},
          h("td", { class: "vmid" }, u.name, u.name === S.session.user ? h("span", { class: "muted small" }, " (you)") : null),
          h("td", {}, u.role), h("td", {}, u.courses === "*" ? "All" : u.courses.join(", ")), h("td", {}, u.twofa ? "on" : "off"),
          h("td", {}, h("div", { class: "actions" },
            h("button", { class: "btn quiet", type: "button", onclick: () => userDialog(u, roles) }, "Change"),
            h("button", { class: "btn quiet", type: "button", onclick: () => newPassword(u.name) }, "New password"),
            h("button", { class: "btn quiet", type: "button", onclick: () => api("POST", "/api/users/" + encodeURIComponent(u.name) + "/unlock").then(() => toast(u.name + " can sign in again.")).catch(fail) }, "Unlock"),
            u.name !== S.session.user ? h("button", { class: "btn danger", type: "button", onclick: () => deleteUser(u.name) }, "Delete") : null))))))));
  }).catch(fail);
  return main;
}
function userDialog(u, roles) {
  dialog((d, close) => {
    const name = h("input", { type: "text", required: true, pattern: "[A-Za-z0-9_.\\-]{1,32}", autofocus: !u });
    const role = roleSelect(roles, u ? u.role : "instructor");
    const courses = courseChecks(u ? u.courses : []);
    const twofa = u && u.twofa ? h("input", { type: "checkbox" }) : null;
    d.append(h("form", { onsubmit: async e => {
      e.preventDefault();
      const c = courses.value();
      if (c !== "*" && !c.length && role.value !== "admin") { toast("Pick at least one course.", true); return; }
      try {
        if (u) {
          const b = { role: role.value, courses: role.value === "admin" ? "*" : c };
          if (twofa && twofa.checked) b.twofa = false;
          await api("PUT", "/api/users/" + encodeURIComponent(u.name), b);
          toast(u.name + " changed."); close();
        } else {
          const r = await api("POST", "/api/users", { name: name.value, role: role.value, courses: role.value === "admin" ? "*" : c });
          close(); showPassword(name.value, r.password, "added");
        }
        render();
      } catch (ex) { fail(ex); }
    } },
      h("header", {}, h("h2", {}, u ? "Change " + u.name : "Add a user")),
      h("div", { class: "content" },
        u ? null : h("label", { class: "field" }, "Name", h("span", { class: "hint" }, "Letters, digits, . _ -"), name),
        h("label", { class: "field" }, "Role", h("span", { class: "hint" }, "What they may do – change roles under Roles"), role),
        h("div", { class: "field" }, h("span", {}, "Courses"), courses),
        twofa ? h("label", { class: "check" }, twofa, "Turn 2FA off (they set it up again from Account)") : null,
        u ? null : h("p", { class: "muted small" }, "A strong password is made for them and shown once.")),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, u ? "Save changes" : "Add user"))));
  });
}
function showPassword(name, pw, what) {
  dialog((d, close) => d.append(h("div", { class: "dlg" },
    h("header", {}, h("h2", {}, name + (what === "added" ? " added" : " has a new password"))),
    h("div", { class: "content" }, h("p", {}, "Give this password to " + name + ". It is shown only now."), h("div", { class: "pw" }, pw)),
    h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close, autofocus: true }, "Done")))));
}
async function newPassword(name) {
  if (!confirm("Make a new password for " + name + "? Their old one stops working.")) return;
  try { const r = await api("POST", "/api/users/" + encodeURIComponent(name) + "/password"); showPassword(name, r.password); } catch (e) { fail(e); }
}
async function deleteUser(name) {
  if (!confirm("Delete " + name + "? They can't sign in any more.")) return;
  try { await api("DELETE", "/api/users/" + encodeURIComponent(name)); toast(name + " deleted."); render(); } catch (e) { fail(e); }
}

/* ================================================================== admin: roles */
function pageRoles() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Roles"), h("div", { class: "sub" }, "What each role may do. Admins may always do everything."))));
  const panel = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading roles…")));
  main.append(panel);
  api("GET", "/api/roles").then(rr => {
    const roles = rr.roles, perms = rr.perms;
    const newRole = () => {
      const n = (prompt("Name of the new role (small letters, digits, - and _):") || "").trim().toLowerCase();
      if (!n) return;
      if (!/^[a-z][a-z0-9_-]{0,23}$/.test(n) || n === "admin" || roles[n]) { toast("Choose another name.", true); return; }
      roles[n] = []; draw();
    };
    const delRole = r => { if (confirm("Delete the role " + r + "?")) { delete roles[r]; draw(); } };
    const toggle = (r, k, on) => { roles[r] = on ? [...new Set([...roles[r], k])] : roles[r].filter(x => x !== k); };
    const names = () => Object.keys(roles);
    const headRow = () => h("tr", {}, h("th", {}, "Permission"), h("th", {}, "admin"),
      names().map(r => h("th", {}, r, " ", h("button", { class: "btn quiet small", type: "button", title: "Delete the role " + r, onclick: () => delRole(r) }, "×"))));
    const permRow = (k, label) => h("tr", {},
      h("td", {}, label),
      h("td", {}, h("input", { type: "checkbox", checked: true, disabled: true, "aria-label": "admin: " + label })),
      names().map(r => h("td", {}, h("input", { type: "checkbox", checked: roles[r].includes(k), "aria-label": r + ": " + label,
        onchange: e => toggle(r, k, e.target.checked) }))));
    const draw = () => panel.replaceChildren(
      h("header", {}, h("h2", {}, plural(names().length + 1, "role")),
        h("button", { class: "btn", type: "button", onclick: newRole }, "New role"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/roles", { roles }).then(() => toast("Roles saved.")).catch(fail) }, "Save roles")),
      h("div", { class: "tablewrap" }, h("table", { class: "matrix" },
        h("thead", {}, headRow()),
        h("tbody", {}, Object.entries(perms).map(([k, label]) => permRow(k, label))))));
    draw();
  }).catch(fail);
  return main;
}

/* ================================================================== admin: course map, activity */
function pageMap() {
  const ta = h("textarea", { "aria-label": "VMID map", spellcheck: "false" });
  const unmapped = h("div"), mixed = h("div");
  let shipped = "";
  api("GET", "/api/vmidmap").then(r => {
    ta.value = r.text; shipped = r.default || "";
    unmapped.replaceChildren(r.unmapped && r.unmapped.length ? h("p", { class: "small notice" },
      h("b", {}, plural(r.unmapped.length, "guest") + " belong to no course"), " (their VMIDs aren't in the map, so nobody sees them): ",
      r.unmapped.slice(0, 40).join(", ") + (r.unmapped.length > 40 ? " …" : ""), ". Add a folder line for them, or put them in a mixed course.") : "");
  }).catch(fail);
  const loadMixed = () => api("GET", "/api/mixed").then(r => {
    const rows = r.courses.map(c => h("tr", {},
      h("td", {}, h("b", {}, c.name), c.expired ? h("span", { class: "chip" }, "ended") : null),
      h("td", { class: "small" }, c.desc || ""),
      h("td", { class: "small" }, plural(c.vmids.length, "guest") + (c.missing.length ? " (" + c.missing.length + " no longer exist)" : "")),
      h("td", { class: "small" }, c.expires ? (c.expired ? "ended " : "until ") + c.expires : "kept"),
      h("td", { class: "muted small" }, (c.by || "") + (c.created ? ", " + c.created : "")),
      h("td", {}, h("div", { class: "actions" },
        h("button", { class: "btn quiet", type: "button", onclick: () => mixedDialog(r.guests, c, loadMixed) }, "Edit"),
        h("button", { class: "btn quiet danger", type: "button", onclick: () => {
          if (confirm("Delete the mixed course " + c.name + "? The guests themselves stay as they are."))
            api("DELETE", "/api/mixed/" + encodeURIComponent(c.name)).then(() => { toast("Deleted."); loadMixed(); boot(); }).catch(fail);
        } }, "Delete")))));
    mixed.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Mixed courses"),
        h("span", { class: "muted small" }, "Guests from different courses, as a course of their own"),
        h("button", { class: "btn primary", type: "button", onclick: () => mixedDialog(r.guests, null, loadMixed) }, "New mixed course…")),
      rows.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Course", "Description", "Guests", "Runs", "Made by", ""].map(t => h("th", {}, t)))), h("tbody", {}, rows))) :
        h("div", { class: "body muted small" }, "None yet. A mixed course can be kept, or be a one-shot that ends by itself on a date – e.g. a workshop with servers from 613 and clients from NetWars.")));
  }).catch(fail);
  loadMixed();
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Course map"), h("div", { class: "sub" }, "How VMIDs become courses and groups – and courses mixed from several."))),
    mixed,
    h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "VMID map"),
        h("button", { class: "btn quiet", type: "button", title: "Put the map that comes with this version in the editor – press Save map to use it",
          onclick: () => { if (shipped && confirm("Replace the text below with the map that comes with ICS Ranges? Nothing changes until you press Save map.")) ta.value = shipped; } }, "Load the shipped map"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/vmidmap", { text: ta.value }).then(() => { toast("Course map saved."); S.data = null; boot(); }).catch(fail) }, "Save map")),
      h("div", { class: "body" },
        unmapped,
        h("p", { class: "muted small" }, "A VMID is read as AABCDD: AA the course, B the version (or module, rack, sub-group), C the group, DD the number. VMIDs below 100000 are Management."),
        h("p", { class: "muted small" }, "Lines: folder AA NAME description · module AA B name · sub AA C name · msub AA B C name (a group in one module only) · bname AA word (an unnamed B is shown as \u201cword B\u201d, e.g. Rack 2; otherwise as a version v2)."),
        ta)));
}

/* a course mixed from guests of any courses - kept, or one-shot until a date */
function mixedDialog(all, c, done) {
  const sel = new Set(c ? c.vmids : []);
  const inWeek = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
  dialog((d, close) => {
    const name = h("input", { type: "text", value: c ? c.name : "", required: true, pattern: "[A-Za-z0-9][A-Za-z0-9_.\\-]{0,39}", placeholder: "e.g. Workshop-Nov", autofocus: true });
    const desc = h("input", { type: "text", value: c ? c.desc || "" : "", placeholder: "shown under the name in the side bar" });
    const keep = h("input", { type: "radio", name: "mk", checked: !c || !c.expires }), once = h("input", { type: "radio", name: "mk", checked: !!(c && c.expires) });
    const until = h("input", { type: "date", value: c && c.expires ? c.expires : inWeek, min: new Date().toISOString().slice(0, 10) });
    const filter = h("input", { type: "search", placeholder: "Filter by name, VMID, course or group" });
    const range = h("input", { type: "text", placeholder: "510101-510105, 521101" });
    const count = h("span", { class: "muted small" });
    const list = h("div", { class: "picker" });
    // course -> group -> guests, each level with a tick; courses you opened stay open while you tick
    const tree = {};
    all.forEach(g => { const cn = g.course || "No course", gn = g.group || "Other"; ((tree[cn] = tree[cn] || {})[gn] = tree[cn][gn] || []).push(g); });
    const opened = new Set(c ? all.filter(g => sel.has(g.vmid)).map(g => g.course || "No course") : []);
    const tick = (gs, on) => gs.forEach(g => on ? sel.add(g.vmid) : sel.delete(g.vmid));
    const box = (gs, after) => {
      const on = gs.filter(g => sel.has(g.vmid)).length;
      const i = h("input", { type: "checkbox", checked: on === gs.length && gs.length > 0, onchange: e => { tick(gs, e.target.checked); after(); } });
      i.indeterminate = on > 0 && on < gs.length;
      return [i, on];
    };
    let shownNow = [];
    const draw = () => {
      const f = filter.value.trim().toLowerCase();
      const match = g => !f || (g.vmid + " " + g.name + " " + g.course + " " + g.group).toLowerCase().includes(f);
      shownNow = [];
      list.replaceChildren(...Object.entries(tree).map(([cn, groups]) => {
        const cg = Object.values(groups).flat().filter(match);
        if (!cg.length) return "";
        shownNow.push(...cg);
        const [cbox, con] = box(cg, draw);
        const det = h("details", { open: !!f || opened.has(cn), ontoggle: e => { e.target.open ? opened.add(cn) : opened.delete(cn); } },
          h("summary", {}, h("label", { class: "check", onclick: e => e.stopPropagation() }, cbox, h("b", {}, cn)),
            h("span", { class: "muted small" }, " " + con + " of " + cg.length)),
          Object.entries(groups).map(([gn, gs]) => {
            const shown = gs.filter(match);
            if (!shown.length) return "";
            const [gbox, gon] = box(shown, draw);
            return h("div", { class: "pick-group" },
              h("label", { class: "check" }, gbox, h("b", {}, gn), h("span", { class: "muted small" }, " " + gon + " of " + shown.length)),
              shown.map(g => h("label", { class: "check pick" }, h("input", { type: "checkbox", checked: sel.has(g.vmid), onchange: e => { tick([g], e.target.checked); draw(); } }),
                lamp(g.status === "running" ? "running" : ""), " " + g.vmid + " ", h("span", {}, g.name))));
          }));
        return det;
      }));
      count.textContent = plural(sel.size, "guest") + " picked";
    };
    const selectShown = () => { tick(shownNow, true); draw(); };
    const deselectAll = () => { sel.clear(); draw(); };
    filter.addEventListener("input", draw);
    const addRange = () => {
      const want = new Set();
      for (const part of range.value.split(/[\s,]+/)) { const m = part.match(/^(\d+)(?:-(\d+))?$/); if (m) for (let v = +m[1]; v <= +(m[2] || m[1]) && v - m[1] < 100000; v++) want.add(v); }
      let n = 0; all.forEach(g => { if (want.has(g.vmid) && !sel.has(g.vmid)) { sel.add(g.vmid); n++; } });
      toast(n ? "Added " + plural(n, "guest") + "." : "No (new) guests with those VMIDs.", !n); range.value = ""; draw();
    };
    draw();
    d.classList.add("wide");
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      if (!sel.size) { toast("Pick at least one guest.", true); return; }
      const nm = name.value.trim();
      api("PUT", "/api/mixed/" + encodeURIComponent(nm), { old: c ? c.name : "", desc: desc.value, vmids: [...sel], expires: once.checked ? until.value : "" })
        .then(() => { toast("Mixed course " + nm + " saved – it's in the side bar."); close(); done(); boot(); }).catch(fail);
    } },
      h("header", {}, h("h2", {}, c ? "Mixed course " + c.name : "New mixed course"),
        h("p", { class: "muted small" }, "Pick guests from any courses. The new course gets its own class guide and add-ons, and Start class and End class work as in any course. The guests also stay in their own courses.")),
      h("div", { class: "content" },
        h("div", { class: "cols" }, h("label", { class: "field" }, "Name", name), h("label", { class: "field" }, "Description", desc)),
        h("div", { class: "field" }, h("span", {}, "Runs"), h("div", { class: "radio-row" },
          h("label", { class: "check" }, keep, "Kept until deleted"),
          h("label", { class: "check" }, once, "One-shot – ends on ", until))),
        h("div", { class: "cols" }, h("label", { class: "field" }, "Guests", filter),
          h("div", { class: "field" }, h("span", {}, "Add by VMID"), h("div", { class: "inline" }, range, h("button", { class: "btn", type: "button", onclick: addRange }, "Add")))),
        h("div", { class: "inline gap-top" }, count, h("span", { class: "grow" }),
          h("button", { class: "btn quiet small", type: "button", onclick: selectShown }, "Select all shown"),
          h("button", { class: "btn quiet small", type: "button", onclick: deselectAll }, "Deselect all")),
        list),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save course"))));
  });
}
function pageActivity() {
  const pre = h("pre", { class: "log" }, "Reading…");
  api("GET", "/api/audit").then(r => { pre.textContent = r.lines.join("\n") || "Nothing yet."; }).catch(fail);
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Activity"), h("div", { class: "sub" }, "Sign-ins and everything that ran, newest first."))),
    h("section", { class: "panel" }, h("div", { class: "body" }, pre)));
}

/* ================================================================== account: password, 2FA */
function accountDialog() {
  dialog((d, close) => {
    const old = h("input", { type: "password", autocomplete: "current-password" }), nw = h("input", { type: "password", autocomplete: "new-password" });
    const twofaBox = h("div");
    const draw2fa = () => {
      if (S.session.twofa) {
        const pw = h("input", { type: "password", autocomplete: "current-password" });
        twofaBox.replaceChildren(h("p", {}, "2FA is on."), h("label", { class: "field" }, "Your password, to turn it off", pw),
          h("button", { class: "btn danger", type: "button", onclick: () => api("POST", "/api/me/2fa-off", { password: pw.value }).then(() => { S.session.twofa = false; toast("2FA is off."); draw2fa(); }).catch(fail) }, "Turn 2FA off"));
      } else {
        twofaBox.replaceChildren(h("p", { class: "muted" }, "Sign-in also asks for a code from an authenticator app."),
          h("button", { class: "btn", type: "button", onclick: async () => {
            try {
              const r = await api("POST", "/api/me/2fa-start");
              const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code" });
              twofaBox.replaceChildren(h("p", {}, "In your authenticator app, add an account by key and enter:"), h("div", { class: "pw" }, r.secret.replace(/(.{4})/g, "$1 ").trim()),
                h("p", { class: "muted small gap-top" }, "Account name: ICS Ranges, time-based."),
                h("label", { class: "field" }, "Then type the 6-digit code it shows", code),
                h("button", { class: "btn primary", type: "button", onclick: () => api("POST", "/api/me/2fa-confirm", { code: code.value }).then(() => { S.session.twofa = true; toast("2FA is on."); draw2fa(); }).catch(fail) }, "Turn 2FA on"));
              code.focus();
            } catch (e) { fail(e); }
          } }, "Set up 2FA"));
      }
    };
    draw2fa();
    const themeNames = [["", "As set by the admin"], ["light", "Light"], ["dark", "Dark"]].concat(Object.keys(S.session.themes || {}).map(n => [n, n]));
    let curTheme = ""; try { curTheme = localStorage.getItem("pvr-theme") || ""; } catch (e) { /* ignore */ }
    const theme = h("select", {}, themeNames.map(([v, t]) => h("option", { value: v, selected: curTheme === v }, t)));
    theme.addEventListener("change", () => { try { localStorage.setItem("pvr-theme", theme.value); } catch (e) { /* private mode */ } applyTheme(); });
    d.append(h("div", { class: "dlg" },
      h("header", {}, h("h2", {}, "Account – " + S.session.user)),
      h("div", { class: "content" },
        h("h3", {}, "Password"),
        h("label", { class: "field" }, "Current password", old), h("label", { class: "field" }, "New password", h("span", { class: "hint" }, "At least 10 characters"), nw),
        h("button", { class: "btn", type: "button", onclick: () => api("POST", "/api/me/password", { old: old.value, new: nw.value }).then(() => { toast("Password changed."); old.value = nw.value = ""; }).catch(fail) }, "Change password"),
        h("h3", { class: "gap-top" }, "Two-factor sign-in"), twofaBox,
        h("h3", { class: "gap-top" }, "Colours"), h("label", { class: "field" }, "Theme on this computer", theme)),
      h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close }, "Close"))));
  });
}
function applyTheme() {
  let t = "";
  try { t = localStorage.getItem("pvr-theme") || ""; } catch (e) { /* ignore */ }
  if (!t && S.session && S.session.settings) t = S.session.settings.default_theme || "";
  const root = document.documentElement;
  for (const v of ["--canvas", "--panel", "--panel-2", "--ink", "--line", "--line-2", "--action", "--focus"]) root.style.removeProperty(v);
  const custom = S.session && S.session.themes && S.session.themes[t];
  if (custom) {
    root.dataset.theme = custom.dark ? "dark" : "light";
    const mix = (a, b, p) => { const x = parseInt(a.slice(1), 16), y = parseInt(b.slice(1), 16); const c = i => Math.round(((x >> i) & 255) * (1 - p) + ((y >> i) & 255) * p); return "#" + [16, 8, 0].map(i => c(i).toString(16).padStart(2, "0")).join(""); };
    root.style.setProperty("--canvas", custom.canvas); root.style.setProperty("--panel", custom.panel);
    root.style.setProperty("--panel-2", mix(custom.panel, custom.ink, 0.06)); root.style.setProperty("--ink", custom.ink);
    root.style.setProperty("--line", custom.line); root.style.setProperty("--line-2", mix(custom.line, custom.panel, 0.45));
    root.style.setProperty("--action", custom.action); root.style.setProperty("--focus", custom.action);
  } else if (t === "light" || t === "dark") root.dataset.theme = t;
  else delete root.dataset.theme;
}

/* ================================================================== start */
/* while Proxmox doesn't answer: the last known guests are shown, nothing can run */
function offlineNote() {
  const o = S.offline;
  return h("div", { id: "offline-note", class: o ? "offline-note" : "", hidden: !o, role: o ? "alert" : null },
    o ? [h("b", {}, "Proxmox isn't answering"), " since " + o.since + ". Showing the last known guests" + (o.cache ? " (from " + o.cache + ")" : "") +
      " – starting, stopping and snapshots wait until it answers. The admin pages work."] : null);
}

async function boot() {
  applyTheme();
  try {
    const s = await api("GET", "/api/session");
    if (!s.signed_in) { S.session = null; S.setup = s.setup; render(); return; }
    S.session = s;
    S.offline = s.offline || null;
    applyTheme();
    try { S.courses = await api("GET", "/api/courses"); } catch (e) { S.courses = []; }   // the admin pages work without Proxmox
    render();
  } catch (e) { document.getElementById("root").replaceChildren(h("div", { class: "signin" }, h("p", {}, "Can't reach ICS Ranges: " + e.message))); }
}
boot();
