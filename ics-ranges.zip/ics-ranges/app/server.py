#!/usr/bin/env python3
"""ICS Ranges - a web console for running Proxmox training ranges.

Talks to Proxmox only through its API (token), plus one optional SSH key that may run
nothing but ovs-vsctl (port mirroring). Python standard library only.

The program is split into modules in ics/ (by topic: core, content, share, netops, addons,
updates, mirrors, plans, readiness, kit, web, cli). This file starts it - the web server, or
the command line (pvr) when given arguments - and holds the version: the host's updater reads
the VERSION line here.
"""
VERSION = "3.2.2"

import os
import ssl
import sys
import threading

from ics import web
from ics.cli import cli
from ics.content import fix_612_map
from ics.core import API_URLS, DATA, PORT, PVEError, path, pve, sessions_load
from ics.updates import update_checker
from ics.web import Handler, Server


def main():
    os.makedirs(DATA, exist_ok=True)
    srv = Server(("0.0.0.0", PORT), Handler)
    cert, key = path("tls/cert.pem"), path("tls/key.pem")
    if os.path.exists(cert) and os.path.exists(key):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        print("ICS Ranges %s on https://0.0.0.0:%d" % (VERSION, PORT), flush=True)
    else:
        web.COOKIE_FLAGS = ""   # set on the module the request handler reads it from
        print("ICS Ranges %s on http://0.0.0.0:%d (no certificate - testing only)" % (VERSION, PORT), flush=True)
    try:
        if API_URLS:
            v = pve.call("GET", "/version")
            print("Proxmox API OK - version %s" % v.get("version"), flush=True)
    except PVEError as e:
        print("Proxmox API: %s" % e, flush=True)
    fix_612_map()
    sessions_load()   # who was signed in before a restart or an update stays signed in
    threading.Thread(target=update_checker, daemon=True).start()
    srv.serve_forever()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            sys.exit(cli(sys.argv[1:]))
        except (ValueError, KeyError, PermissionError, PVEError) as e:   # a plain message, not a traceback
            print("error: %s" % str(e).strip("'"), file=sys.stderr)
            sys.exit(1)
        except KeyboardInterrupt:
            sys.exit(130)
    main()
