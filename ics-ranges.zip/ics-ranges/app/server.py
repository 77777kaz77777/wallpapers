#!/usr/bin/env python3
"""ICS Ranges - a web console for running Proxmox training ranges.

Talks to Proxmox only through its API (token), plus one optional SSH key that may run
nothing but ovs-vsctl (port mirroring). Python standard library only.
"""
import base64
import io
import shutil
import tarfile
import gzip
import concurrent.futures as cf
import hashlib
import hmac
import http.server
import json
import os
import re
import secrets
import ssl
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

VERSION = "2.9.3"
DATA = os.environ.get("DATA_DIR", "/data")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
PORT = int(os.environ.get("PORT", "8443"))
API_URLS = [u.rstrip("/") for u in os.environ.get("PVE_API_URL", "").replace(",", " ").split() if u]
API_TOKEN = os.environ.get("PVE_API_TOKEN", "")
PARALLEL = int(os.environ.get("MAX_PARALLEL", "8"))
SHUTDOWN_TIMEOUT = int(os.environ.get("SHUTDOWN_TIMEOUT", "180"))
IDLE = int(os.environ.get("SESSION_IDLE", "900"))
OVS_KEY = os.path.join(DATA, "ssh", "ovs_ed25519")

PERMS = {
    "class_run": "Start class / End class",
    "power": "Power on / off",
    "snap_take": "Take snapshots",
    "snap_restore": "Restore snapshots",
    "snap_delete": "Delete snapshots",
    "mirror_status": "See port-mirror status",
    "mirror_apply": "Re-apply port mirrors",
    "mirror_setup": "Set up and remove port mirrors",
    "guide_read": "Read class guides",
    "guide_edit": "Write and edit class guides",
    "addons_run": "Run add-ons",
    "addons_edit": "Create and edit add-ons",
    "overview": "Storage and disks",
    "network": "Change network settings",
    "disks": "Move and convert disks",
    "migrate": "Migrate guests",
    "efi": "Enroll EFI keys (Secure Boot)",
    "save": "Save & share (repository, backups)",
    "software": "Software updates (install other ICS Ranges versions)",
    "users": "Manage users",
    "settings": "Roles, course map, groups, themes and settings",
}
DEFAULT_ROLES = {
    "instructor": ["class_run", "power", "mirror_status", "mirror_apply"],
    "viewer": ["overview", "mirror_status", "guide_read"],
}
DEFAULT_MAP = """\
folder 10 Mgmt      Management
folder 40 SANS      SANS
folder 50 612       ICS612
folder 51 613       ICS613
folder 52 NetWars   NetWars
folder 53 727       ICS727

# SANS (40BCDD) - B = rack number
bname  40 Rack
module 40 0 Rack Services
sub    40 0 Network
sub    40 1 Servers
sub    40 2 Clients

# 612 (50BCDD) - B = version, C = system
sub 50 0 Services
sub 50 1 Lvl 3 Servers
sub 50 2 Lvl 3 EWS
sub 50 3 Lvl 3 OWS
sub 50 6 NSM
sub 50 5 iDMZ - Jump Hosts
sub 50 4 iDMZ - File Servers

# 613 (51BCDD) - B = version, C = system
sub 51 0 Services
sub 51 1 Enterprise Servers
sub 51 2 ICS Servers
sub 51 3 ABB Servers
sub 51 4 Enterprise Clients
sub 51 5 iDMZ Jump Hosts
sub 51 6 EWS Clients
sub 51 7 ABB Clients

# NetWars (52BCDD) - B = module, C = group inside the module
module 52 0 Mgmt
module 52 1 Grid
module 52 2 Cookie
module 52 3 Injection
module 52 4 Crane
module 52 5 Qatar
msub   52 1 0 Servers
msub   52 1 1 Clients - Level 3
msub   52 1 2 Clients - Level 4
msub   52 2 0 Servers
msub   52 2 1 Clients - Level 4

# 727 (53BCDD) - B = version, C = system
sub 53 0 Services
sub 53 1 Dragos Servers
sub 53 2 EWS Clients
"""
LOCK = threading.RLock()
COOKIE_FLAGS = "; Secure"   # cleared only when the server runs without a certificate (testing)


# ---------------------------------------------------------------------------- files
def path(name):
    return os.path.join(DATA, name)


def load_json(name, default):
    try:
        with open(path(name)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, value):
    tmp = path(name + ".new")
    with open(tmp, "w") as f:
        json.dump(value, f, indent=2, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path(name))


def audit(user, text):
    line = "%s  %-14s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), user or "-", text)
    with LOCK:
        try:   # keep it from growing forever: past 5 MB it becomes audit.log.1 (the one before is dropped)
            if os.path.getsize(path("audit.log")) > 5 * 1024 * 1024:
                os.replace(path("audit.log"), path("audit.log.1"))
        except OSError:
            pass
        with open(path("audit.log"), "a") as f:
            f.write(line)


# ---------------------------------------------------------------------------- Proxmox API
class PVEError(Exception):
    pass


class PVE:
    def __init__(self):
        ca = path("pve-root-ca.pem")
        if os.path.exists(ca):
            self.ctx = ssl.create_default_context(cafile=ca)
            self.ctx.check_hostname = False
        else:   # the nodes' own self-signed certificate
            self.ctx = ssl._create_unverified_context()
        self.good = 0

    def call(self, method, api_path, params=None, timeout=20):
        if not API_URLS or not API_TOKEN:
            raise PVEError("PVE_API_URL and PVE_API_TOKEN must be set in .env")
        params = {k: v for k, v in (params or {}).items() if v is not None}
        body = None
        query = ""
        if method == "GET":
            query = ("?" + urllib.parse.urlencode(params)) if params else ""
        else:
            body = urllib.parse.urlencode(params).encode()
        last = None
        order = API_URLS[self.good:] + API_URLS[:self.good]
        for url in order:
            req = urllib.request.Request(url + "/api2/json" + api_path + query, data=body, method=method)
            req.add_header("Authorization", "PVEAPIToken=" + API_TOKEN)
            if body is not None:
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=self.ctx if url.startswith("https") else None) as r:
                    self.good = API_URLS.index(url)
                    return json.load(r).get("data")
            except urllib.error.HTTPError as e:   # Proxmox answered - no point trying another node
                detail = ""
                try:
                    j = json.loads(e.read() or b"{}")
                    detail = "; ".join("%s: %s" % kv for kv in (j.get("errors") or {}).items())
                except ValueError:
                    pass
                raise PVEError("%s %s -> HTTP %s %s%s" % (method, api_path, e.code, e.reason, (" (" + detail + ")") if detail else ""))
            except (urllib.error.URLError, OSError) as e:
                last = e
        raise PVEError("can't reach the Proxmox API (%s): %s" % (" ".join(API_URLS), last))

    def wait(self, upid):
        node = upid.split(":")[1]
        q = urllib.parse.quote(upid, safe="")
        polls = 0
        while True:
            st = self.call("GET", "/nodes/%s/tasks/%s/status" % (node, q))
            if st.get("status") == "stopped":
                break
            polls += 1
            time.sleep(0.25 if polls <= 8 else 1)
        es = st.get("exitstatus") or ""
        if es == "OK" or es.startswith("WARNINGS"):
            return "" if es == "OK" else es
        log = self.call("GET", "/nodes/%s/tasks/%s/log" % (node, q), {"limit": 500}) or []
        tail = " / ".join(x.get("t", "") for x in log[-4:])
        raise PVEError("task failed: %s%s" % (es or "unknown", (" - " + tail) if tail else ""))

    def task(self, method, api_path, params=None):
        r = self.call(method, api_path, params)
        if isinstance(r, str) and r.startswith("UPID:"):
            return self.wait(r)
        return ""


pve = PVE()


# ---------------------------------------------------------------------------- VMID map
_MAP_CACHE = {"key": None, "val": None}


def load_map():
    try:
        key = os.stat(path("vmid-map.conf")).st_mtime_ns
    except OSError:
        key = "default"
    if _MAP_CACHE["key"] == key:
        return _MAP_CACHE["val"]
    _MAP_CACHE["val"] = _parse_map()
    _MAP_CACHE["key"] = key
    return _MAP_CACHE["val"]


def _parse_map():
    text = ""
    try:
        with open(path("vmid-map.conf")) as f:
            text = f.read()
    except OSError:
        text = DEFAULT_MAP
    return _parse_map_text(text)


def _parse_map_text(text):
    # folder AA NAME desc | module AA B name | sub AA C name | msub AA B C name (one module only)
    # bname AA word (what an unnamed B is called, e.g. Rack -> "Rack 2"; default: version "v2")
    m = {"folder": {}, "desc": {}, "sub": {}, "module": {}, "msub": {}, "bname": {}}
    for line in text.splitlines():
        p = line.split("#", 1)[0].split()
        if len(p) >= 3 and p[0] == "folder" and p[1].isdigit():
            m["folder"][int(p[1])] = p[2]
            m["desc"][int(p[1])] = " ".join(p[3:])
        elif len(p) >= 4 and p[0] in ("sub", "module") and p[1].isdigit() and p[2].isdigit():
            m[p[0]][(int(p[1]), int(p[2]))] = " ".join(p[3:])
        elif len(p) >= 5 and p[0] == "msub" and p[1].isdigit() and p[2].isdigit() and p[3].isdigit():
            m["msub"][(int(p[1]), int(p[2]), int(p[3]))] = " ".join(p[4:])
        elif len(p) >= 3 and p[0] == "bname" and p[1].isdigit():
            m["bname"][int(p[1])] = " ".join(p[2:])
    return m, text


def course_of(vmid, m):   # None: the map has no course for it (shown on the Course map page)
    if vmid < 100000:
        return "Management"
    return m["folder"].get(vmid // 10000)


def courses_for(s):   # the courses this user may open, with guest counts (Management first, mixed last)
    allow = allowed_courses(s["u"])
    m, _ = load_map()
    out = {}
    for g in inv.guests.values():
        c = g["course"]
        if c is None or (allow is not None and c not in allow):
            continue
        o = out.setdefault(c, {"name": c, "count": 0, "running": 0})
        o["count"] += 1
        o["running"] += g["status"] == "running"
    order = {v: k for k, v in m["folder"].items()}
    for c in out.values():
        aa = order.get(c["name"])
        c["desc"] = m["desc"].get(aa, "VMID below 100000" if c["name"] == "Management" else "")
        c["order"] = -1 if c["name"] == "Management" else (aa if aa is not None else 1000)
    for name, mc in mixed_active().items():
        if allow is not None and name not in allow:
            continue
        ids = [v for v in set(mc.get("vmids", [])) if v in inv.guests]
        out[name] = {"name": name, "count": len(ids), "running": sum(inv.guests[v]["status"] == "running" for v in ids),
                     "desc": mc.get("desc") or ("One-shot until %s" % mc["expires"] if mc.get("expires") else "Mixed course"),
                     "order": 2000, "mixed": True, "expires": mc.get("expires", "")}
    return sorted(out.values(), key=lambda c: (c["order"], c["name"]))


# ---------------------------------------------------------------------------- mixed courses
# Guests picked from any courses, as a course of their own - kept, or one-shot until a date.
def mixed_courses():
    c = load_json("courses.json", {})
    return c if isinstance(c, dict) else {}


def mixed_active():
    today = time.strftime("%Y-%m-%d")
    return {n: c for n, c in mixed_courses().items() if not c.get("expires") or c["expires"] >= today}


def _bpart(aa, b, m):   # the B digit as a name: a module / rack name, "Rack 2", or the version "v2"
    if (aa, b) in m["module"]:
        return m["module"][(aa, b)]
    if aa in m["bname"]:
        return "%s %d" % (m["bname"][aa], b)
    if any(k[0] == aa for k in m["module"]):
        return "Module %d" % b
    return "v%d" % b


def _named_b(aa, m):   # B is a module / rack / sub-group, not a version
    return aa in m["bname"] or any(k[0] == aa for k in m["module"])


def _sub(aa, b, c, m):
    return m["msub"].get((aa, b, c)) or m["sub"].get((aa, c)) or "Group %d" % c


def label_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa, b, c, dd = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10, vmid % 100
    return "%s %s %s #%02d" % (m["folder"].get(aa, str(aa)), _bpart(aa, b, m), _sub(aa, b, c, m), dd)


def group_of(vmid, m):   # the sub-group heading the GUI groups guests under
    if vmid < 100000:
        return "Management"
    aa, b, c = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10
    if _named_b(aa, m):
        return "%s - %s" % (_bpart(aa, b, m), _sub(aa, b, c, m))
    return _sub(aa, b, c, m)


# ---------------------------------------------------------------------------- inventory
class Inventory:
    def __init__(self):
        self.lock = threading.Lock()
        self.res_at = 0
        self.guests = {}
        self.nodes = []
        self.snaps = {}       # vmid -> (time, [ {name, ram} ])
        self.cfgs = {}        # vmid -> (time, {config})
        self.hot_until = 0    # right after an action: also read each node, the overview can lag
        self.offline = None   # {"error", "since"} while Proxmox doesn't answer
        self.retrying = False
        self.saved_at = 0

    def refresh(self, force=False):
        if self.offline and not force:
            # Proxmox isn't answering: serve what we know at once, and try again in the
            # background now and then - no page waits for a server that is off
            if not self.retrying and time.time() - self.res_at > 15:
                self.retrying = True
                threading.Thread(target=self._retry, daemon=True).start()
            return
        with self.lock:
            if not force and time.time() - self.res_at < 3:
                return
            self._read(force)

    def _retry(self):
        try:
            with self.lock:
                self._read()
        finally:
            self.retrying = False

    def _went_offline(self, e):
        if not self.offline:
            self.offline = {"error": str(e), "since": time.strftime("%H:%M")}
            sys.stderr.write("Proxmox isn't answering: %s\n" % e)
        if not self.guests:   # just started: show the last known guests, state unknown
            c = load_json("inventory-cache.json", {})
            self.guests = {int(k): dict(g, status="unknown") for k, g in (c.get("guests") or {}).items()}
            self.offline["cache"] = c.get("at", "")
        self.nodes = []
        self.res_at = time.time()

    def _read(self, force=False):
        if True:
            try:
                res = pve.call("GET", "/cluster/resources", timeout=8)
            except PVEError as e:
                return self._went_offline(e)
            m, _ = load_map()
            guests, nodes = {}, []
            prot = protected_ids()
            for r in res:
                if r.get("type") in ("qemu", "lxc") and int(r.get("vmid", 0)) in prot:
                    continue
                if r.get("type") == "node" and r.get("status") == "online":
                    nodes.append(r["node"])
                elif r.get("type") in ("qemu", "lxc") and not r.get("template"):
                    v = int(r["vmid"])
                    guests[v] = {
                        "vmid": v, "type": r["type"], "node": r["node"], "name": r.get("name") or "-",
                        "status": r.get("status", "unknown"),
                        "tags": [t for t in (r.get("tags") or "").replace(",", ";").split(";") if t],
                        "course": course_of(v, m), "label": label_of(v, m), "group": group_of(v, m),
                    }
            # the live state - only right after an action (or when asked): the cluster
            # overview can lag a few seconds then; otherwise it is enough (1 call, not 1 + 2 per node)
            def live(n_t):
                n, t = n_t
                try:
                    return pve.call("GET", "/nodes/%s/%s" % (n, t)) or []
                except PVEError:
                    return []
            hot = force or time.time() < self.hot_until
            with cf.ThreadPoolExecutor(8) as ex:
                for lst in ex.map(live, [(n, t) for n in nodes for t in ("qemu", "lxc")] if hot else []):
                    for g in lst:
                        v = int(g["vmid"])
                        if v in guests:
                            guests[v]["status"] = g.get("status", guests[v]["status"])
            if self.offline:
                sys.stderr.write("Proxmox answers again\n")
            self.guests, self.nodes, self.res_at, self.offline = guests, sorted(nodes), time.time(), None
            if time.time() - self.saved_at > 60:   # the last known guests, for when Proxmox is off
                self.saved_at = time.time()
                try:
                    save_json("inventory-cache.json", {"at": time.strftime("%Y-%m-%d %H:%M"), "guests": {str(k): v for k, v in guests.items()}})
                except OSError:
                    pass

    def forget(self, ids):
        for v in ids:   # read them again next time - but keep what we knew, in case Proxmox goes away
            if v in self.snaps:
                self.snaps[v] = (0, self.snaps[v][1])
            self.cfgs.pop(v, None)
        self.res_at = 0
        self.hot_until = time.time() + 120

    def _snap(self, v):
        g = self.guests[v]
        try:
            lst = pve.call("GET", "/nodes/%s/%s/%d/snapshot" % (g["node"], g["type"], v), timeout=8) or []
        except PVEError:
            if v in self.snaps:   # keep what we knew - don't make the snapshots vanish
                self.snaps[v] = (time.time(), self.snaps[v][1])
                return
            lst = []
        out = [{"name": s["name"], "ram": bool(s.get("vmstate")), "time": s.get("snaptime", 0)}
               for s in lst if s.get("name") != "current"]
        out.sort(key=lambda s: s["time"])
        self.snaps[v] = (time.time(), out)

    def snapshots(self, ids, max_age=300):
        need = [v for v in ids if v in self.guests and (v not in self.snaps or time.time() - self.snaps[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(32) as ex:
                list(ex.map(self._snap, need))
        return {v: self.snaps.get(v, (0, []))[1] for v in ids}

    def _cfg(self, v):
        g = self.guests[v]
        try:
            self.cfgs[v] = (time.time(), pve.call("GET", "/nodes/%s/%s/%d/config" % (g["node"], g["type"], v)) or {})
        except PVEError:
            self.cfgs[v] = (time.time(), {})

    def configs(self, ids, max_age=120):
        need = [v for v in ids if v in self.guests and (v not in self.cfgs or time.time() - self.cfgs[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(32) as ex:
                list(ex.map(self._cfg, need))
        return {v: self.cfgs.get(v, (0, {}))[1] for v in ids}

    def course_ids(self, course):
        prot = protected_ids()
        mixed = mixed_active().get(course)
        if mixed is not None:
            return sorted(v for v in set(mixed.get("vmids", [])) if v in self.guests and v not in prot)
        return sorted(v for v, g in self.guests.items() if g["course"] == course and v not in prot)


inv = Inventory()


# ---------------------------------------------------------------------------- users, roles
def roles():
    r = load_json("roles.json", None)
    if not isinstance(r, dict):
        r = {k: list(v) for k, v in DEFAULT_ROLES.items()}
    r.pop("admin", None)
    return r


def user_perms(user):   # what a signed-in user may do; the command line (pvr) counts as admin
    u = users().get(user)
    return set(PERMS) if u is None else set(perms_of(u.get("role", "")))


def perms_of(role):
    if role == "admin":
        return list(PERMS)
    return [p for p in roles().get(role, []) if p in PERMS]


def users():
    u = load_json("users.json", {})
    return u if isinstance(u, dict) else {}


def hash_pw(pw, salt=None, n=310000):
    salt = salt or secrets.token_hex(16)
    return "pbkdf2_sha256$%d$%s$%s" % (n, salt, hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), n).hex())


def check_pw(pw, stored):
    try:
        _, n, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, salt, int(n)).split("$")[3], h)
    except (ValueError, AttributeError):
        return False


def totp(secret, t=None):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    c = int((t or time.time()) // 30)
    d = hmac.new(key, struct.pack(">Q", c), "sha1").digest()
    o = d[-1] & 15
    return "%06d" % ((struct.unpack(">I", d[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_ok(secret, code):
    code = re.sub(r"\s", "", code or "")
    now = time.time()
    return any(hmac.compare_digest(totp(secret, now + 30 * w), code) for w in (-1, 0, 1))


def gen_password():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(14))


def allowed_courses(u):
    c = u.get("courses", "*")
    return None if c == "*" or u.get("role") == "admin" else set(c)


SESSIONS = {}   # fingerprint of the sign-in token -> {user, last}; kept on disk, so an update doesn't sign anyone out
_SESS = {"saved": 0}


def skey(tok):   # only a fingerprint is kept - a copy of the file can't be used to sign in
    return hashlib.sha256(tok.encode()).hexdigest()


def sessions_load():
    d = load_json("priv/sessions.json", {})
    now = time.time()
    for k, v in (d.items() if isinstance(d, dict) else []):
        if isinstance(v, dict) and now - v.get("last", 0) < IDLE:
            SESSIONS[k] = {"user": v.get("user", ""), "last": v["last"]}


def sessions_save(force=False):
    if not force and time.time() - _SESS["saved"] < 30:
        return
    _SESS["saved"] = time.time()
    try:
        os.makedirs(path("priv"), exist_ok=True)
        save_json("priv/sessions.json", {k: {"user": v["user"], "last": v["last"]} for k, v in list(SESSIONS.items())})
        os.chmod(path("priv/sessions.json"), 0o600)
    except OSError:
        pass
FAILS = {}


def failed_recently(key):
    now = time.time()
    FAILS[key] = [t for t in FAILS.get(key, []) if now - t < 600]
    return len(FAILS[key]) >= 5


# ---------------------------------------------------------------------------- settings
DEFAULT_SETTINGS = {
    "default_snapshot": "ClassStart",
    "shutdown_timeout": SHUTDOWN_TIMEOUT,
    "max_parallel": PARALLEL,
    "protected": "",
    "sensor_pattern": "dragos|sensor|tenable|zeek|suricata|snort|onion|nsm",
    "show_guide": True,
    "default_theme": "",
    "backup_keep": 30,
    "start_delay": 0,
}


def settings():
    s = dict(DEFAULT_SETTINGS)
    v = load_json("settings.json", {})
    if isinstance(v, dict):
        s.update({k: v[k] for k in DEFAULT_SETTINGS if k in v})
    return s


def parse_ranges(text):
    """'100-105,9001 9100-9110' -> set of VMIDs"""
    out = set()
    for part in re.split(r"[\s,]+", text or ""):
        m = re.match(r"^(\d+)(?:-(\d+))?$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2) or m.group(1))
            if a <= b and b - a <= 100000:
                out.update(range(a, b + 1))
    return out


def protected_ids():
    return parse_ranges(settings()["protected"])


# ---------------------------------------------------------------------------- shared files: class guides, add-ons
SHARE = os.path.join(DATA, "share")
GUIDES = os.path.join(SHARE, "guides")
ADDONS = os.path.join(SHARE, "addons")
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
ADDON_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}\.sh$")


COURSE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$")   # starts with a letter or digit - never "." or ".."


def field(self, method, b, key, kind):
    """A save must be a PUT that names what it saves - a missing field never wipes anything."""
    if method != "PUT":
        raise ValueError("use PUT to save")
    v = b.get(key)
    if not isinstance(v, kind):
        raise ValueError("bad request - %s is missing" % key)
    return v


def guide_file(course):
    if not COURSE_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(GUIDES, course + ".md")


def read_text(f):
    try:
        with open(f, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def write_text(f, text, mode=0o640):
    os.makedirs(os.path.dirname(f), exist_ok=True)
    tmp = f + ".new"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, f)


def fetch_url(url, limit=1_000_000):
    """Import a guide or add-on from a web address (GitHub / Gitea raw files)."""
    if not re.match(r"^https?://[^\s]+$", url or ""):
        raise ValueError("give a web address starting with https://")
    url = re.sub(r"^(https://github\.com/[^/]+/[^/]+)/blob/", r"\1/raw/", url)   # GitHub page -> raw file
    url = re.sub(r"^(https?://[^/]+/[^/]+/[^/]+)/src/branch/", r"\1/raw/branch/", url)   # Gitea page -> raw file
    req = urllib.request.Request(url, headers={"User-Agent": "ics-ranges"})
    try:
        with urllib.request.urlopen(req, timeout=20, context=ssl.create_default_context()) as r:
            data = r.read(limit + 1)
    except (urllib.error.URLError, OSError) as e:
        raise ValueError("couldn't download it: %s" % e)
    if len(data) > limit:
        raise ValueError("that file is larger than 1 MB")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("that isn't a text file")


def addon_dir(course):
    if course != "_all" and not COURSE_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(ADDONS, course)


def addon_meta(text, fname):
    meta = {"name": fname[:-3], "desc": "", "guests": False}
    for line in (text or "").splitlines()[:30]:
        m = re.match(r"^#\s*(NAME|DESC|GUESTS):\s*(.*)$", line)
        if m:
            k, v = m.group(1), m.group(2).strip()
            if k == "NAME":
                meta["name"] = v
            elif k == "DESC":
                meta["desc"] = v
            else:
                meta["guests"] = v.lower() in ("yes", "1", "true")
    return meta


def list_addons(course):
    out = []
    for d in ("_all", course):
        p = addon_dir(d)
        try:
            names = sorted(os.listdir(p))
        except OSError:
            continue
        for f in names:
            if ADDON_RE.match(f):
                meta = addon_meta(read_text(os.path.join(p, f)), f)
                meta.update({"file": f, "scope": d})
                out.append(meta)
    return out


ADDON_TEMPLATE = """#!/usr/bin/env bash
# NAME: My add-on
# DESC: What it does, in one line
# GUESTS: yes
#
# Runs inside ICS Ranges with the Proxmox API. You can use:
#   $GUESTS   the VMIDs picked in the GUI (if GUESTS: yes), e.g. "510101 510102"
#   $COURSE   the course in use
#   qm, pct, pvesh   work as on a node, through the API
#   qm enroll-efi-keys <vmid>   works too, with the node key (Settings, Node key)
for id in $GUESTS; do
    echo "== $id"
    qm status "$id" 2>/dev/null || pct status "$id"
done
"""


# ---------------------------------------------------------------------------- Git: history, your repository, backups
REPO = os.path.join(DATA, "repo")
BACKUPS = os.path.join(DATA, "backups")
GIT_LOCK = threading.Lock()
SAVED = ["roles.json", "vmid-map.conf", "settings.json", "mirrors.json", "groups.json", "themes.json", "courses.json"]


def git_conf():
    c = load_json("git.json", {})
    return c if isinstance(c, dict) else {}


def git_env():
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", HOME=DATA)
    tok = path("priv/git-token")
    if os.path.exists(tok):
        ask = path("priv/askpass.sh")
        if not os.path.exists(ask):
            write_text(ask, "#!/bin/sh\ncat '%s'\n" % tok, 0o700)
        env["GIT_ASKPASS"] = ask
    key = path("ssh/git_ed25519")
    env["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=%s%s" % (
        path("ssh/known_hosts"), (" -o IdentitiesOnly=yes -i " + key) if os.path.exists(key) else "")
    return env


def remote_url(c):
    url, user = c.get("url", ""), c.get("user", "")
    if user and re.match(r"^https?://", url) and "@" not in url.split("/")[2]:
        url = re.sub(r"^(https?://)", r"\1%s@" % urllib.parse.quote(user, safe=""), url)
    return url


def git(*args, check=True, cwd=REPO, timeout=60):
    c = git_conf()
    pre = ["git", "-c", "user.name=ics-ranges", "-c", "user.email=ics-ranges@localhost", "-c", "init.defaultBranch=main"]
    if c.get("insecure"):
        pre += ["-c", "http.sslVerify=false"]
    p = subprocess.run(pre + list(args), cwd=cwd, env=git_env(), capture_output=True, text=True, timeout=timeout)
    if check and p.returncode:
        raise PVEError((p.stderr or p.stdout).strip().splitlines()[-1] if (p.stderr or p.stdout).strip() else "git failed")
    return p.stdout


def export_tree(dest):
    """Copy what is shared (no users, no secrets) into dest."""
    import shutil
    for sub in ("addons", "guides"):
        shutil.rmtree(os.path.join(dest, sub), ignore_errors=True)
        src = os.path.join(SHARE, sub)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dest, sub))
    os.makedirs(os.path.join(dest, "settings"), exist_ok=True)
    for f in SAVED:
        s = path(f)
        t = os.path.join(dest, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, t)
        elif os.path.exists(t):
            os.remove(t)
    readme = os.path.join(dest, "README.md")
    if not os.path.exists(readme):
        write_text(readme, "# ICS Ranges\n\nAdd-ons, class guides and settings of ICS Ranges.\n\n"
                   "- `addons/_all/` add-ons for every course, `addons/<course>/` for one course\n"
                   "- `guides/<course>.md` how each course is run\n- `settings/` roles, course map, mirrors, groups, themes\n")


def import_tree(src):
    import shutil
    for sub in ("addons", "guides"):
        s = os.path.join(src, sub)
        if os.path.isdir(s):
            shutil.rmtree(os.path.join(SHARE, sub), ignore_errors=True)
            shutil.copytree(s, os.path.join(SHARE, sub))
    for f in SAVED:
        s = os.path.join(src, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, path(f))
    inv.forget(list(inv.guests))


def repo_init():
    if not os.path.isdir(os.path.join(REPO, ".git")):
        os.makedirs(REPO, exist_ok=True)
        git("init", "-q")
    c = git_conf()
    url = remote_url(c)
    have = git("remote", check=False).split()
    if url and "origin" not in have:
        git("remote", "add", "origin", url)
    elif url:
        git("remote", "set-url", "origin", url)
    elif "origin" in have:
        git("remote", "remove", "origin")


def repo_save(who, msg):
    """Commit the shared files; push to your repository if one is connected. Returns a short report."""
    with GIT_LOCK:
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        changed = bool(git("status", "--porcelain").strip())
        if changed:
            git("commit", "-q", "-m", msg, "--author", "%s <%s@ics-ranges>" % (who, who))
        c = git_conf()
        if not c.get("url"):
            return "Saved in the history." if changed else "Nothing new to save."
        br = c.get("branch") or "main"
        if git("ls-remote", "--heads", "origin", br, check=False).strip():
            git("fetch", "-q", "origin", br)
            if git("merge-base", "HEAD", "origin/" + br, check=False).strip() == "":
                git("merge", "-q", "--allow-unrelated-histories", "-X", "ours", "-m", "Join with the repository", "origin/" + br)
            else:
                git("merge", "-q", "-X", "ours", "-m", "Join with the repository", "origin/" + br, check=False)
        git("push", "-q", "origin", "HEAD:" + br, timeout=120)
        return "Saved and uploaded to %s (%s)." % (c["url"], br)


def repo_pull(who):
    with GIT_LOCK:
        c = git_conf()
        if not c.get("url"):
            raise ValueError("connect a repository first")
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        if git("status", "--porcelain").strip():
            git("commit", "-q", "-m", "Before getting the latest", "--author", "%s <%s@ics-ranges>" % (who, who))
        br = c.get("branch") or "main"
        git("fetch", "-q", "origin", br)
        if git("rev-parse", "--verify", "-q", "HEAD", check=False).strip():
            git("merge", "-q", "--allow-unrelated-histories", "-X", "theirs", "-m", "Latest from the repository", "origin/" + br)
        else:
            git("reset", "-q", "--hard", "origin/" + br)
        import_tree(REPO)
        return "Loaded the latest from %s (%s)." % (c["url"], br)


AUTOSAVE = {"t": None}


def autosave(who, msg):
    """Every change is saved (and uploaded) a moment later, in the background."""
    def go():
        try:
            r = repo_save(who, msg)
            if git_conf().get("url"):
                audit(who, "auto-save: " + r)
        except Exception as e:   # noqa
            audit(who, "auto-save FAILED: %s" % e)
        try:
            if settings().get("backup_keep", 0):
                make_backup(auto=True)
        except Exception:   # noqa
            pass
    t = AUTOSAVE.get("t")
    if t:
        t.cancel()
    AUTOSAVE["t"] = threading.Timer(3, go)
    AUTOSAVE["t"].daemon = True
    AUTOSAVE["t"].start()


def make_backup(auto=False):
    import shutil
    import tarfile
    import tempfile
    os.makedirs(BACKUPS, exist_ok=True)
    name = "backup-%s.tar.gz" % time.strftime("%Y%m%d-%H%M%S")
    with tempfile.TemporaryDirectory() as tmp:
        export_tree(tmp)
        with tarfile.open(os.path.join(BACKUPS, name), "w:gz") as t:
            for x in os.listdir(tmp):
                t.add(os.path.join(tmp, x), arcname=x)
        del shutil
    keep = int(settings().get("backup_keep") or 30)
    files = sorted(f for f in os.listdir(BACKUPS) if f.startswith("backup-"))
    for f in files[:-keep]:
        os.remove(os.path.join(BACKUPS, f))
    return name


def restore_backup(name):
    import tarfile
    import tempfile
    if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", name or ""):
        raise ValueError("bad backup name")
    f = os.path.join(BACKUPS, name)
    if not os.path.exists(f):
        raise KeyError("no such backup")
    with tempfile.TemporaryDirectory() as tmp, tarfile.open(f) as t:
        for m in t.getmembers():
            if m.name.startswith("/") or ".." in m.name.split("/") or not (m.isfile() or m.isdir()):
                raise ValueError("unsafe backup file")
        t.extractall(tmp)
        import_tree(tmp)


# ---------------------------------------------------------------------------- build actions: network, disks, migration, add-ons
def net_split(val):
    parts = [p for p in val.split(",") if p]
    return parts


def net_change(g, val, ch):
    """Change bridge / VLAN / firewall / model of one NIC line, keeping the MAC and the rest."""
    parts = net_split(val)
    kv = []
    for p in parts:
        k, _, v = p.partition("=")
        kv.append([k, v])
    keys = [k for k, _ in kv]
    def setk(k, v):
        if v is None:
            return
        if k in keys:
            if v == "":
                kv[:] = [x for x in kv if x[0] != k]
                keys.remove(k)
            else:
                kv[keys.index(k)][1] = v
        elif v != "":
            kv.append([k, v])
            keys.append(k)
    setk("bridge", ch.get("bridge") or None)
    if "vlan" in ch and ch["vlan"] is not None:
        setk("tag", str(ch["vlan"]).strip())
    if ch.get("firewall") in ("on", "off"):
        setk("firewall", "1" if ch["firewall"] == "on" else "0")
    if ch.get("model") and g["type"] == "qemu" and kv and re.match(r"^[0-9A-Fa-f:]{17}$", kv[0][1] or ""):
        kv[0][0] = ch["model"]
    return ",".join(k + (("=" + v) if v != "" else "") for k, v in kv)


DISK_RE = re.compile(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$")
RAW_ONLY = ("lvm", "lvmthin", "zfspool", "rbd", "iscsi", "iscsidirect", "zfs")


def storage_types():
    return {x["storage"]: x.get("type", "") for x in pve.call("GET", "/storage") or []}


def run_addon(user, course, f, ids, buf):
    env = dict(os.environ, COURSE=course, PVE_RANGE_FOLDER=course, GUESTS=" ".join(map(str, ids)),
               PVE_RANGE_API="1", PVE_RANGE_GUI="1", PVE_RANGE_USER=user, LC_PVERANGE_USER=user,
               PVE_RANGE_DATA=DATA, PATH="/usr/local/lib/ics-ranges/api:" + os.environ.get("PATH", ""))
    p = subprocess.Popen(["bash", f], cwd="/tmp", env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    t0 = time.time()
    size = 0
    for line in p.stdout:
        size += len(line)
        if size < 400_000:
            buf.append(line)
        if time.time() - t0 > 1800:
            p.kill()
            buf.append("\n[stopped after 30 minutes]\n")
            break
    rc = p.wait()
    if rc:
        raise PVEError("the add-on ended with exit code %d" % rc)
    return ""


# ---------------------------------------------------------------------------- port mirroring (ovs-vsctl over the restricted key)
def node_ip(node):
    for s in pve.call("GET", "/cluster/status") or []:
        if s.get("type") == "node" and s.get("name") == node:
            return s.get("ip")
    raise PVEError("no IP for node %s" % node)


def node_cmd(node, *args, timeout=30):
    """Run one allowed command on a node with the restricted key: ovs-vsctl ..., or
    qm enroll-efi-keys <vmid> (the node's key line allows nothing else)."""
    if not os.path.exists(OVS_KEY):
        raise PVEError("the node key isn't set up - see Settings, Node key")
    cmd = ["ssh", "-n", "-i", OVS_KEY, "-o", "BatchMode=yes", "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=8",
           "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=accept-new",
           "-o", "UserKnownHostsFile=" + os.path.join(DATA, "ssh", "known_hosts"),
           "root@" + node_ip(node)] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode:
        err = (p.stderr or p.stdout).strip()
        if args[:1] == ("qm",) and "only ovs-vsctl" in err:
            raise PVEError("the key line on %s only allows ovs-vsctl - add the new line from Settings, Node key "
                           "(or use 'New EFI disk with keys')" % node)
        raise PVEError(err or "%s failed on %s" % (args[0], node))
    return p.stdout


def ovs(node, *args):
    return node_cmd(node, "ovs-vsctl", *args)


def mirrors():
    m = load_json("mirrors.json", [])
    return m if isinstance(m, list) else []


def nic_dev(g, nic):
    n = nic[3:]
    return ("veth%di%s" if g["type"] == "lxc" else "tap%di%s") % (g["vmid"], n)


def mirror_status(node, bridge):
    """The mirrors on a bridge, each with its output port and packets sent."""
    out = {"node": node, "bridge": bridge, "mirrors": [], "error": "", "snooping": None,
           "applied": load_json("mirror-applied.json", {}).get("%s/%s" % (node, bridge))}
    if inv.offline:
        out["error"] = "Proxmox isn't answering - the mirrors can't be checked"
        return out
    try:
        out["snooping"] = ovs(node, "get", "bridge", bridge, "mcast_snooping_enable").strip() == "true"
    except (PVEError, subprocess.TimeoutExpired):
        pass
    try:
        on = set(re.findall(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", ovs(node, "get", "bridge", bridge, "mirrors")))
        if on:
            ports = json.loads(ovs(node, "--format=json", "--columns=_uuid,name", "list", "port"))["data"]
            pmap = {r[0][1]: r[1] for r in ports}
            rows = json.loads(ovs(node, "--format=json", "--columns=_uuid,name,output_port,statistics", "list", "mirror"))["data"]
            for r in rows:
                if r[0][1] not in on:
                    continue
                port = pmap.get(r[2][1], "?") if r[2][0] == "uuid" else "-"
                stats = dict(r[3][1]) if r[3][0] == "map" else {}
                out["mirrors"].append({"name": r[1], "port": port, "packets": stats.get("tx_packets", 0)})
    except (PVEError, ValueError, KeyError, IndexError, TypeError, subprocess.TimeoutExpired) as e:
        out["error"] = str(e)
    return out


def mirror_groups(G, in_course, notes, user, all_saved=False):
    """The stages that put a course's saved mirrors back (and IGMP snooping as chosen)."""
    groups = []
    for mr in mirrors():
        if any(e.get("vmid") in in_course or all_saved for e in mr.get("entries", [])):
            groups.extend(bridge_groups(G, mr, notes, user))
    return groups


def bridge_groups(G, mr, notes, user):
    """One bridge: turn the firewall off on its mirror NICs, (re)create the mirrors, IGMP snooping as chosen."""
    groups = []
    node, bridge = mr["node"], mr["bridge"]
    all_ents = [e for e in mr.get("entries", []) if e.get("vmid") in G]
    cfgs = inv.configs([e["vmid"] for e in all_ents], max_age=0)
    fw, ovs_args, names = [], [], []
    for k, e in enumerate(all_ents):
        g = G[e["vmid"]]
        cur = cfgs.get(g["vmid"], {}).get(e["nic"], "")
        if not cur:
            notes.append("%d has no %s - skipped" % (g["vmid"], e["nic"]))
            continue
        if g["node"] != node:
            notes.append("%d is on %s, not %s - skipped" % (g["vmid"], g["node"], node))
            continue
        if g["status"] != "running":
            notes.append("%d %s isn't running - its mirror works once it runs (then Re-apply mirrors)" % (g["vmid"], g["name"]))
        if "firewall=1" in cur.split(","):
            new = ",".join(p for p in cur.split(",") if p != "firewall=1")
            fw.append(step("Turn the firewall off on %d %s (needed for its mirror)" % (g["vmid"], e["nic"]), node,
                           (lambda g=g, nic=e["nic"], new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), g["vmid"]))
        ovs_args += ["--", "--id=@p%d" % k, "get", "port", nic_dev(g, e["nic"]),
                     "--", "--id=@m%d" % k, "create", "mirror", "name=m-%d-%s" % (g["vmid"], e["nic"]),
                     "select-all=true", "output-port=@p%d" % k]
        names.append("@m%d" % k)
    if fw:
        groups.append(fw)
    want = mr.get("igmp") or ("off" if mr.get("igmp_off") else "")
    snoop = ["--", "set", "bridge", bridge, "mcast_snooping_enable=%s" % ("true" if want == "on" else "false")] if want else []

    def done(node=node, bridge=bridge):
        st = load_json("mirror-applied.json", {})
        st["%s/%s" % (node, bridge)] = {"at": time.strftime("%Y-%m-%d %H:%M"), "by": user}
        save_json("mirror-applied.json", st)
    if names:
        args = ovs_args + ["--", "set", "bridge", bridge, "mirrors=" + ",".join(names)] + snoop

        def run(node=node, args=args, fw=fw):
            time.sleep(1 if fw else 0)
            ovs(node, *args)
            done()
            return ""
        groups.append([step("Mirror %s on %s to %d port(s)%s" % (bridge, node, len(names), (", IGMP snooping " + want) if want else ""), node, run, None)])
    elif snoop:
        groups.append([step("IGMP snooping %s on %s (%s)" % (want, bridge, node), node, (lambda node=node, a=snoop[1:]: ovs(node, *a) and ""), None)])
    return groups


# ---------------------------------------------------------------------------- plans and jobs
PLANS = {}
JOBS = {}


def step(label, node, fn, vmid=None, buf=None):
    return {"label": label, "node": node, "fn": fn, "vmid": vmid, "buf": buf}


def gpath(g):
    return "/nodes/%s/%s/%d" % (g["node"], g["type"], g["vmid"])


def st_rollback(g, snap):
    return step("Restore %d %s to %s" % (g["vmid"], g["name"], snap), g["node"],
                lambda: pve.task("POST", gpath(g) + "/snapshot/%s/rollback" % urllib.parse.quote(snap, safe="")), g["vmid"])


def st_start(g):
    return step("Start %d %s" % (g["vmid"], g["name"]), g["node"], lambda: pve.task("POST", gpath(g) + "/status/start"), g["vmid"])


def st_stop(g, mode):
    if mode == "stop":
        return step("Power off %d %s (hard)" % (g["vmid"], g["name"]), g["node"],
                    lambda: pve.task("POST", gpath(g) + "/status/stop"), g["vmid"])
    return step("Shut down %d %s" % (g["vmid"], g["name"]), g["node"],
                lambda: pve.task("POST", gpath(g) + "/status/shutdown", {"timeout": int(settings()["shutdown_timeout"]), "forceStop": 1}), g["vmid"])


def start_groups(gs):
    """Containers first, then VMs - all at once, or one by one with a pause (Settings)."""
    delay = int(settings().get("start_delay") or 0)
    cts, vms = ct_first(gs)
    if delay <= 0:
        return [[st_start(g) for g in grp] for grp in (cts, vms) if grp]
    out = []
    for g in cts + vms:
        st = st_start(g)
        fn = st["fn"]
        st["fn"] = (lambda fn=fn: (fn(), time.sleep(delay))[0])
        st["label"] += "  (then %d s pause)" % delay
        out.append([st])
    return out


def ct_first(gs):
    return [g for g in gs if g["type"] == "lxc"], [g for g in gs if g["type"] == "qemu"]


def build_plan(user, body):
    a = body.get("action")
    course = body.get("course")
    u = users().get(user, {})
    allow = allowed_courses(u)
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh()
    in_course = set(inv.course_ids(course))
    pick = lambda key: [int(x) for x in body.get(key, []) if int(x) in in_course]
    ids = pick("ids")
    G = inv.guests
    groups, notes = [], []
    need = {"class_start": "class_run", "class_end": "class_run", "power_on": "power", "power_off": "power",
            "snap_take": "snap_take", "snap_restore": "snap_restore", "snap_delete": "snap_delete",
            "mirror_apply": "mirror_apply", "network": "network", "disk_move": "disks", "migrate": "migrate",
            "addon_run": "addons_run", "efi_keys": "efi", "igmp": "mirror_setup", "net_addons": "mirror_setup"}.get(a)
    if not need or need not in perms_of(u.get("role")):
        raise PermissionError("your role can't do this")

    snap = (body.get("snapshot") or "").strip()
    if a in ("class_start", "class_end", "snap_restore", "snap_delete", "snap_take"):
        if not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", snap):
            raise ValueError("snapshot names start with a letter: letters, digits, - and _")

    if a in ("class_start", "class_end"):
        # restore = guests to roll back; start / off = guests to power on / switch off
        restore, power = pick("restore"), pick("start" if a == "class_start" else "off")
        if a == "class_start" and restore and "snap_restore" not in user_perms(user):
            restore = []   # Start class only powers on, unless the role may restore snapshots
            notes.append("Start class powers the guests on as they are - End class resets them")
        ids = sorted(set(restore) | set(power))
        snaps = inv.snapshots(ids)
        has = {v: {s["name"]: s for s in snaps.get(v, [])} for v in ids}
        restore = [v for v in restore if snap in has[v]]
        ram = {v for v in restore if G[v]["type"] == "qemu" and has[v][snap]["ram"]}
        if restore:
            groups.append([st_rollback(G[v], snap) for v in restore])
        if a == "class_start":
            start = []
            for v in power:
                if v in ram:
                    notes.append("%d %s: its snapshot includes memory, so the restore brings it back running" % (v, G[v]["name"]))
                elif v not in restore and G[v]["status"] == "running":
                    notes.append("%d %s is already running" % (v, G[v]["name"]))
                else:
                    start.append(G[v])
            groups.extend(start_groups(start))
        else:
            mode = "stop" if body.get("mode") == "stop" else "shutdown"
            restored_on = [G[v] for v in power if v in ram]
            kept_on = [G[v] for v in power if v not in restore and G[v]["status"] == "running"]
            if restored_on:
                groups.append([st_stop(g, "stop") for g in restored_on])
                notes.append("Reset guests whose snapshot includes memory come back running - they are then powered off at once (nothing in them to save)")
            if kept_on:
                groups.append([st_stop(g, mode) for g in kept_on])
            if restore and len(ram) < len(restore):
                notes.append("Reset guests whose snapshot has no memory are off right after the restore - no separate switch-off")
    elif a == "power_on":
        todo = [G[v] for v in ids if G[v]["status"] != "running"]
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d of the selected guests already run - left as they are" % skipped)
        groups.extend(start_groups(todo))
    elif a == "power_off":
        mode = "stop" if body.get("mode") == "stop" else "shutdown"
        todo = [G[v] for v in ids if G[v]["status"] == "running"]
        if len(todo) < len(ids):
            notes.append("%d of the selected guests are already off - left as they are" % (len(ids) - len(todo)))
        cts, vms = ct_first(todo)
        if vms:
            groups.append([st_stop(g, mode) for g in vms])
        if cts:
            groups.append([st_stop(g, mode) for g in cts])
    elif a == "snap_take":
        ram = bool(body.get("ram"))
        when = body.get("when", "running")   # running | off_first | off_after
        existing = inv.snapshots(ids)
        clash = [v for v in ids if any(s["name"] == snap for s in existing.get(v, []))]
        if clash and not body.get("replace"):
            raise ValueError("%d guest(s) already have a snapshot called %s - tick 'replace' to overwrite it" % (len(clash), snap))
        if clash:
            groups.append([step("Delete the old snapshot %s of %d" % (snap, v), G[v]["node"],
                                (lambda g=G[v]: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))), v) for v in clash])
        on = [G[v] for v in ids if G[v]["status"] == "running"]
        if when == "off_first" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
            notes.append("Running guests are shut down first, so their disks are clean")
            ram = False
        groups.append([step("Snapshot %d %s as %s%s" % (v, G[v]["name"], snap, " with memory" if ram and G[v]["type"] == "qemu" and G[v]["status"] == "running" else ""),
                            G[v]["node"],
                            (lambda g=G[v]: pve.task("POST", gpath(g) + "/snapshot",
                                                     {"snapname": snap, "vmstate": 1 if ram and g["type"] == "qemu" and g["status"] == "running" else None})),
                            v) for v in ids])
        if when == "off_after" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
    elif a == "snap_restore":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if len(todo) < len(ids):
            notes.append("%d guest(s) don't have %s" % (len(ids) - len(todo), snap))
        if todo:
            groups.append([st_rollback(g, snap) for g in todo])
        ram = {g["vmid"] for g in todo if g["type"] == "qemu" and any(x["name"] == snap and x["ram"] for x in snaps.get(g["vmid"], []))}
        after = body.get("after", "leave")   # leave | start | off
        if after == "start":
            groups.extend(start_groups([g for g in todo if g["vmid"] not in ram]))
            if ram:
                notes.append("%d guest(s) come back running by themselves (memory snapshot)" % len(ram))
        elif after == "off" and ram:
            groups.append([st_stop(G[v], "stop") for v in sorted(ram)])
            notes.append("Guests restored with memory come back running - they are switched off afterwards")
        elif after == "leave" and ram:
            notes.append("%d guest(s) come back running (memory snapshot); the others stay off" % len(ram))
    elif a == "snap_delete":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if todo:
            groups.append([step("Delete snapshot %s of %d %s" % (snap, g["vmid"], g["name"]), g["node"],
                                (lambda g=g: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))),
                                g["vmid"]) for g in todo])
    elif a == "mirror_apply":
        groups.extend(mirror_groups(G, in_course, notes, user, body.get("all_saved")))
        if not groups and not notes:
            notes.append("No saved mirrors for this course - an admin sets them up under Sensors")
    elif a == "net_addons":   # one bridge: mirrors, IGMP snooping, and per NIC firewall / connected
        node, bridge = body.get("node", ""), body.get("bridge", "")
        if node not in inv.nodes or not re.match(r"^[A-Za-z0-9_.-]{1,32}$", bridge):
            raise ValueError("pick a bridge")
        ovs_br = bridge in node_bridges(node).get("ovs", [])
        want = {}
        for n in body.get("nics") or []:
            v, nic = int(n.get("vmid", 0)), str(n.get("nic", ""))
            if v not in in_course or not re.match(r"^net\d+$", nic):
                raise ValueError("%s %s isn't a NIC of this course" % (v, nic))
            tag = str(n.get("tag", "keep")).strip()
            if tag not in ("keep", "") and not (tag.isdigit() and 1 <= int(tag) <= 4094):
                raise ValueError("%d %s: a VLAN tag is a number from 1 to 4094 (or empty for none)" % (v, nic))
            want[(v, nic)] = {"firewall": bool(n.get("firewall")), "connected": bool(n.get("connected", True)), "tag": tag}
        mirror = [(int(m["vmid"]), str(m["nic"])) for m in body.get("mirror") or [] if int(m.get("vmid", 0)) in in_course and re.match(r"^net\d+$", str(m.get("nic", "")))]
        if mirror and not ovs_br:
            raise ValueError("%s on %s isn't an Open vSwitch bridge - mirrors need one" % (bridge, node))
        igmp = body.get("igmp") if body.get("igmp") in ("on", "off") else ""
        if igmp and not ovs_br:
            raise ValueError("IGMP snooping can only be switched on Open vSwitch bridges here")
        cfgs = inv.configs([v for v, _ in want], max_age=0)
        changes = []
        for (v, nic), w in sorted(want.items()):
            cur = cfgs.get(v, {}).get(nic, "")
            if not cur or "bridge=%s" % bridge not in cur.split(","):
                raise ValueError("%d %s isn't on %s" % (v, nic, bridge))
            if (v, nic) in mirror:
                w["firewall"] = False   # a mirror port must not be firewalled
            old_tag = (re.search(r"(?:^|,)tag=(\d+)", cur) or [None, ""])[1]
            new_tag = old_tag if w["tag"] == "keep" else w["tag"]
            parts = [p for p in cur.split(",") if not p.startswith(("firewall=", "link_down=", "tag="))]
            if new_tag:
                parts.append("tag=" + new_tag)
            if w["firewall"]:
                parts.append("firewall=1")
            if not w["connected"]:
                parts.append("link_down=1")
            new = ",".join(parts)
            if set(new.split(",")) != set(cur.split(",")):
                g = G[v]
                what = []
                if ("firewall=1" in cur.split(",")) != w["firewall"]:
                    what.append("firewall " + ("on" if w["firewall"] else "off"))
                if ("link_down=1" in cur.split(",")) == w["connected"]:
                    what.append("connected" if w["connected"] else "disconnected")
                if new_tag != old_tag:
                    what.append(("VLAN %s" % new_tag) if new_tag else "no VLAN tag")
                changes.append(step("%d %s %s: %s" % (v, g["name"], nic, ", ".join(what)), g["node"],
                                    (lambda g=g, nic=nic, new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), v))
        if changes and "network" not in user_perms(user):
            raise PermissionError("changing the firewall, connections or VLAN tags needs the permission 'Change network settings'")
        if changes:
            groups.append(changes)
        if ovs_br:
            old = next((m for m in mirrors() if m["node"] == node and m["bridge"] == bridge), None)
            keep_igmp = igmp or (old or {}).get("igmp") or ("off" if (old or {}).get("igmp_off") else "")
            others = [e for e in (old or {}).get("entries", []) if e.get("vmid") not in in_course]   # other courses' sensors stay
            ents = others + [{"vmid": v, "nic": nic} for v, nic in mirror]
            new_mr = {"node": node, "bridge": bridge, "entries": ents, "igmp": keep_igmp}
            changed = old is None and (ents or igmp) or old is not None and (sorted(map(str, old.get("entries", []))) != sorted(map(str, ents)) or (old.get("igmp") or "") != keep_igmp)
            if changed:
                def save(new_mr=new_mr, node=node, bridge=bridge, user=user):
                    with LOCK:
                        ms = [m for m in mirrors() if not (m["node"] == node and m["bridge"] == bridge)]
                        if new_mr["entries"] or new_mr["igmp"]:
                            ms.append(new_mr)
                        save_json("mirrors.json", ms)
                    audit(user, "network add-ons saved for %s on %s: %d mirror port(s), IGMP snooping %s" % (bridge, node, len(new_mr["entries"]), new_mr["igmp"] or "as it is"))
                    autosave(user, "network add-ons %s/%s" % (node, bridge))
                    return ""
                groups.append([step("Save the network add-ons for %s on %s" % (bridge, node), node, save, None)])
            if ents:
                groups.extend(bridge_groups(G, new_mr, notes, user))
            else:
                if old and old.get("entries"):
                    groups.append([step("Remove the mirrors on %s (%s)" % (bridge, node), node, (lambda node=node: ovs(node, "clear", "bridge", bridge, "mirrors") and ""), None)])
                if igmp:
                    groups.append([step("IGMP snooping %s on %s (%s)" % (igmp, bridge, node), node,
                                        (lambda node=node: ovs(node, "set", "bridge", bridge, "mcast_snooping_enable=%s" % ("true" if igmp == "on" else "false")) and ""), None)])
        if not groups:
            notes.append("Nothing to change - the NICs and the bridge already look like that")
    elif a == "igmp":   # IGMP snooping on an Open vSwitch bridge - on or off; the choice is kept for re-applies
        node, bridge, on = body.get("node", ""), body.get("bridge", ""), bool(body.get("on"))
        if not any(m["node"] == node and m["bridge"] == bridge for m in mirrors()):
            raise ValueError("pick a bridge with mirrors")

        def set_snooping(node=node, bridge=bridge, on=on, user=user):
            ovs(node, "set", "bridge", bridge, "mcast_snooping_enable=%s" % ("true" if on else "false"))
            with LOCK:
                ms = mirrors()
                for m in ms:
                    if m["node"] == node and m["bridge"] == bridge:
                        m["igmp"] = "on" if on else "off"
                        m.pop("igmp_off", None)
                save_json("mirrors.json", ms)
            audit(user, "IGMP snooping %s on %s/%s" % ("on" if on else "off", node, bridge))
            autosave(user, "IGMP snooping %s on %s/%s" % ("on" if on else "off", node, bridge))
            return ""
        groups.append([step("IGMP snooping %s on %s (%s)" % ("on" if on else "off", bridge, node), node, set_snooping, None)])
    elif a == "network":
        ch = body.get("change") or {}
        if ch.get("bridge") and not re.match(r"^[A-Za-z0-9_.-]+$", ch["bridge"]):
            raise ValueError("bad bridge name")
        if ch.get("vlan") not in (None, "") and not re.match(r"^\d{1,4}$", str(ch["vlan"])):
            raise ValueError("VLAN tags are numbers 1-4094 (empty = no tag)")
        if ch.get("model") and ch["model"] not in ("virtio", "e1000", "e1000e", "rtl8139", "vmxnet3"):
            raise ValueError("bad NIC model")
        nic = body.get("nic") or "all"
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^net\d+$", k) and (nic == "all" or k == nic):
                    new = net_change(G[v], val, ch)
                    if new != val:
                        todo.append(step("%d %s %s: %s" % (v, G[v]["name"], k, new), G[v]["node"],
                                         (lambda g=G[v], k=k, new=new: pve.task("PUT", gpath(g) + "/config", {k: new})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("Nothing to change - the NICs already look like that")
    elif a == "disk_move":
        target, fmt, delete = body.get("storage", ""), body.get("format", "keep"), bool(body.get("delete", True))
        types = storage_types()
        if target not in types:
            raise ValueError("pick a storage")
        if fmt not in ("keep", "raw", "qcow2", "vmdk"):
            raise ValueError("bad format")
        if fmt in ("qcow2", "vmdk") and types[target] in RAW_ONLY:
            raise ValueError("%s (%s) only holds raw disks" % (target, types[target]))
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            g = G[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not DISK_RE.match(k) or "media=cdrom" in val or ":" not in val.split(",")[0]:
                    continue
                if body.get("disk") not in (None, "", "all") and k != body["disk"]:
                    continue
                vol = val.split(",")[0]
                cur_fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                want = cur_fmt if fmt == "keep" or types[target] in RAW_ONLY else fmt
                if types[target] in RAW_ONLY:
                    want = "raw"
                if vol.split(":")[0] == target and want == cur_fmt:
                    continue
                if g["type"] == "lxc":
                    if g["status"] == "running":
                        notes.append("%d %s is a running container - switch it off to move %s" % (v, g["name"], k))
                        continue
                    todo.append(step("Move %d %s %s to %s" % (v, g["name"], k, target), g["node"],
                                     (lambda g=g, k=k: pve.task("POST", gpath(g) + "/move_volume", {"volume": k, "storage": target, "delete": 1 if delete else 0})), v))
                else:
                    todo.append(step("Move %d %s %s to %s as %s" % (v, g["name"], k, target, want), g["node"],
                                     (lambda g=g, k=k, want=want: pve.task("POST", gpath(g) + "/move_disk", {"disk": k, "storage": target, "format": want if types[target] not in RAW_ONLY else None, "delete": 1 if delete else 0})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("No disk needs moving")
    elif a == "migrate":
        targets = body.get("nodes") or [body.get("node", "")]
        if not targets or any(t not in inv.nodes for t in targets):
            raise ValueError("pick nodes that are online")
        how = body.get("spread", "one")   # one | round | blocks
        plan_to = {}
        if how == "round":
            for k, v in enumerate(ids):
                plan_to[v] = targets[k % len(targets)]
        elif how == "blocks":
            per = -(-len(ids) // len(targets))
            for k, v in enumerate(ids):
                plan_to[v] = targets[min(k // per, len(targets) - 1)]
        else:
            plan_to = {v: targets[0] for v in ids}
        todo = []
        for v in ids:
            g = G[v]
            target = plan_to[v]
            if g["node"] == target:
                continue
            if g["type"] == "qemu":
                prm = {"target": target, "online": 1, "with-local-disks": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (live)" if g["status"] == "running" else "")
            else:
                prm = {"target": target, "restart": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (restart)" if g["status"] == "running" else "")
            todo.append(step(label, g["node"], (lambda g=g, prm=prm: pve.task("POST", gpath(g) + "/migrate", prm)), v))
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d already where they should be" % skipped)
        if todo:
            groups.append(todo)
    elif a == "efi_keys":
        method = body.get("method", "enroll")   # enroll (keeps boot entries) | recreate (API only)
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            g, c = G[v], cfgs.get(v, {})
            if g["type"] != "qemu":
                notes.append("%d %s is a container - containers have no EFI" % (v, g["name"]))
                continue
            if c.get("bios") != "ovmf":
                notes.append("%d %s uses SeaBIOS, not UEFI - skipped" % (v, g["name"]))
                continue
            if g["status"] == "running":
                notes.append("%d %s is running - switch it off first" % (v, g["name"]))
                continue
            efi = c.get("efidisk0", "")
            if "pre-enrolled-keys=1" in efi.split(",") and not body.get("again"):
                notes.append("%d %s already has the keys" % (v, g["name"]))
                continue
            if method == "enroll":
                if not efi:
                    notes.append("%d %s has no EFI disk - use 'New EFI disk with keys'" % (v, g["name"]))
                    continue
                todo.append(step("Enroll the EFI keys of %d %s" % (v, g["name"]), g["node"],
                                 (lambda g=g: node_cmd(g["node"], "qm", "enroll-efi-keys", str(g["vmid"]), timeout=120) and ""), v))
            else:
                if efi:
                    stor = efi.split(",")[0].split(":")[0]
                else:   # no EFI disk yet: put it with the VM's first disk
                    first = next((val for k, val in sorted(c.items()) if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]), "")
                    stor = first.split(":")[0] if first else ""
                if not stor:
                    notes.append("%d %s: no storage found for the EFI disk" % (v, g["name"]))
                    continue
                et = (re.search(r"efitype=([^,]+)", efi) or [None, "4m"])[1]
                new = "%s:1,efitype=%s,pre-enrolled-keys=1" % (stor, et)
                def recreate(g=g, had=bool(efi), new=new):
                    if had:   # the old EFI disk stays attached as 'unused' - you can switch back
                        pve.task("PUT", gpath(g) + "/config", {"delete": "efidisk0"})
                    return pve.task("PUT", gpath(g) + "/config", {"efidisk0": new})
                todo.append(step("New EFI disk with the keys for %d %s on %s%s" % (v, g["name"], stor, " (old one kept as unused)" if efi else ""),
                                 g["node"], recreate, v))
        if method != "enroll" and todo:
            notes.append("A new EFI disk starts without boot entries; most systems boot through the default path. "
                         "The old EFI disk stays on the VM as 'unused' until you remove it.")
        if todo:
            groups.append(todo)
    elif a == "addon_run":
        scope, f = body.get("scope", ""), body.get("file", "")
        if not ADDON_RE.match(f or ""):
            raise ValueError("bad add-on")
        if scope not in ("_all", course):
            raise PermissionError("that add-on isn't for this course")
        full = os.path.join(addon_dir(scope), f)
        if not os.path.exists(full):
            raise KeyError("no such add-on")
        meta = addon_meta(read_text(full), f)
        if meta["guests"] and not ids:
            raise ValueError("this add-on works on guests - select some first")
        buf = []
        groups.append([step("Run %s%s" % (meta["name"], (" on " + plural_n(len(ids), "guest")) if meta["guests"] else ""), "container",
                            (lambda: run_addon(user, course, full, ids if meta["guests"] else [], buf)), None, buf)])
    groups = [g for g in groups if g]
    pid = secrets.token_hex(8)
    PLANS[pid] = {"user": user, "title": body.get("title") or a, "groups": groups, "notes": notes,
                  "action": a, "course": course, "at": time.time()}
    return pid


def plural_n(n, word):
    return "%d %s%s" % (n, word, "" if n == 1 else "s")


def plan_view(pid):
    p = PLANS[pid]
    return {"id": pid, "title": p["title"], "notes": p["notes"],
            "groups": [[{"label": s["label"], "node": s["node"]} for s in g] for g in p["groups"]],
            "count": sum(len(g) for g in p["groups"])}


def run_job(jid):
    j = JOBS[jid]
    touched = set()
    with cf.ThreadPoolExecutor(max(1, int(settings()["max_parallel"]))) as ex:
        for gi, grp in enumerate(j["plan"]["groups"]):
            def one(si, s=None):
                s = grp[si]
                st = j["steps"][gi][si]
                st["state"] = "running"
                t0 = time.time()
                try:
                    msg = s["fn"]() or ""
                    st["state"], st["msg"] = "ok", msg
                except Exception as e:   # noqa - show every failure in the GUI
                    st["state"], st["msg"] = "failed", str(e)
                st["secs"] = round(time.time() - t0, 1)
                if s.get("vmid"):
                    touched.add(s["vmid"])
                audit(j["user"], "%s [%s] %s: %s%s" % (j["plan"]["title"], s["node"], s["label"], st["state"],
                                                       (" - " + st["msg"]) if st["msg"] else ""))
            list(ex.map(one, range(len(grp))))
    inv.forget(touched)
    j["state"] = "done"
    j["ended"] = time.time()


def start_job(user, pid):
    p = PLANS.pop(pid, None)
    if not p or p["user"] != user or time.time() - p["at"] > 900:
        raise ValueError("this plan has expired - make it again")
    jid = secrets.token_hex(8)
    inv.hot_until = time.time() + 180
    JOBS[jid] = {"user": user, "plan": p, "state": "running", "started": time.time(),
                 "steps": [[{"label": s["label"], "node": s["node"], "state": "waiting", "msg": "", "secs": 0, "buf": s.get("buf")} for s in g] for g in p["groups"]]}
    audit(user, "run: %s (%s, %d step(s))" % (p["title"], p["course"], sum(len(g) for g in p["groups"])))
    threading.Thread(target=run_job, args=(jid,), daemon=True).start()
    return jid


# ---------------------------------------------------------------------------- HTTP
STATIC_CACHE = {}
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".woff2": "font/woff2",
        ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".txt": "text/plain"}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "ics-ranges"
    sys_version = ""

    def log_message(self, *a):
        pass

    # -- helpers
    def send(self, code, obj=None, ctype="application/json", raw=None, headers=None, cache="no-store", gz=None):
        b = raw if raw is not None else json.dumps(obj, separators=(",", ":")).encode()
        zipped = False
        if "gzip" in (self.headers.get("Accept-Encoding") or "") and len(b) > 1400 and \
                (ctype.startswith(("application/json", "text/")) or ctype in ("image/svg+xml",)):
            b = gz if gz is not None else gzip.compress(b, 6)
            zipped = True
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        if zipped:
            self.send_header("Content-Encoding", "gzip")
        self.send_header("Vary", "Accept-Encoding")
        self.send_header("X-ICS-Version", VERSION)
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def body(self, limit=1_000_000):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise ValueError("request too large")
        try:
            b = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            raise ValueError("bad request - not JSON")
        if not isinstance(b, dict):   # every change is sent as one JSON object
            raise ValueError("bad request - expected a JSON object")
        return b

    def client(self):
        return self.client_address[0]

    def session(self):
        c = self.headers.get("Cookie", "")
        m = re.search(r"(?:^|;\s*)pvr=([A-Za-z0-9_-]+)", c)
        if not m:
            return None
        s = SESSIONS.get(skey(m.group(1)))
        if not s or time.time() - s["last"] > IDLE:
            SESSIONS.pop(skey(m.group(1)), None)
            return None
        u = users().get(s["user"])
        if not u:
            return None
        s["last"] = time.time()
        sessions_save()   # at most every 30 s
        return {"token": m.group(1), "user": s["user"], "role": u.get("role", "viewer"), "u": u,
                "perms": perms_of(u.get("role", "viewer"))}

    def need(self, s, perm):
        if perm not in s["perms"]:
            raise PermissionError("your role can't do this")

    # -- routing
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        url = urllib.parse.urlparse(self.path)
        p = url.path
        try:
            if method == "GET" and not p.startswith("/api/"):
                return self.static(p)
            if method != "GET" and self.headers.get("X-PVR") != "1":   # only our own page may change things
                return self.send(403, {"error": "missing request header"})
            q = dict(urllib.parse.parse_qsl(url.query))
            fixed = {"/api/session": "GET", "/api/setup": "POST", "/api/login": "POST", "/api/logout": "POST"}
            if p in fixed and method != fixed[p]:
                return self.send(405, {"error": "use %s for %s" % (fixed[p], p)})
            if p == "/api/session" and method == "GET":
                return self.api_session()
            if p == "/api/setup" and method == "POST":
                return self.api_setup()
            if p == "/api/login" and method == "POST":
                return self.api_login()
            s = self.session()
            if not s:
                return self.send(401, {"error": "Sign in again - your session ended."})
            if p == "/api/logout" and method == "POST":
                SESSIONS.pop(skey(s["token"]), None)
                sessions_save(True)
                return self.send(200, {"ok": True}, headers={"Set-Cookie": "pvr=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict" + COOKIE_FLAGS})
            h = getattr(self, "api_" + p[5:].split("/")[0].replace("-", "_"), None)
            if not h:
                return self.send(404, {"error": "not found"})
            return h(s, method, p.split("/")[3:], q)
        except PermissionError as e:
            return self.send(403, {"error": str(e)})
        except (ValueError, KeyError) as e:
            return self.send(400, {"error": str(e).strip("'")})
        except PVEError as e:
            return self.send(502, {"error": str(e)})
        except (TypeError, AttributeError) as e:   # a value of the wrong kind (a number where text belongs ...)
            sys.stderr.write("bad request %s %s: %s\n" % (method, p, e))
            return self.send(400, {"error": "bad request - a value has the wrong type"})
        except Exception as e:   # noqa
            traceback.print_exc()
            return self.send(500, {"error": "internal error: %s" % e})

    def static(self, p):
        if p in ("", "/"):
            p = "/index.html"
        f = os.path.normpath(os.path.join(STATIC, p.lstrip("/")))
        if not f.startswith(STATIC) or not os.path.isfile(f):
            f = os.path.join(STATIC, "index.html")
        st = os.stat(f)
        c = STATIC_CACHE.get(f)
        if not c or c["mtime"] != st.st_mtime_ns:   # read, compress and fingerprint each file once
            with open(f, "rb") as fh:
                raw = fh.read()
            if f.endswith("index.html"):   # the page names its files with the version: a new version is fetched for sure
                t = raw.decode()
                for a in ("/app.css", "/app.js", "/tools.js", "/favicon.png"):
                    t = t.replace('"%s"' % a, '"%s?v=%s"' % (a, VERSION))
                t = t.replace('<meta charset="utf-8">', '<meta charset="utf-8">\n<meta name="ics-version" content="%s">' % VERSION)
                raw = t.encode()
            c = STATIC_CACHE[f] = {"mtime": st.st_mtime_ns, "raw": raw, "gz": gzip.compress(raw, 9),
                                   "etag": '"%s"' % hashlib.sha1(raw).hexdigest()[:16]}
        ext = os.path.splitext(f)[1]
        # app files: the browser keeps them and asks "still the same?" (a tiny 304 answer);
        # fonts never change; pictures are kept a day
        versioned = "v=" in urllib.parse.urlparse(self.path).query
        cache = "public, max-age=31536000, immutable" if ext == ".woff2" or (versioned and not f.endswith("index.html")) else \
                "public, max-age=86400" if ext in (".png", ".ico", ".svg") else "no-cache"
        if self.headers.get("If-None-Match") == c["etag"]:
            self.send_response(304)
            self.send_header("ETag", c["etag"])
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return
        return self.send(200, raw=c["raw"], gz=c["gz"], ctype=MIME.get(ext, "application/octet-stream"),
                         cache=cache, headers={"ETag": c["etag"]})

    # -- sign-in
    def api_session(self):
        s = self.session()
        if not s:
            return self.send(200, {"signed_in": False, "setup": not users(), "version": VERSION})
        return self.send(200, {"signed_in": True, "user": s["user"], "role": s["role"], "perms": s["perms"], "offline": inv.offline,
                               "twofa": bool(s["u"].get("totp")), "version": VERSION,
                               "perm_names": PERMS, "settings": {k: settings()[k] for k in ("default_snapshot", "show_guide", "default_theme", "shutdown_timeout")},
                               "themes": load_json("themes.json", {}),
                               "update_available": (load_json("update-check.json", {}).get("newest", "")
                                                    if "software" in s["perms"] and ver_key(load_json("update-check.json", {}).get("newest", "")) > ver_key(VERSION) else "")})

    def start_session(self, name):
        tok = secrets.token_urlsafe(32)
        SESSIONS[skey(tok)] = {"user": name, "last": time.time()}
        sessions_save(True)
        return {"Set-Cookie": "pvr=%s; Path=/; HttpOnly; SameSite=Strict%s" % (tok, COOKIE_FLAGS)}

    def api_setup(self):
        with LOCK:
            if users():
                raise PermissionError("already set up - sign in")
            b = self.body()
            name, pw = (b.get("user") or "").strip(), b.get("password") or ""
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                raise ValueError("user names: letters, digits, . _ -")
            if len(pw) < 10:
                raise ValueError("use at least 10 characters for the password")
            save_json("users.json", {name: {"hash": hash_pw(pw), "role": "admin", "courses": "*", "totp": ""}})
        audit(name, "first admin created")
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    def api_login(self):
        b = self.body()
        name, pw, code = (b.get("user") or "").strip(), b.get("password") or "", b.get("code") or ""
        key = name.lower() + "|" + self.client()
        if failed_recently(key):
            return self.send(429, {"error": "Too many wrong attempts. Wait 10 minutes, or ask an admin to unlock you."})
        u = users().get(name)
        if not u or not check_pw(pw, u.get("hash", "")):
            FAILS.setdefault(key, []).append(time.time())
            audit(name, "sign-in FAILED from %s" % self.client())
            return self.send(401, {"error": "That name and password don't match."})
        if u.get("totp"):
            if not code:
                return self.send(200, {"need_code": True})
            if not totp_ok(u["totp"], code):
                FAILS.setdefault(key, []).append(time.time())
                audit(name, "sign-in FAILED (2FA code) from %s" % self.client())
                return self.send(401, {"error": "That code doesn't match. Check the time on your phone.", "need_code": True})
        FAILS.pop(key, None)
        audit(name, "signed in from %s" % self.client())
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    # -- courses and guests
    def api_courses(self, s, method, parts, q):
        inv.refresh()
        return self.send(200, courses_for(s))

    def api_course(self, s, method, parts, q):
        course = urllib.parse.unquote(parts[0]) if parts else ""
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        inv.refresh(force=q.get("fresh") == "1")
        ids = inv.course_ids(course)
        snaps = inv.snapshots(ids)
        mixed = course in mixed_active()
        guests = []
        for v in ids:
            g = dict(inv.guests[v])
            g["snapshots"] = snaps.get(v, [])
            if mixed:   # in a mixed course, say where each guest comes from
                g["home"] = g["course"] or "no course"
                g["group"] = "%s · %s" % (g["home"], g["group"])
            guests.append(g)
        summary = {}
        for g in guests:
            for sn in g["snapshots"]:
                o = summary.setdefault(sn["name"], {"name": sn["name"], "count": 0, "ram": 0})
                o["count"] += 1
                o["ram"] += sn["ram"]
        out = {"course": course, "guests": guests, "nodes": inv.nodes, "offline": inv.offline,
               "snapshots": sorted(summary.values(), key=lambda x: (-x["count"], x["name"]))}
        if q.get("with") == "courses":   # the course list too - one request per refresh instead of two
            out["courses"] = courses_for(s)
        return self.send(200, out)

    # -- plans and jobs
    def api_plan(self, s, method, parts, q):
        if method == "POST" and inv.offline:
            raise PVEError("Proxmox isn't answering (since %s) - nothing can be started or stopped until it does" % inv.offline["since"])
        if method == "POST" and not parts:
            pid = build_plan(s["user"], self.body())
            return self.send(200, plan_view(pid))
        if method == "POST" and len(parts) == 2 and parts[1] == "run":
            return self.send(200, {"job": start_job(s["user"], parts[0])})
        raise ValueError("bad request")

    def api_job(self, s, method, parts, q):
        j = JOBS.get(parts[0] if parts else "")
        if not j or (j["user"] != s["user"] and s["role"] != "admin"):
            raise KeyError("no such job")
        flat = [st for g in j["steps"] for st in g]
        groups = [[dict({k: v for k, v in st.items() if k != "buf"}, out="".join(st["buf"])[-30000:] if st.get("buf") is not None else None) for st in g] for g in j["steps"]]
        return self.send(200, {"title": j["plan"]["title"], "state": j["state"], "groups": groups,
                               "notes": j["plan"]["notes"],
                               "ok": sum(st["state"] == "ok" for st in flat), "failed": sum(st["state"] == "failed" for st in flat),
                               "total": len(flat), "secs": round((j.get("ended") or time.time()) - j["started"], 1)})

    # -- mirrors
    def api_mirrors(self, s, method, parts, q):
        if method == "GET":
            self.need(s, "mirror_status")
            course = q.get("course", "")
            inv.refresh()
            ids = set(inv.course_ids(course))
            saved = [m for m in mirrors() if any(e.get("vmid") in ids for e in m.get("entries", []))] if course else mirrors()
            with cf.ThreadPoolExecutor(4) as ex:
                live = list(ex.map(lambda m: mirror_status(m["node"], m["bridge"]), saved))
            for m, l in zip(saved, live):
                l["igmp"] = m.get("igmp") or ("off" if m.get("igmp_off") else "")
                l["entries"] = [dict(e, name=inv.guests.get(e["vmid"], {}).get("name", "?"),
                                     status=inv.guests.get(e["vmid"], {}).get("status", "missing"),
                                     port=nic_dev(inv.guests[e["vmid"]], e["nic"]) if e["vmid"] in inv.guests else "")
                                for e in m.get("entries", [])]
            return self.send(200, live)
        self.need(s, "mirror_setup")
        b = self.body()   # {node, bridge, entries:[{vmid,nic}]}  (empty entries = remove)
        node, bridge = b.get("node", ""), b.get("bridge", "")
        if not re.match(r"^[A-Za-z0-9_.-]+$", node) or not re.match(r"^[A-Za-z0-9_.-]+$", bridge):
            raise ValueError("pick a node and a bridge")
        ents = [{"vmid": int(e["vmid"]), "nic": e["nic"]} for e in b.get("entries", []) if re.match(r"^net\d+$", e.get("nic", ""))]
        with LOCK:
            ms = [m for m in mirrors() if not (m["node"] == node and m["bridge"] == bridge)]
            old = next((m for m in mirrors() if m["node"] == node and m["bridge"] == bridge), {})
            if ents:
                keep = {"igmp": old.get("igmp") or ("off" if old.get("igmp_off") else "")} if (old.get("igmp") or old.get("igmp_off")) else {}
                ms.append(dict({"node": node, "bridge": bridge, "entries": ents}, **keep))
            save_json("mirrors.json", ms)
        autosave(s["user"], "Mirrors on %s/%s changed" % (node, bridge))
        if not ents:
            try:
                ovs(node, "clear", "bridge", bridge, "mirrors")
            except PVEError:
                pass
        audit(s["user"], "mirrors on %s/%s: %s" % (node, bridge, ", ".join("%d:%s" % (e["vmid"], e["nic"]) for e in ents) or "removed"))
        return self.send(200, {"ok": True})

    def api_nics(self, s, method, parts, q):   # the course's NICs on every bridge, for the network add-ons
        self.need(s, "mirror_setup")
        course = q.get("course", "")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids, max_age=0)
        bridges = {n: node_bridges(n) for n in inv.nodes}
        out = []
        for v in ids:
            g = inv.guests[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not re.match(r"^net\d+$", k):
                    continue
                parts_ = val.split(",")
                br = (re.search(r"bridge=([^,]+)", val) or [None, ""])[1]
                mac = (re.search(r"(?:^|,)(?:[a-z0-9]+|hwaddr)=([0-9A-Fa-f:]{17})", val) or [None, ""])[1]
                out.append({"vmid": v, "name": g["name"], "node": g["node"], "group": g.get("group", ""),
                            "nic": k, "bridge": br, "mac": mac, "tag": (re.search(r"tag=(\d+)", val) or [None, ""])[1],
                            "ovs": br in bridges.get(g["node"], {}).get("ovs", []),
                            "firewall": "firewall=1" in parts_, "connected": "link_down=1" not in parts_, "status": g["status"],
                            "sensor": "sensor" in g["tags"] or bool(re.search(r"dragos|sensor|tenable|zeek|suricata|snort|onion|nsm", g["name"], re.I))})
        snoop = {}
        for n_, b_ in {(x["node"], x["bridge"]) for x in out if x["ovs"]}:
            try:
                snoop["%s/%s" % (n_, b_)] = ovs(n_, "get", "bridge", b_, "mcast_snooping_enable").strip() == "true"
            except (PVEError, subprocess.TimeoutExpired, OSError):
                snoop["%s/%s" % (n_, b_)] = None
        return self.send(200, {"nics": out, "bridges": bridges, "snooping": snoop})

    def api_netsummary(self, s, method, parts, q):   # disconnected NICs and firewall-off NICs of a course
        self.need(s, "mirror_status")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        return self.send(200, net_summary(course))

    def api_overview(self, s, method, parts, q):
        self.need(s, "overview")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use this course")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        disks = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$", k) and "media=cdrom" not in val:
                    vol = val.split(",")[0]
                    if ":" not in vol:
                        continue
                    size = (re.search(r"size=([^,]+)", val) or [None, ""])[1]
                    fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                    disks.append({"vmid": v, "name": inv.guests[v]["name"], "disk": k, "storage": vol.split(":")[0], "format": fmt, "size": size})
        st = []
        for x in pve.call("GET", "/storage") or []:
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "shared": bool(x.get("shared")),
                       "formats": "qcow2 raw vmdk" if t in ("dir", "nfs", "cifs", "glusterfs", "cephfs") else "raw",
                       "content": x.get("content", "")})
        return self.send(200, {"storages": st, "disks": disks})

    # -- users (admin)
    def api_users(self, s, method, parts, q):
        self.need(s, "users")
        with LOCK:
            us = users()
            if method == "GET":
                return self.send(200, [{"name": n, "role": u.get("role"), "courses": u.get("courses", "*"), "twofa": bool(u.get("totp"))}
                                       for n, u in sorted(us.items())])
            b = self.body() if method in ("POST", "PUT") else {}
            if method == "POST" and not parts:   # add
                name = (b.get("name") or "").strip()
                if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                    raise ValueError("user names: letters, digits, . _ - (max 32)")
                if name in us:
                    raise ValueError("%s already exists" % name)
                pw = b.get("password") or gen_password()
                if len(pw) < 10:
                    raise ValueError("use at least 10 characters for the password")
                us[name] = {"hash": hash_pw(pw), "role": self.valid_role(b.get("role")), "courses": self.valid_courses(b.get("courses")), "totp": ""}
                save_json("users.json", us)
                audit(s["user"], "user %s added (%s)" % (name, us[name]["role"]))
                return self.send(200, {"ok": True, "password": None if b.get("password") else pw})
            name = parts[0] if parts else ""
            if name not in us:
                raise KeyError("no user %s" % name)
            admins = [n for n, u in us.items() if u.get("role") == "admin"]
            if method == "DELETE":
                if name == s["user"]:
                    raise ValueError("you can't delete yourself")
                if us[name].get("role") == "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin" % name)
                del us[name]
                save_json("users.json", us)
                audit(s["user"], "user %s deleted" % name)
                return self.send(200, {"ok": True})
            if method == "PUT":
                role = self.valid_role(b.get("role", us[name].get("role")))
                if us[name].get("role") == "admin" and role != "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin - make another admin first" % name)
                us[name]["role"] = role
                us[name]["courses"] = self.valid_courses(b.get("courses", us[name].get("courses", "*")))
                if b.get("twofa") is False:
                    us[name]["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "user %s changed: %s, courses %s" % (name, role, us[name]["courses"]))
                return self.send(200, {"ok": True})
            if method == "POST" and len(parts) == 2 and parts[1] == "password":
                pw = gen_password()
                us[name]["hash"] = hash_pw(pw)
                save_json("users.json", us)
                for t, ss in list(SESSIONS.items()):
                    if ss["user"] == name:
                        SESSIONS.pop(t, None)
                sessions_save(True)   # also gone after a restart
                audit(s["user"], "new password for %s" % name)
                return self.send(200, {"password": pw})
            if method == "POST" and len(parts) == 2 and parts[1] == "unlock":
                for k in [k for k in FAILS if k.startswith(name.lower() + "|")]:
                    FAILS.pop(k, None)
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    def valid_role(self, r):
        if r != "admin" and r not in roles():
            raise ValueError("no role %s" % r)
        return r

    def valid_courses(self, c):
        if c == "*" or c is None:
            return "*"
        if not isinstance(c, list) or not c or not all(isinstance(x, str) and re.match(r"^[A-Za-z0-9_.-]+$", x) for x in c):
            raise ValueError("pick at least one course")
        return sorted(set(c))

    # -- own account: password, 2FA
    def api_me(self, s, method, parts, q):
        with LOCK:
            us = users()
            me = us[s["user"]]
            b = self.body() if method != "GET" else {}
            what = parts[0] if parts else ""
            if method == "POST" and what == "password":
                if not check_pw(b.get("old", ""), me["hash"]):
                    raise ValueError("your current password doesn't match")
                if len(b.get("new", "")) < 10:
                    raise ValueError("use at least 10 characters")
                me["hash"] = hash_pw(b["new"])
                save_json("users.json", us)
                audit(s["user"], "changed own password")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-start":
                secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
                SESSIONS[skey(s["token"])]["pending_totp"] = secret
                return self.send(200, {"secret": secret, "uri": "otpauth://totp/ICS%%20Ranges:%s?secret=%s&issuer=ICS%%20Ranges" % (urllib.parse.quote(s["user"]), secret)})
            if method == "POST" and what == "2fa-confirm":
                secret = SESSIONS[skey(s["token"])].get("pending_totp")
                if not secret or not totp_ok(secret, b.get("code", "")):
                    raise ValueError("that code doesn't match - check the time on your phone")
                me["totp"] = secret
                save_json("users.json", us)
                audit(s["user"], "2FA turned on")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-off":
                if not check_pw(b.get("password", ""), me["hash"]):
                    raise ValueError("your password doesn't match")
                me["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "2FA turned off")
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    # -- roles, VMID map, audit (admin)
    def api_roles(self, s, method, parts, q):
        if method == "GET":
            return self.send(200, {"roles": roles(), "perms": PERMS})
        self.need(s, "settings")
        b = self.body()   # {roles: {name: [perms]}}
        new = {}
        for name, ps in field(self, method, b, "roles", dict).items():
            if name == "admin":
                continue
            if not re.match(r"^[a-z][a-z0-9_-]{0,23}$", name):
                raise ValueError("role names: small letters, digits, - and _")
            new[name] = sorted(p for p in ps if p in PERMS)
        used = {u.get("role") for u in users().values()}
        gone = [r for r in roles() if r not in new and r in used]
        if gone:
            raise ValueError("users still have the role %s - give them another role first" % ", ".join(gone))
        save_json("roles.json", new)
        autosave(s["user"], "Roles changed")
        audit(s["user"], "roles: " + "; ".join("%s=%s" % (k, ",".join(v)) for k, v in new.items()))
        return self.send(200, {"ok": True})

    def api_vmidmap(self, s, method, parts, q):
        self.need(s, "settings")
        if method == "GET":
            inv.refresh()
            return self.send(200, {"text": load_map()[1], "default": DEFAULT_MAP,
                                   "unmapped": sorted(v for v, g in inv.guests.items() if g["course"] is None)})
        text = field(self, method, self.body(), "text", str)
        if len(text) > 100000:
            raise ValueError("too long")
        if not _parse_map_text(text)[0]["folder"]:
            raise ValueError("the map has no folder lines - nothing would be a course (Load the shipped map to start again)")
        with open(path("vmid-map.conf"), "w") as f:
            f.write(text)
        inv.forget(list(inv.guests))
        autosave(s["user"], "Course map changed")
        audit(s["user"], "VMID map changed")
        return self.send(200, {"ok": True})

    def api_audit(self, s, method, parts, q):
        self.need(s, "users")

        def tail(f, n):   # the last n lines, reading only the end of a (possibly large) file
            try:
                with open(f, "rb") as fh:
                    fh.seek(0, 2)
                    start = max(0, fh.tell() - 120000)
                    fh.seek(start)
                    ls = fh.read().decode("utf-8", "replace").splitlines(True)
                    return (ls[1:] if start else ls)[-n:]   # drop a line cut in half
            except OSError:
                return []
        lines = tail(path("audit.log"), 300)
        if len(lines) < 300:   # just rotated: the rest comes from the previous file
            lines = tail(path("audit.log.1"), 300 - len(lines)) + lines
        return self.send(200, {"lines": [x.rstrip("\n") for x in reversed(lines)]})


# ---------------------------------------------------------------------------- more endpoints
def _course_ok(self, s, course):
    allow = allowed_courses(s["u"])
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)


def api_settings(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, {"settings": settings(), "defaults": DEFAULT_SETTINGS})
    self.need(s, "settings")
    if method != "PUT":
        raise ValueError("use PUT to save")
    b = self.body()
    cur = load_json("settings.json", {})
    for k, v in b.items():
        if k not in DEFAULT_SETTINGS:
            continue
        d = DEFAULT_SETTINGS[k]
        if isinstance(d, bool):
            v = bool(v)
        elif isinstance(d, int):
            v = int(v)
            if k == "max_parallel" and not 1 <= v <= 32:
                raise ValueError("steps at once: 1 to 32")
            if k == "shutdown_timeout" and not 10 <= v <= 3600:
                raise ValueError("shutdown timeout: 10 to 3600 seconds")
            if k == "backup_keep" and not 0 <= v <= 500:
                raise ValueError("backups to keep: 0 to 500")
            if k == "start_delay" and not 0 <= v <= 600:
                raise ValueError("pause between starts: 0 to 600 seconds")
        else:
            v = str(v).strip()
            if k == "default_snapshot" and not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", v):
                raise ValueError("snapshot names start with a letter")
            if k == "protected" and v and not re.match(r"^[\d\s,-]+$", v):
                raise ValueError("protected guests: VMIDs and ranges like 100-105, 9001")
            if k == "sensor_pattern":
                try:
                    re.compile(v)
                except re.error:
                    raise ValueError("sensor names: not a valid pattern")
        cur[k] = v
    save_json("settings.json", cur)
    inv.forget(list(inv.guests))
    autosave(s["user"], "Settings changed")
    audit(s["user"], "settings: " + ", ".join("%s=%s" % kv for kv in sorted(b.items())))
    return self.send(200, {"ok": True})


def api_guide(self, s, method, parts, q):
    course = urllib.parse.unquote(parts[0]) if parts else ""
    _course_ok(self, s, course)
    f = guide_file(course)
    if method == "GET":
        self.need(s, "guide_read")
        text = read_text(f)
        if text is None:   # pve-range keeps its class guides as <course>.txt
            text = read_text(f[:-3] + ".txt")
        return self.send(200, {"course": course, "text": text})
    self.need(s, "guide_edit")
    if method == "DELETE":
        for x in (f, f[:-3] + ".txt"):
            try:
                os.remove(x)
            except OSError:
                pass
        autosave(s["user"], "Class guide for %s deleted" % course)
        audit(s["user"], "class guide %s deleted" % course)
        return self.send(200, {"ok": True})
    b = self.body()
    text = fetch_url(b["url"]) if b.get("url") else b.get("text", "")
    if len(text) > 1_000_000:
        raise ValueError("a guide can be at most 1 MB")
    write_text(f, text)
    try:
        os.remove(f[:-3] + ".txt")   # the .md replaces a guide brought over from pve-range
    except OSError:
        pass
    autosave(s["user"], "Class guide for %s saved" % course)
    audit(s["user"], "class guide %s saved (%d characters)" % (course, len(text)))
    return self.send(200, {"ok": True, "text": text})


def api_addons(self, s, method, parts, q):
    course = q.get("course", "")
    if method == "GET" and not parts:
        self.need(s, "addons_run")
        _course_ok(self, s, course)
        return self.send(200, {"addons": list_addons(course), "template": ADDON_TEMPLATE if "addons_edit" in s["perms"] else ""})
    scope, f = (parts + ["", ""])[:2]
    if scope != "_all":
        _course_ok(self, s, scope)
    if not ADDON_RE.match(f or ""):
        raise ValueError("add-on file names end in .sh: letters, digits, . _ -")
    full = os.path.join(addon_dir(scope), f)
    if method == "GET":
        self.need(s, "addons_run")
        t = read_text(full)
        if t is None:
            raise KeyError("no such add-on")
        return self.send(200, {"text": t, "meta": addon_meta(t, f)})
    self.need(s, "addons_edit")
    if method == "DELETE":
        try:
            os.remove(full)
        except OSError:
            pass
        autosave(s["user"], "Add-on %s/%s deleted" % (scope, f))
        audit(s["user"], "add-on %s/%s deleted" % (scope, f))
        return self.send(200, {"ok": True})
    b = self.body()
    text = fetch_url(b["url"]) if b.get("url") else b.get("text", "")
    if len(text) > 1_000_000:
        raise ValueError("an add-on can be at most 1 MB")
    if b.get("move_to") and b["move_to"] != scope:   # move to another course (or all)
        dest = b["move_to"]
        if dest != "_all":
            _course_ok(self, s, dest)
        write_text(os.path.join(addon_dir(dest), f), text, 0o750)
        try:
            os.remove(full)
        except OSError:
            pass
    else:
        write_text(full, text.replace("\r\n", "\n"), 0o750)
    autosave(s["user"], "Add-on %s/%s saved" % (scope, f))
    audit(s["user"], "add-on %s/%s saved" % (b.get("move_to") or scope, f))
    return self.send(200, {"ok": True, "text": text})


def api_groups(self, s, method, parts, q):
    g = load_json("groups.json", {})
    if method == "GET":
        return self.send(200, g if isinstance(g, dict) else {})
    self.need(s, "settings")
    b = self.body()
    new = {}
    for k, v in field(self, method, b, "groups", dict).items():
        if not re.match(r"^[A-Za-z0-9 _.-]{1,40}$", k) or not re.match(r"^[\d\s,-]+$", v or ""):
            raise ValueError("group names: letters, digits, spaces; members: VMIDs and ranges")
        new[k.strip()] = v.strip()
    save_json("groups.json", new)
    autosave(s["user"], "Saved groups changed")
    return self.send(200, {"ok": True})


def api_themes(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, load_json("themes.json", {}))
    self.need(s, "settings")
    b = self.body()
    new = {}
    for name, cols in field(self, method, b, "themes", dict).items():
        if not re.match(r"^[A-Za-z0-9 _-]{1,24}$", name):
            raise ValueError("theme names: letters, digits, spaces")
        c = {k: v for k, v in cols.items() if k in ("canvas", "panel", "ink", "line", "action", "dark") and (k == "dark" or re.match(r"^#[0-9a-fA-F]{6}$", str(v)))}
        if len([k for k in c if k != "dark"]) != 5:
            raise ValueError("each theme needs five colours as #rrggbb")
        new[name] = c
    save_json("themes.json", new)
    autosave(s["user"], "Colour themes changed")
    return self.send(200, {"ok": True})


def api_git(self, s, method, parts, q):
    self.need(s, "save")
    what = parts[0] if parts else ""
    if method == "GET" and what == "":
        c = git_conf()
        hist = []
        if os.path.isdir(os.path.join(REPO, ".git")):
            out = git("log", "-50", "--format=%h%x09%an%x09%ar%x09%s", check=False)
            hist = [dict(zip(("id", "who", "when", "what"), ln.split("\t", 3))) for ln in out.splitlines() if ln.count("\t") >= 3]
        try:
            backups = sorted((f for f in os.listdir(BACKUPS) if f.startswith("backup-")), reverse=True)
        except OSError:
            backups = []
        return self.send(200, {"url": c.get("url", ""), "user": c.get("user", ""), "branch": c.get("branch", "main"),
                               "insecure": bool(c.get("insecure")), "history": hist, "backups": backups,
                               "has_token": os.path.exists(path("priv/git-token")),
                               "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "GET" and what == "backup" and len(parts) == 2:
        f = os.path.join(BACKUPS, parts[1])
        if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", parts[1]) or not os.path.exists(f):
            raise KeyError("no such backup")
        with open(f, "rb") as fh:
            return self.send(200, raw=fh.read(), ctype="application/gzip",
                             headers={"Content-Disposition": 'attachment; filename="%s"' % parts[1]})
    b = self.body() if method in ("POST", "PUT") else {}
    if method == "PUT" and what == "connect":
        url = (b.get("url") or "").strip()
        if url and not re.match(r"^(https?://[^\s/]+/\S+|git@[^\s:]+:\S+|ssh://\S+)$", url):
            raise ValueError("give the repository address, e.g. https://gitea.lab/team/ics-ranges.git")
        c = {"url": url, "user": (b.get("user") or "").strip(), "branch": (b.get("branch") or "main").strip(), "insecure": bool(b.get("insecure"))}
        if not re.match(r"^[A-Za-z0-9._/-]{1,60}$", c["branch"]):
            raise ValueError("bad branch name")
        old = git_conf()
        save_json("git.json", c)
        os.makedirs(path("priv"), exist_ok=True)
        if b.get("token"):
            write_text(path("priv/git-token"), b["token"].strip() + "\n", 0o600)
        if url.startswith(("git@", "ssh://")) and not os.path.exists(path("ssh/git_ed25519")):
            subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "ics-ranges-git", "-f", path("ssh/git_ed25519")], check=False)
        if url:
            with GIT_LOCK:
                repo_init()
            p_ = subprocess.run(["git"] + (["-c", "http.sslVerify=false"] if c["insecure"] else []) + ["ls-remote", remote_url(c)],
                                env=git_env(), capture_output=True, text=True, timeout=40)
            if p_.returncode:
                save_json("git.json", old)
                err = (p_.stderr or "").strip().splitlines()
                raise ValueError("can't connect: %s" % (err[-1] if err else "check the address, user and token"))
        audit(s["user"], "repository: %s" % (url or "disconnected"))
        try:
            r = repo_save(s["user"], "Connected to %s" % url) if url else "Disconnected."
        except PVEError as e:
            raise ValueError("connected, but the upload failed: %s" % e)
        return self.send(200, {"ok": True, "report": r, "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "POST" and what == "save":
        r = repo_save(s["user"], b.get("message") or "Saved from the GUI")
        audit(s["user"], "save: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "pull":
        r = repo_pull(s["user"])
        audit(s["user"], "get latest: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "backup":
        name = make_backup()
        audit(s["user"], "backup %s" % name)
        return self.send(200, {"report": "Backup %s made." % name})
    if method == "POST" and what == "restore":
        make_backup()
        restore_backup(b.get("name", ""))
        audit(s["user"], "restored backup %s" % b.get("name"))
        autosave(s["user"], "Restored backup %s" % b.get("name"))
        return self.send(200, {"report": "Restored %s (a backup of the state before was made first)." % b.get("name")})
    raise ValueError("bad request")


def api_nodekey(self, s, method, parts, q):   # the line to add on a node, for Settings
    self.need(s, "settings")
    return self.send(200, {"text": read_text(path("ssh/node-key.txt")) or ""})


def api_storages(self, s, method, parts, q):   # for Move / convert disks
    self.need(s, "disks")
    st = []
    for x in pve.call("GET", "/storage") or []:
        if "images" in (x.get("content") or "") or "rootdir" in (x.get("content") or ""):
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "raw_only": t in RAW_ONLY})
    return self.send(200, st)


def api_bridges(self, s, method, parts, q):   # for Network settings
    self.need(s, "network")
    out = {}
    for n in inv.nodes or [r["node"] for r in pve.call("GET", "/nodes") or []]:
        try:
            out[n] = sorted({b["iface"] for b in pve.call("GET", "/nodes/%s/network" % n) or [] if b.get("type") in ("bridge", "OVSBridge")})
        except PVEError:
            out[n] = []
    return self.send(200, out)


for _f in (api_settings, api_guide, api_addons, api_groups, api_themes, api_git, api_storages, api_bridges, api_nodekey):
    setattr(Handler, _f.__name__, _f)


# ---------------------------------------------------------------------------- command line
def cli(argv):
    """docker compose exec ics-ranges pvr ...  (no sign-in: whoever can run this is the admin)"""
    import getpass
    if not argv or argv[0] in ("-h", "--help", "help"):
        print("""pvr users                          list web users
pvr users add NAME --role R [--courses 613,NetWars] [--password P]
pvr users passwd NAME              new generated password
pvr users role NAME ROLE           change the role
pvr users courses NAME 613,NetWars|*
pvr users unlock NAME              clear a lock-out (restart not needed)
pvr users del NAME
pvr roles                          roles and what they may do
pvr courses                        courses and guest counts
pvr list --course C                guests of a course: status, node, snapshots
pvr storage --course C             storages and the course's disks
pvr mirror-status [--course C]     saved mirrors and whether they run
pvr guide --course C               print the class guide
pvr node-key                       the lines that put the node key on a node
pvr kit export FILE                everything in one encrypted file (password from $KIT_PASSWORD or typed)
pvr kit import FILE                put a kit file back - users, roles, settings, guides, add-ons ...
pvr update                         this version, the host updater, and the releases in the repository
pvr update install v2.4.0          ask the host's updater to install that version
pvr update connect URL USER [--insecure]   connect the repository (token from $PVR_TOKEN or typed)
pvr run ACTION --course C [--snapshot S] [--ids 510101,510102] [--yes] [--hard]
    ACTION: class_start class_end power_on power_off snap_take snap_restore snap_delete mirror_apply
    snap_restore also takes --after leave|start|off
pvr save "message"                 save to the history / your repository
pvr pull                           get the latest from your repository
pvr backup                         make a backup""")
        return 0
    cmd, rest = argv[0], argv[1:]
    def opt(name, default=None):
        if name in rest:
            i = rest.index(name)
            return rest[i + 1] if i + 1 < len(rest) else default
        return default
    if cmd == "users":
        us = users()
        if not rest:
            for n, u in sorted(us.items()):
                print("%-20s %-12s %-28s 2FA %s" % (n, u.get("role"), u.get("courses") if u.get("courses") == "*" else ",".join(u.get("courses", [])), "on" if u.get("totp") else "off"))
            return 0
        sub, name = rest[0], (rest[1] if len(rest) > 1 else "")
        if sub == "add":
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name) or name in us:
                print("bad or existing name"); return 1
            pw = opt("--password") or gen_password()
            role = opt("--role", "instructor")
            if role != "admin" and role not in roles():
                print("no role %s" % role); return 1
            c = opt("--courses", "*")
            us[name] = {"hash": hash_pw(pw), "role": role, "courses": "*" if c == "*" else sorted(c.split(",")), "totp": ""}
            save_json("users.json", us)
            print("User %s added (%s). Password: %s" % (name, role, pw if not opt("--password") else "(as given)"))
        elif name not in us:
            print("no user %s" % name); return 1
        elif sub == "passwd":
            pw = gen_password()
            us[name]["hash"] = hash_pw(pw)
            save_json("users.json", us)
            print("New password for %s: %s" % (name, pw))
        elif sub == "role":
            r = rest[2] if len(rest) > 2 else ""
            if r != "admin" and r not in roles():
                print("no role %s" % r); return 1
            us[name]["role"] = r
            save_json("users.json", us)
            print("%s is now %s" % (name, r))
        elif sub == "courses":
            c = rest[2] if len(rest) > 2 else "*"
            us[name]["courses"] = "*" if c == "*" else sorted(c.split(","))
            save_json("users.json", us)
            print("%s may use: %s" % (name, c))
        elif sub == "unlock":
            print("Lock-outs are kept in memory - restart to clear them: docker compose restart")
        elif sub == "del":
            del us[name]
            save_json("users.json", us)
            print("%s deleted" % name)
        audit("cli", "users %s %s" % (sub, name))
        return 0
    if cmd == "roles":
        print("%-14s %s" % ("admin", "(everything)"))
        for r, ps in roles().items():
            print("%-14s %s" % (r, " ".join(ps)))
        return 0
    if cmd == "courses":
        inv.refresh(force=True)
        cnt = {}
        for g in inv.guests.values():
            cnt.setdefault(g["course"], [0, 0])
            cnt[g["course"]][0] += 1
            cnt[g["course"]][1] += g["status"] == "running"
        for c, (n, r) in sorted(cnt.items()):
            print("%-14s %3d guests, %d running" % (c, n, r))
        return 0
    if cmd == "list":
        course = opt("--course", "")
        inv.refresh(force=True)
        ids = inv.course_ids(course)
        if not ids:
            print("no guests in %r - pvr courses" % course); return 1
        snaps = inv.snapshots(ids)
        print("%-8s %-4s %-12s %-8s %-24s %-34s %s" % ("VMID", "TYPE", "NODE", "STATUS", "NAME", "GROUP", "SNAPSHOTS"))
        for v in ids:
            g = inv.guests[v]
            print("%-8d %-4s %-12s %-8s %-24s %-34s %s" % (v, "CT" if g["type"] == "lxc" else "VM", g["node"], g["status"], g["name"][:24], g["label"][:34],
                                                         " ".join(x["name"] + ("+mem" if x["ram"] else "") for x in snaps.get(v, []))))
        return 0
    if cmd == "storage":
        course = opt("--course", "")
        inv.refresh(force=True)
        cfgs = inv.configs(inv.course_ids(course))
        print("STORAGES")
        for x in pve.call("GET", "/storage") or []:
            print("  %-16s %-10s %s" % (x["storage"], x.get("type", ""), "raw only" if x.get("type") in RAW_ONLY else "qcow2 raw vmdk"))
        print("DISKS IN %s" % course)
        for v, c in sorted(cfgs.items()):
            for k, val in sorted(c.items()):
                if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]:
                    vol = val.split(",")[0]
                    print("  %-8d %-10s %-16s %s" % (v, k, vol.split(":")[0], "qcow2" if vol.endswith(".qcow2") else "raw"))
        return 0
    if cmd == "mirror-status":
        course = opt("--course")
        inv.refresh(force=True)
        ids = set(inv.course_ids(course)) if course else None
        for m in mirrors():
            if ids is not None and not any(e.get("vmid") in ids for e in m.get("entries", [])):
                continue
            st = mirror_status(m["node"], m["bridge"])
            print("%s on %s%s" % (m["bridge"], m["node"], ("  - " + st["error"]) if st["error"] else ""))
            live = {x["port"]: x for x in st["mirrors"]}
            for e in m.get("entries", []):
                g = inv.guests.get(e["vmid"])
                port = nic_dev(g, e["nic"]) if g else "?"
                x = live.get(port)
                print("  %-8d %-6s %-14s %s" % (e["vmid"], e["nic"], port, ("mirrored, %s packets" % x["packets"]) if x else "NOT mirrored"))
        return 0
    if cmd == "kit":
        sub = rest[0] if rest else ""
        f = rest[1] if len(rest) > 1 else "-"
        pw = os.environ.get("KIT_PASSWORD") or __import__("getpass").getpass("Kit password: ")
        if sub == "export":
            data = kit_export(pw, "cli")
            (sys.stdout.buffer.write(data) if f == "-" else open(f, "wb").write(data))
            if f != "-":
                print("Kit saved: %s (%d KB)" % (f, len(data) // 1024))
            return 0
        if sub in ("import", "env"):
            blob = sys.stdin.buffer.read() if f == "-" else open(f, "rb").read()
            if sub == "env":   # the Proxmox settings in the kit, as .env lines (for setup.sh import)
                man, _ = kit_open(blob, pw)
                for k, v in (man.get("env") or {}).items():
                    print("%s=%s" % (k, v))
                return 0
            man, before = kit_import(blob, pw, "cli")
            print("Kit imported - made %s by %s (version %s), users: %s" % (man.get("made"), man.get("by"), man.get("version"), ", ".join(man.get("users", []))))
            print("The state before is kept as backups/%s" % before)
            return 0
        print("usage: pvr kit export FILE | pvr kit import FILE | pvr kit env FILE   (FILE - = stdin/stdout; password from $KIT_PASSWORD)")
        return 2
    if cmd == "update":
        if rest[:1] == ["connect"]:
            if len(rest) < 3:
                print("usage: pvr update connect URL USER [--insecure]   (token from $PVR_TOKEN, or typed)"); return 2
            token = os.environ.get("PVR_TOKEN") or (sys.stdin.readline() if not sys.stdin.isatty() else
                                                     __import__("getpass").getpass("Read-only token: "))
            rel = update_connect("cli", rest[1], rest[2], token, "--insecure" in rest)
            print("Connected - %d release(s) found." % len(rel))
            return 0
        if rest[:1] == ["install"]:
            tag = rest[1] if len(rest) > 1 else ""
            print("Requested %s - the host's updater installs it now; follow it with: pvr update" % request_install("cli", tag)["tag"])
            return 0
        st = upd_state()
        print("This version:  %s" % VERSION)
        print("Repository:    %s" % (upd_conf().get("url") or "not connected (web page: Software updates)"))
        print("Host updater:  %s" % (("set up, allows %s" % st["pinned"]) if st["installed"] else "not set up (on the host: sudo ./setup.sh updater)"))
        if st["state"]:
            print("Last update:   %s %s - %s (%s)" % (st["version"], st["state"], st["message"], st["at"]))
        if upd_conf().get("url"):
            try:
                rels = fetch_releases()
                if not rels:
                    print("Releases:      none yet - publish one with ./release.sh")
                for r in rels[:10]:
                    print("  %-10s %-8s %s%s" % (r["tag"], r["relation"], r["date"], "" if r["installable"] else "  (missing: %s)" % ", ".join(r["missing"])))
            except PVEError as e:
                print("Releases:      %s" % e)
        return 0
    if cmd == "node-key":   # just the lines to run on a node - no log prefixes
        t = read_text(path("ssh/node-key.txt"))
        if not t:
            print("No node key yet - it's made when the container starts."); return 1
        print(t, end="" if t.endswith("\n") else "\n"); return 0
    if cmd == "guide":
        t = read_text(guide_file(opt("--course", "")))
        if t is None:
            t = read_text(guide_file(opt("--course", ""))[:-3] + ".txt")
        print(t if t is not None else "No class guide for this course.")
        return 0
    if cmd == "run":
        action = rest[0] if rest else ""
        course = opt("--course", "")
        inv.refresh(force=True)
        ids = [int(x) for x in (opt("--ids") or "").split(",") if x.strip().isdigit()] or inv.course_ids(course)
        snap = opt("--snapshot") or settings()["default_snapshot"]
        body = {"action": action, "course": course, "ids": ids, "snapshot": snap, "restore": ids, "start": ids, "off": ids,
                "after": opt("--after", "leave"),
                "mode": "stop" if "--hard" in rest else "shutdown", "title": "%s %s (command line)" % (action, course)}
        us = users()
        admin = next((n for n, u in us.items() if u.get("role") == "admin"), None)
        if not admin:
            print("create the first admin first (open the web page)"); return 1
        pid = build_plan(admin, body)
        v = plan_view(pid)
        for i, g in enumerate(v["groups"]):
            print("Stage %d:" % (i + 1))
            for st in g:
                print("  [%s] %s" % (st["node"], st["label"]))
        for n in v["notes"]:
            print("  note: " + n)
        if not v["count"]:
            print("Nothing to do."); return 0
        if "--yes" not in rest and input("Run %d step(s)? [y/N] " % v["count"]).lower() not in ("y", "yes"):
            return 1
        jid = start_job(admin, pid)
        while JOBS[jid]["state"] != "done":
            time.sleep(0.5)
        bad = 0
        for g in JOBS[jid]["steps"]:
            for st in g:
                print("  %-7s %s %s" % (st["state"], st["label"], st["msg"]))
                bad += st["state"] == "failed"
        return 1 if bad else 0
    if cmd == "save":
        print(repo_save("cli", " ".join(rest) or "Saved from the command line")); return 0
    if cmd == "pull":
        print(repo_pull("cli")); return 0
    if cmd == "backup":
        print("Backup %s made." % make_backup()); return 0
    del getpass
    print("unknown command - pvr help")
    return 1


# ---------------------------------------------------------------------------- software updates
# The web page never updates itself: it can't (no Docker access, on purpose). It lists the
# releases of your ics-ranges-app repository and writes an install REQUEST (just a version
# tag) into /updates, a folder shared with the host. The host's updater (./setup.sh updater)
# then downloads that version itself, from the repository pinned on the host, checks it,
# runs ./setup.sh update and goes back to the old version if the new one doesn't start.
UPD = os.environ.get("UPDATES_DIR", "/updates")
TAG_RE = re.compile(r"^v?\d+\.\d+\.\d+(?:[.-][A-Za-z0-9]+)?$")
BUSY = ("requested", "downloading", "checking", "installing", "rolling_back")


def upd_conf():
    c = load_json("update.json", {})
    return c if isinstance(c, dict) else {}


def repo_parts(url):
    """http://gitea:3000/kaz/ics-ranges-app(.git) -> (base, owner, repo)"""
    url = (url or "").strip().rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    m = re.match(r"^(https?://[^/\s]+(?:/[^/\s]+)*)/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$", url)
    if not m:
        raise ValueError("give the repository's address, e.g. http://192.168.77.93:3000/kaz/ics-ranges-app")
    return m.group(1), m.group(2), m.group(3)


def repo_norm(url):
    b, o, r = repo_parts(url)
    return "%s/%s/%s" % (b.lower(), o.lower(), r.lower())


def ver_key(v):
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", v or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def cached_versions():
    """Versions kept on this kit (updates/cache/<tag>, both files) -> the date they were kept."""
    d, out = os.path.join(UPD, "cache"), {}
    try:
        for t in os.listdir(d):
            f = os.path.join(d, t)
            if TAG_RE.match(t) and os.path.isfile(os.path.join(f, "ics-ranges.zip")) and os.path.isfile(os.path.join(f, "ics-ranges.zip.sha256")):
                out[t] = time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(f)))
    except OSError:
        pass
    return out


def changelog_section(text, version):
    """The '## <version>' section of a CHANGELOG.md text ('' if there is none)."""
    m = re.search(r"^## %s[ \t]*\n(.*?)(?=^## |\Z)" % re.escape(version.lstrip("v")), text or "", re.M | re.S)
    return m.group(1).strip() if m else ""


def changelog_notes(tag):
    """What's new in a version: from the kept zip's CHANGELOG.md, else from this version's own."""
    kept = os.path.join(UPD, "cache", tag, "ics-ranges.zip")
    if os.path.isfile(kept):
        try:
            import zipfile
            with zipfile.ZipFile(kept) as z:
                t = changelog_section(z.read("ics-ranges/CHANGELOG.md").decode("utf-8", "replace"), tag)
                if t:
                    return t
        except (OSError, KeyError, zipfile.BadZipFile):
            pass
    here = os.path.dirname(os.path.abspath(__file__))
    for f in (os.path.join(here, "CHANGELOG.md"), os.path.join(here, "..", "CHANGELOG.md")):
        t = read_text(f)
        if t:
            return changelog_section(t, tag)
    return ""


def releases_with_cache():
    """The repository's releases, each marked if it is kept on this kit; when the repository can't be
    reached, the kept versions alone - so going back works offline."""
    kept = cached_versions()
    cur = ver_key(VERSION)
    offline = ""
    try:
        rel = fetch_releases()
    except PVEError as e:
        rel, offline = [], str(e)
    for r in rel:
        r["cached"] = r["tag"] in kept
    for t, day in kept.items():   # kept here but not (or no longer) in the repository
        if not any(r["tag"] == t for r in rel):
            k = ver_key(t)
            rel.append({"tag": t, "name": "ICS Ranges %s" % t.lstrip("v"), "notes": "", "date": day, "prerelease": False,
                        "installable": True, "missing": [], "cached": True,
                        "relation": "current" if k == cur else "newer" if k > cur else "older"})
    for r in rel:   # no release notes (or just the title): what's new from the changelog
        if not (r.get("notes") or "").strip() or r["notes"].strip() in (r["tag"], "ICS Ranges %s" % r["tag"].lstrip("v")):
            r["notes"] = changelog_notes(r["tag"])
    rel.sort(key=lambda x: ver_key(x["tag"]), reverse=True)
    return rel, offline


def fetch_releases(c=None, token=None):
    c = c or upd_conf()
    token = token if token is not None else (read_text(path("priv/update-token")) or "").strip()
    base, owner, repo = repo_parts(c.get("url", ""))
    github = re.match(r"^https?://(www\.)?github\.com$", base)
    api = ("https://api.github.com/repos/%s/%s/releases?per_page=50" % (owner, repo)) if github else \
          ("%s/api/v1/repos/%s/%s/releases?limit=50" % (base, owner, repo))
    req = urllib.request.Request(api, headers={"Accept": "application/json", "User-Agent": "ics-ranges"})
    if token:
        req.add_header("Authorization", ("Bearer " if github else "token ") + token)
    ctx = ssl._create_unverified_context() if c.get("insecure") else ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=20, context=ctx if api.startswith("https") else None) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        raise PVEError({401: "the repository refused the token", 403: "the token may not read this repository",
                        404: "no such repository (or the token can't see it)"}.get(e.code, "HTTP %d from the repository" % e.code))
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise PVEError("can't reach the repository: %s" % getattr(e, "reason", e))
    cur = ver_key(VERSION)
    out = []
    for r in data if isinstance(data, list) else []:
        if r.get("draft"):
            continue
        tag = r.get("tag_name") or ""
        if not TAG_RE.match(tag):
            continue
        names = [a.get("name") for a in r.get("assets") or []]
        k = ver_key(tag)
        missing = [n for n in ("ics-ranges.zip", "ics-ranges.zip.sha256") if n not in names]
        out.append({"tag": tag, "name": r.get("name") or tag, "notes": (r.get("body") or "")[:20000],
                    "date": (r.get("published_at") or r.get("created_at") or "")[:10], "prerelease": bool(r.get("prerelease")),
                    "installable": not missing, "missing": missing,
                    "relation": "current" if k == cur else "newer" if k > cur else "older"})
    out.sort(key=lambda x: ver_key(x["tag"]), reverse=True)
    newest = next((x["tag"] for x in out if x["relation"] == "newer" and x["installable"] and not x["prerelease"]), "")
    save_json("update-check.json", {"at": time.strftime("%Y-%m-%d %H:%M"), "newest": newest, "current": VERSION})
    return out


def kv_file(f):
    out = {}
    for line in (read_text(f) or "").splitlines():
        k, _, v = line.partition("=")
        if re.match(r"^[A-Z_]+$", k):
            out[k] = v
    return out


def upd_state():
    info = kv_file(os.path.join(UPD, "updater.info"))
    st = kv_file(os.path.join(UPD, "status"))
    pending = os.path.exists(os.path.join(UPD, "request")) or os.path.exists(os.path.join(UPD, "request.running"))
    log = read_text(os.path.join(UPD, "update.log")) or ""
    c = upd_conf()
    try:
        matches = bool(info.get("REPO")) and bool(c.get("url")) and repo_norm(info["REPO"]) == repo_norm(c["url"])
    except ValueError:
        matches = False
    waiting = 0   # seconds a request has waited for the host to pick it up
    try:
        if st.get("STATE") == "requested" and os.path.exists(os.path.join(UPD, "request")):
            waiting = int(time.time() - os.path.getmtime(os.path.join(UPD, "request")))
    except OSError:
        pass
    return {"installed": bool(info.get("REPO")), "pinned": info.get("REPO", ""), "since": info.get("SINCE", ""), "waiting": waiting,
            "matches": matches, "writable": os.path.isdir(UPD) and os.access(UPD, os.W_OK),
            "state": st.get("STATE", ""), "version": st.get("VERSION", ""), "message": st.get("MESSAGE", ""),
            "at": st.get("AT", ""), "by": st.get("BY", ""), "pending": pending, "log": log[-6000:]}


def write_upd(name, text, mode):
    f = os.path.join(UPD, name)
    tmp = f + ".new"
    with open(tmp, "w") as fh:
        fh.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, f)


def request_install(user, tag):
    if not TAG_RE.match(tag or ""):
        raise ValueError("bad version")
    c = upd_conf()
    if not c.get("url"):
        raise ValueError("connect the repository first")
    st = upd_state()
    if not st["writable"]:
        raise ValueError("the host's updater isn't set up - on the host run: sudo ./setup.sh updater")
    if not st["installed"]:
        raise ValueError("the host's updater isn't set up - on the host run: sudo ./setup.sh updater")
    if not st["matches"]:
        raise ValueError("the host only allows updates from %s - run sudo ./setup.sh updater again to allow this repository" % st["pinned"])
    if st["pending"] or (st["state"] in BUSY and st["at"] and time.time() - os.path.getmtime(os.path.join(UPD, "status")) < 1800):
        raise ValueError("an update is already running")
    if tag in cached_versions():   # kept on this kit - no repository needed
        rel = {"tag": tag, "name": "ICS Ranges %s" % tag.lstrip("v"), "installable": True, "missing": [], "cached": True}
    else:
        rel = next((r for r in fetch_releases(c) if r["tag"] == tag), None)
    if not rel:
        raise KeyError("no release %s in the repository" % tag)
    if not rel["installable"]:
        raise ValueError("release %s is missing %s - attach it in Gitea, or run ./release.sh publish %s"
                         % (tag, " and ".join(rel["missing"]), tag))
    token = (read_text(path("priv/update-token")) or "").strip()
    write_upd("request.token", "%s:%s\n" % (c.get("user", ""), token), 0o600)
    write_upd("status", "STATE=requested\nVERSION=%s\nMESSAGE=Waiting for the host's updater\nAT=%s\nBY=%s\n"
              % (tag, time.strftime("%Y-%m-%dT%H:%M:%S"), user), 0o644)
    write_upd("request", "TAG=%s\nBY=%s\n" % (tag, user), 0o644)   # last - the host starts on this file
    audit(user, "software update to %s requested (now %s)" % (tag, VERSION))
    return rel


def update_connect(who, url, user, token, insecure):
    """Connect Software updates to a repository - tested before anything is saved."""
    url = (url or "").strip()
    repo_parts(url)
    user = (user or "").strip()
    if not re.match(r"^[A-Za-z0-9_.@-]{1,64}$", user):
        raise ValueError("give the user name on the repository server")
    token = (token or "").strip() or (read_text(path("priv/update-token")) or "").strip()
    if not re.match(r"^[A-Za-z0-9_-]{8,200}$", token):
        raise ValueError("give a read-only token for the repository")
    c = {"url": url.rstrip("/").removesuffix(".git"), "user": user, "insecure": bool(insecure)}
    rel = fetch_releases(c, token)
    save_json("update.json", c)
    os.makedirs(path("priv"), exist_ok=True)
    write_text(path("priv/update-token"), token + "\n", 0o600)
    audit(who, "software repository: %s" % c["url"])
    return rel


def host_command():   # the one line to run on the host, with this page's repository filled in
    c = upd_conf()
    return "sudo ./setup.sh updater" + (" --repo %s" % c["url"] if c.get("url") else "") + (" --insecure" if c.get("insecure") else "")


_BRIDGES = {}


def node_bridges(node):
    """{"ovs": [...], "linux": [...]} - the bridges of a node (cached a minute)."""
    t, b = _BRIDGES.get(node, (0, None))
    if b is None or time.time() - t > 60:
        b = {"ovs": [], "linux": []}
        try:
            for x in pve.call("GET", "/nodes/%s/network" % node, timeout=8) or []:
                if x.get("type") == "OVSBridge":
                    b["ovs"].append(x["iface"])
                elif x.get("type") == "bridge":
                    b["linux"].append(x["iface"])
        except PVEError:
            pass
        _BRIDGES[node] = (time.time(), b)
    return b


def net_summary(course):
    """NICs of a course: how many, which are disconnected, how many have the firewall off."""
    if inv.offline:
        return {"nics": 0, "disconnected": [], "fw_off": 0, "offline": True}
    ids = inv.course_ids(course)
    cfgs = inv.configs(ids)
    total, fw_off, down = 0, 0, []
    for v in ids:
        for k, val in sorted(cfgs.get(v, {}).items()):
            if not re.match(r"^net\d+$", k):
                continue
            total += 1
            parts = val.split(",")
            if "firewall=1" not in parts:
                fw_off += 1
            if "link_down=1" in parts:
                down.append({"vmid": v, "name": inv.guests[v]["name"], "nic": k,
                             "bridge": (re.search(r"bridge=([^,]+)", val) or [None, ""])[1]})
    return {"nics": total, "disconnected": down, "fw_off": fw_off}


# ---------------------------------------------------------------------------- readiness check
_STORE = {}   # node -> (time, [storages with used / total])


def node_storage(node):
    t, lst = _STORE.get(node, (0, None))
    if lst is None or time.time() - t > 60:
        lst = pve.call("GET", "/nodes/%s/storage" % node, timeout=8) or []
        _STORE[node] = (time.time(), lst)
    return lst


def readiness(course, snap):
    """Is the course ready for class? A list of checks - ok / warn / fail / info - each with the guests it found."""
    checks = []

    def add(state, title, detail="", items=None, fix=""):
        checks.append({"state": state, "title": title, "detail": detail, "items": items or [], "fix": fix})
    G = inv.guests
    if inv.offline:
        add("fail", "Proxmox answers", "It isn't answering since %s - nothing can be checked or started" % inv.offline["since"],
            fix="Check that the Proxmox nodes are on and reachable from the ICS Ranges host")
        return checks
    ids = inv.course_ids(course)
    if not ids:
        add("fail", "Guests", "This course has no guests")
        return checks
    lbl = lambda v: "%d %s" % (v, G[v]["name"])   # noqa
    add("ok", "Proxmox answers", "%d node(s) online: %s" % (len(inv.nodes), ", ".join(inv.nodes)))
    gone = sorted({G[v]["node"] for v in ids} - set(inv.nodes))
    if gone:
        add("fail", "Nodes", "Guests are on node(s) that aren't online: " + ", ".join(gone),
            [lbl(v) for v in ids if G[v]["node"] in gone], "Start the node, or migrate its guests")
    snaps = inv.snapshots(ids, max_age=60)
    missing = [v for v in ids if not any(x["name"] == snap for x in snaps.get(v, []))]
    if missing:
        add("fail" if len(missing) > len(ids) // 2 else "warn", "Class snapshot %s" % snap,
            "%d of %d guests don't have it - Start / End class can't reset them" % (len(missing), len(ids)),
            [lbl(v) for v in missing], "Take %s on these guests (Snapshots… → Take a new snapshot), or leave them out of the class" % snap)
    else:
        add("ok", "Class snapshot %s" % snap, "All %d guests have it" % len(ids))
    times = [x.get("time") or 0 for v in ids for x in snaps.get(v, []) if x["name"] == snap and x.get("time")]
    if times and max(times) - min(times) > 7 * 86400:
        old = [v for v in ids for x in snaps.get(v, []) if x["name"] == snap and (x.get("time") or 0) < max(times) - 7 * 86400]
        add("warn", "Snapshot age", "%s was taken at different times - %d guest(s) have a copy more than a week older than the newest"
            % (snap, len(old)), [lbl(v) + " (" + time.strftime("%Y-%m-%d", time.localtime(min(x.get("time") or 0 for x in snaps[v] if x["name"] == snap))) + ")" for v in old],
            "Usually fine - check these guests have the same lab state")
    cfgs = inv.configs(ids)
    locked = [(v, cfgs[v]["lock"]) for v in ids if cfgs.get(v, {}).get("lock")]
    if locked:
        add("fail", "Locked guests", "%d guest(s) are locked - they can't be started, stopped or restored" % len(locked),
            ["%s - locked: %s" % (lbl(v), why) for v, why in locked],
            "Usually a backup or snapshot is still running - wait for it. A stuck lock: on the node, qm unlock <vmid>")
    else:
        add("ok", "Locked guests", "None")
    # storage the course's disks are on
    used = {}
    for v in ids:
        for k, val in cfgs.get(v, {}).items():
            if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]:
                used.setdefault((G[v]["node"], val.split(":")[0]), []).append(v)
    full = []
    for (node, st), vs in sorted(used.items()):
        try:
            info = next((x for x in node_storage(node) if x.get("storage") == st), None)
        except PVEError:
            info = None
        if info and info.get("total"):
            frac = info.get("used", 0) / info["total"]
            if frac >= 0.85:
                full.append(("fail" if frac >= 0.95 else "warn", "%s on %s: %d%% used, %d GiB free (%d guest(s) of this course)"
                             % (st, node, frac * 100, info.get("avail", 0) >> 30, len(set(vs)))))
    if full:
        add("fail" if any(x[0] == "fail" for x in full) else "warn", "Storage", "Nearly full - snapshots and restores may fail",
            [x[1] for x in full], "Delete old snapshots or move disks to another storage (Build… → Move disks)")
    else:
        add("ok", "Storage", "The storages of this course have room (%d checked)" % len(used))
    ns = net_summary(course)
    if ns["disconnected"]:
        add("warn", "Network", "%d NIC(s) are disconnected - those guests can't talk on that network" % len(ns["disconnected"]),
            ["%d %s %s on %s" % (d["vmid"], d["name"], d["nic"], d["bridge"]) for d in ns["disconnected"]],
            "If that isn't on purpose: Network add-ons → Change…, tick Connected")
    else:
        add("ok", "Network", "All %d NIC(s) connected" % ns["nics"])
    run = [v for v in ids if G[v]["status"] == "running"]
    add("info", "Running now", "%d of %d guests are running%s" % (len(run), len(ids), " - before class they are usually off (End class)" if run else ""),
        [lbl(v) for v in run][:30])
    # sensors
    ents = [(m, e) for m in mirrors() for e in m.get("entries", []) if e.get("vmid") in ids]
    if ents:
        live = {}
        for m in {(m["node"], m["bridge"]) for m, _ in ents}:
            st_ = mirror_status(*m)
            live[m] = {x["port"] for x in st_["mirrors"]}
        bad = []
        for m, e in ents:
            g = G.get(e["vmid"])
            if not g:
                bad.append("%d - no longer exists" % e["vmid"])
            elif g["status"] != "running":
                bad.append("%s - off" % lbl(e["vmid"]))
            elif nic_dev(g, e["nic"]) not in live.get((m["node"], m["bridge"]), set()):
                bad.append("%s - running, NOT mirrored" % lbl(e["vmid"]))
        if bad:
            add("warn", "Sensors", "%d of %d sensor(s) aren't receiving the traffic" % (len(bad), len(ents)), bad,
                "Start the sensors, then Re-apply mirrors in the Network add-ons panel")
        else:
            add("ok", "Sensors", "All %d sensor(s) running and mirrored" % len(ents))
    return checks


def api_ready(self, s, method, parts, q):
    if not ({"class_run", "overview"} & set(s["perms"])):
        raise PermissionError("your role can't do this")
    course = urllib.parse.unquote(parts[0]) if parts else ""
    allow = allowed_courses(s["u"])
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh(force=not inv.offline)
    snap = q.get("snapshot") or settings().get("default_snapshot") or "ClassStart"
    checks = readiness(course, snap)
    audit(s["user"], "readiness check %s: %s" % (course, ", ".join("%s %s" % (c["title"], c["state"]) for c in checks if c["state"] in ("warn", "fail")) or "all ok"))
    return self.send(200, {"course": course, "snapshot": snap, "checks": checks, "at": time.strftime("%H:%M"),
                           "ready": not any(c["state"] == "fail" for c in checks)})


setattr(Handler, "api_ready", api_ready)


# ---------------------------------------------------------------------------- kit export / import
# One encrypted file with everything that makes up a kit: users (with passwords and 2FA), roles,
# settings, course map, mixed courses, mirrors, groups, themes, class guides, add-ons, history,
# the activity log, the HTTPS certificate, the node key - and the Proxmox settings.
KIT_SKIP = ("backups", "inventory-cache.json", "priv/sessions.json", ".kit-import")
KIT_ENV = ("PVE_API_URL", "PVE_API_TOKEN", "KEY_FROM", "PORT", "MAX_PARALLEL", "SHUTDOWN_TIMEOUT", "SESSION_IDLE")


def _crypt(data, password, decrypt=False):
    if len(password or "") < 10:
        raise ValueError("the kit password must have at least 10 characters")
    cmd = ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000", "-salt", "-pass", "env:KIT_PASSWORD"] + (["-d"] if decrypt else [])
    p = subprocess.run(cmd, input=data, capture_output=True, env=dict(os.environ, KIT_PASSWORD=password), timeout=300)
    if p.returncode:
        raise ValueError("wrong password, or not an ICS Ranges kit file" if decrypt else "encrypting failed: %s" % p.stderr.decode(errors="replace")[:200])
    return p.stdout


def kit_export(password, who):
    buf = io.BytesIO()
    man = {"kind": "ics-ranges-kit", "format": 1, "version": VERSION, "made": time.strftime("%Y-%m-%d %H:%M"), "by": who,
           "env": {k: os.environ[k] for k in KIT_ENV if os.environ.get(k)}, "users": sorted(users())}
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        b = json.dumps(man, indent=2).encode()
        ti = tarfile.TarInfo("kit.json")
        ti.size, ti.mtime = len(b), int(time.time())
        tf.addfile(ti, io.BytesIO(b))
        for root, dirs, files in os.walk(DATA):
            rel = os.path.relpath(root, DATA)
            dirs[:] = [d for d in dirs if os.path.normpath(os.path.join(rel, d)) not in KIT_SKIP]
            for f in files:
                r = os.path.normpath(os.path.join(rel, f))
                if r not in KIT_SKIP and not r.startswith(KIT_SKIP):
                    tf.add(os.path.join(root, f), arcname="data/" + r)
    audit(who, "kit exported")
    return _crypt(buf.getvalue(), password)


def kit_open(blob, password):
    """Decrypt and check a kit file - returns (manifest, tarfile)."""
    tf = tarfile.open(fileobj=io.BytesIO(_crypt(blob, password, decrypt=True)), mode="r:gz")
    try:
        man = json.load(tf.extractfile("kit.json"))
    except (KeyError, ValueError):
        raise ValueError("that isn't an ICS Ranges kit file")
    if man.get("kind") != "ics-ranges-kit":
        raise ValueError("that isn't an ICS Ranges kit file")
    for m in tf.getmembers():   # only plain files and folders, all under data/ - nothing can land elsewhere
        if m.name == "kit.json":
            continue
        n = os.path.normpath(m.name)
        if not (m.isfile() or m.isdir()) or os.path.isabs(n) or n.startswith("..") or not n.startswith("data"):
            raise ValueError("the kit file contains something unexpected: %s" % m.name)
    return man, tf


def kit_import(blob, password, who):
    man, tf = kit_open(blob, password)
    # first a kit file of what is here now (same password) - an import can be undone
    os.makedirs(path("backups"), exist_ok=True)
    before = path("backups/kit-before-import-%s.icskit" % time.strftime("%Y%m%d-%H%M%S"))
    with open(before, "wb") as f:
        f.write(kit_export(password, who))
    tmp = path(".kit-import")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    with LOCK:
        for m in tf.getmembers():
            if m.name == "kit.json":
                continue
            dst = os.path.join(tmp, os.path.relpath(os.path.normpath(m.name), "data"))
            if m.isdir():
                os.makedirs(dst, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with tf.extractfile(m) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
                os.chmod(dst, m.mode & 0o700 | 0o600 if "priv" in m.name or "ssh" in m.name or "tls/key" in m.name else 0o640)
        for item in os.listdir(DATA):   # replace everything except the backups (and the kit just made)
            if item in ("backups", ".kit-import"):
                continue
            pth = os.path.join(DATA, item)
            shutil.rmtree(pth) if os.path.isdir(pth) and not os.path.islink(pth) else os.remove(pth)
        for item in os.listdir(tmp):
            shutil.move(os.path.join(tmp, item), os.path.join(DATA, item))
        shutil.rmtree(tmp, ignore_errors=True)
        SESSIONS.clear()   # the users may be different now - everyone signs in again
        sessions_save(True)
        _MAP_CACHE["key"] = None
    audit(who, "kit imported (made %s by %s, version %s); the state before is in %s" % (man.get("made"), man.get("by"), man.get("version"), os.path.basename(before)))
    return man, os.path.basename(before)


def api_kit(self, s, method, parts, q):
    if s["role"] != "admin":
        raise PermissionError("only admins can export or import a kit")
    what = parts[0] if parts else ""
    if method == "POST" and what == "export":
        b = self.body()
        data = kit_export(b.get("password", ""), s["user"])
        name = "ics-ranges-kit-%s.icskit" % time.strftime("%Y%m%d-%H%M")
        return self.send(200, raw=data, ctype="application/octet-stream",
                         headers={"Content-Disposition": 'attachment; filename="%s"' % name})
    if method == "POST" and what in ("check", "import"):
        b = self.body(limit=80_000_000)
        try:
            blob = base64.b64decode(b.get("data", ""), validate=True)
        except (ValueError, TypeError):
            raise ValueError("the file didn't arrive whole")
        if what == "check":   # what is in it - nothing is changed
            man, _ = kit_open(blob, b.get("password", ""))
            return self.send(200, {"made": man.get("made"), "by": man.get("by"), "version": man.get("version"), "users": man.get("users", []),
                                   "proxmox": (man.get("env") or {}).get("PVE_API_URL", "")})
        man, before = kit_import(blob, b.get("password", ""), s["user"])
        return self.send(200, {"ok": True, "made": man.get("made"), "before": before, "proxmox": (man.get("env") or {}).get("PVE_API_URL", ""),
                               "here": os.environ.get("PVE_API_URL", "")})
    raise ValueError("bad request")


setattr(Handler, "api_kit", api_kit)


def fix_612_map():
    """612 groups: 4 iDMZ - File Servers, 5 iDMZ - Jump Hosts, 6 NSM. A saved map with the lines 2.9.0 shipped
    (4 NSM / 6 iDMZ - File Servers) or the old "6 NSM (future)" gets just those lines changed - nothing else."""
    f = path("vmid-map.conf")
    try:
        text = open(f).read()
    except OSError:
        return
    fixes = {r"^sub\s+50\s+4\s+NSM\s*$": "sub 50 4 iDMZ - File Servers",
             r"^sub\s+50\s+6\s+iDMZ - File Servers\s*$": "sub 50 6 NSM",
             r"^sub\s+50\s+6\s+NSM \(future\)\s*$": "sub 50 6 NSM"}
    new = text
    for pat, rep_ in fixes.items():
        new = re.sub(pat, rep_, new, flags=re.M)
    if new != text:
        write_text(f, new)
        audit("ics-ranges", "course map: 612 groups set to 4 iDMZ - File Servers, 5 iDMZ - Jump Hosts, 6 NSM")
        print("Course map: 612 groups 4 / 6 set to iDMZ - File Servers / NSM", flush=True)


def update_checker():   # in the background: is there a newer version? (for the side bar)
    while True:
        time.sleep(30)
        try:
            if upd_conf().get("url"):
                fetch_releases()
        except Exception:   # noqa - offline kits are normal
            pass
        time.sleep(6 * 3600)


def api_updates(self, s, method, parts, q):
    self.need(s, "software")
    what = parts[0] if parts else ""
    if method == "GET" and what == "":
        c = upd_conf()
        return self.send(200, {"current": VERSION, "url": c.get("url", ""), "user": c.get("user", ""),
                               "insecure": bool(c.get("insecure")), "has_token": bool((read_text(path("priv/update-token")) or "").strip()),
                               "check": load_json("update-check.json", {}), "updater": upd_state(), "command": host_command()})
    if method == "GET" and what == "releases":
        rel, offline = releases_with_cache()
        return self.send(200, {"current": VERSION, "releases": rel, "offline": offline, "kept": len(cached_versions())})
    b = self.body()
    if method == "PUT" and what == "connect":
        rel = update_connect(s["user"], b.get("url"), b.get("user"), b.get("token"), b.get("insecure"))
        return self.send(200, {"ok": True, "releases": len(rel), "command": host_command()})
    if method == "POST" and what == "install":
        rel = request_install(s["user"], b.get("tag", ""))
        return self.send(200, {"ok": True, "tag": rel["tag"]})
    raise ValueError("bad request")


setattr(Handler, "api_updates", api_updates)


def api_mixed(self, s, method, parts, q):
    self.need(s, "settings")
    if method == "GET":
        inv.refresh()
        today = time.strftime("%Y-%m-%d")
        lst = [dict(c, name=n, expired=bool(c.get("expires")) and c["expires"] < today,
                    missing=[v for v in c.get("vmids", []) if v not in inv.guests]) for n, c in sorted(mixed_courses().items())]
        guests = [{"vmid": v, "name": g["name"], "course": g["course"] or "", "group": g["group"], "type": g["type"],
                   "status": g["status"]} for v, g in sorted(inv.guests.items())]
        return self.send(200, {"courses": lst, "guests": guests})
    name = urllib.parse.unquote(parts[0]) if parts else ""
    with LOCK:
        allc = mixed_courses()
        if method == "DELETE":
            if allc.pop(name, None) is None:
                raise KeyError("no such mixed course")
            save_json("courses.json", allc)
            audit(s["user"], "mixed course %s deleted" % name)
            autosave(s["user"], "Mixed course %s deleted" % name)
            return self.send(200, {"ok": True})
        b = self.body()
        old = b.get("old") or ""
        m, _ = load_map()
        if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$", name):
            raise ValueError("course names: letters, digits, . _ - (no spaces), up to 40")
        if name in m["folder"].values() or name == "Management":
            raise ValueError("%s is already a course from the course map" % name)
        if name in allc and name != old:
            raise ValueError("there is already a mixed course %s" % name)
        try:
            vmids = sorted({int(v) for v in b.get("vmids", [])})
        except (TypeError, ValueError):
            raise ValueError("bad guest list")
        if not vmids:
            raise ValueError("pick at least one guest")
        if len(vmids) > 1000:
            raise ValueError("at most 1000 guests")
        exp = (b.get("expires") or "").strip()
        if exp:
            try:
                time.strptime(exp, "%Y-%m-%d")
            except ValueError:
                raise ValueError("the end date must look like 2026-11-30")
            if exp < time.strftime("%Y-%m-%d"):
                raise ValueError("the end date is in the past")
        prev = allc.pop(old, None) if old and old != name else allc.get(name)
        allc[name] = {"desc": (b.get("desc") or "").strip()[:120], "vmids": vmids, "expires": exp,
                      "by": (prev or {}).get("by", s["user"]), "created": (prev or {}).get("created", time.strftime("%Y-%m-%d"))}
        save_json("courses.json", allc)
        if old and old != name:   # renamed: users who had the old name get the new one
            us = users()
            for u in us.values():
                if isinstance(u.get("courses"), list) and old in u["courses"]:
                    u["courses"] = [name if c == old else c for c in u["courses"]]
            save_json("users.json", us)
    audit(s["user"], "mixed course %s: %d guests%s" % (name, len(vmids), (", until " + exp) if exp else ""))
    autosave(s["user"], "Mixed course %s saved" % name)
    return self.send(200, {"ok": True})


setattr(Handler, "api_mixed", api_mixed)


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True


def main():
    os.makedirs(DATA, exist_ok=True)
    srv = Server(("0.0.0.0", PORT), Handler)
    cert, key = path("tls/cert.pem"), path("tls/key.pem")
    if os.path.exists(cert) and os.path.exists(key):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        print("ICS Ranges %s on https://0.0.0.0:%d" % (VERSION, PORT), flush=True)
    else:
        global COOKIE_FLAGS
        COOKIE_FLAGS = ""
        print("ICS Ranges %s on http://0.0.0.0:%d (no certificate - testing only)" % (VERSION, PORT), flush=True)
    try:
        if API_URLS:
            v = pve.call("GET", "/version")
            print("Proxmox API OK - version %s" % v.get("version"), flush=True)
    except PVEError as e:
        print("Proxmox API: %s" % e, flush=True)
    fix_612_map()
    sessions_load()   # who was signed in before a restart or an update stays signed in
    threading.Thread(target=update_checker, daemon=True).start()
    srv.serve_forever()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            sys.exit(cli(sys.argv[1:]))
        except (ValueError, KeyError, PermissionError, PVEError) as e:   # a plain message, not a traceback
            print("error: %s" % str(e).strip("'"), file=sys.stderr)
            sys.exit(1)
        except KeyboardInterrupt:
            sys.exit(130)
    main()
