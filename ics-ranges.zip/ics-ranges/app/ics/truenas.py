"""ICS Ranges - TrueNAS health: pools, alerts, version - read through the TrueNAS API.

TrueNAS 25.04 and later speak JSON-RPC 2.0 over a WebSocket (wss://<host>/api/current); the REST
API is deprecated there (25.10.1 raises an alert on every REST call) and removed in TrueNAS 26.
So this talks WebSocket - a small RFC 6455 client from the standard library - and falls back to
REST (/api/v2.0) only for older TrueNAS that has no WebSocket API yet. API keys go over HTTPS only:
TrueNAS revokes a key that is sent over plain HTTP.
"""
import base64
import hashlib
import json
import os
import re
import secrets
import socket
import ssl
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .core import load_json, path, save_json

CONF = "priv/truenas.json"
_CACHE = {"t": 0, "v": None}
_LOCK = threading.Lock()
TIMEOUT = 8


class TrueNASError(Exception):
    pass


def conf():
    c = load_json(CONF, {})
    return c if isinstance(c, dict) else {}


def conf_public():
    """What the page may see: never the key itself."""
    c = conf()
    return {"url": c.get("url", ""), "user": c.get("user", ""), "verify": bool(c.get("verify", False)), "has_key": bool(c.get("key"))}


def conf_save(b):
    c = conf()
    url = str(b.get("url") or "").strip().rstrip("/")
    if url and not re.match(r"^https://[A-Za-z0-9.\-]+(:\d{1,5})?$", url):
        raise ValueError("the TrueNAS address: https://name-or-ip (HTTPS - TrueNAS revokes API keys sent over HTTP)")
    user = str(b.get("user") or "").strip()
    if user and not re.match(r"^[A-Za-z0-9_.\-]{1,64}$", user):
        raise ValueError("the TrueNAS user: letters, digits, _ . -")
    c.update({"url": url, "user": user, "verify": bool(b.get("verify", False))})
    if isinstance(b.get("key"), str) and b["key"].strip():   # empty: keep the key there is
        c["key"] = b["key"].strip()
    if not url:
        c = {}   # no address: TrueNAS isn't checked
    save_json(CONF, c)
    os.chmod(path(CONF), 0o600)
    _CACHE["t"] = 0


# ------------------------------------------------------------------ a small WebSocket client (RFC 6455)
class WS:
    def __init__(self, url, verify, timeout=TIMEOUT):
        u = urllib.parse.urlparse(url)
        host, port = u.hostname, u.port or (443 if u.scheme == "wss" else 80)
        raw = socket.create_connection((host, port), timeout=timeout)
        if u.scheme == "wss":
            ctx = ssl.create_default_context()
            if not verify:   # TrueNAS' own certificate is often self-signed
                ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
            raw = ctx.wrap_socket(raw, server_hostname=host)
        self.s, self.buf = raw, b""
        key = base64.b64encode(secrets.token_bytes(16)).decode()
        req = ("GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n") % (u.path or "/", u.netloc, key)
        self.s.sendall(req.encode())
        head = self._until(b"\r\n\r\n").decode("latin-1")
        status = head.split("\r\n", 1)[0]
        if " 101 " not in status + " ":
            raise TrueNASError("no WebSocket API at %s (%s)" % (url, status.strip()))
        want = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        if want not in head:
            raise TrueNASError("the WebSocket answer from %s isn't valid" % url)

    def _read(self, n):
        while len(self.buf) < n:
            d = self.s.recv(65536)
            if not d:
                raise TrueNASError("TrueNAS closed the connection")
            self.buf += d
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def _until(self, mark):
        while mark not in self.buf:
            d = self.s.recv(65536)
            if not d:
                raise TrueNASError("TrueNAS closed the connection")
            self.buf += d
            if len(self.buf) > 65536:
                raise TrueNASError("TrueNAS sent too much before the WebSocket started")
        i = self.buf.index(mark) + len(mark)
        out, self.buf = self.buf[:i], self.buf[i:]
        return out

    def _frame(self, op, data):
        mask = secrets.token_bytes(4)   # a client masks every frame
        n = len(data)
        head = bytes([0x80 | op])
        head += bytes([0x80 | n]) if n < 126 else (bytes([0x80 | 126]) + struct.pack(">H", n) if n < 65536 else bytes([0x80 | 127]) + struct.pack(">Q", n))
        self.s.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def send(self, text):
        self._frame(0x1, text.encode())

    def recv(self):
        parts = []
        while True:
            b1, b2 = self._read(2)
            fin, op, n = b1 & 0x80, b1 & 0x0F, b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            if n > 64 * 1024 * 1024:
                raise TrueNASError("TrueNAS sent a message that is far too large")
            mask = self._read(4) if b2 & 0x80 else None
            data = self._read(n)
            if mask:
                data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
            if op == 0x9:   # ping -> pong
                self._frame(0xA, data)
                continue
            if op == 0xA:
                continue
            if op == 0x8:
                raise TrueNASError("TrueNAS closed the connection")
            parts.append(data)
            if fin:
                return b"".join(parts).decode("utf-8", "replace")

    def close(self):
        try:
            self._frame(0x8, b"")
            self.s.close()
        except OSError:
            pass


class RPC:
    """JSON-RPC 2.0 over the WebSocket."""
    def __init__(self, url, verify):
        self.ws, self.n = WS(url, verify), 0

    def call(self, method, params=None):
        self.n += 1
        self.ws.send(json.dumps({"jsonrpc": "2.0", "id": self.n, "method": method, "params": params or []}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") != self.n:   # notifications and events: not ours
                continue
            if "error" in m:
                e = m["error"] or {}
                raise TrueNASError("%s: %s" % (method, (e.get("data") or {}).get("reason") or e.get("message") or e))
            return m.get("result")

    def close(self):
        self.ws.close()


# ------------------------------------------------------------------ reading the health
def _ws_read(c):
    host = c["url"].split("://", 1)[1]
    rpc = RPC("wss://%s/api/current" % host, c.get("verify"))
    try:
        try:
            r = rpc.call("auth.login_ex", [{"mechanism": "API_KEY_PLAIN", "username": c.get("user") or "root", "api_key": c["key"]}])
            ok = isinstance(r, dict) and r.get("response_type") == "SUCCESS"
        except TrueNASError as e:
            if "auth.login_ex" in str(e) and re.search(r"not found|unknown|Method", str(e), re.I):
                ok = rpc.call("auth.login_with_api_key", [c["key"]]) is True   # an older 25.x
            else:
                raise
        if not ok:
            raise TrueNASError("TrueNAS refused the API key for %s" % (c.get("user") or "root"))
        info = rpc.call("system.info") or {}
        pools = rpc.call("pool.query") or []
        alerts = rpc.call("alert.list") or []
        return info, pools, alerts, "WebSocket API"
    finally:
        rpc.close()


def _rest_read(c):   # TrueNAS before 25.04: no WebSocket JSON-RPC yet
    ctx = ssl.create_default_context()
    if not c.get("verify"):
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE

    def get(p):
        r = urllib.request.Request(c["url"] + "/api/v2.0" + p, headers={"Authorization": "Bearer " + c["key"]})
        try:
            with urllib.request.urlopen(r, timeout=TIMEOUT, context=ctx) as f:
                return json.loads(f.read())
        except urllib.error.HTTPError as e:
            raise TrueNASError("TrueNAS REST %s: HTTP %d" % (p, e.code))
    return get("/system/info"), get("/pool"), get("/alert/list"), "REST API (TrueNAS before 25.04)"


def _summary(info, pools, alerts, via):
    out_pools, worst = [], "ok"
    def worse(a, b):
        return a if ["ok", "warn", "fail"].index(a) >= ["ok", "warn", "fail"].index(b) else b
    for p in pools if isinstance(pools, list) else []:
        size, used = p.get("size") or 0, p.get("allocated") or 0
        pct = round(100.0 * used / size, 1) if size else None
        status = str(p.get("status") or "?")
        st = "ok" if p.get("healthy", status == "ONLINE") and status == "ONLINE" else "fail"
        if st == "ok" and (p.get("warning") or (pct is not None and pct >= 85)):
            st = "warn"
        if pct is not None and pct >= 95:
            st = "fail"
        worst = worse(worst, st)
        out_pools.append({"name": p.get("name", "?"), "status": status, "state": st, "used_pct": pct,
                          "size": size, "free": p.get("free") or (size - used if size else None)})
    out_alerts = []
    for a in alerts if isinstance(alerts, list) else []:
        lvl = str(a.get("level") or "INFO").upper()
        if a.get("dismissed") or lvl in ("INFO", "NOTICE"):
            continue
        st = "fail" if lvl in ("CRITICAL", "ALERT", "EMERGENCY") else "warn"
        worst = worse(worst, st)
        text = re.sub(r"<[^>]+>", "", str(a.get("formatted") or a.get("text") or a.get("klass") or "?")).strip()
        out_alerts.append({"level": lvl, "state": st, "text": text[:400]})
    return {"configured": True, "reachable": True, "state": worst, "via": via, "hostname": info.get("hostname", ""),
            "version": info.get("version", ""), "uptime": int(info.get("uptime_seconds") or 0),
            "pools": out_pools, "alerts": out_alerts, "at": time.strftime("%H:%M:%S")}


def plain(e, c):
    """The reason in plain words, with what to do."""
    m = str(e)
    if isinstance(e, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in m:
        return "its certificate isn't trusted (%s) - untick \"Check its certificate\" for TrueNAS' own self-signed one" % (m.split("certificate verify failed:")[-1].split("(_ssl")[0].strip() or "not trusted")
    if isinstance(e, ConnectionRefusedError) or "Connection refused" in m:
        return "nothing answers at %s - is the address right, and the TrueNAS web interface running?" % c.get("url")
    if isinstance(e, (socket.timeout, TimeoutError)) or "timed out" in m:
        return "no answer from %s within %d seconds - address, network or firewall" % (c.get("url"), TIMEOUT)
    if isinstance(e, socket.gaierror) or "Name or service not known" in m or "nodename nor servname" in m:
        return "the name in %s can't be found - use the IP address, or check DNS" % c.get("url")
    return m[:300]


def health(max_age=30):
    """TrueNAS health, kept for half a minute so pages don't ask it every time."""
    c = conf()
    if not c.get("url") or not c.get("key"):
        return {"configured": False}
    with _LOCK:
        if _CACHE["v"] is not None and time.time() - _CACHE["t"] < max_age:
            return _CACHE["v"]
        try:
            try:
                v = _summary(*_ws_read(c))
            except TrueNASError as e:
                if not str(e).startswith("no WebSocket API"):
                    raise
                v = _summary(*_rest_read(c))
        except (TrueNASError, OSError, ValueError, ssl.SSLError) as e:
            v = {"configured": True, "reachable": False, "state": "fail", "error": plain(e, c), "at": time.strftime("%H:%M:%S")}
        _CACHE.update(t=time.time(), v=v)
        return v
