"""ControlYard - the server, split into modules by topic. The program starts in server.py."""
