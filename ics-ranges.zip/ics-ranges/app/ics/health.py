"""ICS Ranges - health at a glance: the Proxmox cluster (quorum, nodes, guests, storage) and TrueNAS."""
import time

from .core import PVEError, allowed_courses, inv, pve
from . import truenas


def cluster_health(user):
    """Like Proxmox' Datacenter summary - for the courses this user may see."""
    out = {"state": "ok", "at": time.strftime("%H:%M:%S")}
    if inv.offline:
        return dict(out, state="fail", reachable=False, error="Proxmox isn't answering since %s" % inv.offline["since"])
    try:
        st = pve.call("GET", "/cluster/status", timeout=8) or []
        res = pve.call("GET", "/cluster/resources", {"type": "storage"}, timeout=8) or []
    except PVEError as e:
        return dict(out, state="fail", reachable=False, error=str(e)[:300])
    cl = next((x for x in st if x.get("type") == "cluster"), None)
    nodes = sorted(({"name": x.get("name"), "online": bool(x.get("online")), "ip": x.get("ip", "")} for x in st if x.get("type") == "node"), key=lambda n: n["name"])
    out.update(reachable=True, cluster=cl.get("name") if cl else "", quorate=(bool(cl.get("quorate")) if cl else None), nodes=nodes)
    allow = allowed_courses(user) if user else None   # no user: the whole range (Ready for class?)
    gs = [g for g in inv.guests.values() if allow is None or g.get("course") in allow]
    count = lambda t, s: sum(1 for g in gs if g["type"] == t and (g["status"] == "running") == (s == "running"))   # noqa: E731
    out["guests"] = {"vm": {"running": count("qemu", "running"), "stopped": count("qemu", "stopped")},
                     "ct": {"running": count("lxc", "running"), "stopped": count("lxc", "stopped")},
                     "limited": allow is not None}
    full, seen = [], set()
    for s in res:
        key = s.get("storage") if s.get("shared") else "%s/%s" % (s.get("node"), s.get("storage"))
        if key in seen or not s.get("maxdisk"):
            continue
        seen.add(key)
        pct = round(100.0 * (s.get("disk") or 0) / s["maxdisk"], 1)
        if pct >= 85 or s.get("status") not in (None, "available"):
            full.append({"storage": key, "used_pct": pct, "status": s.get("status") or "", "state": "fail" if pct >= 95 or s.get("status") not in (None, "available") else "warn"})
    out["storage"] = sorted(full, key=lambda x: -x["used_pct"])
    off = [n for n in nodes if not n["online"]]
    if out["quorate"] is False or (nodes and len(off) == len(nodes)):
        out["state"] = "fail"
    elif off or any(x["state"] == "fail" for x in full):
        out["state"] = "fail" if any(x["state"] == "fail" for x in full) else "warn"
    elif full:
        out["state"] = "warn"
    return out


def health(user):
    c = cluster_health(user)
    t = truenas.health()
    order = ["ok", "warn", "fail"]
    worst = max([c["state"]] + ([t["state"]] if t.get("configured") else []), key=order.index)
    return {"state": worst, "proxmox": c, "truenas": t}


def issues(h, course_storage=None):
    """What's wrong across the range, as (state, text) - the same rules as the Health page.
    course_storage: {(node, storage): [vmids]} - nearly full storage this course uses says so."""
    out, p, t = [], h["proxmox"], h["truenas"]
    if not p.get("reachable"):
        out.append(("fail", "Proxmox: " + p.get("error", "not answering")))
    else:
        if p.get("quorate") is False:
            out.append(("fail", "The cluster has no quorum - it can't make changes"))
        for n in p.get("nodes", []):
            if not n["online"]:
                out.append(("warn", "Node %s is offline" % n["name"]))
        for x in p.get("storage", []):
            on = 0
            for (node, st), vs in (course_storage or {}).items():
                if x["storage"] in ("%s/%s" % (node, st), st):
                    on += len(set(vs))
            out.append((x["state"], "%s: %s%% used%s - snapshots and restores may fail" % (
                x["storage"], x["used_pct"], " (%d guest(s) of this course on it)" % on if on else "")))
    if t.get("configured"):
        if not t.get("reachable"):
            out.append(("fail", "TrueNAS can't be read: " + t.get("error", "?")))
        else:
            for pl in t["pools"]:
                if pl["state"] != "ok":
                    out.append((pl["state"], "TrueNAS pool %s: %s%s" % (pl["name"], pl["status"], ", %s%% used" % pl["used_pct"] if pl["used_pct"] is not None else "")))
            for a in t["alerts"]:
                out.append((a["state"], "TrueNAS %s: %s" % (a["level"], a["text"])))
    return out
