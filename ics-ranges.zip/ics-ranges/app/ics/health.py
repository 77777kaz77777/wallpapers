"""ControlYard - health at a glance: the Proxmox cluster (quorum, nodes, guests, storage) and TrueNAS."""
import time
from concurrent.futures import ThreadPoolExecutor

from .core import PVEError, allowed_courses, inv, pve
from . import truenas


def cluster_health(user):
    """Like Proxmox' Datacenter summary - for the courses this user may see."""
    out = {"state": "ok", "at": time.strftime("%H:%M:%S")}
    if inv.offline:
        return dict(out, state="fail", reachable=False, error="Proxmox isn't answering since %s" % inv.offline["since"])
    try:   # all at the same time: the guest list (counted below), the cluster, the storage
        with ThreadPoolExecutor(max_workers=3) as ex:
            f_inv = ex.submit(inv.refresh)
            f_st = ex.submit(pve.call, "GET", "/cluster/status", None, 8)
            f_res = ex.submit(pve.call, "GET", "/cluster/resources", {"type": "storage"}, 8)
            st, res = f_st.result() or [], f_res.result() or []
            f_inv.result()
    except PVEError as e:
        return dict(out, state="fail", reachable=False, error=str(e)[:300])
    cl = next((x for x in st if x.get("type") == "cluster"), None)
    nodes = sorted(({"name": x.get("name"), "online": bool(x.get("online")), "ip": x.get("ip", "")} for x in st if x.get("type") == "node"), key=lambda n: n["name"])
    out.update(reachable=True, cluster=cl.get("name") if cl else "", quorate=(bool(cl.get("quorate")) if cl else None), nodes=nodes)
    allow = allowed_courses(user) if user else None   # no user: the whole range (Ready for class?)
    gs = [g for g in inv.guests.values() if allow is None or g.get("course") in allow]
    count = lambda t, s: sum(1 for g in gs if g["type"] == t and (g["status"] == "running") == (s == "running"))   # noqa: E731
    out["guests"] = {"vm": {"running": count("qemu", "running"), "stopped": count("qemu", "stopped")},
                     "ct": {"running": count("lxc", "running"), "stopped": count("lxc", "stopped")},
                     "limited": allow is not None}
    full, seen = [], set()
    for s in res:
        key = s.get("storage") if s.get("shared") else "%s/%s" % (s.get("node"), s.get("storage"))
        if key in seen or not s.get("maxdisk"):
            continue
        seen.add(key)
        pct = round(100.0 * (s.get("disk") or 0) / s["maxdisk"], 1)
        if pct >= 85 or s.get("status") not in (None, "available"):
            full.append({"storage": key, "used_pct": pct, "status": s.get("status") or "", "state": "fail" if pct >= 95 or s.get("status") not in (None, "available") else "warn"})
    out["storage"] = sorted(full, key=lambda x: -x["used_pct"])
    off = [n for n in nodes if not n["online"]]
    if out["quorate"] is False or (nodes and len(off) == len(nodes)):
        out["state"] = "fail"
    elif off or any(x["state"] == "fail" for x in full):
        out["state"] = "fail" if any(x["state"] == "fail" for x in full) else "warn"
    elif full:
        out["state"] = "warn"
    return out


def health(user):
    c = cluster_health(user)
    t = truenas.health()
    order = ["ok", "warn", "fail"]
    worst = max([c["state"]] + ([t["state"]] if t.get("configured") else []), key=order.index)
    return {"state": worst, "proxmox": c, "truenas": t}
