"""ControlYard - share (split from server.py; see server.py for the program)."""
import os
import re
import subprocess
import threading
import time
import urllib.request
from .core import (DATA, PVEError, audit, inv, load_json, path, settings)
from .content import (SHARE, write_text)


# ---------------------------------------------------------------------------- Git: history, your repository, backups
REPO = os.path.join(DATA, "repo")
BACKUPS = os.path.join(DATA, "backups")
GIT_LOCK = threading.Lock()
SAVED = ["roles.json", "vmid-map.conf", "settings.json", "mirrors.json", "groups.json", "themes.json", "courses.json"]


def git_conf():
    c = load_json("git.json", {})
    return c if isinstance(c, dict) else {}


def git_env():
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", HOME=DATA)
    tok = path("priv/git-token")
    if os.path.exists(tok):
        ask = path("priv/askpass.sh")
        if not os.path.exists(ask):
            write_text(ask, "#!/bin/sh\ncat '%s'\n" % tok, 0o700)
        env["GIT_ASKPASS"] = ask
    key = path("ssh/git_ed25519")
    env["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=%s%s" % (
        path("ssh/known_hosts"), (" -o IdentitiesOnly=yes -i " + key) if os.path.exists(key) else "")
    return env


def remote_url(c):
    url, user = c.get("url", ""), c.get("user", "")
    if user and re.match(r"^https?://", url) and "@" not in url.split("/")[2]:
        url = re.sub(r"^(https?://)", r"\1%s@" % urllib.parse.quote(user, safe=""), url)
    return url


def git(*args, check=True, cwd=REPO, timeout=60):
    c = git_conf()
    pre = ["git", "-c", "user.name=ics-ranges", "-c", "user.email=ics-ranges@localhost", "-c", "init.defaultBranch=main"]
    if c.get("insecure"):
        pre += ["-c", "http.sslVerify=false"]
    p = subprocess.run(pre + list(args), cwd=cwd, env=git_env(), capture_output=True, text=True, timeout=timeout)
    if check and p.returncode:
        raise PVEError((p.stderr or p.stdout).strip().splitlines()[-1] if (p.stderr or p.stdout).strip() else "git failed")
    return p.stdout


def export_tree(dest):
    """Copy what is shared (no users, no secrets) into dest."""
    import shutil
    for sub in ("addons", "guides"):
        shutil.rmtree(os.path.join(dest, sub), ignore_errors=True)
        src = os.path.join(SHARE, sub)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dest, sub))
    os.makedirs(os.path.join(dest, "settings"), exist_ok=True)
    for f in SAVED:
        s = path(f)
        t = os.path.join(dest, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, t)
        elif os.path.exists(t):
            os.remove(t)
    readme = os.path.join(dest, "README.md")
    if not os.path.exists(readme):
        write_text(readme, "# ControlYard\n\nAdd-ons, class guides and settings of ControlYard.\n\n"
                   "- `addons/_all/` add-ons for every course, `addons/<course>/` for one course\n"
                   "- `guides/<course>.md` how each course is run\n- `settings/` roles, course map, mirrors, groups, themes\n")


def import_tree(src):
    import shutil
    for sub in ("addons", "guides"):
        s = os.path.join(src, sub)
        if os.path.isdir(s):
            shutil.rmtree(os.path.join(SHARE, sub), ignore_errors=True)
            shutil.copytree(s, os.path.join(SHARE, sub))
    for f in SAVED:
        s = os.path.join(src, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, path(f))
    inv.forget(list(inv.guests))


def repo_init():
    if not os.path.isdir(os.path.join(REPO, ".git")):
        os.makedirs(REPO, exist_ok=True)
        git("init", "-q")
    c = git_conf()
    url = remote_url(c)
    have = git("remote", check=False).split()
    if url and "origin" not in have:
        git("remote", "add", "origin", url)
    elif url:
        git("remote", "set-url", "origin", url)
    elif "origin" in have:
        git("remote", "remove", "origin")


def guard_branch(br):
    """Never the program's branch: one that holds app/server.py is the code, not a kit's content -
    saving would merge the two. Works for any branch name (none is fixed)."""
    if git("ls-tree", "--name-only", "origin/" + br, "app/server.py", check=False).strip():
        raise ValueError("the branch %s holds the program's code - choose another branch for this kit's content "
                         "(Save & share -> connect), e.g. kit-config; it is made when you save" % br)


def repo_save(who, msg):
    """Commit the shared files; push to your repository if one is connected. Returns a short report."""
    with GIT_LOCK:
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        changed = bool(git("status", "--porcelain").strip())
        if changed:
            git("commit", "-q", "-m", msg, "--author", "%s <%s@ics-ranges>" % (who, who))
        c = git_conf()
        if not c.get("url"):
            return "Saved in the history." if changed else "Nothing new to save."
        br = c.get("branch") or "main"
        if git("ls-remote", "--heads", "origin", br, check=False).strip():
            git("fetch", "-q", "origin", br)
            guard_branch(br)
            if git("merge-base", "HEAD", "origin/" + br, check=False).strip() == "":
                git("merge", "-q", "--allow-unrelated-histories", "-X", "ours", "-m", "Join with the repository", "origin/" + br)
            else:
                git("merge", "-q", "-X", "ours", "-m", "Join with the repository", "origin/" + br, check=False)
        git("push", "-q", "origin", "HEAD:" + br, timeout=120)
        return "Saved and uploaded to %s (%s)." % (c["url"], br)


def repo_pull(who):
    with GIT_LOCK:
        c = git_conf()
        if not c.get("url"):
            raise ValueError("connect a repository first")
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        if git("status", "--porcelain").strip():
            git("commit", "-q", "-m", "Before getting the latest", "--author", "%s <%s@ics-ranges>" % (who, who))
        br = c.get("branch") or "main"
        git("fetch", "-q", "origin", br)
        guard_branch(br)
        if git("rev-parse", "--verify", "-q", "HEAD", check=False).strip():
            git("merge", "-q", "--allow-unrelated-histories", "-X", "theirs", "-m", "Latest from the repository", "origin/" + br)
        else:
            git("reset", "-q", "--hard", "origin/" + br)
        import_tree(REPO)
        return "Loaded the latest from %s (%s)." % (c["url"], br)


AUTOSAVE = {"t": None}


def autosave(who, msg):
    """Every change is saved (and uploaded) a moment later, in the background."""
    def go():
        try:
            r = repo_save(who, msg)
            if git_conf().get("url"):
                audit(who, "auto-save: " + r)
        except Exception as e:   # noqa
            audit(who, "auto-save FAILED: %s" % e)
        try:
            if settings().get("backup_keep", 0):
                make_backup()
        except Exception:   # noqa
            pass
    t = AUTOSAVE.get("t")
    if t:
        t.cancel()
    AUTOSAVE["t"] = threading.Timer(3, go)
    AUTOSAVE["t"].daemon = True
    AUTOSAVE["t"].start()


def make_backup():
    import shutil
    import tarfile
    import tempfile
    os.makedirs(BACKUPS, exist_ok=True)
    name = "backup-%s.tar.gz" % time.strftime("%Y%m%d-%H%M%S")
    with tempfile.TemporaryDirectory() as tmp:
        export_tree(tmp)
        with tarfile.open(os.path.join(BACKUPS, name), "w:gz") as t:
            for x in os.listdir(tmp):
                t.add(os.path.join(tmp, x), arcname=x)
        del shutil
    keep = int(settings().get("backup_keep") or 30)
    files = sorted(f for f in os.listdir(BACKUPS) if f.startswith("backup-"))
    for f in files[:-keep]:
        os.remove(os.path.join(BACKUPS, f))
    return name


def restore_backup(name):
    import tarfile
    import tempfile
    if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", name or ""):
        raise ValueError("bad backup name")
    f = os.path.join(BACKUPS, name)
    if not os.path.exists(f):
        raise KeyError("no such backup")
    with tempfile.TemporaryDirectory() as tmp, tarfile.open(f) as t:
        for m in t.getmembers():
            if m.name.startswith("/") or ".." in m.name.split("/") or not (m.isfile() or m.isdir()):
                raise ValueError("unsafe backup file")
        t.extractall(tmp)
        import_tree(tmp)
