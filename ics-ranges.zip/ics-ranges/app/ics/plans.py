"""ICS Ranges - plans (split from server.py; see server.py for the program)."""
import concurrent.futures as cf
import os
import re
import secrets
import threading
import time
import urllib.request
from .core import (snapshot_capable, allowed_courses, audit, gpath, inv, perms_of, pve, settings, step, user_perms, users)
from .content import (ADDON_RE, addon_dir, addon_meta, read_text)
from .netops import (DISK_RE, RAW_ONLY, net_change, node_cmd, storage_types)
from .addons import (run_addon)
from .mirrors import (madd_for, madd_steps)


# ---------------------------------------------------------------------------- plans and jobs
PLANS = {}
JOBS = {}


def st_rollback(g, snap):
    return step("Restore %d %s to %s" % (g["vmid"], g["name"], snap), g["node"],
                lambda: pve.task("POST", gpath(g) + "/snapshot/%s/rollback" % urllib.parse.quote(snap, safe="")), g["vmid"])


def st_start(g):
    return step("Start %d %s" % (g["vmid"], g["name"]), g["node"], lambda: pve.task("POST", gpath(g) + "/status/start"), g["vmid"])


def st_stop(g, mode):
    if mode == "stop":
        return step("Power off %d %s (hard)" % (g["vmid"], g["name"]), g["node"],
                    lambda: pve.task("POST", gpath(g) + "/status/stop"), g["vmid"])
    return step("Shut down %d %s" % (g["vmid"], g["name"]), g["node"],
                lambda: pve.task("POST", gpath(g) + "/status/shutdown", {"timeout": int(settings()["shutdown_timeout"]), "forceStop": 1}), g["vmid"])


def start_groups(gs):
    """Containers first, then VMs - all at once, or one by one with a pause (Settings)."""
    delay = int(settings().get("start_delay") or 0)
    cts, vms = ct_first(gs)
    if delay <= 0:
        return [[st_start(g) for g in grp] for grp in (cts, vms) if grp]
    out = []
    for g in cts + vms:
        st = st_start(g)
        fn = st["fn"]
        st["fn"] = (lambda fn=fn: (fn(), time.sleep(delay))[0])
        st["label"] += "  (then %d s pause)" % delay
        out.append([st])
    return out


def ct_first(gs):
    return [g for g in gs if g["type"] == "lxc"], [g for g in gs if g["type"] == "qemu"]


def build_plan(user, body):
    a = body.get("action")
    course = body.get("course")
    u = users().get(user, {})
    allow = allowed_courses(u)
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh()
    in_course = set(inv.course_ids(course))
    pick = lambda key: [int(x) for x in body.get(key, []) if int(x) in in_course]
    ids = pick("ids")
    G = inv.guests
    groups, notes = [], []
    need = {"class_start": "class_run", "class_end": "class_run", "power_on": "power", "power_off": "power",
            "snap_take": "snap_take", "snap_restore": "snap_restore", "snap_delete": "snap_delete",
            "mirror_apply": "mirror_apply", "network": "network", "disk_move": "disks", "migrate": "migrate",
            "addon_run": "addons_run", "efi_keys": "efi", "net_addons": "network",
            "nic_connect": "network", "mirror_on": "mirror_apply", "mirror_off": "mirror_apply"}.get(a)
    if need is None:
        raise ValueError("unknown action %s" % (a or "(none)"))
    if a == "addon_run" and need not in perms_of(u.get("role")) and "class_run" in perms_of(u.get("role")):
        f_ = os.path.join(addon_dir(body.get("scope", "")), body.get("file", "")) if ADDON_RE.match(body.get("file", "") or "") and body.get("scope") in ("_all", body.get("course")) else ""
        if f_ and os.path.exists(f_) and addon_meta(read_text(f_), body["file"])["button"]:
            need = "class_run"   # a button made for instructors
    if a in ("mirror_on", "mirror_off", "mirror_apply") and need not in perms_of(u.get("role")) and "class_run" in perms_of(u.get("role")):
        need = "class_run"
    if not need or need not in perms_of(u.get("role")):
        raise PermissionError("your role can't do this")

    snap = (body.get("snapshot") or "").strip()
    if a in ("class_start", "class_end", "snap_restore", "snap_delete", "snap_take"):
        if not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", snap):
            raise ValueError("snapshot names start with a letter: letters, digits, - and _")

    if a in ("class_start", "class_end"):
        # restore = guests to roll back; start / off = guests to power on / switch off
        restore, power = pick("restore"), pick("start" if a == "class_start" else "off")
        if a == "class_start" and restore and "snap_restore" not in user_perms(user):
            restore = []   # Start class only powers on, unless the role may restore snapshots
            notes.append("Start class powers the guests on as they are - End class resets them")
        ids = sorted(set(restore) | set(power))
        snaps = inv.snapshots(ids)
        has = {v: {s["name"]: s for s in snaps.get(v, [])} for v in ids}
        restore = [v for v in restore if snap in has[v]]
        ram = {v for v in restore if G[v]["type"] == "qemu" and has[v][snap]["ram"]}
        if restore:
            groups.append([st_rollback(G[v], snap) for v in restore])
        if a == "class_start":
            start = []
            for v in power:
                if v in ram:
                    notes.append("%d %s: its snapshot includes memory, so the restore brings it back running" % (v, G[v]["name"]))
                elif v not in restore and G[v]["status"] == "running":
                    notes.append("%d %s is already running" % (v, G[v]["name"]))
                else:
                    start.append(G[v])
            groups.extend(start_groups(start))
        else:
            mode = "stop" if body.get("mode") == "stop" else "shutdown"
            restored_on = [G[v] for v in power if v in ram]
            kept_on = [G[v] for v in power if v not in restore and G[v]["status"] == "running"]
            if restored_on:
                groups.append([st_stop(g, "stop") for g in restored_on])
                notes.append("Reset guests whose snapshot includes memory come back running - they are then powered off at once (nothing in them to save)")
            if kept_on:
                groups.append([st_stop(g, mode) for g in kept_on])
            if restore and len(ram) < len(restore):
                notes.append("Reset guests whose snapshot has no memory are off right after the restore - no separate switch-off")
    elif a == "power_on":
        todo = [G[v] for v in ids if G[v]["status"] != "running"]
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d of the selected guests already run - left as they are" % skipped)
        groups.extend(start_groups(todo))
    elif a == "power_off":
        mode = "stop" if body.get("mode") == "stop" else "shutdown"
        todo = [G[v] for v in ids if G[v]["status"] == "running"]
        if len(todo) < len(ids):
            notes.append("%d of the selected guests are already off - left as they are" % (len(ids) - len(todo)))
        cts, vms = ct_first(todo)
        if vms:
            groups.append([st_stop(g, mode) for g in vms])
        if cts:
            groups.append([st_stop(g, mode) for g in cts])
    elif a == "snap_take":
        cap = snapshot_capable([G[v] for v in ids])
        cant = [v for v in ids if cap.get(v) is False]
        for v in cant:
            notes.append("%d %s: its storage can't take snapshots (e.g. a container on directory storage) - left out" % (v, G[v]["name"]))
        ids = [v for v in ids if v not in cant]
        ram = bool(body.get("ram"))
        when = body.get("when", "running")   # running | off_first | off_after
        existing = inv.snapshots(ids)
        clash = [v for v in ids if any(s["name"] == snap for s in existing.get(v, []))]
        if clash and not body.get("replace"):
            raise ValueError("%d guest(s) already have a snapshot called %s - tick 'replace' to overwrite it" % (len(clash), snap))
        if clash:
            groups.append([step("Delete the old snapshot %s of %d" % (snap, v), G[v]["node"],
                                (lambda g=G[v]: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))), v) for v in clash])
        on = [G[v] for v in ids if G[v]["status"] == "running"]
        if when == "off_first" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
            notes.append("Running guests are shut down first, so their disks are clean")
            ram = False
        groups.append([step("Snapshot %d %s as %s%s" % (v, G[v]["name"], snap, " with memory" if ram and G[v]["type"] == "qemu" and G[v]["status"] == "running" else ""),
                            G[v]["node"],
                            (lambda g=G[v]: pve.task("POST", gpath(g) + "/snapshot",
                                                     {"snapname": snap, "vmstate": 1 if ram and g["type"] == "qemu" and g["status"] == "running" else None})),
                            v) for v in ids])
        if when == "off_after" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
    elif a == "snap_restore":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if len(todo) < len(ids):
            notes.append("%d guest(s) don't have %s" % (len(ids) - len(todo), snap))
        if todo:
            groups.append([st_rollback(g, snap) for g in todo])
        ram = {g["vmid"] for g in todo if g["type"] == "qemu" and any(x["name"] == snap and x["ram"] for x in snaps.get(g["vmid"], []))}
        after = body.get("after", "leave")   # leave | start | off
        if after == "start":
            groups.extend(start_groups([g for g in todo if g["vmid"] not in ram]))
            if ram:
                notes.append("%d guest(s) come back running by themselves (memory snapshot)" % len(ram))
        elif after == "off" and ram:
            groups.append([st_stop(G[v], "stop") for v in sorted(ram)])
            notes.append("Guests restored with memory come back running - they are switched off afterwards")
        elif after == "leave" and ram:
            notes.append("%d guest(s) come back running (memory snapshot); the others stay off" % len(ram))
    elif a == "snap_delete":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if todo:
            groups.append([step("Delete snapshot %s of %d %s" % (snap, g["vmid"], g["name"]), g["node"],
                                (lambda g=g: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))),
                                g["vmid"]) for g in todo])
    elif a in ("mirror_on", "mirror_off"):   # one mirror add-on, by its button
        mid = str(body.get("id") or "")
        m = next((x for x in madd_for(course) if x["id"] == mid), None)
        if not m:
            raise KeyError("no such mirror add-on for %s" % course)
        groups.extend(madd_steps(m, mid, a == "mirror_on", user, notes))
    elif a == "mirror_apply":   # every active mirror add-on of the course again (after a reboot or a sensor restart)
        act = [m for m in madd_for(course) if m.get("active")]
        if not act:
            notes.append("No mirror add-on of %s is active - switch one on with its button" % course)
        for m in act:
            try:
                groups.extend(madd_steps(m, m["id"], True, user, notes))
            except ValueError as e:
                notes.append(str(e) + " - skipped")
    elif a == "net_addons":   # the Network tab: one bridge - per NIC firewall, connected and VLAN tag
        node, bridge = body.get("node", ""), body.get("bridge", "")
        if node not in inv.nodes or not re.match(r"^[A-Za-z0-9_.-]{1,32}$", bridge):
            raise ValueError("pick a bridge")
        want = {}
        for n in body.get("nics") or []:
            v, nic = int(n.get("vmid", 0)), str(n.get("nic", ""))
            if v not in in_course or not re.match(r"^net\d+$", nic):
                raise ValueError("%s %s isn't a NIC of this course" % (v, nic))
            tag = str(n.get("tag", "keep")).strip()
            if tag not in ("keep", "") and not (tag.isdigit() and 1 <= int(tag) <= 4094):
                raise ValueError("%d %s: a VLAN tag is a number from 1 to 4094 (or empty for none)" % (v, nic))
            want[(v, nic)] = {"firewall": bool(n.get("firewall")), "connected": bool(n.get("connected", True)), "tag": tag}
        cfgs = inv.configs([v for v, _ in want], max_age=0)
        changes = []
        for (v, nic), w in sorted(want.items()):
            cur = cfgs.get(v, {}).get(nic, "")
            if not cur or "bridge=%s" % bridge not in cur.split(","):
                raise ValueError("%d %s isn't on %s" % (v, nic, bridge))
            old_tag = (re.search(r"(?:^|,)tag=(\d+)", cur) or [None, ""])[1]
            new_tag = old_tag if w["tag"] == "keep" else w["tag"]
            parts = [p for p in cur.split(",") if not p.startswith(("firewall=", "link_down=", "tag="))]
            if new_tag:
                parts.append("tag=" + new_tag)
            if w["firewall"]:
                parts.append("firewall=1")
            if not w["connected"]:
                parts.append("link_down=1")
            new = ",".join(parts)
            if set(new.split(",")) != set(cur.split(",")):
                g = G[v]
                what = []
                if ("firewall=1" in cur.split(",")) != w["firewall"]:
                    what.append("firewall " + ("on" if w["firewall"] else "off"))
                if ("link_down=1" in cur.split(",")) == w["connected"]:
                    what.append("connected" if w["connected"] else "disconnected")
                if new_tag != old_tag:
                    what.append(("VLAN %s" % new_tag) if new_tag else "no VLAN tag")
                changes.append(step("%d %s %s: %s" % (v, g["name"], nic, ", ".join(what)), g["node"],
                                    (lambda g=g, nic=nic, new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), v))
        if changes and "network" not in user_perms(user):
            raise PermissionError("changing the firewall, connections or VLAN tags needs the permission 'Change network settings'")
        if changes:
            groups.append(changes)
        if not groups:
            notes.append("Nothing to change - the NICs already look like that")
    elif a == "nic_connect":   # plug the virtual cable back in - firewall, VLAN and mirrors stay as they are
        want = []
        for n in body.get("nics") or []:
            if not isinstance(n, dict):
                raise ValueError("bad request")
            v, nic = int(n.get("vmid") or 0), str(n.get("nic") or "")
            if v not in in_course or not re.match(r"^net\d+$", nic):
                raise ValueError("%s %s isn't a NIC of this course" % (v, nic))
            want.append((v, nic))
        if not want:
            raise ValueError("tick at least one NIC")
        cfgs = inv.configs(sorted({v for v, _ in want}), max_age=0)
        todo = []
        for v, nic in sorted(set(want)):
            g = G[v]
            cur = cfgs.get(v, {}).get(nic, "")
            if not cur:
                notes.append("%d %s has no %s" % (v, g["name"], nic))
            elif "link_down=1" not in cur.split(","):
                notes.append("%d %s %s is already connected" % (v, g["name"], nic))
            else:
                new = ",".join(p for p in cur.split(",") if p != "link_down=1")
                todo.append(step("Connect %d %s %s" % (v, g["name"], nic), g["node"],
                                 (lambda g=g, nic=nic, new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), v))
        if todo:
            groups.append(todo)
    elif a == "network":
        ch = body.get("change") or {}
        if ch.get("bridge") and not re.match(r"^[A-Za-z0-9_.-]+$", ch["bridge"]):
            raise ValueError("bad bridge name")
        if ch.get("vlan") not in (None, "") and not re.match(r"^\d{1,4}$", str(ch["vlan"])):
            raise ValueError("VLAN tags are numbers 1-4094 (empty = no tag)")
        if ch.get("model") and ch["model"] not in ("virtio", "e1000", "e1000e", "rtl8139", "vmxnet3"):
            raise ValueError("bad NIC model")
        nic = body.get("nic") or "all"
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^net\d+$", k) and (nic == "all" or k == nic):
                    new = net_change(G[v], val, ch)
                    if new != val:
                        todo.append(step("%d %s %s: %s" % (v, G[v]["name"], k, new), G[v]["node"],
                                         (lambda g=G[v], k=k, new=new: pve.task("PUT", gpath(g) + "/config", {k: new})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("Nothing to change - the NICs already look like that")
    elif a == "disk_move":
        target, fmt, delete = body.get("storage", ""), body.get("format", "keep"), bool(body.get("delete", True))
        types = storage_types()
        if target not in types:
            raise ValueError("pick a storage")
        if fmt not in ("keep", "raw", "qcow2", "vmdk"):
            raise ValueError("bad format")
        if fmt in ("qcow2", "vmdk") and types[target] in RAW_ONLY:
            raise ValueError("%s (%s) only holds raw disks" % (target, types[target]))
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            g = G[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not DISK_RE.match(k) or "media=cdrom" in val or ":" not in val.split(",")[0]:
                    continue
                if body.get("disk") not in (None, "", "all") and k != body["disk"]:
                    continue
                vol = val.split(",")[0]
                cur_fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                want = cur_fmt if fmt == "keep" or types[target] in RAW_ONLY else fmt
                if types[target] in RAW_ONLY:
                    want = "raw"
                if vol.split(":")[0] == target and want == cur_fmt:
                    continue
                if g["type"] == "lxc":
                    if g["status"] == "running":
                        notes.append("%d %s is a running container - switch it off to move %s" % (v, g["name"], k))
                        continue
                    todo.append(step("Move %d %s %s to %s" % (v, g["name"], k, target), g["node"],
                                     (lambda g=g, k=k: pve.task("POST", gpath(g) + "/move_volume", {"volume": k, "storage": target, "delete": 1 if delete else 0})), v))
                else:
                    todo.append(step("Move %d %s %s to %s as %s" % (v, g["name"], k, target, want), g["node"],
                                     (lambda g=g, k=k, want=want: pve.task("POST", gpath(g) + "/move_disk", {"disk": k, "storage": target, "format": want if types[target] not in RAW_ONLY else None, "delete": 1 if delete else 0})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("No disk needs moving")
    elif a == "migrate":
        targets = body.get("nodes") or [body.get("node", "")]
        if not targets or any(t not in inv.nodes for t in targets):
            raise ValueError("pick nodes that are online")
        how = body.get("spread", "one")   # one | round | blocks
        plan_to = {}
        if how == "round":
            for k, v in enumerate(ids):
                plan_to[v] = targets[k % len(targets)]
        elif how == "blocks":
            per = -(-len(ids) // len(targets))
            for k, v in enumerate(ids):
                plan_to[v] = targets[min(k // per, len(targets) - 1)]
        else:
            plan_to = {v: targets[0] for v in ids}
        todo = []
        for v in ids:
            g = G[v]
            target = plan_to[v]
            if g["node"] == target:
                continue
            if g["type"] == "qemu":
                prm = {"target": target, "online": 1, "with-local-disks": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (live)" if g["status"] == "running" else "")
            else:
                prm = {"target": target, "restart": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (restart)" if g["status"] == "running" else "")
            todo.append(step(label, g["node"], (lambda g=g, prm=prm: pve.task("POST", gpath(g) + "/migrate", prm)), v))
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d already where they should be" % skipped)
        if todo:
            groups.append(todo)
    elif a == "efi_keys":
        method = body.get("method", "enroll")   # enroll (keeps boot entries) | recreate (API only)
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            g, c = G[v], cfgs.get(v, {})
            if g["type"] != "qemu":
                notes.append("%d %s is a container - containers have no EFI" % (v, g["name"]))
                continue
            if c.get("bios") != "ovmf":
                notes.append("%d %s uses SeaBIOS, not UEFI - skipped" % (v, g["name"]))
                continue
            if g["status"] == "running":
                notes.append("%d %s is running - switch it off first" % (v, g["name"]))
                continue
            efi = c.get("efidisk0", "")
            if "pre-enrolled-keys=1" in efi.split(",") and not body.get("again"):
                notes.append("%d %s already has the keys" % (v, g["name"]))
                continue
            if method == "enroll":
                if not efi:
                    notes.append("%d %s has no EFI disk - use 'New EFI disk with keys'" % (v, g["name"]))
                    continue
                todo.append(step("Enroll the EFI keys of %d %s" % (v, g["name"]), g["node"],
                                 (lambda g=g: node_cmd(g["node"], "qm", "enroll-efi-keys", str(g["vmid"]), timeout=120) and ""), v))
            else:
                if efi:
                    stor = efi.split(",")[0].split(":")[0]
                else:   # no EFI disk yet: put it with the VM's first disk
                    first = next((val for k, val in sorted(c.items()) if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]), "")
                    stor = first.split(":")[0] if first else ""
                if not stor:
                    notes.append("%d %s: no storage found for the EFI disk" % (v, g["name"]))
                    continue
                et = (re.search(r"efitype=([^,]+)", efi) or [None, "4m"])[1]
                new = "%s:1,efitype=%s,pre-enrolled-keys=1" % (stor, et)
                def recreate(g=g, had=bool(efi), new=new):
                    if had:   # the old EFI disk stays attached as 'unused' - you can switch back
                        pve.task("PUT", gpath(g) + "/config", {"delete": "efidisk0"})
                    return pve.task("PUT", gpath(g) + "/config", {"efidisk0": new})
                todo.append(step("New EFI disk with the keys for %d %s on %s%s" % (v, g["name"], stor, " (old one kept as unused)" if efi else ""),
                                 g["node"], recreate, v))
        if method != "enroll" and todo:
            notes.append("A new EFI disk starts without boot entries; most systems boot through the default path. "
                         "The old EFI disk stays on the VM as 'unused' until you remove it.")
        if todo:
            groups.append(todo)
    elif a == "addon_run":
        scope, f = body.get("scope", ""), body.get("file", "")
        if not ADDON_RE.match(f or ""):
            raise ValueError("bad add-on")
        if scope not in ("_all", course):
            raise PermissionError("that add-on isn't for this course")
        full = os.path.join(addon_dir(scope), f)
        if not os.path.exists(full):
            raise KeyError("no such add-on")
        text = read_text(full) or ""
        meta = addon_meta(text, f)
        # guests of another course: said plainly, before anything runs
        asked = [int(x) for x in body.get("ids", []) if str(x).isdigit()]
        outside = sorted(set(asked) - in_course)
        if meta["guests"] and outside:
            raise ValueError("%s %s in %s - an add-on only works on the guests of its course"
                             % (", ".join(map(str, outside)), "isn't" if len(outside) == 1 else "aren't", course))
        fixed = re.search(r"^#\s*IDS:\s*(.*)$", text, re.M)
        if fixed:
            want = set()
            for part in re.split(r"[\s,]+", fixed.group(1).strip()):
                r = re.match(r"^(\d+)(?:-(\d+))?$", part)
                if r:
                    lo, hi = int(r.group(1)), int(r.group(2) or r.group(1))
                    want |= {v for v in inv.guests if lo <= v <= hi} if hi - lo <= 1000000 else set()
            bad = sorted(want - in_course)
            if bad:
                raise ValueError("%s: its fixed guest%s %s %s in %s - change the add-on's guests" % (
                    meta["name"], "" if len(bad) == 1 else "s", ", ".join(map(str, bad[:8])) + (" …" if len(bad) > 8 else ""),
                    "isn't" if len(bad) == 1 else "aren't", course))
        if meta["guests"] and not ids:
            raise ValueError("this add-on works on guests - select some first")
        buf = []
        groups.append([step("Run %s%s" % (meta["name"], (" on " + plural_n(len(ids), "guest")) if meta["guests"] else ""), "container",
                            (lambda: run_addon(user, course, full, ids if meta["guests"] else [], buf)), None, buf)])
    else:   # an action with a permission but no plan here would silently do nothing - never again
        raise ValueError("unknown action %s" % a)
    groups = [g for g in groups if g]
    pid = secrets.token_hex(8)
    PLANS[pid] = {"user": user, "title": body.get("title") or a, "groups": groups, "notes": notes,
                  "action": a, "course": course, "at": time.time()}
    return pid


def plural_n(n, word):
    return "%d %s%s" % (n, word, "" if n == 1 else "s")


def plan_view(pid):
    p = PLANS[pid]
    return {"id": pid, "title": p["title"], "notes": p["notes"],
            "groups": [[{"label": s["label"], "node": s["node"]} for s in g] for g in p["groups"]],
            "count": sum(len(g) for g in p["groups"])}


def run_job(jid):
    j = JOBS[jid]
    touched = set()
    with cf.ThreadPoolExecutor(max(1, int(settings()["max_parallel"]))) as ex:
        for gi, grp in enumerate(j["plan"]["groups"]):
            def one(si, s=None):
                s = grp[si]
                st = j["steps"][gi][si]
                st["state"] = "running"
                t0 = time.time()
                try:
                    msg = s["fn"]() or ""
                    st["state"], st["msg"] = "ok", msg
                except Exception as e:   # noqa - show every failure in the GUI
                    st["state"], st["msg"] = "failed", str(e)
                st["secs"] = round(time.time() - t0, 1)
                if s.get("vmid"):
                    touched.add(s["vmid"])
                audit(j["user"], "%s [%s] %s: %s%s" % (j["plan"]["title"], s["node"], s["label"], st["state"],
                                                       (" - " + st["msg"]) if st["msg"] else ""))
            list(ex.map(one, range(len(grp))))
    inv.forget(touched)
    j["state"] = "done"
    j["ended"] = time.time()


def start_job(user, pid):
    p = PLANS.pop(pid, None)
    if not p or p["user"] != user or time.time() - p["at"] > 900:
        raise ValueError("this plan has expired - make it again")
    jid = secrets.token_hex(8)
    inv.hot_until = time.time() + 180
    JOBS[jid] = {"user": user, "plan": p, "state": "running", "started": time.time(),
                 "steps": [[{"label": s["label"], "node": s["node"], "state": "waiting", "msg": "", "secs": 0, "buf": s.get("buf")} for s in g] for g in p["groups"]]}
    audit(user, "run: %s (%s, %d step(s))" % (p["title"], p["course"], sum(len(g) for g in p["groups"])))
    threading.Thread(target=run_job, args=(jid,), daemon=True).start()
    return jid
