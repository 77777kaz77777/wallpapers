"""ICS Ranges - updates (split from server.py; see server.py for the program)."""
import json
import os
import re
import ssl
import time
import urllib.request
from .core import (PVEError, VERSION, audit, load_json, path, save_json)
from .content import (read_text, write_text)


# ---------------------------------------------------------------------------- software updates
# The web page never updates itself: it can't (no Docker access, on purpose). It lists the
# releases of your ics-ranges-app repository and writes an install REQUEST (just a version
# tag) into /updates, a folder shared with the host. The host's updater (./setup.sh updater)
# then downloads that version itself, from the repository pinned on the host, checks it,
# runs ./setup.sh update and goes back to the old version if the new one doesn't start.
UPD = os.environ.get("UPDATES_DIR", "/updates")
TAG_RE = re.compile(r"^v?\d+\.\d+\.\d+(?:[.-][A-Za-z0-9]+)?$")
BUSY = ("requested", "downloading", "checking", "installing", "rolling_back")


def upd_conf():
    c = load_json("update.json", {})
    return c if isinstance(c, dict) else {}


def repo_parts(url):
    """http://gitea:3000/kaz/ics-ranges-app(.git) -> (base, owner, repo)"""
    url = (url or "").strip().rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    m = re.match(r"^(https?://[^/\s]+(?:/[^/\s]+)*)/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$", url)
    if not m:
        raise ValueError("give the repository's address, e.g. http://192.168.77.93:3000/kaz/ics-ranges-app")
    return m.group(1), m.group(2), m.group(3)


def repo_norm(url):
    b, o, r = repo_parts(url)
    return "%s/%s/%s" % (b.lower(), o.lower(), r.lower())


def ver_key(v):
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", v or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def cached_versions():
    """Versions kept on this kit (updates/cache/<tag>, both files) -> the date they were kept."""
    d, out = os.path.join(UPD, "cache"), {}
    try:
        for t in os.listdir(d):
            f = os.path.join(d, t)
            if TAG_RE.match(t) and os.path.isfile(os.path.join(f, "ics-ranges.zip")) and os.path.isfile(os.path.join(f, "ics-ranges.zip.sha256")):
                out[t] = time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(f)))
    except OSError:
        pass
    return out


def changelog_section(text, version):
    """The '## <version>' section of a CHANGELOG.md text ('' if there is none)."""
    m = re.search(r"^## %s[ \t]*\n(.*?)(?=^## |\Z)" % re.escape(version.lstrip("v")), text or "", re.M | re.S)
    return m.group(1).strip() if m else ""


def changelog_notes(tag):
    """What's new in a version: from the kept zip's CHANGELOG.md, else from this version's own."""
    kept = os.path.join(UPD, "cache", tag, "ics-ranges.zip")
    if os.path.isfile(kept):
        try:
            import zipfile
            with zipfile.ZipFile(kept) as z:
                t = changelog_section(z.read("ics-ranges/CHANGELOG.md").decode("utf-8", "replace"), tag)
                if t:
                    return t
        except (OSError, KeyError, zipfile.BadZipFile):
            pass
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # app/, where server.py is
    for f in (os.path.join(here, "CHANGELOG.md"), os.path.join(here, "..", "CHANGELOG.md")):
        t = read_text(f)
        if t:
            return changelog_section(t, tag)
    return ""


def releases_with_cache():
    """The repository's releases, each marked if it is kept on this kit; when the repository can't be
    reached, the kept versions alone - so going back works offline."""
    kept = cached_versions()
    cur = ver_key(VERSION)
    offline = ""
    try:
        rel = fetch_releases()
    except PVEError as e:
        rel, offline = [], str(e)
    for r in rel:
        r["cached"] = r["tag"] in kept
    for t, day in kept.items():   # kept here but not (or no longer) in the repository
        if not any(r["tag"] == t for r in rel):
            k = ver_key(t)
            rel.append({"tag": t, "name": "ICS Ranges %s" % t.lstrip("v"), "notes": "", "date": day, "prerelease": False,
                        "installable": True, "missing": [], "cached": True,
                        "relation": "current" if k == cur else "newer" if k > cur else "older"})
    for r in rel:   # no release notes (or just the title): what's new from the changelog
        if not (r.get("notes") or "").strip() or r["notes"].strip() in (r["tag"], "ICS Ranges %s" % r["tag"].lstrip("v")):
            r["notes"] = changelog_notes(r["tag"])
    rel.sort(key=lambda x: ver_key(x["tag"]), reverse=True)
    return rel, offline


def fetch_releases(c=None, token=None):
    c = c or upd_conf()
    token = token if token is not None else (read_text(path("priv/update-token")) or "").strip()
    base, owner, repo = repo_parts(c.get("url", ""))
    github = re.match(r"^https?://(www\.)?github\.com$", base) or base == os.environ.get("GH_WEB")   # GH_WEB/GH_API: for tests
    api = ("%s/repos/%s/%s/releases?per_page=50" % (os.environ.get("GH_API", "https://api.github.com"), owner, repo)) if github else \
          ("%s/api/v1/repos/%s/%s/releases?limit=50" % (base, owner, repo))
    req = urllib.request.Request(api, headers={"Accept": "application/json", "User-Agent": "ics-ranges"})
    if token:
        req.add_header("Authorization", ("Bearer " if github else "token ") + token)
    ctx = ssl._create_unverified_context() if c.get("insecure") else ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=20, context=ctx if api.startswith("https") else None) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        raise PVEError({401: "the repository refused the token", 403: "the token may not read this repository",
                        404: "no such repository (or the token can't see it)"}.get(e.code, "HTTP %d from the repository" % e.code))
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise PVEError("can't reach the repository: %s" % getattr(e, "reason", e))
    cur = ver_key(VERSION)
    out = []
    for r in data if isinstance(data, list) else []:
        if r.get("draft"):
            continue
        tag = r.get("tag_name") or ""
        if not TAG_RE.match(tag):
            continue
        names = [a.get("name") for a in r.get("assets") or []]
        k = ver_key(tag)
        missing = [n for n in ("ics-ranges.zip", "ics-ranges.zip.sha256") if n not in names]
        out.append({"tag": tag, "name": r.get("name") or tag, "notes": (r.get("body") or "")[:20000],
                    "date": (r.get("published_at") or r.get("created_at") or "")[:10], "prerelease": bool(r.get("prerelease")),
                    "installable": not missing, "missing": missing,
                    "relation": "current" if k == cur else "newer" if k > cur else "older"})
    out.sort(key=lambda x: ver_key(x["tag"]), reverse=True)
    newest = next((x["tag"] for x in out if x["relation"] == "newer" and x["installable"] and not x["prerelease"]), "")
    save_json("update-check.json", {"at": time.strftime("%Y-%m-%d %H:%M"), "newest": newest, "current": VERSION})
    return out


def kv_file(f):
    out = {}
    for line in (read_text(f) or "").splitlines():
        k, _, v = line.partition("=")
        if re.match(r"^[A-Z_]+$", k):
            out[k] = v
    return out


def upd_state():
    info = kv_file(os.path.join(UPD, "updater.info"))
    st = kv_file(os.path.join(UPD, "status"))
    pending = os.path.exists(os.path.join(UPD, "request")) or os.path.exists(os.path.join(UPD, "request.running"))
    log = read_text(os.path.join(UPD, "update.log")) or ""
    c = upd_conf()
    try:
        matches = bool(info.get("REPO")) and bool(c.get("url")) and repo_norm(info["REPO"]) == repo_norm(c["url"])
    except ValueError:
        matches = False
    waiting = 0   # seconds a request has waited for the host to pick it up
    try:
        if st.get("STATE") == "requested" and os.path.exists(os.path.join(UPD, "request")):
            waiting = int(time.time() - os.path.getmtime(os.path.join(UPD, "request")))
    except OSError:
        pass
    return {"installed": bool(info.get("REPO")), "pinned": info.get("REPO", ""), "since": info.get("SINCE", ""), "waiting": waiting,
            "matches": matches, "writable": os.path.isdir(UPD) and os.access(UPD, os.W_OK),
            "state": st.get("STATE", ""), "version": st.get("VERSION", ""), "message": st.get("MESSAGE", ""),
            "at": st.get("AT", ""), "by": st.get("BY", ""), "pending": pending, "log": log[-6000:]}


def write_upd(name, text, mode):
    f = os.path.join(UPD, name)
    tmp = f + ".new"
    with open(tmp, "w") as fh:
        fh.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, f)


def request_install(user, tag):
    if not TAG_RE.match(tag or ""):
        raise ValueError("bad version %s - a tag like v3.1.6 (the versions: pvr update, or Software updates)" % (tag or "(none)"))
    c = upd_conf()
    if not c.get("url"):
        raise ValueError("connect the repository first")
    st = upd_state()
    if not st["writable"]:
        raise ValueError("the host's updater isn't set up - on the host run: sudo ./setup.sh updater")
    if not st["installed"]:
        raise ValueError("the host's updater isn't set up - on the host run: sudo ./setup.sh updater")
    if not st["matches"]:
        raise ValueError("the host only allows updates from %s - run sudo ./setup.sh updater again to allow this repository" % st["pinned"])
    if st["pending"] or (st["state"] in BUSY and st["at"] and time.time() - os.path.getmtime(os.path.join(UPD, "status")) < 1800):
        raise ValueError("an update is already running")
    if tag in cached_versions():   # kept on this kit - no repository needed
        rel = {"tag": tag, "name": "ICS Ranges %s" % tag.lstrip("v"), "installable": True, "missing": [], "cached": True}
    else:
        rel = next((r for r in fetch_releases(c) if r["tag"] == tag), None)
    if not rel:
        raise KeyError("no release %s in the repository" % tag)
    if not rel["installable"]:
        raise ValueError("release %s is missing %s - attach it in Gitea, or run ./release.sh publish %s"
                         % (tag, " and ".join(rel["missing"]), tag))
    token = (read_text(path("priv/update-token")) or "").strip()
    write_upd("request.token", "%s:%s\n" % (c.get("user", ""), token), 0o600)
    write_upd("status", "STATE=requested\nVERSION=%s\nMESSAGE=Waiting for the host's updater\nAT=%s\nBY=%s\n"
              % (tag, time.strftime("%Y-%m-%dT%H:%M:%S"), user), 0o644)
    write_upd("request", "TAG=%s\nBY=%s\n" % (tag, user), 0o644)   # last - the host starts on this file
    audit(user, "software update to %s requested (now %s)" % (tag, VERSION))
    return rel


def update_connect(who, url, user, token, insecure):
    """Connect Software updates to a repository - tested before anything is saved."""
    url = (url or "").strip()
    repo_parts(url)
    user = (user or "").strip()
    if not re.match(r"^[A-Za-z0-9_.@-]{1,64}$", user):
        raise ValueError("give the user name on the repository server")
    token = (token or "").strip() or (read_text(path("priv/update-token")) or "").strip()
    if not re.match(r"^[A-Za-z0-9_-]{8,200}$", token):
        raise ValueError("give a read-only token for the repository")
    c = {"url": url.rstrip("/").removesuffix(".git"), "user": user, "insecure": bool(insecure)}
    rel = fetch_releases(c, token)
    save_json("update.json", c)
    os.makedirs(path("priv"), exist_ok=True)
    write_text(path("priv/update-token"), token + "\n", 0o600)
    audit(who, "software repository: %s" % c["url"])
    return rel


def host_command():   # the one line to run on the host, with this page's repository filled in
    c = upd_conf()
    return "sudo ./setup.sh updater" + (" --repo %s" % c["url"] if c.get("url") else "") + (" --insecure" if c.get("insecure") else "")


def update_checker():   # in the background: is there a newer version? (for the side bar)
    while True:
        time.sleep(30)
        try:
            if upd_conf().get("url"):
                fetch_releases()
        except Exception:   # noqa - offline kits are normal
            pass
        time.sleep(6 * 3600)
