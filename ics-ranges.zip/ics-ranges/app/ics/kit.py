"""ControlYard - kit (split from server.py; see server.py for the program)."""
import io
import json
import os
import shutil
import subprocess
import tarfile
import time
from .core import (DATA, LOCK, SESSIONS, VERSION, _MAP_CACHE, audit, path, sessions_save, users)


# ---------------------------------------------------------------------------- kit export / import
# One encrypted file with everything that makes up a kit: users (with passwords and 2FA), roles,
# settings, course map, mixed courses, mirrors, groups, themes, class guides, add-ons, history,
# the activity log, the HTTPS certificate, the node key - and the Proxmox settings.
KIT_SKIP = ("backups", "inventory-cache.json", "priv/sessions.json", ".kit-import")
KIT_ENV = ("PVE_API_URL", "PVE_API_TOKEN", "KEY_FROM", "PORT", "MAX_PARALLEL", "SHUTDOWN_TIMEOUT", "SESSION_IDLE")


def _crypt(data, password, decrypt=False):
    if len(password or "") < 10:
        raise ValueError("the kit password must have at least 10 characters")
    cmd = ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000", "-salt", "-pass", "env:KIT_PASSWORD"] + (["-d"] if decrypt else [])
    p = subprocess.run(cmd, input=data, capture_output=True, env=dict(os.environ, KIT_PASSWORD=password), timeout=300)
    if p.returncode:
        raise ValueError("wrong password, or not an ControlYard kit file" if decrypt else "encrypting failed: %s" % p.stderr.decode(errors="replace")[:200])
    return p.stdout


def kit_export(password, who):
    buf = io.BytesIO()
    man = {"kind": "controlyard-kit", "format": 1, "version": VERSION, "made": time.strftime("%Y-%m-%d %H:%M"), "by": who,
           "env": {k: os.environ[k] for k in KIT_ENV if os.environ.get(k)}, "users": sorted(users())}
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        b = json.dumps(man, indent=2).encode()
        ti = tarfile.TarInfo("kit.json")
        ti.size, ti.mtime = len(b), int(time.time())
        tf.addfile(ti, io.BytesIO(b))
        for root, dirs, files in os.walk(DATA):
            rel = os.path.relpath(root, DATA)
            dirs[:] = [d for d in dirs if os.path.normpath(os.path.join(rel, d)) not in KIT_SKIP]
            for f in files:
                r = os.path.normpath(os.path.join(rel, f))
                if r not in KIT_SKIP and not r.startswith(KIT_SKIP):
                    tf.add(os.path.join(root, f), arcname="data/" + r)
    audit(who, "kit exported")
    return _crypt(buf.getvalue(), password)


def kit_open(blob, password):
    """Decrypt and check a kit file - returns (manifest, tarfile)."""
    tf = tarfile.open(fileobj=io.BytesIO(_crypt(blob, password, decrypt=True)), mode="r:gz")
    try:
        man = json.load(tf.extractfile("kit.json"))
    except (KeyError, ValueError):
        raise ValueError("that isn't an ControlYard kit file")
    if man.get("kind") not in ("controlyard-kit", "ics-ranges-kit"):   # kit files from before the rename too
        raise ValueError("that isn't an ControlYard kit file")
    for m in tf.getmembers():   # only plain files and folders, all under data/ - nothing can land elsewhere
        if m.name == "kit.json":
            continue
        n = os.path.normpath(m.name)
        if not (m.isfile() or m.isdir()) or os.path.isabs(n) or n.startswith("..") or not n.startswith("data"):
            raise ValueError("the kit file contains something unexpected: %s" % m.name)
    return man, tf


def kit_import(blob, password, who):
    man, tf = kit_open(blob, password)
    # first a kit file of what is here now (same password) - an import can be undone
    os.makedirs(path("backups"), exist_ok=True)
    before = path("backups/kit-before-import-%s.icskit" % time.strftime("%Y%m%d-%H%M%S"))
    with open(before, "wb") as f:
        f.write(kit_export(password, who))
    tmp = path(".kit-import")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    with LOCK:
        for m in tf.getmembers():
            if m.name == "kit.json":
                continue
            dst = os.path.join(tmp, os.path.relpath(os.path.normpath(m.name), "data"))
            if m.isdir():
                os.makedirs(dst, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with tf.extractfile(m) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
                os.chmod(dst, m.mode & 0o700 | 0o600 if "priv" in m.name or "ssh" in m.name or "tls/key" in m.name else 0o640)
        for item in os.listdir(DATA):   # replace everything except the backups (and the kit just made)
            if item in ("backups", ".kit-import"):
                continue
            pth = os.path.join(DATA, item)
            shutil.rmtree(pth) if os.path.isdir(pth) and not os.path.islink(pth) else os.remove(pth)
        for item in os.listdir(tmp):
            shutil.move(os.path.join(tmp, item), os.path.join(DATA, item))
        shutil.rmtree(tmp, ignore_errors=True)
        SESSIONS.clear()   # the users may be different now - everyone signs in again
        sessions_save(True)
        _MAP_CACHE["key"] = None
    audit(who, "kit imported (made %s by %s, version %s); the state before is in %s" % (man.get("made"), man.get("by"), man.get("version"), os.path.basename(before)))
    return man, os.path.basename(before)
