"""ICS Ranges - content (split from server.py; see server.py for the program)."""
import os
import re
import ssl
import urllib.request
from .core import (DATA)


# ---------------------------------------------------------------------------- shared files: class guides, add-ons
SHARE = os.path.join(DATA, "share")
GUIDES = os.path.join(SHARE, "guides")
ADDONS = os.path.join(SHARE, "addons")
MIRRORING = os.path.join(SHARE, "mirroring")   # mirror add-ons: one JSON file each
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
ADDON_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\.sh$")   # starts with a letter or digit - no hidden files


COURSE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$")   # starts with a letter or digit - never "." or ".."


def field(self, method, b, key, kind):
    """A save must be a PUT that names what it saves - a missing field never wipes anything."""
    if method != "PUT":
        raise ValueError("use PUT to save")
    v = b.get(key)
    if not isinstance(v, kind):
        raise ValueError("bad request - %s is missing" % key)
    return v


def guide_file(course):
    if not COURSE_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(GUIDES, course + ".md")


def read_text(f):
    try:
        with open(f, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def write_text(f, text, mode=0o640):
    os.makedirs(os.path.dirname(f), exist_ok=True)
    tmp = f + ".new"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, f)


def fetch_url(url, limit=1_000_000):
    """Import a guide or add-on from a web address (GitHub / Gitea raw files)."""
    if not re.match(r"^https?://[^\s]+$", url or ""):
        raise ValueError("give a web address starting with https://")
    url = re.sub(r"^(https://github\.com/[^/]+/[^/]+)/blob/", r"\1/raw/", url)   # GitHub page -> raw file
    url = re.sub(r"^(https?://[^/]+/[^/]+/[^/]+)/src/branch/", r"\1/raw/branch/", url)   # Gitea page -> raw file
    req = urllib.request.Request(url, headers={"User-Agent": "ics-ranges"})
    try:
        with urllib.request.urlopen(req, timeout=20, context=ssl.create_default_context()) as r:
            data = r.read(limit + 1)
    except (urllib.error.URLError, OSError) as e:
        raise ValueError("couldn't download it: %s" % e)
    if len(data) > limit:
        raise ValueError("that file is larger than 1 MB")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("that isn't a text file")


def addon_dir(course):
    if course != "_all" and not COURSE_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(ADDONS, course)


def addon_meta(text, fname):
    meta = {"name": fname[:-3], "desc": "", "guests": False, "kind": "vm", "button": False, "node": ""}
    for line in (text or "").splitlines()[:30]:
        m = re.match(r"^#\s*(NAME|DESC|GUESTS|KIND|BUTTON|NODE):\s*(.*)$", line.rstrip("\r"))
        if m:
            k, v = m.group(1), m.group(2).strip()
            if k == "NAME":
                meta["name"] = v
            elif k == "DESC":
                meta["desc"] = v
            elif k == "KIND":
                meta["kind"] = "host" if v.lower() == "host" else "vm"
            elif k == "BUTTON":
                meta["button"] = v.lower() in ("yes", "1", "true")
            elif k == "NODE":
                meta["node"] = v if re.match(r"^[A-Za-z0-9_.-]{1,32}$", v) else ""
            else:
                meta["guests"] = v.lower() in ("yes", "1", "true")
    if meta["kind"] == "host":
        meta["guests"] = False
    return meta


def list_addons(course):
    out = []
    for d in ("_all", course):
        p = addon_dir(d)
        try:
            names = sorted(os.listdir(p))
        except OSError:
            continue
        for f in names:
            if ADDON_RE.match(f):
                meta = addon_meta(read_text(os.path.join(p, f)), f)
                meta.update({"file": f, "scope": d})
                out.append(meta)
    return out


ADDON_TEMPLATE = """#!/usr/bin/env bash
# NAME: My add-on
# DESC: What it does, in one line
# GUESTS: yes
#
# Runs inside ICS Ranges with the Proxmox API. You can use:
#   $GUESTS   the VMIDs picked in the GUI (if GUESTS: yes), e.g. "510101 510102"
#   $COURSE   the course in use
#   qm, pct, pvesh   work as on a node, through the API
#   qm enroll-efi-keys <vmid>   works too, with the node key (Settings, Node key)
for id in $GUESTS; do
    echo "== $id"
    qm status "$id" 2>/dev/null || pct status "$id"
done
"""


