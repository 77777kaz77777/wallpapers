"""ICS Ranges - readiness (split from server.py; see server.py for the program)."""
import time
from .core import (PVEError, inv, pve)
from .netops import (DISK_RE, net_summary)
from .mirrors import (madd_view)
from . import truenas


# ---------------------------------------------------------------------------- readiness check
_STORE = {}   # node -> (time, [storages with used / total])


def node_storage(node):
    t, lst = _STORE.get(node, (0, None))
    if lst is None or time.time() - t > 60:
        lst = pve.call("GET", "/nodes/%s/storage" % node, timeout=8) or []
        _STORE[node] = (time.time(), lst)
    return lst


def readiness(course, snap):
    """Is the course ready for class? A list of checks - ok / warn / fail / info - each with the guests it found."""
    checks = []

    def add(state, title, detail="", items=None, fix=""):
        checks.append({"state": state, "title": title, "detail": detail, "items": items or [], "fix": fix})
    G = inv.guests
    if inv.offline:
        add("fail", "Proxmox answers", "It isn't answering since %s - nothing can be checked or started" % inv.offline["since"],
            fix="Check that the Proxmox nodes are on and reachable from the ICS Ranges host")
        return checks
    ids = inv.course_ids(course)
    if not ids:
        add("fail", "Guests", "This course has no guests")
        return checks
    lbl = lambda v: "%d %s" % (v, G[v]["name"])   # noqa
    add("ok", "Proxmox answers", "%d node(s) online: %s" % (len(inv.nodes), ", ".join(inv.nodes)))
    gone = sorted({G[v]["node"] for v in ids} - set(inv.nodes))
    if gone:
        add("fail", "Nodes", "Guests are on node(s) that aren't online: " + ", ".join(gone),
            [lbl(v) for v in ids if G[v]["node"] in gone], "Start the node, or migrate its guests")
    snaps = inv.snapshots(ids, max_age=60)
    missing = [v for v in ids if not any(x["name"] == snap for x in snaps.get(v, []))]
    if missing:
        add("fail" if len(missing) > len(ids) // 2 else "warn", "Class snapshot %s" % snap,
            "%d of %d guests don't have it - Start / End class can't reset them" % (len(missing), len(ids)),
            [lbl(v) for v in missing], "Take %s on these guests (Snapshots… → Take a new snapshot), or leave them out of the class" % snap)
    else:
        add("ok", "Class snapshot %s" % snap, "All %d guests have it" % len(ids))
    times = [x.get("time") or 0 for v in ids for x in snaps.get(v, []) if x["name"] == snap and x.get("time")]
    if times and max(times) - min(times) > 7 * 86400:
        old = [v for v in ids for x in snaps.get(v, []) if x["name"] == snap and (x.get("time") or 0) < max(times) - 7 * 86400]
        add("warn", "Snapshot age", "%s was taken at different times - %d guest(s) have a copy more than a week older than the newest"
            % (snap, len(old)), [lbl(v) + " (" + time.strftime("%Y-%m-%d", time.localtime(min(x.get("time") or 0 for x in snaps[v] if x["name"] == snap))) + ")" for v in old],
            "Usually fine - check these guests have the same lab state")
    cfgs = inv.configs(ids)
    locked = [(v, cfgs[v]["lock"]) for v in ids if cfgs.get(v, {}).get("lock")]
    if locked:
        add("fail", "Locked guests", "%d guest(s) are locked - they can't be started, stopped or restored" % len(locked),
            ["%s - locked: %s" % (lbl(v), why) for v, why in locked],
            "Usually a backup or snapshot is still running - wait for it. A stuck lock: on the node, qm unlock <vmid>")
    else:
        add("ok", "Locked guests", "None")
    # storage the course's disks are on
    used = {}
    for v in ids:
        for k, val in cfgs.get(v, {}).items():
            if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]:
                used.setdefault((G[v]["node"], val.split(":")[0]), []).append(v)
    full = []
    for (node, st), vs in sorted(used.items()):
        try:
            info = next((x for x in node_storage(node) if x.get("storage") == st), None)
        except PVEError:
            info = None
        if info and info.get("total"):
            frac = info.get("used", 0) / info["total"]
            if frac >= 0.85:
                full.append(("fail" if frac >= 0.95 else "warn", "%s on %s: %d%% used, %d GiB free (%d guest(s) of this course)"
                             % (st, node, frac * 100, info.get("avail", 0) >> 30, len(set(vs)))))
    if full:
        add("fail" if any(x[0] == "fail" for x in full) else "warn", "Storage", "Nearly full - snapshots and restores may fail",
            [x[1] for x in full], "Delete old snapshots or move disks to another storage (Network, disks & more… → Move / convert disks)")
    else:
        add("ok", "Storage", "The storages of this course have room (%d checked)" % len(used))
    ns = net_summary(course)
    if ns["disconnected"]:
        add("warn", "Network", "%d NIC(s) are disconnected - those guests can't talk on that network" % len(ns["disconnected"]),
            ["%d %s %s on %s" % (d["vmid"], d["name"], d["nic"], d["bridge"]) for d in ns["disconnected"]],
            "If that isn't on purpose: the Network tab → Connect them…")
    else:
        add("ok", "Network", "All %d NIC(s) connected" % ns["nics"])
    run = [v for v in ids if G[v]["status"] == "running"]
    add("info", "Running now", "%d of %d guests are running%s" % (len(run), len(ids), " - before class they are usually off (End class)" if run else ""),
        [lbl(v) for v in run][:30])
    # TrueNAS (if set up): pools and alerts - the course's disks may live there
    tn = truenas.health()
    if tn.get("configured"):
        if not tn.get("reachable"):
            add("fail", "TrueNAS", "Can't be read: %s" % tn.get("error", "?"), [], "Settings → TrueNAS → Test")
        else:
            bad_pools = ["%s: %s%s" % (p["name"], p["status"], ", %s%% used" % p["used_pct"] if p["used_pct"] is not None else "") for p in tn["pools"] if p["state"] != "ok"]
            items = bad_pools + ["%s: %s" % (a["level"], a["text"]) for a in tn["alerts"]]
            if tn["state"] == "ok":
                add("ok", "TrueNAS", "%d pool(s) healthy, no alerts (%s)" % (len(tn["pools"]), tn.get("hostname") or "TrueNAS"))
            else:
                add(tn["state"], "TrueNAS", "%d pool(s) not healthy or nearly full, %d alert(s)" % (len(bad_pools), len(tn["alerts"])), items,
                    "Look at TrueNAS (Storage, Alerts) – a degraded pool or a full one can stop the class's disks")
    # mirror add-ons (sensors)
    act = [m for m in madd_view(course) if m.get("active")]
    if act:
        bad = [m["name"] + " - " + m["status"]["text"] for m in act if m["status"]["state"] in ("problem", "unknown")]
        quiet = [m["name"] + " - " + m["status"]["text"] for m in act if m["status"]["state"] == "warn"]
        if bad:
            add("warn", "Mirrors", "%d of %d active mirror add-on(s) don't deliver the copy" % (len(bad), len(act)), bad + quiet,
                "Start the sensors, then press Activate on each (or Re-activate all) in the Add-ons panel")
        else:
            add("ok", "Mirrors", "All %d active mirror add-on(s) are in place%s" % (len(act), " (some see no traffic right now)" if quiet else ""), quiet)
    return checks
