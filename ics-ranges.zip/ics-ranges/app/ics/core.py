"""ControlYard - core (split from server.py; see server.py for the program)."""
import base64
import concurrent.futures as cf
import hashlib
import hmac
import json
import os
import re
import secrets
import ssl
import struct
import sys
import threading
import time
import urllib.request


def _read_version():   # the version lives in server.py - the updater reads it there
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "server.py")) as f:
        return re.search(r'^VERSION = "([^"]+)"', f.read(), re.M).group(1)


VERSION = _read_version()
DATA = os.environ.get("DATA_DIR", "/data")
STATIC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")   # app/static
PORT = int(os.environ.get("PORT", "8443"))
API_URLS = [u.rstrip("/") for u in os.environ.get("PVE_API_URL", "").replace(",", " ").split() if u]
API_TOKEN = os.environ.get("PVE_API_TOKEN", "")
PARALLEL = int(os.environ.get("MAX_PARALLEL", "8"))
SHUTDOWN_TIMEOUT = int(os.environ.get("SHUTDOWN_TIMEOUT", "180"))
IDLE = int(os.environ.get("SESSION_IDLE", "900"))
OVS_KEY = os.path.join(DATA, "ssh", "ovs_ed25519")

PERMS = {   # what each one really unlocks - shown on the Roles page
    "class_run": "Start / End class and Ready for class? – also reads class guides, runs add-on buttons and switches mirrors on and off",
    "power": "Power ticked guests on and off",
    "snap_take": "Take snapshots",
    "snap_restore": "Restore snapshots – Start class then restores first, End class resets",
    "snap_delete": "Delete snapshots",
    "mirror_status": "See the Add-ons panel and whether mirrors deliver (Check traffic)",
    "mirror_apply": "Activate / Deactivate mirrors and Re-activate all (comes with Start / End class too)",
    "mirror_setup": "Make and change mirror add-ons (Add-ons → Port mirroring)",
    "guide_read": "Read class guides (comes with Start / End class too)",
    "guide_edit": "Write and edit class guides",
    "addons_run": "Run any add-on – Run an add-on… on ticked guests (buttons come with Start / End class)",
    "addons_edit": "Make and change VM and host add-ons (Add-ons tab)",
    "overview": "Ready for class? and the Storage and disks tab",
    "network": "Network tab – firewall, connected, VLAN – and moving NICs / NIC model",
    "disks": "Move and convert disks",
    "migrate": "Migrate guests to another node",
    "efi": "Enroll EFI keys (Secure Boot)",
    "save": "Save & share and the automatic backups",
    "software": "Software updates (install other ControlYard versions)",
    "users": "Manage users",
    "settings": "Settings (with TrueNAS and the node key), roles, course map, groups, themes",
}
DEFAULT_ROLES = {
    "instructor": ["class_run", "power", "mirror_status", "mirror_apply"],
    "viewer": ["overview", "mirror_status", "guide_read"],
}
DEFAULT_MAP = """\
folder 10 Mgmt      Management
folder 40 SANS      SANS
folder 50 612       ICS612
folder 51 613       ICS613
folder 52 NetWars   NetWars
folder 53 727       ICS727

# SANS (40BCDD) - B = rack number
bname  40 Rack
module 40 0 Rack Services
sub    40 0 Network
sub    40 1 Servers
sub    40 2 Clients

# 612 (50BCDD) - B = version, C = system
sub 50 0 Services
sub 50 1 Lvl 3 Servers
sub 50 2 Lvl 3 EWS
sub 50 3 Lvl 3 OWS
sub 50 6 NSM
sub 50 5 iDMZ - Jump Hosts
sub 50 4 iDMZ - File Servers

# 613 (51BCDD) - B = version, C = system
sub 51 0 Services
sub 51 1 Enterprise Servers
sub 51 2 ICS Servers
sub 51 3 ABB Servers
sub 51 4 Enterprise Clients
sub 51 5 iDMZ Jump Hosts
sub 51 6 EWS Clients
sub 51 7 ABB Clients

# NetWars (52BCDD) - B = module, C = group inside the module
module 52 0 Mgmt
module 52 1 Grid
module 52 2 Cookie
module 52 3 Injection
module 52 4 Crane
module 52 5 Qatar
msub   52 1 0 Servers
msub   52 1 1 Clients - Level 3
msub   52 1 2 Clients - Level 4
msub   52 2 0 Servers
msub   52 2 1 Clients - Level 4

# 727 (53BCDD) - B = version, C = system
sub 53 0 Services
sub 53 1 Dragos Servers
sub 53 2 EWS Clients
"""
LOCK = threading.RLock()


# ---------------------------------------------------------------------------- files
def path(name):
    return os.path.join(DATA, name)


def load_json(name, default):
    try:
        with open(path(name)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, value):
    tmp = path(name + ".new")
    with open(tmp, "w") as f:
        json.dump(value, f, indent=2, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path(name))


def audit(user, text):
    line = "%s  %-14s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), user or "-", text)
    with LOCK:
        try:   # keep it from growing forever: past 5 MB it becomes audit.log.1 (the one before is dropped)
            if os.path.getsize(path("audit.log")) > 5 * 1024 * 1024:
                os.replace(path("audit.log"), path("audit.log.1"))
        except OSError:
            pass
        with open(path("audit.log"), "a") as f:
            f.write(line)


# ---------------------------------------------------------------------------- Proxmox API
class PVEError(Exception):
    pass


class PVE:
    def __init__(self):
        ca = path("pve-root-ca.pem")
        if os.path.exists(ca):
            self.ctx = ssl.create_default_context(cafile=ca)
            self.ctx.check_hostname = False
        else:   # the nodes' own self-signed certificate
            self.ctx = ssl._create_unverified_context()
        self.good = 0

    def call(self, method, api_path, params=None, timeout=20):
        if not API_URLS or not API_TOKEN:
            raise PVEError("PVE_API_URL and PVE_API_TOKEN must be set in .env")
        params = {k: v for k, v in (params or {}).items() if v is not None}
        body = None
        query = ""
        if method == "GET":
            query = ("?" + urllib.parse.urlencode(params)) if params else ""
        else:
            body = urllib.parse.urlencode(params).encode()
        last = None
        order = API_URLS[self.good:] + API_URLS[:self.good]
        for url in order:
            req = urllib.request.Request(url + "/api2/json" + api_path + query, data=body, method=method)
            req.add_header("Authorization", "PVEAPIToken=" + API_TOKEN)
            if body is not None:
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=self.ctx if url.startswith("https") else None) as r:
                    self.good = API_URLS.index(url)
                    return json.load(r).get("data")
            except urllib.error.HTTPError as e:   # Proxmox answered - no point trying another node
                detail = ""
                try:
                    j = json.loads(e.read() or b"{}")
                    detail = "; ".join("%s: %s" % kv for kv in (j.get("errors") or {}).items())
                except ValueError:
                    pass
                raise PVEError("%s %s -> HTTP %s %s%s" % (method, api_path, e.code, e.reason, (" (" + detail + ")") if detail else ""))
            except (urllib.error.URLError, OSError) as e:
                last = e
        raise PVEError("can't reach the Proxmox API (%s): %s" % (" ".join(API_URLS), last))

    def wait(self, upid):
        node = upid.split(":")[1]
        q = urllib.parse.quote(upid, safe="")
        polls = 0
        while True:
            st = self.call("GET", "/nodes/%s/tasks/%s/status" % (node, q))
            if st.get("status") == "stopped":
                break
            polls += 1
            time.sleep(0.25 if polls <= 8 else 1)
        es = st.get("exitstatus") or ""
        if es == "OK" or es.startswith("WARNINGS"):
            return "" if es == "OK" else es
        log = self.call("GET", "/nodes/%s/tasks/%s/log" % (node, q), {"limit": 500}) or []
        tail = " / ".join(x.get("t", "") for x in log[-4:])
        raise PVEError("task failed: %s%s" % (es or "unknown", (" - " + tail) if tail else ""))

    def task(self, method, api_path, params=None):
        r = self.call(method, api_path, params)
        if isinstance(r, str) and r.startswith("UPID:"):
            return self.wait(r)
        return ""


pve = PVE()


# ---------------------------------------------------------------------------- VMID map
_MAP_CACHE = {"key": None, "val": None}


def load_map():
    try:
        key = os.stat(path("vmid-map.conf")).st_mtime_ns
    except OSError:
        key = "default"
    if _MAP_CACHE["key"] == key:
        return _MAP_CACHE["val"]
    _MAP_CACHE["val"] = _parse_map()
    _MAP_CACHE["key"] = key
    return _MAP_CACHE["val"]


def _parse_map():
    text = ""
    try:
        with open(path("vmid-map.conf")) as f:
            text = f.read()
    except OSError:
        text = DEFAULT_MAP
    return _parse_map_text(text)


def _parse_map_text(text):
    # folder AA NAME desc | module AA B name | sub AA C name | msub AA B C name (one module only)
    # bname AA word (what an unnamed B is called, e.g. Rack -> "Rack 2"; default: version "v2")
    m = {"folder": {}, "desc": {}, "sub": {}, "module": {}, "msub": {}, "bname": {}}
    for line in text.splitlines():
        p = line.split("#", 1)[0].split()
        if len(p) >= 3 and p[0] == "folder" and p[1].isdigit():
            m["folder"][int(p[1])] = p[2]
            m["desc"][int(p[1])] = " ".join(p[3:])
        elif len(p) >= 4 and p[0] in ("sub", "module") and p[1].isdigit() and p[2].isdigit():
            m[p[0]][(int(p[1]), int(p[2]))] = " ".join(p[3:])
        elif len(p) >= 5 and p[0] == "msub" and p[1].isdigit() and p[2].isdigit() and p[3].isdigit():
            m["msub"][(int(p[1]), int(p[2]), int(p[3]))] = " ".join(p[4:])
        elif len(p) >= 3 and p[0] == "bname" and p[1].isdigit():
            m["bname"][int(p[1])] = " ".join(p[2:])
    return m, text


def course_of(vmid, m):   # None: the map has no course for it (shown on the Course map page)
    if vmid < 100000:
        return "Management"
    return m["folder"].get(vmid // 10000)


def courses_for(s):   # the courses this user may open, with guest counts (Management first, mixed last)
    allow = allowed_courses(s["u"])
    m, _ = load_map()
    out = {}
    for g in inv.guests.values():
        c = g["course"]
        if c is None or (allow is not None and c not in allow):
            continue
        o = out.setdefault(c, {"name": c, "count": 0, "running": 0})
        o["count"] += 1
        o["running"] += g["status"] == "running"
    order = {v: k for k, v in m["folder"].items()}
    for c in out.values():
        aa = order.get(c["name"])
        c["desc"] = m["desc"].get(aa, "VMID below 100000" if c["name"] == "Management" else "")
        c["order"] = -1 if c["name"] == "Management" else (aa if aa is not None else 1000)
    for name, mc in mixed_active().items():
        if allow is not None and name not in allow:
            continue
        ids = [v for v in set(mc.get("vmids", [])) if v in inv.guests]
        out[name] = {"name": name, "count": len(ids), "running": sum(inv.guests[v]["status"] == "running" for v in ids),
                     "desc": mc.get("desc") or ("One-shot until %s" % mc["expires"] if mc.get("expires") else "Mixed course"),
                     "order": 2000, "mixed": True, "expires": mc.get("expires", "")}
    return sorted(out.values(), key=lambda c: (c["order"], c["name"]))


# ---------------------------------------------------------------------------- mixed courses
# Guests picked from any courses, as a course of their own - kept, or one-shot until a date.
def mixed_courses():
    c = load_json("courses.json", {})
    return c if isinstance(c, dict) else {}


def mixed_active():
    today = time.strftime("%Y-%m-%d")
    return {n: c for n, c in mixed_courses().items() if not c.get("expires") or c["expires"] >= today}


def _bpart(aa, b, m):   # the B digit as a name: a module / rack name, "Rack 2", or the version "v2"
    if (aa, b) in m["module"]:
        return m["module"][(aa, b)]
    if aa in m["bname"]:
        return "%s %d" % (m["bname"][aa], b)
    if any(k[0] == aa for k in m["module"]):
        return "Module %d" % b
    return "v%d" % b


def _named_b(aa, m):   # B is a module / rack / sub-group, not a version
    return aa in m["bname"] or any(k[0] == aa for k in m["module"])


def _sub(aa, b, c, m):
    return m["msub"].get((aa, b, c)) or m["sub"].get((aa, c)) or "Group %d" % c


def label_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa, b, c, dd = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10, vmid % 100
    return "%s %s %s #%02d" % (m["folder"].get(aa, str(aa)), _bpart(aa, b, m), _sub(aa, b, c, m), dd)


def group_of(vmid, m):   # the sub-group heading the GUI groups guests under
    if vmid < 100000:
        return "Management"
    aa, b, c = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10
    if _named_b(aa, m):
        return "%s - %s" % (_bpart(aa, b, m), _sub(aa, b, c, m))
    return _sub(aa, b, c, m)


# ---------------------------------------------------------------------------- inventory
class Inventory:
    def __init__(self):
        self.lock = threading.Lock()
        self.res_at = 0
        self.guests = {}
        self.nodes = []
        self.snaps = {}       # vmid -> (time, [ {name, ram} ])
        self.cfgs = {}        # vmid -> (time, {config})
        self.hot_until = 0    # right after an action: also read each node, the overview can lag
        self.offline = None   # {"error", "since"} while Proxmox doesn't answer
        self.retrying = False
        self.saved_at = 0

    def refresh(self, force=False):
        if self.offline and not force:
            # Proxmox isn't answering: serve what we know at once, and try again in the
            # background now and then - no page waits for a server that is off
            if not self.retrying and time.time() - self.res_at > 15:
                self.retrying = True
                threading.Thread(target=self._retry, daemon=True).start()
            return
        with self.lock:
            if not force and time.time() - self.res_at < 3:
                return
            self._read(force)

    def _retry(self):
        try:
            with self.lock:
                self._read()
        finally:
            self.retrying = False

    def _went_offline(self, e):
        if not self.offline:
            self.offline = {"error": str(e), "since": time.strftime("%H:%M")}
            sys.stderr.write("Proxmox isn't answering: %s\n" % e)
        if not self.guests:   # just started: show the last known guests, state unknown
            c = load_json("inventory-cache.json", {})
            self.guests = {int(k): dict(g, status="unknown") for k, g in (c.get("guests") or {}).items()}
            self.offline["cache"] = c.get("at", "")
        self.nodes = []
        self.res_at = time.time()

    def _read(self, force=False):
        try:
            res = pve.call("GET", "/cluster/resources", timeout=8)
        except PVEError as e:
            return self._went_offline(e)
        m, _ = load_map()
        guests, nodes = {}, []
        prot = protected_ids()
        for r in res:
            if r.get("type") in ("qemu", "lxc") and int(r.get("vmid", 0)) in prot:
                continue
            if r.get("type") == "node" and r.get("status") == "online":
                nodes.append(r["node"])
            elif r.get("type") in ("qemu", "lxc") and not r.get("template"):
                v = int(r["vmid"])
                guests[v] = {
                    "vmid": v, "type": r["type"], "node": r["node"], "name": r.get("name") or "-",
                    "status": r.get("status", "unknown"),
                    "tags": [t for t in (r.get("tags") or "").replace(",", ";").split(";") if t],
                    "course": course_of(v, m), "label": label_of(v, m), "group": group_of(v, m),
                }
        # the live state - only right after an action (or when asked): the cluster
        # overview can lag a few seconds then; otherwise it is enough (1 call, not 1 + 2 per node)
        def live(n_t):
            n, t = n_t
            try:
                return pve.call("GET", "/nodes/%s/%s" % (n, t)) or []
            except PVEError:
                return []
        hot = force or time.time() < self.hot_until
        with cf.ThreadPoolExecutor(8) as ex:
            for lst in ex.map(live, [(n, t) for n in nodes for t in ("qemu", "lxc")] if hot else []):
                for g in lst:
                    v = int(g["vmid"])
                    if v in guests:
                        guests[v]["status"] = g.get("status", guests[v]["status"])
        if self.offline:
            sys.stderr.write("Proxmox answers again\n")
        self.guests, self.nodes, self.res_at, self.offline = guests, sorted(nodes), time.time(), None
        if time.time() - self.saved_at > 60:   # the last known guests, for when Proxmox is off
            self.saved_at = time.time()
            try:
                save_json("inventory-cache.json", {"at": time.strftime("%Y-%m-%d %H:%M"), "guests": {str(k): v for k, v in guests.items()}})
            except OSError:
                pass

    def forget(self, ids):
        for v in ids:   # read them again next time - but keep what we knew, in case Proxmox goes away
            if v in self.snaps:
                self.snaps[v] = (0, self.snaps[v][1])
            self.cfgs.pop(v, None)
        self.res_at = 0
        self.hot_until = time.time() + 120

    def _snap(self, v):
        g = self.guests[v]
        try:
            lst = pve.call("GET", "/nodes/%s/%s/%d/snapshot" % (g["node"], g["type"], v), timeout=8) or []
        except PVEError:
            if v in self.snaps:   # keep what we knew - don't make the snapshots vanish
                self.snaps[v] = (time.time(), self.snaps[v][1])
                return
            lst = []
        out = [{"name": s["name"], "ram": bool(s.get("vmstate")), "time": s.get("snaptime", 0)}
               for s in lst if s.get("name") != "current"]
        out.sort(key=lambda s: s["time"])
        self.snaps[v] = (time.time(), out)

    def snapshots(self, ids, max_age=300):
        need = [v for v in ids if v in self.guests and (v not in self.snaps or time.time() - self.snaps[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(32) as ex:
                list(ex.map(self._snap, need))
        return {v: self.snaps.get(v, (0, []))[1] for v in ids}

    def _cfg(self, v):
        g = self.guests[v]
        try:
            self.cfgs[v] = (time.time(), pve.call("GET", "/nodes/%s/%s/%d/config" % (g["node"], g["type"], v)) or {})
        except PVEError:
            self.cfgs[v] = (time.time(), {})

    def configs(self, ids, max_age=120):
        need = [v for v in ids if v in self.guests and (v not in self.cfgs or time.time() - self.cfgs[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(32) as ex:
                list(ex.map(self._cfg, need))
        return {v: self.cfgs.get(v, (0, {}))[1] for v in ids}

    def course_ids(self, course):
        prot = protected_ids()
        mixed = mixed_active().get(course)
        if mixed is not None:
            return sorted(v for v in set(mixed.get("vmids", [])) if v in self.guests and v not in prot)
        return sorted(v for v, g in self.guests.items() if g["course"] == course and v not in prot)


inv = Inventory()


# ---------------------------------------------------------------------------- users, roles
def roles():
    r = load_json("roles.json", None)
    if not isinstance(r, dict):
        r = {k: list(v) for k, v in DEFAULT_ROLES.items()}
    r.pop("admin", None)
    return r


def user_perms(user):   # what a signed-in user may do; the command line (pvr) counts as admin
    u = users().get(user)
    return set(PERMS) if u is None else set(perms_of(u.get("role", "")))


def perms_of(role):
    if role == "admin":
        return list(PERMS)
    return [p for p in roles().get(role, []) if p in PERMS]


def users():
    u = load_json("users.json", {})
    return u if isinstance(u, dict) else {}


def hash_pw(pw, salt=None, n=310000):
    salt = salt or secrets.token_hex(16)
    return "pbkdf2_sha256$%d$%s$%s" % (n, salt, hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), n).hex())


def check_pw(pw, stored):
    try:
        _, n, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, salt, int(n)).split("$")[3], h)
    except (ValueError, AttributeError):
        return False


def totp(secret, t=None):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    c = int((t or time.time()) // 30)
    d = hmac.new(key, struct.pack(">Q", c), "sha1").digest()
    o = d[-1] & 15
    return "%06d" % ((struct.unpack(">I", d[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_ok(secret, code):
    code = re.sub(r"\s", "", code or "")
    now = time.time()
    return any(hmac.compare_digest(totp(secret, now + 30 * w), code) for w in (-1, 0, 1))


def gen_password():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(14))


def allowed_courses(u):
    c = u.get("courses", "*")
    return None if c == "*" or u.get("role") == "admin" else set(c)


SESSIONS = {}   # fingerprint of the sign-in token -> {user, last}; kept on disk, so an update doesn't sign anyone out
_SESS = {"saved": 0}


def skey(tok):   # only a fingerprint is kept - a copy of the file can't be used to sign in
    return hashlib.sha256(tok.encode()).hexdigest()


def pw_mark(u):
    """A short fingerprint of a user's password hash: a session signed in with an older password ends."""
    return hashlib.sha256((u or {}).get("hash", "").encode()).hexdigest()[:16]


def sessions_load():
    d = load_json("priv/sessions.json", {})
    now = time.time()
    for k, v in (d.items() if isinstance(d, dict) else []):
        if isinstance(v, dict) and now - v.get("last", 0) < IDLE:
            SESSIONS[k] = {"user": v.get("user", ""), "last": v["last"], "pw": v.get("pw", "")}


def sessions_save(force=False):
    if not force and time.time() - _SESS["saved"] < 30:
        return
    _SESS["saved"] = time.time()
    try:
        os.makedirs(path("priv"), exist_ok=True)
        save_json("priv/sessions.json", {k: {"user": v["user"], "last": v["last"], "pw": v.get("pw", "")} for k, v in list(SESSIONS.items())})
        os.chmod(path("priv/sessions.json"), 0o600)
    except OSError:
        pass
FAILS = {}


def failed_recently(key):
    now = time.time()
    FAILS[key] = [t for t in FAILS.get(key, []) if now - t < 600]
    return len(FAILS[key]) >= 5


# ---------------------------------------------------------------------------- settings
DEFAULT_SETTINGS = {
    "default_snapshot": "ClassStart",
    "shutdown_timeout": SHUTDOWN_TIMEOUT,
    "max_parallel": PARALLEL,
    "protected": "",
    "sensor_pattern": "dragos|sensor|tenable|zeek|suricata|snort|onion|nsm",
    "show_guide": True,
    "default_theme": "",
    "backup_keep": 30,
    "start_delay": 0,
}


def settings():
    s = dict(DEFAULT_SETTINGS)
    v = load_json("settings.json", {})
    if isinstance(v, dict):
        s.update({k: v[k] for k in DEFAULT_SETTINGS if k in v})
    return s


def is_sensor(g):
    """A sensor: tagged "sensor", or its name matches the sensor pattern in Settings."""
    if "sensor" in (g.get("tags") or []):
        return True
    try:
        return bool(re.search(settings()["sensor_pattern"] or "$^", g.get("name") or "", re.I))
    except re.error:
        return False


def parse_ranges(text):
    """'100-105,9001 9100-9110' -> set of VMIDs"""
    out = set()
    for part in re.split(r"[\s,]+", text or ""):
        m = re.match(r"^(\d+)(?:-(\d+))?$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2) or m.group(1))
            if a <= b and b - a <= 100000:
                out.update(range(a, b + 1))
    return out


def protected_ids():
    return parse_ranges(settings()["protected"])


def step(label, node, fn, vmid=None, buf=None):
    return {"label": label, "node": node, "fn": fn, "vmid": vmid, "buf": buf}


def gpath(g):
    return "/nodes/%s/%s/%d" % (g["node"], g["type"], g["vmid"])


_CAP = {}   # vmid -> time it was seen able to take snapshots (only "yes" is kept: a disk moved to a
            # storage with snapshots must count at once; "no" is asked again - few guests, cheap)


def snapshot_capable(gs):
    """{vmid: True / False / None} - can each guest take a snapshot where its disks are? (Proxmox' own
    answer: a container on directory storage, or a raw disk on storage without snapshots, can't.)
    None: Proxmox didn't say - then nothing is left out."""
    from concurrent.futures import ThreadPoolExecutor

    def ask(g):
        try:
            r = pve.call("GET", gpath(g) + "/feature", {"feature": "snapshot"}, timeout=10)
            return g["vmid"], bool(r.get("hasFeature")) if isinstance(r, dict) and "hasFeature" in r else None
        except PVEError:
            return g["vmid"], None
    now = time.time()
    out = {g["vmid"]: True for g in gs if now - _CAP.get(g["vmid"], 0) < 600}
    todo = [g for g in gs if g["vmid"] not in out]
    if todo:
        with ThreadPoolExecutor(max_workers=min(32, len(todo))) as ex:
            for v, ok in ex.map(ask, todo):
                out[v] = ok
                if ok:
                    _CAP[v] = now
                else:
                    _CAP.pop(v, None)
    return out
