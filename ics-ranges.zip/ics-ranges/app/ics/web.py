"""ICS Ranges - web (split from server.py; see server.py for the program)."""
import base64
import gzip
import hashlib
import http.server
import json
import os
import re
import secrets
import subprocess
import sys
import time
import traceback
import urllib.request
from .core import (DEFAULT_MAP, DEFAULT_SETTINGS, FAILS, IDLE, LOCK, PERMS, PVEError, SESSIONS, STATIC, VERSION, _parse_map_text, allowed_courses, audit, check_pw, courses_for, failed_recently, gen_password, hash_pw, inv, is_sensor, load_json, load_map, mixed_active, mixed_courses, path, perms_of, pve, pw_mark, roles, save_json, sessions_save, settings, skey, totp_ok, users)
from .content import (ADDON_RE, ADDON_TEMPLATE, addon_dir, addon_meta, fetch_url, field, guide_file, list_addons, read_text, write_text)
from .share import (BACKUPS, GIT_LOCK, REPO, autosave, git, git_conf, git_env, make_backup, remote_url, repo_init, repo_pull, repo_save, restore_backup)
from .netops import (RAW_ONLY, net_summary, node_bridges, ovs)
from .updates import (cached_versions, host_command, releases_with_cache, request_install, upd_conf, upd_state, update_connect, ver_key)
from .mirrors import (IFACE_RE, MID_RE, _VIEW, madd_from_script, madd_measure, madd_off_now, madd_path, madd_save, madd_view, node_ports)
from .plans import (JOBS, build_plan, plan_view, start_job)
from .readiness import (readiness)
from .kit import (kit_export, kit_import, kit_open)
from . import health as _health, truenas
COOKIE_FLAGS = "; Secure"   # cleared only when the server runs without a certificate (testing)


# ---------------------------------------------------------------------------- HTTP
STATIC_CACHE = {}
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".woff2": "font/woff2",
        ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".txt": "text/plain"}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "ics-ranges"
    sys_version = ""

    def log_message(self, *a):
        pass

    # -- helpers
    def send(self, code, obj=None, ctype="application/json", raw=None, headers=None, cache="no-store", gz=None):
        b = raw if raw is not None else json.dumps(obj, separators=(",", ":")).encode()
        zipped = False
        if "gzip" in (self.headers.get("Accept-Encoding") or "") and len(b) > 1400 and \
                (ctype.startswith(("application/json", "text/")) or ctype in ("image/svg+xml",)):
            b = gz if gz is not None else gzip.compress(b, 6)
            zipped = True
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        if zipped:
            self.send_header("Content-Encoding", "gzip")
        self.send_header("Vary", "Accept-Encoding")
        self.send_header("X-ICS-Version", VERSION)
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def body(self, limit=1_000_000):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise ValueError("request too large")
        try:
            b = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            raise ValueError("bad request - not JSON")
        if not isinstance(b, dict):   # every change is sent as one JSON object
            raise ValueError("bad request - expected a JSON object")
        return b

    def client(self):
        return self.client_address[0]

    def session(self):
        c = self.headers.get("Cookie", "")
        m = re.search(r"(?:^|;\s*)pvr=([A-Za-z0-9_-]+)", c)
        if not m:
            return None
        s = SESSIONS.get(skey(m.group(1)))
        if not s or time.time() - s["last"] > IDLE:
            SESSIONS.pop(skey(m.group(1)), None)
            return None
        u = users().get(s["user"])
        if not u:
            return None
        if s.get("pw") and s["pw"] != pw_mark(u):   # the password was changed (page, Users, pvr): sign in again
            SESSIONS.pop(skey(m.group(1)), None)
            sessions_save(True)
            return None
        s["last"] = time.time()
        sessions_save()   # at most every 30 s
        return {"token": m.group(1), "user": s["user"], "role": u.get("role", "viewer"), "u": u,
                "perms": perms_of(u.get("role", "viewer"))}

    def need(self, s, perm):
        if perm not in s["perms"]:
            raise PermissionError("your role can't do this")

    # -- routing
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        url = urllib.parse.urlparse(self.path)
        p = url.path
        try:
            if method == "GET" and not p.startswith("/api/"):
                return self.static(p)
            if method != "GET" and self.headers.get("X-PVR") != "1":   # only our own page may change things
                return self.send(403, {"error": "missing request header"})
            q = dict(urllib.parse.parse_qsl(url.query))
            fixed = {"/api/session": "GET", "/api/setup": "POST", "/api/login": "POST", "/api/logout": "POST"}
            if p in fixed and method != fixed[p]:
                return self.send(405, {"error": "use %s for %s" % (fixed[p], p)})
            if p == "/api/session" and method == "GET":
                return self.api_session()
            if p == "/api/setup" and method == "POST":
                return self.api_setup()
            if p == "/api/login" and method == "POST":
                return self.api_login()
            s = self.session()
            if not s:
                return self.send(401, {"error": "Sign in again - your session ended."})
            if p == "/api/logout" and method == "POST":
                SESSIONS.pop(skey(s["token"]), None)
                sessions_save(True)
                return self.send(200, {"ok": True}, headers={"Set-Cookie": "pvr=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict" + COOKIE_FLAGS})
            # a delete names exactly one thing: never a longer address than the endpoint expects
            dparts = {"users": 1, "addons": 2, "mixed": 1, "guide": 1, "madd": 1}
            seg = [x for x in p[5:].split("/")[1:] if x != ""]
            ep = p[5:].split("/")[0]
            if method == "DELETE" and ep in dparts and len(seg) != dparts[ep]:
                return self.send(400, {"error": "bad request - a delete names exactly one item"})
            h = getattr(self, "api_" + p[5:].split("/")[0].replace("-", "_"), None)
            if not h:
                return self.send(404, {"error": "not found"})
            return h(s, method, p.split("/")[3:], q)
        except PermissionError as e:
            return self.send(403, {"error": str(e)})
        except (ValueError, KeyError) as e:
            return self.send(400, {"error": str(e).strip("'")})
        except PVEError as e:
            return self.send(502, {"error": str(e)})
        except (TypeError, AttributeError) as e:   # a value of the wrong kind (a number where text belongs ...)
            sys.stderr.write("bad request %s %s: %s\n" % (method, p, e))
            return self.send(400, {"error": "bad request - a value has the wrong type"})
        except Exception as e:   # noqa
            traceback.print_exc()
            return self.send(500, {"error": "internal error: %s" % e})

    def static(self, p):
        if p in ("", "/"):
            p = "/index.html"
        f = os.path.normpath(os.path.join(STATIC, p.lstrip("/")))
        if not f.startswith(STATIC) or not os.path.isfile(f):
            f = os.path.join(STATIC, "index.html")
        st = os.stat(f)
        c = STATIC_CACHE.get(f)
        if not c or c["mtime"] != st.st_mtime_ns:   # read, compress and fingerprint each file once
            with open(f, "rb") as fh:
                raw = fh.read()
            if f.endswith("index.html"):   # the page names its files with the version: a new version is fetched for sure
                t = raw.decode()
                for a in ("/app.css", "/app.js", "/tools.js", "/favicon.png"):
                    t = t.replace('"%s"' % a, '"%s?v=%s"' % (a, VERSION))
                t = t.replace('<meta charset="utf-8">', '<meta charset="utf-8">\n<meta name="ics-version" content="%s">' % VERSION)
                raw = t.encode()
            c = STATIC_CACHE[f] = {"mtime": st.st_mtime_ns, "raw": raw, "gz": gzip.compress(raw, 9),
                                   "etag": '"%s"' % hashlib.sha1(raw).hexdigest()[:16]}
        ext = os.path.splitext(f)[1]
        # app files: the browser keeps them and asks "still the same?" (a tiny 304 answer);
        # fonts never change; pictures are kept a day
        versioned = "v=" in urllib.parse.urlparse(self.path).query
        cache = "public, max-age=31536000, immutable" if ext == ".woff2" or (versioned and not f.endswith("index.html")) else \
                "public, max-age=86400" if ext in (".png", ".ico", ".svg") else "no-cache"
        if self.headers.get("If-None-Match") == c["etag"]:
            self.send_response(304)
            self.send_header("ETag", c["etag"])
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return
        return self.send(200, raw=c["raw"], gz=c["gz"], ctype=MIME.get(ext, "application/octet-stream"),
                         cache=cache, headers={"ETag": c["etag"]})

    # -- sign-in
    def api_session(self):
        s = self.session()
        if not s:
            return self.send(200, {"signed_in": False, "setup": not users(), "version": VERSION})
        return self.send(200, {"signed_in": True, "user": s["user"], "role": s["role"], "perms": s["perms"], "offline": inv.offline,
                               "twofa": bool(s["u"].get("totp")), "version": VERSION,
                               "perm_names": PERMS, "settings": {k: settings()[k] for k in ("default_snapshot", "show_guide", "default_theme", "shutdown_timeout")},
                               "themes": load_json("themes.json", {}),
                               "update_available": (load_json("update-check.json", {}).get("newest", "")
                                                    if "software" in s["perms"] and ver_key(load_json("update-check.json", {}).get("newest", "")) > ver_key(VERSION) else "")})

    def start_session(self, name):
        tok = secrets.token_urlsafe(32)
        SESSIONS[skey(tok)] = {"user": name, "last": time.time(), "pw": pw_mark(users().get(name))}
        sessions_save(True)
        return {"Set-Cookie": "pvr=%s; Path=/; HttpOnly; SameSite=Strict%s" % (tok, COOKIE_FLAGS)}

    def api_setup(self):
        with LOCK:
            if users():
                raise PermissionError("already set up - sign in")
            b = self.body()
            name, pw = (b.get("user") or "").strip(), b.get("password") or ""
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                raise ValueError("user names: letters, digits, . _ -")
            if len(pw) < 10:
                raise ValueError("use at least 10 characters for the password")
            save_json("users.json", {name: {"hash": hash_pw(pw), "role": "admin", "courses": "*", "totp": ""}})
        audit(name, "first admin created")
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    def api_login(self):
        b = self.body()
        name, pw, code = (b.get("user") or "").strip(), b.get("password") or "", b.get("code") or ""
        key = name.lower() + "|" + self.client()
        if failed_recently(key):
            return self.send(429, {"error": "Too many wrong attempts. Wait 10 minutes, or ask an admin to unlock you."})
        u = users().get(name)
        if not u or not check_pw(pw, u.get("hash", "")):
            FAILS.setdefault(key, []).append(time.time())
            audit(name, "sign-in FAILED from %s" % self.client())
            return self.send(401, {"error": "That name and password don't match."})
        if u.get("totp"):
            if not code:
                return self.send(200, {"need_code": True})
            if not totp_ok(u["totp"], code):
                FAILS.setdefault(key, []).append(time.time())
                audit(name, "sign-in FAILED (2FA code) from %s" % self.client())
                return self.send(401, {"error": "That code doesn't match. Check the time on your phone.", "need_code": True})
        FAILS.pop(key, None)
        audit(name, "signed in from %s" % self.client())
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    # -- courses and guests
    def api_courses(self, s, method, parts, q):
        inv.refresh()
        return self.send(200, courses_for(s))

    def api_course(self, s, method, parts, q):
        course = urllib.parse.unquote(parts[0]) if parts else ""
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        inv.refresh(force=q.get("fresh") == "1")
        ids = inv.course_ids(course)
        snaps = inv.snapshots(ids)
        mixed = course in mixed_active()
        guests = []
        for v in ids:
            g = dict(inv.guests[v])
            g["snapshots"] = snaps.get(v, [])
            if mixed:   # in a mixed course, say where each guest comes from
                g["home"] = g["course"] or "no course"
                g["group"] = "%s · %s" % (g["home"], g["group"])
            guests.append(g)
        summary = {}
        for g in guests:
            for sn in g["snapshots"]:
                o = summary.setdefault(sn["name"], {"name": sn["name"], "count": 0, "ram": 0})
                o["count"] += 1
                o["ram"] += sn["ram"]
        out = {"course": course, "guests": guests, "nodes": inv.nodes, "offline": inv.offline,
               "snapshots": sorted(summary.values(), key=lambda x: (-x["count"], x["name"]))}
        if q.get("with") == "courses":   # the course list too - one request per refresh instead of two
            out["courses"] = courses_for(s)
        return self.send(200, out)

    # -- plans and jobs
    def api_plan(self, s, method, parts, q):
        if method == "POST" and inv.offline:
            raise PVEError("Proxmox isn't answering (since %s) - nothing can be started or stopped until it does" % inv.offline["since"])
        if method == "POST" and not parts:
            pid = build_plan(s["user"], self.body())
            return self.send(200, plan_view(pid))
        if method == "POST" and len(parts) == 2 and parts[1] == "run":
            return self.send(200, {"job": start_job(s["user"], parts[0])})
        raise ValueError("bad request")

    def api_job(self, s, method, parts, q):
        j = JOBS.get(parts[0] if parts else "")
        if not j or (j["user"] != s["user"] and s["role"] != "admin"):
            raise KeyError("no such job")
        flat = [st for g in j["steps"] for st in g]
        groups = [[dict({k: v for k, v in st.items() if k != "buf"}, out="".join(st["buf"])[-30000:] if st.get("buf") is not None else None) for st in g] for g in j["steps"]]
        return self.send(200, {"title": j["plan"]["title"], "state": j["state"], "groups": groups,
                               "notes": j["plan"]["notes"],
                               "ok": sum(st["state"] == "ok" for st in flat), "failed": sum(st["state"] == "failed" for st in flat),
                               "total": len(flat), "secs": round((j.get("ended") or time.time()) - j["started"], 1)})

    # -- mirrors
    def api_nics(self, s, method, parts, q):   # the course's NICs on every bridge, for the network add-ons
        self.need(s, "network")   # the Network tab
        course = q.get("course", "")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids, max_age=0)
        bridges = {n: node_bridges(n) for n in inv.nodes}
        out = []
        for v in ids:
            g = inv.guests[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not re.match(r"^net\d+$", k):
                    continue
                parts_ = val.split(",")
                br = (re.search(r"bridge=([^,]+)", val) or [None, ""])[1]
                mac = (re.search(r"(?:^|,)(?:[a-z0-9]+|hwaddr)=([0-9A-Fa-f:]{17})", val) or [None, ""])[1]
                out.append({"vmid": v, "name": g["name"], "node": g["node"], "group": g.get("group", ""),
                            "nic": k, "bridge": br, "mac": mac, "tag": (re.search(r"tag=(\d+)", val) or [None, ""])[1],
                            "ovs": br in bridges.get(g["node"], {}).get("ovs", []),
                            "firewall": "firewall=1" in parts_, "connected": "link_down=1" not in parts_, "status": g["status"],
                            "sensor": is_sensor(g)})
        snoop = {}
        for n_, b_ in {(x["node"], x["bridge"]) for x in out if x["ovs"]}:
            try:
                snoop["%s/%s" % (n_, b_)] = ovs(n_, "get", "bridge", b_, "mcast_snooping_enable").strip() == "true"
            except (PVEError, subprocess.TimeoutExpired, OSError):
                snoop["%s/%s" % (n_, b_)] = None
        return self.send(200, {"nics": out, "bridges": bridges, "snooping": snoop})

    def api_madd(self, s, method, parts, q):   # mirror add-ons
        mid = parts[0] if parts else ""
        if method == "GET" and not mid:
            self.need(s, "mirror_status")
            course = q.get("course", "")
            allow = allowed_courses(s["u"])
            if allow is not None and course not in allow:
                raise PermissionError("you can't use the course %s" % course)
            inv.refresh()
            return self.send(200, {"addons": madd_view(course)})
        if method == "POST" and mid == "parse":
            self.need(s, "mirror_setup")
            b = self.body()
            props, notes = madd_from_script(str(b.get("text") or ""), str(b.get("course") or "_all"))
            return self.send(200, {"addons": props, "notes": notes})
        if method == "POST" and len(parts) == 2 and parts[1] == "check" and MID_RE.match(mid):
            self.need(s, "mirror_status")
            return self.send(200, madd_measure(mid))
        self.need(s, "mirror_setup")
        if len(parts) > 1:   # only /api/madd/<id> changes or deletes - never a longer address
            raise ValueError("bad request")
        if method == "POST" and not mid:
            new = madd_save(self.body(), None, s["user"])
            audit(s["user"], "mirror add-on made: %s" % new)
            autosave(s["user"], "mirror add-on %s" % new)
            return self.send(200, {"ok": True, "id": new})
        if not os.path.exists(madd_path(mid)):
            raise KeyError("no such mirror add-on")
        if method == "PUT":
            madd_save(self.body(), mid, s["user"])
            audit(s["user"], "mirror add-on changed: %s" % mid)
            autosave(s["user"], "mirror add-on %s" % mid)
            return self.send(200, {"ok": True, "id": mid})
        if method == "DELETE":
            m = load_json(os.path.join("share", "mirroring", mid + ".json"), {})
            if m.get("active") or m.get("added"):
                try:
                    madd_off_now(m, mid)
                    for iface in m.get("added", []):   # a physical NIC it put on the bridge comes off again
                        ovs(m["node"], "--if-exists", "del-port", m["bridge"], iface)
                except (PVEError, subprocess.TimeoutExpired, KeyError):
                    pass
            os.remove(madd_path(mid))
            _VIEW.clear()
            audit(s["user"], "mirror add-on deleted: %s" % mid)
            autosave(s["user"], "mirror add-on %s deleted" % mid)
            return self.send(200, {"ok": True})
        raise ValueError("bad request")

    def api_bridgeports(self, s, method, parts, q):   # for the mirror builder: hosts, their bridges, and the ports on one
        self.need(s, "mirror_setup")
        inv.refresh()
        node, bridge = q.get("node", ""), q.get("bridge", "")
        if not node:
            return self.send(200, {"nodes": {n: node_bridges(n) for n in inv.nodes}})
        if node not in inv.nodes or not IFACE_RE.match(bridge):
            raise ValueError("pick a host and a bridge")
        return self.send(200, node_ports(node, bridge))

    def api_netsummary(self, s, method, parts, q):   # disconnected NICs and firewall-off NICs of a course
        if "mirror_status" not in s["perms"] and "network" not in s["perms"]:
            raise PermissionError("your role can't do this")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        inv.refresh()
        return self.send(200, net_summary(course))

    def api_overview(self, s, method, parts, q):
        self.need(s, "overview")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use this course")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        disks = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$", k) and "media=cdrom" not in val:
                    vol = val.split(",")[0]
                    if ":" not in vol:
                        continue
                    size = (re.search(r"size=([^,]+)", val) or [None, ""])[1]
                    fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                    disks.append({"vmid": v, "name": inv.guests[v]["name"], "disk": k, "storage": vol.split(":")[0], "format": fmt, "size": size})
        st = []
        for x in pve.call("GET", "/storage") or []:
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "shared": bool(x.get("shared")),
                       "formats": "qcow2 raw vmdk" if t in ("dir", "nfs", "cifs", "glusterfs", "cephfs") else "raw",
                       "content": x.get("content", "")})
        return self.send(200, {"storages": st, "disks": disks})

    # -- users (admin)
    def api_users(self, s, method, parts, q):
        self.need(s, "users")
        with LOCK:
            us = users()
            if method == "GET":
                return self.send(200, [{"name": n, "role": u.get("role"), "courses": u.get("courses", "*"), "twofa": bool(u.get("totp"))}
                                       for n, u in sorted(us.items())])
            b = self.body() if method in ("POST", "PUT") else {}
            if method == "POST" and not parts:   # add
                name = (b.get("name") or "").strip()
                if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                    raise ValueError("user names: letters, digits, . _ - (max 32)")
                if name in us:
                    raise ValueError("%s already exists" % name)
                pw = b.get("password") or gen_password()
                if len(pw) < 10:
                    raise ValueError("use at least 10 characters for the password")
                us[name] = {"hash": hash_pw(pw), "role": self.valid_role(b.get("role")), "courses": self.valid_courses(b.get("courses")), "totp": ""}
                save_json("users.json", us)
                audit(s["user"], "user %s added (%s)" % (name, us[name]["role"]))
                return self.send(200, {"ok": True, "password": None if b.get("password") else pw})
            name = parts[0] if parts else ""
            if name not in us:
                raise KeyError("no user %s" % name)
            admins = [n for n, u in us.items() if u.get("role") == "admin"]
            if method == "DELETE":
                if name == s["user"]:
                    raise ValueError("you can't delete yourself")
                if us[name].get("role") == "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin" % name)
                del us[name]
                save_json("users.json", us)
                audit(s["user"], "user %s deleted" % name)
                return self.send(200, {"ok": True})
            if method == "PUT":
                role = self.valid_role(b.get("role", us[name].get("role")))
                if us[name].get("role") == "admin" and role != "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin - make another admin first" % name)
                us[name]["role"] = role
                us[name]["courses"] = self.valid_courses(b.get("courses", us[name].get("courses", "*")))
                if b.get("twofa") is False:
                    us[name]["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "user %s changed: %s, courses %s" % (name, role, us[name]["courses"]))
                return self.send(200, {"ok": True})
            if method == "POST" and len(parts) == 2 and parts[1] == "password":
                pw = gen_password()
                us[name]["hash"] = hash_pw(pw)
                save_json("users.json", us)
                for t, ss in list(SESSIONS.items()):
                    if ss["user"] == name:
                        SESSIONS.pop(t, None)
                sessions_save(True)   # also gone after a restart
                audit(s["user"], "new password for %s" % name)
                return self.send(200, {"password": pw})
            if method == "POST" and len(parts) == 2 and parts[1] == "unlock":
                for k in [k for k in FAILS if k.startswith(name.lower() + "|")]:
                    FAILS.pop(k, None)
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    def valid_role(self, r):
        if r != "admin" and r not in roles():
            raise ValueError("no role %s" % r)
        return r

    def valid_courses(self, c):
        if c == "*" or c is None:
            return "*"
        if not isinstance(c, list) or not c or not all(isinstance(x, str) and re.match(r"^[A-Za-z0-9_.-]+$", x) for x in c):
            raise ValueError("pick at least one course")
        return sorted(set(c))

    # -- own account: password, 2FA
    def api_me(self, s, method, parts, q):
        with LOCK:
            us = users()
            me = us[s["user"]]
            b = self.body() if method != "GET" else {}
            what = parts[0] if parts else ""
            if method == "POST" and what == "password":
                if not check_pw(b.get("old", ""), me["hash"]):
                    raise ValueError("your current password doesn't match")
                if len(b.get("new", "")) < 10:
                    raise ValueError("use at least 10 characters")
                me["hash"] = hash_pw(b["new"])
                save_json("users.json", us)
                SESSIONS[skey(s["token"])]["pw"] = pw_mark(me)   # this page stays signed in, others end
                audit(s["user"], "changed own password")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-start":
                secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
                SESSIONS[skey(s["token"])]["pending_totp"] = secret
                return self.send(200, {"secret": secret, "uri": "otpauth://totp/ICS%%20Ranges:%s?secret=%s&issuer=ICS%%20Ranges" % (urllib.parse.quote(s["user"]), secret)})
            if method == "POST" and what == "2fa-confirm":
                secret = SESSIONS[skey(s["token"])].get("pending_totp")
                if not secret or not totp_ok(secret, b.get("code", "")):
                    raise ValueError("that code doesn't match - check the time on your phone")
                me["totp"] = secret
                save_json("users.json", us)
                audit(s["user"], "2FA turned on")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-off":
                if not check_pw(b.get("password", ""), me["hash"]):
                    raise ValueError("your password doesn't match")
                me["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "2FA turned off")
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    # -- roles, VMID map, audit (admin)
    def api_roles(self, s, method, parts, q):
        if method == "GET":
            return self.send(200, {"roles": roles(), "perms": PERMS})
        self.need(s, "settings")
        b = self.body()   # {roles: {name: [perms]}}
        new = {}
        for name, ps in field(self, method, b, "roles", dict).items():
            if name == "admin":
                continue
            if not re.match(r"^[a-z][a-z0-9_-]{0,23}$", name):
                raise ValueError("role names: small letters, digits, - and _")
            new[name] = sorted(p for p in ps if p in PERMS)
        used = {u.get("role") for u in users().values()}
        gone = [r for r in roles() if r not in new and r in used]
        if gone:
            raise ValueError("users still have the role %s - give them another role first" % ", ".join(gone))
        save_json("roles.json", new)
        autosave(s["user"], "Roles changed")
        audit(s["user"], "roles: " + "; ".join("%s=%s" % (k, ",".join(v)) for k, v in new.items()))
        return self.send(200, {"ok": True})

    def api_vmidmap(self, s, method, parts, q):
        self.need(s, "settings")
        if method == "GET":
            inv.refresh()
            return self.send(200, {"text": load_map()[1], "default": DEFAULT_MAP,
                                   "unmapped": sorted(v for v, g in inv.guests.items() if g["course"] is None)})
        text = field(self, method, self.body(), "text", str)
        if len(text) > 100000:
            raise ValueError("too long")
        if not _parse_map_text(text)[0]["folder"]:
            raise ValueError("the map has no folder lines - nothing would be a course (Load the shipped map to start again)")
        with open(path("vmid-map.conf"), "w") as f:
            f.write(text)
        inv.forget(list(inv.guests))
        autosave(s["user"], "Course map changed")
        audit(s["user"], "VMID map changed")
        return self.send(200, {"ok": True})

    def api_audit(self, s, method, parts, q):
        self.need(s, "users")

        def tail(f, n):   # the last n lines, reading only the end of a (possibly large) file
            try:
                with open(f, "rb") as fh:
                    fh.seek(0, 2)
                    start = max(0, fh.tell() - 120000)
                    fh.seek(start)
                    ls = fh.read().decode("utf-8", "replace").splitlines(True)
                    return (ls[1:] if start else ls)[-n:]   # drop a line cut in half
            except OSError:
                return []
        lines = tail(path("audit.log"), 300)
        if len(lines) < 300:   # just rotated: the rest comes from the previous file
            lines = tail(path("audit.log.1"), 300 - len(lines)) + lines
        return self.send(200, {"lines": [x.rstrip("\n") for x in reversed(lines)]})


# ---------------------------------------------------------------------------- more endpoints
def _course_ok(self, s, course):
    allow = allowed_courses(s["u"])
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)


def api_settings(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, {"settings": settings(), "defaults": DEFAULT_SETTINGS})
    self.need(s, "settings")
    if method != "PUT":
        raise ValueError("use PUT to save")
    b = self.body()
    cur = load_json("settings.json", {})
    for k, v in b.items():
        if k not in DEFAULT_SETTINGS:
            continue
        d = DEFAULT_SETTINGS[k]
        if isinstance(d, bool):
            v = bool(v)
        elif isinstance(d, int):
            v = int(v)
            if k == "max_parallel" and not 1 <= v <= 32:
                raise ValueError("steps at once: 1 to 32")
            if k == "shutdown_timeout" and not 10 <= v <= 3600:
                raise ValueError("shutdown timeout: 10 to 3600 seconds")
            if k == "backup_keep" and not 0 <= v <= 500:
                raise ValueError("backups to keep: 0 to 500")
            if k == "start_delay" and not 0 <= v <= 600:
                raise ValueError("pause between starts: 0 to 600 seconds")
        else:
            v = str(v).strip()
            if k == "default_snapshot" and not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", v):
                raise ValueError("snapshot names start with a letter")
            if k == "protected" and v and not re.match(r"^[\d\s,-]+$", v):
                raise ValueError("protected guests: VMIDs and ranges like 100-105, 9001")
            if k == "sensor_pattern":
                try:
                    re.compile(v)
                except re.error:
                    raise ValueError("sensor names: not a valid pattern")
        cur[k] = v
    save_json("settings.json", cur)
    inv.forget(list(inv.guests))
    autosave(s["user"], "Settings changed")
    audit(s["user"], "settings: " + ", ".join("%s=%s" % kv for kv in sorted(b.items())))
    return self.send(200, {"ok": True})


def api_guide(self, s, method, parts, q):
    course = urllib.parse.unquote(parts[0]) if parts else ""
    _course_ok(self, s, course)
    f = guide_file(course)
    if method == "GET":
        if "guide_read" not in s["perms"] and "class_run" not in s["perms"]:   # running a class includes reading its guide
            raise PermissionError("your role can't do this")
        text = read_text(f)
        if text is None:   # pve-range keeps its class guides as <course>.txt
            text = read_text(f[:-3] + ".txt")
        return self.send(200, {"course": course, "text": text})
    self.need(s, "guide_edit")
    if method == "DELETE":
        for x in (f, f[:-3] + ".txt"):
            try:
                os.remove(x)
            except OSError:
                pass
        autosave(s["user"], "Class guide for %s deleted" % course)
        audit(s["user"], "class guide %s deleted" % course)
        return self.send(200, {"ok": True})
    b = self.body()
    if not b.get("url") and not isinstance(b.get("text"), str):   # nothing to save - never an empty file by accident
        raise ValueError("nothing to save - send its text (to remove it, use Delete)")
    text = fetch_url(b["url"]) if b.get("url") else b["text"]
    if isinstance(text, str):
        text = text.replace("\r\n", "\n").replace("\r", "\n")   # saved on Windows: Unix line ends
    if len(text) > 1_000_000:
        raise ValueError("a guide can be at most 1 MB")
    write_text(f, text)
    try:
        os.remove(f[:-3] + ".txt")   # the .md replaces a guide brought over from pve-range
    except OSError:
        pass
    autosave(s["user"], "Class guide for %s saved" % course)
    audit(s["user"], "class guide %s saved (%d characters)" % (course, len(text)))
    return self.send(200, {"ok": True, "text": text})


def api_addons(self, s, method, parts, q):
    course = q.get("course", "")
    if method == "GET" and not parts:
        _course_ok(self, s, course)
        if "addons_run" in s["perms"]:
            return self.send(200, {"addons": list_addons(course), "template": ADDON_TEMPLATE if "addons_edit" in s["perms"] else ""})
        if "class_run" in s["perms"]:   # instructors: the add-ons made into buttons for them
            return self.send(200, {"addons": [a for a in list_addons(course) if a.get("button")], "template": ""})
        raise PermissionError("your role can't do this")
    scope, f = (parts + ["", ""])[:2]
    if scope != "_all":
        _course_ok(self, s, scope)
    if not ADDON_RE.match(f or ""):
        raise ValueError("add-on file names end in .sh: letters, digits, . _ -")
    full = os.path.join(addon_dir(scope), f)
    if method == "GET":
        self.need(s, "addons_run")
        t = read_text(full)
        if t is None:
            raise KeyError("no such add-on")
        return self.send(200, {"text": t, "meta": addon_meta(t, f)})
    self.need(s, "addons_edit")
    if method == "DELETE":
        try:
            os.remove(full)
        except OSError:
            pass
        autosave(s["user"], "Add-on %s/%s deleted" % (scope, f))
        audit(s["user"], "add-on %s/%s deleted" % (scope, f))
        return self.send(200, {"ok": True})
    b = self.body()
    if not b.get("url") and not isinstance(b.get("text"), str):   # nothing to save - never an empty file by accident
        raise ValueError("nothing to save - send its text (to remove it, use Delete)")
    text = fetch_url(b["url"]) if b.get("url") else b["text"]
    if isinstance(text, str):
        text = text.replace("\r\n", "\n").replace("\r", "\n")   # saved on Windows: Unix line ends
    if len(text) > 1_000_000:
        raise ValueError("an add-on can be at most 1 MB")
    if b.get("move_to") and b["move_to"] != scope:   # move to another course (or all)
        dest = b["move_to"]
        if dest != "_all":
            _course_ok(self, s, dest)
        write_text(os.path.join(addon_dir(dest), f), text, 0o750)
        try:
            os.remove(full)
        except OSError:
            pass
    else:
        write_text(full, text.replace("\r\n", "\n"), 0o750)
    autosave(s["user"], "Add-on %s/%s saved" % (scope, f))
    audit(s["user"], "add-on %s/%s saved" % (b.get("move_to") or scope, f))
    return self.send(200, {"ok": True, "text": text})


def api_groups(self, s, method, parts, q):
    g = load_json("groups.json", {})
    if method == "GET":
        return self.send(200, g if isinstance(g, dict) else {})
    self.need(s, "settings")
    b = self.body()
    new = {}
    for k, v in field(self, method, b, "groups", dict).items():
        if not re.match(r"^[A-Za-z0-9 _.-]{1,40}$", k) or not re.match(r"^[\d\s,-]+$", v or ""):
            raise ValueError("group names: letters, digits, spaces; members: VMIDs and ranges")
        new[k.strip()] = v.strip()
    save_json("groups.json", new)
    autosave(s["user"], "Saved groups changed")
    return self.send(200, {"ok": True})


def api_themes(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, load_json("themes.json", {}))
    self.need(s, "settings")
    b = self.body()
    new = {}
    for name, cols in field(self, method, b, "themes", dict).items():
        if not re.match(r"^[A-Za-z0-9 _-]{1,24}$", name):
            raise ValueError("theme names: letters, digits, spaces")
        c = {k: v for k, v in cols.items() if k in ("canvas", "panel", "ink", "line", "action", "dark") and (k == "dark" or re.match(r"^#[0-9a-fA-F]{6}$", str(v)))}
        if len([k for k in c if k != "dark"]) != 5:
            raise ValueError("each theme needs five colours as #rrggbb")
        new[name] = c
    save_json("themes.json", new)
    autosave(s["user"], "Colour themes changed")
    return self.send(200, {"ok": True})


def api_git(self, s, method, parts, q):
    self.need(s, "save")
    what = parts[0] if parts else ""
    if method == "GET" and what == "":
        c = git_conf()
        hist = []
        if os.path.isdir(os.path.join(REPO, ".git")):
            out = git("log", "-50", "--format=%h%x09%an%x09%ar%x09%s", check=False)
            hist = [dict(zip(("id", "who", "when", "what"), ln.split("\t", 3))) for ln in out.splitlines() if ln.count("\t") >= 3]
        try:
            backups = sorted((f for f in os.listdir(BACKUPS) if f.startswith("backup-")), reverse=True)
        except OSError:
            backups = []
        return self.send(200, {"url": c.get("url", ""), "user": c.get("user", ""), "branch": c.get("branch", "main"),
                               "insecure": bool(c.get("insecure")), "history": hist, "backups": backups,
                               "has_token": os.path.exists(path("priv/git-token")),
                               "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "GET" and what == "backup" and len(parts) == 2:
        f = os.path.join(BACKUPS, parts[1])
        if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", parts[1]) or not os.path.exists(f):
            raise KeyError("no such backup")
        with open(f, "rb") as fh:
            return self.send(200, raw=fh.read(), ctype="application/gzip",
                             headers={"Content-Disposition": 'attachment; filename="%s"' % parts[1]})
    b = self.body() if method in ("POST", "PUT") else {}
    if method == "PUT" and what == "connect":
        url = (b.get("url") or "").strip()
        if url and not re.match(r"^(https?://[^\s/]+/\S+|git@[^\s:]+:\S+|ssh://\S+)$", url):
            raise ValueError("give the repository address, e.g. https://gitea.lab/team/ics-ranges.git")
        c = {"url": url, "user": (b.get("user") or "").strip(), "branch": (b.get("branch") or "main").strip(), "insecure": bool(b.get("insecure"))}
        if not re.match(r"^[A-Za-z0-9._/-]{1,60}$", c["branch"]):
            raise ValueError("bad branch name")
        old = git_conf()
        save_json("git.json", c)
        os.makedirs(path("priv"), exist_ok=True)
        if b.get("token"):
            write_text(path("priv/git-token"), b["token"].strip() + "\n", 0o600)
        if url.startswith(("git@", "ssh://")) and not os.path.exists(path("ssh/git_ed25519")):
            subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "ics-ranges-git", "-f", path("ssh/git_ed25519")], check=False)
        if url:
            with GIT_LOCK:
                repo_init()
            p_ = subprocess.run(["git"] + (["-c", "http.sslVerify=false"] if c["insecure"] else []) + ["ls-remote", remote_url(c)],
                                env=git_env(), capture_output=True, text=True, timeout=40)
            if p_.returncode:
                save_json("git.json", old)
                err = (p_.stderr or "").strip().splitlines()
                raise ValueError("can't connect: %s" % (err[-1] if err else "check the address, user and token"))
        audit(s["user"], "repository: %s" % (url or "disconnected"))
        try:
            r = repo_save(s["user"], "Connected to %s" % url) if url else "Disconnected."
        except PVEError as e:
            raise ValueError("connected, but the upload failed: %s" % e)
        return self.send(200, {"ok": True, "report": r, "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "POST" and what == "save":
        r = repo_save(s["user"], b.get("message") or "Saved from the GUI")
        audit(s["user"], "save: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "pull":
        r = repo_pull(s["user"])
        audit(s["user"], "get latest: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "backup":
        name = make_backup()
        audit(s["user"], "backup %s" % name)
        return self.send(200, {"report": "Backup %s made." % name})
    if method == "POST" and what == "restore":
        make_backup()
        restore_backup(b.get("name", ""))
        audit(s["user"], "restored backup %s" % b.get("name"))
        autosave(s["user"], "Restored backup %s" % b.get("name"))
        return self.send(200, {"report": "Restored %s (a backup of the state before was made first)." % b.get("name")})
    raise ValueError("bad request")


def api_nodekey(self, s, method, parts, q):   # the line to add on a node, for Settings
    self.need(s, "settings")
    return self.send(200, {"text": read_text(path("ssh/node-key.txt")) or ""})


def api_storages(self, s, method, parts, q):   # for Move / convert disks
    self.need(s, "disks")
    st = []
    for x in pve.call("GET", "/storage") or []:
        if "images" in (x.get("content") or "") or "rootdir" in (x.get("content") or ""):
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "raw_only": t in RAW_ONLY})
    return self.send(200, st)


def api_bridges(self, s, method, parts, q):   # for Network settings
    self.need(s, "network")
    out = {}
    for n in inv.nodes or [r["node"] for r in pve.call("GET", "/nodes") or []]:
        try:
            out[n] = sorted({b["iface"] for b in pve.call("GET", "/nodes/%s/network" % n) or [] if b.get("type") in ("bridge", "OVSBridge")})
        except PVEError:
            out[n] = []
    return self.send(200, out)


for _f in (api_settings, api_guide, api_addons, api_groups, api_themes, api_git, api_storages, api_bridges, api_nodekey):
    setattr(Handler, _f.__name__, _f)


def api_ready(self, s, method, parts, q):
    if not ({"class_run", "overview"} & set(s["perms"])):
        raise PermissionError("your role can't do this")
    course = urllib.parse.unquote(parts[0]) if parts else ""
    allow = allowed_courses(s["u"])
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh(force=not inv.offline)
    snap = q.get("snapshot") or settings().get("default_snapshot") or "ClassStart"
    checks = readiness(course, snap)
    audit(s["user"], "readiness check %s: %s" % (course, ", ".join("%s %s" % (c["title"], c["state"]) for c in checks if c["state"] in ("warn", "fail")) or "all ok"))
    return self.send(200, {"course": course, "snapshot": snap, "checks": checks, "at": time.strftime("%H:%M"),
                           "ready": not any(c["state"] == "fail" for c in checks)})


setattr(Handler, "api_ready", api_ready)


def api_health(self, s, method, parts, q):   # health at a glance - everyone signed in
    if method != "GET":
        raise ValueError("bad request")
    inv.refresh()
    return self.send(200, _health.health(s["u"]))


def api_truenas(self, s, method, parts, q):   # Settings -> TrueNAS (admins)
    self.need(s, "settings")
    if method == "GET":
        return self.send(200, truenas.conf_public())
    if method == "PUT":
        truenas.conf_save(self.body())
        audit(s["user"], "TrueNAS settings changed")
        return self.send(200, dict(truenas.conf_public(), ok=True))
    if method == "POST" and parts == ["test"]:
        return self.send(200, truenas.health(max_age=0))
    raise ValueError("bad request")


setattr(Handler, "api_health", api_health)
setattr(Handler, "api_truenas", api_truenas)


def api_kit(self, s, method, parts, q):
    if s["role"] != "admin":
        raise PermissionError("only admins can export or import a kit")
    what = parts[0] if parts else ""
    if method == "POST" and what == "export":
        b = self.body()
        data = kit_export(b.get("password", ""), s["user"])
        name = "ics-ranges-kit-%s.icskit" % time.strftime("%Y%m%d-%H%M")
        return self.send(200, raw=data, ctype="application/octet-stream",
                         headers={"Content-Disposition": 'attachment; filename="%s"' % name})
    if method == "POST" and what in ("check", "import"):
        b = self.body(limit=80_000_000)
        try:
            blob = base64.b64decode(b.get("data", ""), validate=True)
        except (ValueError, TypeError):
            raise ValueError("the file didn't arrive whole")
        if what == "check":   # what is in it - nothing is changed
            man, _ = kit_open(blob, b.get("password", ""))
            return self.send(200, {"made": man.get("made"), "by": man.get("by"), "version": man.get("version"), "users": man.get("users", []),
                                   "proxmox": (man.get("env") or {}).get("PVE_API_URL", "")})
        man, before = kit_import(blob, b.get("password", ""), s["user"])
        return self.send(200, {"ok": True, "made": man.get("made"), "before": before, "proxmox": (man.get("env") or {}).get("PVE_API_URL", ""),
                               "here": os.environ.get("PVE_API_URL", "")})
    raise ValueError("bad request")


setattr(Handler, "api_kit", api_kit)


def api_updates(self, s, method, parts, q):
    self.need(s, "software")
    what = parts[0] if parts else ""
    if method == "GET" and what == "":
        c = upd_conf()
        return self.send(200, {"current": VERSION, "url": c.get("url", ""), "user": c.get("user", ""),
                               "insecure": bool(c.get("insecure")), "has_token": bool((read_text(path("priv/update-token")) or "").strip()),
                               "check": load_json("update-check.json", {}), "updater": upd_state(), "command": host_command()})
    if method == "GET" and what == "releases":
        rel, offline = releases_with_cache()
        return self.send(200, {"current": VERSION, "releases": rel, "offline": offline, "kept": len(cached_versions())})
    b = self.body()
    if method == "PUT" and what == "connect":
        rel = update_connect(s["user"], b.get("url"), b.get("user"), b.get("token"), b.get("insecure"))
        return self.send(200, {"ok": True, "releases": len(rel), "command": host_command()})
    if method == "POST" and what == "install":
        rel = request_install(s["user"], b.get("tag", ""))
        return self.send(200, {"ok": True, "tag": rel["tag"]})
    raise ValueError("bad request")


setattr(Handler, "api_updates", api_updates)


def api_mixed(self, s, method, parts, q):
    self.need(s, "settings")
    if method == "GET":
        inv.refresh()
        today = time.strftime("%Y-%m-%d")
        lst = [dict(c, name=n, expired=bool(c.get("expires")) and c["expires"] < today,
                    missing=[v for v in c.get("vmids", []) if v not in inv.guests]) for n, c in sorted(mixed_courses().items())]
        guests = [{"vmid": v, "name": g["name"], "course": g["course"] or "", "group": g["group"], "type": g["type"],
                   "status": g["status"]} for v, g in sorted(inv.guests.items())]
        return self.send(200, {"courses": lst, "guests": guests})
    name = urllib.parse.unquote(parts[0]) if parts else ""
    with LOCK:
        allc = mixed_courses()
        if method == "DELETE":
            if allc.pop(name, None) is None:
                raise KeyError("no such mixed course")
            save_json("courses.json", allc)
            audit(s["user"], "mixed course %s deleted" % name)
            autosave(s["user"], "Mixed course %s deleted" % name)
            return self.send(200, {"ok": True})
        b = self.body()
        old = b.get("old") or ""
        m, _ = load_map()
        if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$", name):
            raise ValueError("course names: letters, digits, . _ - (no spaces), up to 40")
        if name in m["folder"].values() or name == "Management":
            raise ValueError("%s is already a course from the course map" % name)
        if name in allc and name != old:
            raise ValueError("there is already a mixed course %s" % name)
        try:
            vmids = sorted({int(v) for v in b.get("vmids", [])})
        except (TypeError, ValueError):
            raise ValueError("bad guest list")
        if not vmids:
            raise ValueError("pick at least one guest")
        if len(vmids) > 1000:
            raise ValueError("at most 1000 guests")
        exp = (b.get("expires") or "").strip()
        if exp:
            try:
                time.strptime(exp, "%Y-%m-%d")
            except ValueError:
                raise ValueError("the end date must look like 2026-11-30")
            if exp < time.strftime("%Y-%m-%d"):
                raise ValueError("the end date is in the past")
        prev = allc.pop(old, None) if old and old != name else allc.get(name)
        allc[name] = {"desc": (b.get("desc") or "").strip()[:120], "vmids": vmids, "expires": exp,
                      "by": (prev or {}).get("by", s["user"]), "created": (prev or {}).get("created", time.strftime("%Y-%m-%d"))}
        save_json("courses.json", allc)
        if old and old != name:   # renamed: users who had the old name get the new one
            us = users()
            for u in us.values():
                if isinstance(u.get("courses"), list) and old in u["courses"]:
                    u["courses"] = [name if c == old else c for c in u["courses"]]
            save_json("users.json", us)
    audit(s["user"], "mixed course %s: %d guests%s" % (name, len(vmids), (", until " + exp) if exp else ""))
    autosave(s["user"], "Mixed course %s saved" % name)
    return self.send(200, {"ok": True})


setattr(Handler, "api_mixed", api_mixed)


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
