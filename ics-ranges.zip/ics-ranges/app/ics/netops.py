"""ControlYard - netops (split from server.py; see server.py for the program)."""
import os
import re
import subprocess
import time
from .core import (DATA, OVS_KEY, PVEError, inv, is_sensor, pve)


# ---------------------------------------------------------------------------- build actions: network, disks, migration, add-ons
def net_split(val):
    parts = [p for p in val.split(",") if p]
    return parts


def net_change(g, val, ch):
    """Change bridge / VLAN / firewall / model of one NIC line, keeping the MAC and the rest."""
    parts = net_split(val)
    kv = []
    for p in parts:
        k, _, v = p.partition("=")
        kv.append([k, v])
    keys = [k for k, _ in kv]
    def setk(k, v):
        if v is None:
            return
        if k in keys:
            if v == "":
                kv[:] = [x for x in kv if x[0] != k]
                keys.remove(k)
            else:
                kv[keys.index(k)][1] = v
        elif v != "":
            kv.append([k, v])
            keys.append(k)
    setk("bridge", ch.get("bridge") or None)
    if "vlan" in ch and ch["vlan"] is not None:
        setk("tag", str(ch["vlan"]).strip())
    if ch.get("firewall") in ("on", "off"):
        setk("firewall", "1" if ch["firewall"] == "on" else "0")
    if ch.get("model") and g["type"] == "qemu" and kv and re.match(r"^[0-9A-Fa-f:]{17}$", kv[0][1] or ""):
        kv[0][0] = ch["model"]
    return ",".join(k + (("=" + v) if v != "" else "") for k, v in kv)


DISK_RE = re.compile(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$")
RAW_ONLY = ("lvm", "lvmthin", "zfspool", "rbd", "iscsi", "iscsidirect", "zfs")


def storage_types():
    return {x["storage"]: x.get("type", "") for x in pve.call("GET", "/storage") or []}


# ---------------------------------------------------------------------------- port mirroring (ovs-vsctl over the restricted key)
_IPS = {"t": 0, "ips": {}}   # node -> IP, remembered for 5 minutes: it practically never changes


def node_ip(node):
    if time.time() - _IPS["t"] > 300 or node not in _IPS["ips"]:
        _IPS["ips"] = {x.get("name"): x.get("ip") for x in pve.call("GET", "/cluster/status") or [] if x.get("type") == "node"}
        _IPS["t"] = time.time()
    ip = _IPS["ips"].get(node)
    if not ip:
        raise PVEError("no IP for node %s" % node)
    return ip


def node_cmd(node, *args, timeout=30):
    """Run one allowed command on a node with the restricted key: ovs-vsctl ..., or
    qm enroll-efi-keys <vmid> (the node's key line allows nothing else)."""
    if not os.path.exists(OVS_KEY):
        raise PVEError("the node key isn't set up - see Settings, Node key")
    cmd = ["ssh", "-n", "-i", OVS_KEY, "-o", "BatchMode=yes", "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=8",
           "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=accept-new",
           # one connection per host, reused for a minute - not a new SSH handshake for every command
           "-o", "ControlMaster=auto", "-o", "ControlPersist=60", "-o", "ControlPath=/tmp/ics-ssh-%C",
           "-o", "UserKnownHostsFile=" + os.path.join(DATA, "ssh", "known_hosts"),
           "root@" + node_ip(node)] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode:
        err = (p.stderr or p.stdout).strip()
        if args[:1] == ("qm",) and "only ovs-vsctl" in err:
            raise PVEError("the key line on %s only allows ovs-vsctl - add the new line from Settings, Node key "
                           "(or use 'New EFI disk with keys')" % node)
        raise PVEError(err or "%s failed on %s" % (args[0], node))
    return p.stdout


def ovs(node, *args):
    return node_cmd(node, "ovs-vsctl", *args)


def nic_dev(g, nic):
    n = nic[3:]
    return ("veth%di%s" if g["type"] == "lxc" else "tap%di%s") % (g["vmid"], n)


_BRIDGES = {}


def node_bridges(node):
    """{"ovs": [...], "linux": [...]} - the bridges of a node (cached a minute)."""
    t, b = _BRIDGES.get(node, (0, None))
    if b is None or time.time() - t > 60:
        b = {"ovs": [], "linux": []}
        try:
            for x in pve.call("GET", "/nodes/%s/network" % node, timeout=8) or []:
                if x.get("type") == "OVSBridge":
                    b["ovs"].append(x["iface"])
                elif x.get("type") == "bridge":
                    b["linux"].append(x["iface"])
        except PVEError:
            pass
        _BRIDGES[node] = (time.time(), b)
    return b


def net_summary(course, max_age=120):
    """NICs of a course: how many, which are disconnected, how many have the firewall off.
    max_age=0 reads the configuration fresh (Refresh, opening a course, Ready for class?)."""
    if inv.offline:
        return {"nics": 0, "disconnected": [], "fw_off": 0, "offline": True}
    ids = inv.course_ids(course)
    cfgs = inv.configs(ids, max_age=max_age)
    total, fw_off, down = 0, 0, []
    for v in ids:
        for k, val in sorted(cfgs.get(v, {}).items()):
            if not re.match(r"^net\d+$", k):
                continue
            total += 1
            parts = val.split(",")
            if "firewall=1" not in parts:
                fw_off += 1
            if "link_down=1" in parts:
                g = inv.guests[v]
                down.append({"vmid": v, "name": g["name"], "nic": k, "node": g["node"],
                             "bridge": (re.search(r"bridge=([^,]+)", val) or [None, ""])[1],
                             "sensor": is_sensor(g)})
    return {"nics": total, "disconnected": down, "fw_off": fw_off}
