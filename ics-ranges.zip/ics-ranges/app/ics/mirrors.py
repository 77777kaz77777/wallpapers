"""ICS Ranges - mirrors (split from server.py; see server.py for the program)."""
import json
import os
import re
import subprocess
import time
from .core import (LOCK, PVEError, audit, gpath, inv, is_sensor, load_json, path, pve, save_json, step)
from .content import (COURSE_RE, MIRRORING)
from .netops import (nic_dev, ovs)


def mirrors():
    m = load_json("mirrors.json", [])
    return m if isinstance(m, list) else []


# ---------------------------------------------------------------------------- mirror add-ons
# A mirror add-on copies traffic on an Open vSwitch bridge to one destination port (a VM NIC or a physical NIC):
# everything on the bridge, or chosen ports. Instructors switch it on and off with a button; each one is its own
# OVS mirror ("ics-<id>"), added to the bridge next to the others - activating one never touches another.
MID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,47}$")
IFACE_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,15}$")
_SAMPLES = {}   # id -> (time, tx_packets) - for the traffic rate between two looks
_OVSLIST = {}   # node -> (time, {mirror name: {...}})


def madd_path(mid):
    if not MID_RE.match(mid or ""):
        raise ValueError("bad mirror add-on id")
    return os.path.join(MIRRORING, mid + ".json")


def madd_all():
    out = []
    try:
        names = sorted(os.listdir(MIRRORING))
    except OSError:
        names = []
    for f in names:
        if f.endswith(".json") and MID_RE.match(f[:-5]):
            m = load_json(os.path.join("share", "mirroring", f), None)
            if isinstance(m, dict):
                m["id"] = f[:-5]
                out.append(m)
    return out


def madd_for(course):
    if os.path.exists(path("mirrors.json")) and inv.guests:
        madd_migrate()
    return [m for m in madd_all() if m.get("course") in (course, "_all")]


def madd_check(m):
    """Validate a mirror add-on definition - returns a clean copy."""
    def port(x, what):
        if not isinstance(x, dict):
            raise ValueError("%s: pick a VM NIC or a physical NIC" % what)
        if x.get("kind") == "vm":
            v, nic = int(x.get("vmid") or 0), str(x.get("nic") or "")
            if v <= 0 or not re.match(r"^net\d+$", nic):
                raise ValueError("%s: pick a VM and its NIC" % what)
            return {"kind": "vm", "vmid": v, "nic": nic}
        if x.get("kind") == "phys" and IFACE_RE.match(str(x.get("iface") or "")):
            return {"kind": "phys", "iface": str(x["iface"])}
        raise ValueError("%s: pick a VM NIC or a physical NIC" % what)
    name = str(m.get("name") or "").strip()
    if not 1 <= len(name) <= 60:
        raise ValueError("give it a name (up to 60 characters)")
    course = str(m.get("course") or "")
    if course != "_all" and not COURSE_RE.match(course):
        raise ValueError("pick a course")
    node, bridge = str(m.get("node") or ""), str(m.get("bridge") or "")
    if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", node) or not IFACE_RE.match(bridge):
        raise ValueError("pick a host and a bridge")
    src = m.get("source") or {"all": True}
    if not isinstance(src, dict):
        raise ValueError("pick what to copy")
    if src.get("all"):
        src = {"all": True}
    else:
        ports = [port(x, "What to copy") for x in (src.get("ports") or [])][:16]
        if not ports:
            raise ValueError("pick at least one port to copy - or everything on the bridge")
        direction = src.get("dir") if src.get("dir") in ("both", "in", "out") else "both"
        src = {"all": False, "ports": ports, "dir": direction}
    dest = port(m.get("dest"), "Send the copy to")
    return {"name": name, "desc": str(m.get("desc") or "").strip()[:200], "course": course, "node": node, "bridge": bridge,
            "source": src, "dest": dest, "firewall_off": bool(m.get("firewall_off", True)),
            "button": bool(m.get("button", True)), "active": bool(m.get("active", False))}   # IGMP snooping: not touched


def madd_save(m, mid=None, who="-"):
    m = madd_check(m)
    os.makedirs(MIRRORING, exist_ok=True)
    if not mid:
        base = re.sub(r"[^a-z0-9]+", "-", m["name"].lower()).strip("-")[:36] or "mirror"
        mid, n = base, 2
        while os.path.exists(madd_path(mid)):
            mid, n = "%s-%d" % (base, n), n + 1
    old = load_json(os.path.join("share", "mirroring", mid + ".json"), {}) if os.path.exists(madd_path(mid)) else {}
    m["active"] = bool(old.get("active", m["active"]))   # editing doesn't switch it on or off
    keys = ("node", "bridge", "source", "dest", "firewall_off")
    if old.get("active") and any(old.get(k) != m.get(k) for k in keys):
        m["stale"] = True   # the bridge still has the mirror as it was - until Activate
    for k in ("at", "by", "added") + (("stale",) if old.get("stale") and m.get("active") else ()):
        if k in old:
            m[k] = old[k]
    save_json(os.path.join("share", "mirroring", mid + ".json"), m)
    _VIEW.clear()   # pages show the change at once
    return mid


def port_name(x):
    """OVS port of a VM NIC (tap<vmid>i<n> / veth<vmid>i<n>) or a physical NIC."""
    if x["kind"] == "phys":
        return x["iface"]
    g = inv.guests.get(x["vmid"])
    if not g:
        raise ValueError("guest %d doesn't exist (any more)" % x["vmid"])
    return nic_dev(g, x["nic"])


def port_label(x):
    if x["kind"] == "phys":
        return "physical NIC " + x["iface"]
    g = inv.guests.get(x["vmid"], {})
    return "%d %s %s" % (x["vmid"], g.get("name", "?"), x["nic"])


def madd_equation(m):
    src = "everything on %s" % m["bridge"] if m["source"]["all"] else "%s %s" % (
        {"both": "traffic to and from", "in": "traffic to", "out": "traffic from"}[m["source"]["dir"]],
        ", ".join(port_label(x) for x in m["source"]["ports"]))
    return "%s on %s  →  %s" % (src, m["node"], port_label(m["dest"]))


def madd_ovs_on(m, mid):
    """The ovs-vsctl words that create this add-on's mirror and add it to the bridge."""
    a = ["--", "--id=@out", "get", "port", port_name(m["dest"])]
    sel = ["select-all=true"]
    if not m["source"]["all"]:
        names = []
        for k, x in enumerate(m["source"]["ports"]):
            a += ["--", "--id=@s%d" % k, "get", "port", port_name(x)]
            names.append("@s%d" % k)
        sel = []
        if m["source"]["dir"] in ("both", "out"):
            sel.append("select-src-port=" + ",".join(names))
        if m["source"]["dir"] in ("both", "in"):
            sel.append("select-dst-port=" + ",".join(names))
    a += ["--", "--id=@m", "create", "mirror", "name=ics-" + mid] + sel + ["output-port=@out",
          "--", "add", "bridge", m["bridge"], "mirrors", "@m"]
    return a


def madd_off_now(m, mid):
    _OVSLIST.pop(m["node"], None)   # the next look reads the bridge again
    try:   # gone already is fine
        ovs(m["node"], "--", "--id=@m", "get", "mirror", "ics-" + mid, "--", "remove", "bridge", m["bridge"], "mirrors", "@m")
    except PVEError as e:
        if "no row" not in str(e):
            raise


def madd_set_active(mid, on, who):
    _VIEW.clear()   # the next look reads again
    with LOCK:
        m = load_json(os.path.join("share", "mirroring", mid + ".json"), None)
        if isinstance(m, dict):
            m["active"], m["at"], m["by"] = on, time.strftime("%Y-%m-%d %H:%M"), who
            m.pop("stale", None)
            save_json(os.path.join("share", "mirroring", mid + ".json"), m)


def madd_steps(m, mid, on, who, notes):
    """The stages that switch a mirror add-on on or off."""
    groups = []
    if not on:
        def off(m=m, mid=mid):
            madd_off_now(m, mid)
            cur = load_json(os.path.join("share", "mirroring", mid + ".json"), {})
            for iface in cur.get("added", []):   # physical NICs this add-on put on the bridge go off it again
                try:
                    ovs(m["node"], "--if-exists", "del-port", m["bridge"], iface)
                except PVEError:
                    pass
            if cur.get("added"):
                with LOCK:
                    cur.pop("added", None)
                    save_json(os.path.join("share", "mirroring", mid + ".json"), cur)
            madd_set_active(mid, False, who)
            audit(who, "mirror off: %s" % m["name"])
            return ""
        return [[step("Stop %s" % m["name"], m["node"], off, None)]]
    d = m["dest"]
    if d["kind"] == "vm":
        g = inv.guests.get(d["vmid"])
        if not g:
            raise ValueError("%s: guest %d doesn't exist (any more)" % (m["name"], d["vmid"]))
        if g["status"] != "running":
            raise ValueError("%s: start %d %s first - its NIC only exists on the bridge while it runs" % (m["name"], g["vmid"], g["name"]))
        if g["node"] != m["node"]:
            raise ValueError("%s: %d %s runs on %s, not %s - migrate it back, or edit the add-on" % (m["name"], g["vmid"], g["name"], g["node"], m["node"]))
        cur = inv.configs([g["vmid"]], max_age=0).get(g["vmid"], {}).get(d["nic"], "")
        if not cur:
            raise ValueError("%s: %d has no %s" % (m["name"], g["vmid"], d["nic"]))
        fix, what = [p for p in cur.split(",") if p != "link_down=1"], []
        if "link_down=1" in cur.split(","):
            what.append("connect it")
        if m.get("firewall_off") and "firewall=1" in fix:
            fix, _ = [p for p in fix if p != "firewall=1"], what.append("firewall off")
        if what:   # keeps the MAC address and everything else
            groups.append([step("%d %s %s: %s" % (g["vmid"], g["name"], d["nic"], ", ".join(what)), g["node"],
                                (lambda g=g, nic=d["nic"], new=",".join(fix): pve.task("PUT", gpath(g) + "/config", {nic: new})), g["vmid"])])
    phys = [x for x in [d] + ([] if m["source"]["all"] else m["source"]["ports"]) if x["kind"] == "phys"]
    if phys:
        nics = {n["iface"]: n for n in host_nics(m["node"], m["bridge"])}
        add = []
        for x in phys:
            n = nics.get(x["iface"])
            if not n:
                raise ValueError("%s: %s has no physical NIC %s" % (m["name"], m["node"], x["iface"]))
            if n["used_by"]:
                raise ValueError("%s: %s belongs to %s - it can't be used on %s" % (m["name"], x["iface"], n["used_by"], m["bridge"]))
            if n["free"]:
                add.append(x["iface"])
        if add:
            def add_ports(m=m, mid=mid, add=add):
                for iface in add:
                    ovs(m["node"], "--may-exist", "add-port", m["bridge"], iface)
                with LOCK:
                    f = os.path.join("share", "mirroring", mid + ".json")
                    cur = load_json(f, {})
                    cur["added"] = sorted(set(cur.get("added", [])) | set(add))
                    save_json(f, cur)
                return ""
            groups.append([step("Add %s to %s on %s (while the mirror is active)" % (", ".join(add), m["bridge"], m["node"]), m["node"], add_ports, None)])
    for x in ([] if m["source"]["all"] else m["source"]["ports"]):
        if x["kind"] == "vm" and inv.guests.get(x["vmid"], {}).get("status") != "running":
            notes.append("%s isn't running - its traffic is copied once it runs (then Activate again)" % port_label(x))
    words = madd_ovs_on(m, mid)

    def on_(m=m, mid=mid, words=words):
        madd_off_now(m, mid)   # one mirror per add-on - never two
        ovs(m["node"], *words)
        _OVSLIST.pop(m["node"], None)
        madd_set_active(mid, True, who)
        _SAMPLES.pop(mid, None)
        audit(who, "mirror on: %s (%s)" % (m["name"], madd_equation(m)))
        return ""
    groups.append([step("Start %s: %s" % (m["name"], madd_equation(m)), m["node"], on_, None)])
    return groups


def ovs_mirrors(node, max_age=4):
    """{mirror name: {"packets", "out"}} on a node, read once for all add-ons (a few seconds' cache)."""
    t, r = _OVSLIST.get(node, (0, None))
    if r is not None and time.time() - t < max_age:
        return r
    ports = {}
    for row in json.loads(ovs(node, "--format=json", "--columns=_uuid,name", "list", "port") or "{}").get("data", []):
        ports[row[0][1]] = row[1]
    r = {"_read": time.time()}   # when this reading was taken - rates only compare newer readings
    for row in json.loads(ovs(node, "--format=json", "--columns=_uuid,name,output_port,statistics", "list", "mirror") or "{}").get("data", []):
        stats = dict(row[3][1]) if isinstance(row[3], list) and row[3][0] == "map" else {}
        outp = row[2][1] if isinstance(row[2], list) and row[2][0] == "uuid" else ""
        r[row[1]] = {"packets": int(stats.get("tx_packets", 0)), "out": ports.get(outp, "")}
    _OVSLIST[node] = (time.time(), r)
    return r


def madd_status(m, mid, live):
    """What an instructor needs to know: is it on, does the copy arrive, and if not, why."""
    st = {"active": m.get("active", False), "running": False, "packets": None, "rate": None, "state": "off", "text": "Off"}
    if live is None:
        st.update(state="unknown", text="Can't be checked now - the host doesn't answer")
        return st
    d = m["dest"]
    if d["kind"] == "vm":
        g = inv.guests.get(d["vmid"])
        st["running"] = bool(g and g["status"] == "running")
        if not g:
            st.update(state="problem", text="Guest %d doesn't exist (any more)" % d["vmid"])
            return st
    else:
        st["running"] = True
    mine = live.get("ics-" + mid)
    if mine:
        st["packets"] = mine["packets"]
        prev = _SAMPLES.get(mid)
        read = live.get("_read", time.time())
        if prev and read - prev[0] >= 2:
            st["rate"] = max(0, (mine["packets"] - prev[1]) / (read - prev[0]))
        elif prev:
            st["rate"] = prev[2] if len(prev) > 2 else None   # the same reading as before: keep its rate
        if not prev or read - prev[0] >= 2:
            _SAMPLES[mid] = (read, mine["packets"], st["rate"])
    if not m.get("active"):
        if mine:
            st.update(state="warn", text="Off here, but the mirror still exists on the bridge - Activate or Deactivate to tidy up")
        return st
    if m.get("stale"):
        st.update(state="warn", text="Changed since it was activated - press Activate to apply the change")
    elif not st["running"]:
        st.update(state="problem", text="Active, but %s is off - start it, then Activate again" % port_label(d))
    elif not mine:
        st.update(state="problem", text="Active, but the mirror is missing on the bridge (sensor or host restarted) - press Activate")
    elif st["rate"] is None:
        st.update(state="ok", text="Active · %s packets copied so far" % format(mine["packets"], ","))
    elif st["rate"] >= 0.5:
        st.update(state="ok", text="Active · traffic flowing (≈ %s packets/s)" % format(round(st["rate"]), ","))
    else:
        st.update(state="warn", text="Active · no traffic right now - is anything talking on %s?" % m["bridge"])
    return st


_VIEW = {}   # course -> (time, view) - several pages open at once share one reading


def madd_view(course, max_age=5):
    """The course's mirror add-ons with their live status - one OVS read per host, kept a few seconds."""
    t, v = _VIEW.get(course, (0, None))
    if v is not None and time.time() - t < max_age:
        return v
    v = _madd_view(course)
    _VIEW[course] = (time.time(), v)
    return v


def _madd_view(course):
    adds = madd_for(course)
    live = {}
    for node in {m["node"] for m in adds}:
        try:
            live[node] = ovs_mirrors(node) if not inv.offline else None
        except (PVEError, subprocess.TimeoutExpired, ValueError, OSError):
            live[node] = None
    out = []
    for m in adds:
        try:
            eq = madd_equation(m)
        except (KeyError, ValueError):
            eq = "?"
        out.append(dict(m, equation=eq, dest_label=port_label(m["dest"]), status=madd_status(m, m["id"], live.get(m["node"]))))
    return out


def madd_measure(mid, secs=4):
    """Check traffic: two looks a few seconds apart - does the copy reach the destination?"""
    m = load_json(os.path.join("share", "mirroring", mid + ".json"), None)
    if not isinstance(m, dict):
        raise KeyError("no such mirror add-on")
    a = ovs_mirrors(m["node"], max_age=0).get("ics-" + mid)
    if not a:
        return {"ok": False, "text": "The mirror isn't on the bridge - press Activate first."}
    time.sleep(secs)
    b = ovs_mirrors(m["node"], max_age=0).get("ics-" + mid) or a
    n = max(0, b["packets"] - a["packets"])
    _SAMPLES[mid] = (time.time(), b["packets"], n / secs)
    if n:
        return {"ok": True, "packets": n, "rate": n / secs,
                "text": "Traffic reaches %s: %s packets in %d seconds (≈ %s/s)." % (port_label(m["dest"]), format(n, ","), secs, format(round(n / secs), ","))}
    return {"ok": False, "packets": 0, "text": "No traffic reached %s in %d seconds. The mirror is in place - is anything talking on %s right now?"
            % (port_label(m["dest"]), secs, m["bridge"])}


def madd_from_script(text, course):
    """Turn a script like 'qm set … firewall=0' + 'ovs-vsctl … create mirror …' into mirror add-ons (one per mirror)."""
    t = re.sub(r"\\\r?\n", " ", (text or "").replace("\r\n", "\n"))
    fw_off, notes, out = set(), [], []
    for mm in re.finditer(r"qm\s+set\s+(\d+)\s+--(net\d+)\s+(\S+)", t):
        if "firewall=0" in mm.group(3):
            fw_off.add((int(mm.group(1)), mm.group(2)))
        if not re.search(r"(?:^|,)[a-z0-9]+=[0-9A-Fa-f:]{17}", mm.group(3)):
            notes.append("'qm set %s --%s %s' would give %s a NEW MAC address each time - the add-on turns the firewall off and keeps the MAC."
                         % (mm.group(1), mm.group(2), mm.group(3), mm.group(2)))
    for line in re.findall(r"ovs-vsctl[^\n]*", t):
        words = line.split()
        refs, mirrors, bridge = {}, [], None
        parts, cur = [], []
        for w in words[1:]:
            if w == "--":
                if cur:
                    parts.append(cur)
                cur = []
            else:
                cur.append(w)
        if cur:
            parts.append(cur)
        for p in parts:
            ref = p[0][5:] if p and p[0].startswith("--id=@") else None
            body = p[1:] if ref else p
            if body[:2] == ["get", "port"] and len(body) > 2 and ref:
                refs[ref] = body[2]
            elif body[:2] == ["create", "mirror"]:
                kv = dict(x.split("=", 1) for x in body[2:] if "=" in x)
                mirrors.append(kv)
            elif body[:2] in (["set", "bridge"], ["add", "bridge"]) and len(body) > 2:
                bridge = body[2]
        for kv in mirrors:
            def to_port(name):
                mm = re.match(r"^(tap|veth)(\d+)i(\d+)$", name or "")
                return {"kind": "vm", "vmid": int(mm.group(2)), "nic": "net" + mm.group(3)} if mm else {"kind": "phys", "iface": name}
            dest_name = refs.get(kv.get("output-port", ""), "")
            if not dest_name:
                continue
            dest = to_port(dest_name)
            src = {"all": True}
            sel = [refs.get(r) for k in ("select-src-port", "select-dst-port") for r in kv.get(k, "").split(",") if r]
            if kv.get("select-all") != "true" and sel:
                d = "both" if kv.get("select-src-port") and kv.get("select-dst-port") else "out" if kv.get("select-src-port") else "in"
                src = {"all": False, "ports": [to_port(x) for x in dict.fromkeys(x for x in sel if x)], "dir": d}
            g = inv.guests.get(dest.get("vmid", 0), {})
            node = g.get("node") or (inv.nodes[0] if len(inv.nodes) == 1 else "")
            name = (g.get("name") or dest_name) + " mirror"
            out.append({"name": name[:60], "desc": "From a script (mirror %s)" % kv.get("name", "?"), "course": course, "node": node,
                        "bridge": bridge or "", "source": src, "dest": dest, "button": True,
                        "firewall_off": True if dest.get("kind") != "vm" else ((dest["vmid"], dest["nic"]) in fw_off or True)})
    if not out:
        notes.append("No 'ovs-vsctl … create mirror …' found in the script.")
    return out, notes


def madd_migrate():
    """3.0: mirrors saved with the old Sensors / Network add-ons become mirror add-ons (one per sensor NIC), kept active."""
    old = mirrors()
    if not old or os.path.isdir(MIRRORING):
        return
    n = 0
    for mr in old:
        for e in mr.get("entries", []):
            g = inv.guests.get(e.get("vmid"))
            if not g:
                continue
            try:
                madd_save({"name": "%s mirror" % g["name"], "desc": "Everything on %s to %s %s" % (mr["bridge"], g["name"], e["nic"]),
                           "course": g.get("course") or "_all", "node": mr["node"], "bridge": mr["bridge"], "source": {"all": True},
                           "dest": {"kind": "vm", "vmid": e["vmid"], "nic": e["nic"]}, "firewall_off": True,
                           "button": True, "active": True})
                n += 1
            except ValueError:
                pass
    os.replace(path("mirrors.json"), path("mirrors.json.before-3.0"))
    audit("ics-ranges", "the saved mirrors became %d mirror add-on(s)" % n)
    print("Mirrors: %d saved mirror(s) became mirror add-ons" % n, flush=True)


def host_nics(node, bridge):
    """Every physical NIC of a host for a bridge: on it, free (not in any bridge - can be added while a mirror
    is active), or used by another bridge (never touched)."""
    nets = pve.call("GET", "/nodes/%s/network" % node, timeout=8) or []
    member = {}   # NIC -> bridge it belongs to
    for x in nets:
        if x.get("type") in ("bridge", "OVSBridge"):
            for pn in (x.get("bridge_ports") or x.get("ovs_ports") or "").split():
                member[pn] = x["iface"]
        if x.get("ovs_bridge"):
            member[x["iface"]] = x["ovs_bridge"]
    live = set()
    try:   # what Open vSwitch itself has on the bridge (also ports added outside the network config)
        live = {pn for pn in ovs(node, "list-ports", bridge).split() if not re.match(r"^(tap|veth|fwpr|fwln|fwbr)\d", pn)}
    except (PVEError, subprocess.TimeoutExpired, OSError):
        pass
    out, seen = [], set()
    for x in nets:
        if x.get("type") in ("eth", "bond", "OVSPort", "OVSBond") and x["iface"] not in seen:
            seen.add(x["iface"])
            on = x["iface"] in live or member.get(x["iface"]) == bridge
            used = "" if on else member.get(x["iface"], "")
            out.append({"kind": "phys", "iface": x["iface"], "on": on, "used_by": used, "free": not on and not used,
                        "active": bool(x.get("active"))})
    for pn in sorted(live - seen):   # on the bridge, but not in the network config
        out.append({"kind": "phys", "iface": pn, "on": True, "used_by": "", "free": False, "active": True})
    return out


def node_ports(node, bridge):
    """Ports for the builder: VM NICs on the bridge (any course) and every physical NIC of the host."""
    vm = []
    ids = [v for v, g in inv.guests.items() if g["node"] == node]
    cfgs = inv.configs(ids)
    for v in sorted(ids):
        g = inv.guests[v]
        for k, val in sorted(cfgs.get(v, {}).items()):
            if re.match(r"^net\d+$", k) and "bridge=%s" % bridge in val.split(","):
                vm.append({"kind": "vm", "vmid": v, "nic": k, "name": g["name"], "course": g.get("course") or "", "status": g["status"],
                           "sensor": is_sensor(g)})
    try:
        phys = host_nics(node, bridge)
    except PVEError:
        phys = []
    return {"vm": vm, "phys": phys}
