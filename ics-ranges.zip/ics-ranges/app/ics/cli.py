"""ICS Ranges - cli (split from server.py; see server.py for the program)."""
import os
import re
import sys
import time
from .core import (PVEError, VERSION, audit, gen_password, hash_pw, inv, path, pve, roles, save_json, settings, users)
from .content import (guide_file, read_text)
from .share import (BACKUPS, make_backup, repo_pull, repo_save)
from .netops import (DISK_RE, RAW_ONLY)
from .updates import (fetch_releases, request_install, upd_conf, upd_state, update_connect)
from .mirrors import (madd_all, madd_view)
from .plans import (JOBS, build_plan, plan_view, start_job)
from .kit import (kit_export, kit_import, kit_open)


# ---------------------------------------------------------------------------- command line
def cli(argv):
    """docker compose exec ics-ranges pvr ...  (no sign-in: whoever can run this is the admin)"""
    import getpass
    if not argv or argv[0] in ("-h", "--help", "help"):
        print("""pvr users                          list web users
pvr users add NAME --role R [--courses 613,NetWars] [--password P]
pvr users passwd NAME              new generated password
pvr users role NAME ROLE           change the role
pvr users courses NAME 613,NetWars|*
pvr users unlock NAME              clear a lock-out (restart not needed)
pvr users del NAME
pvr roles                          roles and what they may do
pvr courses                        courses and guest counts
pvr list --course C                guests of a course: status, node, snapshots
pvr storage --course C             storages and the course's disks
pvr mirror-status [--course C]     mirror add-ons: active or off, and whether the copy arrives
pvr guide --course C               print the class guide
pvr node-key                       the lines that put the node key on a node
pvr kit export FILE                everything in one encrypted file (password from $KIT_PASSWORD or typed)
pvr kit import FILE                put a kit file back - users, roles, settings, guides, add-ons ...
pvr update                         this version, the host updater, and the releases in the repository
pvr update install v3.1.4          ask the host's updater to install that version
pvr update connect URL USER [--insecure]   connect the repository (token from $PVR_TOKEN or typed)
pvr run ACTION --course C [--snapshot S] [--ids 510101,510102] [--yes] [--hard]
                                   mirrors: pvr run mirror_on|mirror_off --course C --id ADD-ON-ID (ids: pvr mirror-status)
    ACTION: class_start class_end power_on power_off snap_take snap_restore snap_delete mirror_apply
    snap_restore also takes --after leave|start|off
pvr save "message"                 save to the history / your repository
pvr pull                           get the latest from your repository
pvr backup                         make a backup""")
        return 0
    cmd, rest = argv[0], argv[1:]
    def opt(name, default=None):
        if name in rest:
            i = rest.index(name)
            return rest[i + 1] if i + 1 < len(rest) else default
        return default
    if cmd == "users":
        us = users()
        if not rest:
            for n, u in sorted(us.items()):
                print("%-20s %-12s %-28s 2FA %s" % (n, u.get("role"), u.get("courses") if u.get("courses") == "*" else ",".join(u.get("courses", [])), "on" if u.get("totp") else "off"))
            return 0
        sub, name = rest[0], (rest[1] if len(rest) > 1 else "")
        if sub == "add":
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name) or name in us:
                print("bad or existing name"); return 1
            pw = opt("--password") or gen_password()
            role = opt("--role", "instructor")
            if role != "admin" and role not in roles():
                print("no role %s" % role); return 1
            c = opt("--courses", "*")
            us[name] = {"hash": hash_pw(pw), "role": role, "courses": "*" if c == "*" else sorted(c.split(",")), "totp": ""}
            save_json("users.json", us)
            print("User %s added (%s). Password: %s" % (name, role, pw if not opt("--password") else "(as given)"))
        elif name not in us:
            print("no user %s" % name); return 1
        elif sub == "passwd":
            pw = gen_password()
            us[name]["hash"] = hash_pw(pw)
            save_json("users.json", us)
            print("New password for %s: %s" % (name, pw))
        elif sub == "role":
            r = rest[2] if len(rest) > 2 else ""
            if not r:
                print("usage: pvr users role NAME ROLE   (roles: pvr roles)"); return 1
            if r != "admin" and r not in roles():
                print("no role %s" % r); return 1
            us[name]["role"] = r
            save_json("users.json", us)
            print("%s is now %s" % (name, r))
        elif sub == "courses":
            c = rest[2] if len(rest) > 2 else "*"
            us[name]["courses"] = "*" if c == "*" else sorted(c.split(","))
            save_json("users.json", us)
            print("%s may use: %s" % (name, c))
        elif sub == "unlock":
            print("Lock-outs are kept in memory - restart to clear them: docker compose restart")
        elif sub == "del":
            del us[name]
            save_json("users.json", us)
            print("%s deleted" % name)
        audit("cli", "users %s %s" % (sub, name))
        return 0
    if cmd == "roles":
        print("%-14s %s" % ("admin", "(everything)"))
        for r, ps in roles().items():
            print("%-14s %s" % (r, " ".join(ps)))
        return 0
    if cmd == "courses":
        inv.refresh(force=True)
        cnt = {}
        for g in inv.guests.values():
            cnt.setdefault(g["course"], [0, 0])
            cnt[g["course"]][0] += 1
            cnt[g["course"]][1] += g["status"] == "running"
        for c, (n, r) in sorted(cnt.items()):
            print("%-14s %3d guests, %d running" % (c, n, r))
        return 0
    if cmd == "list":
        course = opt("--course", "")
        inv.refresh(force=True)
        ids = inv.course_ids(course)
        if not ids:
            print("no guests in %r - pvr courses" % course); return 1
        snaps = inv.snapshots(ids)
        print("%-8s %-4s %-12s %-8s %-24s %-34s %s" % ("VMID", "TYPE", "NODE", "STATUS", "NAME", "GROUP", "SNAPSHOTS"))
        for v in ids:
            g = inv.guests[v]
            print("%-8d %-4s %-12s %-8s %-24s %-34s %s" % (v, "CT" if g["type"] == "lxc" else "VM", g["node"], g["status"], g["name"][:24], g["label"][:34],
                                                         " ".join(x["name"] + ("+mem" if x["ram"] else "") for x in snaps.get(v, []))))
        return 0
    if cmd == "storage":
        course = opt("--course", "")
        inv.refresh(force=True)
        cfgs = inv.configs(inv.course_ids(course))
        print("STORAGES")
        for x in pve.call("GET", "/storage") or []:
            print("  %-16s %-10s %s" % (x["storage"], x.get("type", ""), "raw only" if x.get("type") in RAW_ONLY else "qcow2 raw vmdk"))
        print("DISKS IN %s" % course)
        for v, c in sorted(cfgs.items()):
            for k, val in sorted(c.items()):
                if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]:
                    vol = val.split(",")[0]
                    print("  %-8d %-10s %-16s %s" % (v, k, vol.split(":")[0], "qcow2" if vol.endswith(".qcow2") else "raw"))
        return 0
    if cmd == "mirror-status":   # the mirror add-ons and whether they deliver
        course = opt("--course")
        inv.refresh(force=True)
        courses = [course] if course else sorted({m.get("course") for m in madd_all() if m.get("course") != "_all"} | (
            {g.get("course") for g in inv.guests.values() if g.get("course")} if any(m.get("course") == "_all" for m in madd_all()) else set()))
        shown = set()
        for c_ in courses:
            for m in madd_view(c_, max_age=0):
                if m["id"] in shown:
                    continue
                shown.add(m["id"])
                st = m["status"]
                print("%-24s %-7s %s" % (m["name"][:24], "ACTIVE" if m.get("active") else "off", st["text"]))
                print("%-24s         %s  (id %s, for %s)" % ("", m["equation"], m["id"], "all courses" if m["course"] == "_all" else m["course"]))
        if not shown:
            print("No mirror add-ons%s - make them under Add-ons -> Port mirroring" % (" for " + course if course else ""))
        return 0
    if cmd == "kit":
        sub = rest[0] if rest else ""
        f = rest[1] if len(rest) > 1 else "-"
        if sub not in ("export", "import", "env") or (f == "-" and (sys.stdout.isatty() if sub == "export" else sys.stdin.isatty())):
            print("usage: pvr kit export FILE | pvr kit import FILE | pvr kit env FILE   (- = stdout / stdin; password from KIT_PASSWORD or asked)")
            return 1
        pw = os.environ.get("KIT_PASSWORD") or __import__("getpass").getpass("Kit password: ")
        if sub == "export":
            data = kit_export(pw, "cli")
            (sys.stdout.buffer.write(data) if f == "-" else open(f, "wb").write(data))
            if f != "-":
                print("Kit saved: %s (%d KB)" % (f, len(data) // 1024))
            return 0
        if sub in ("import", "env"):
            blob = sys.stdin.buffer.read() if f == "-" else open(f, "rb").read()
            if sub == "env":   # the Proxmox settings in the kit, as .env lines (for setup.sh import)
                man, _ = kit_open(blob, pw)
                for k, v in (man.get("env") or {}).items():
                    print("%s=%s" % (k, v))
                return 0
            man, before = kit_import(blob, pw, "cli")
            print("Kit imported - made %s by %s (version %s), users: %s" % (man.get("made"), man.get("by"), man.get("version"), ", ".join(man.get("users", []))))
            print("The state before is kept as backups/%s" % before)
            return 0
        print("usage: pvr kit export FILE | pvr kit import FILE | pvr kit env FILE   (FILE - = stdin/stdout; password from $KIT_PASSWORD)")
        return 2
    if cmd == "update":
        if rest[:1] == ["connect"]:
            if len(rest) < 3:
                print("usage: pvr update connect URL USER [--insecure]   (token from $PVR_TOKEN, or typed)"); return 2
            token = os.environ.get("PVR_TOKEN") or (sys.stdin.readline() if not sys.stdin.isatty() else
                                                     __import__("getpass").getpass("Read-only token: "))
            rel = update_connect("cli", rest[1], rest[2], token, "--insecure" in rest)
            print("Connected - %d release(s) found." % len(rel))
            return 0
        if rest[:1] == ["install"]:
            tag = rest[1] if len(rest) > 1 else ""
            print("Requested %s - the host's updater installs it now; follow it with: pvr update" % request_install("cli", tag)["tag"])
            return 0
        st = upd_state()
        print("This version:  %s" % VERSION)
        print("Repository:    %s" % (upd_conf().get("url") or "not connected (web page: Software updates)"))
        print("Host updater:  %s" % (("set up, allows %s" % st["pinned"]) if st["installed"] else "not set up (on the host: sudo ./setup.sh updater)"))
        if st["state"]:
            print("Last update:   %s %s - %s (%s)" % (st["version"], st["state"], st["message"], st["at"]))
        if upd_conf().get("url"):
            try:
                rels = fetch_releases()
                if not rels:
                    print("Releases:      none yet - publish one with ./release.sh")
                for r in rels[:10]:
                    print("  %-10s %-8s %s%s" % (r["tag"], r["relation"], r["date"], "" if r["installable"] else "  (missing: %s)" % ", ".join(r["missing"])))
            except PVEError as e:
                print("Releases:      %s" % e)
        return 0
    if cmd == "node-key":   # just the lines to run on a node - no log prefixes
        t = read_text(path("ssh/node-key.txt"))
        if not t:
            print("No node key yet - it's made when the container starts."); return 1
        print(t, end="" if t.endswith("\n") else "\n"); return 0
    if cmd == "guide":
        t = read_text(guide_file(opt("--course", "")))
        if t is None:
            t = read_text(guide_file(opt("--course", ""))[:-3] + ".txt")
        print(t if t is not None else "No class guide for this course.")
        return 0
    if cmd == "run":
        action = rest[0] if rest else ""
        course = opt("--course", "")
        if not action or action.startswith("--") or not course:
            print("usage: pvr run ACTION --course C [--snapshot S] [--ids 510101,510102] [--id MIRROR] [--yes]"); return 1
        inv.refresh(force=True)
        if not inv.course_ids(course):
            print("no guests in '%s' - pvr courses" % course); return 1
        ids = [int(x) for x in (opt("--ids") or "").split(",") if x.strip().isdigit()] or inv.course_ids(course)
        snap = opt("--snapshot") or settings()["default_snapshot"]
        body = {"action": action, "course": course, "ids": ids, "snapshot": snap, "restore": ids, "start": ids, "off": ids, "id": opt("--id") or "",
                "after": opt("--after", "leave"),
                "mode": "stop" if "--hard" in rest else "shutdown", "title": "%s %s (command line)" % (action, course)}
        us = users()
        admin = next((n for n, u in us.items() if u.get("role") == "admin"), None)
        if not admin:
            print("create the first admin first (open the web page)"); return 1
        pid = build_plan(admin, body)
        v = plan_view(pid)
        for i, g in enumerate(v["groups"]):
            print("Stage %d:" % (i + 1))
            for st in g:
                print("  [%s] %s" % (st["node"], st["label"]))
        for n in v["notes"]:
            print("  note: " + n)
        if not v["count"]:
            print("Nothing to do."); return 0
        if "--yes" not in rest and input("Run %d step(s)? [y/N] " % v["count"]).lower() not in ("y", "yes"):
            return 1
        jid = start_job(admin, pid)
        while JOBS[jid]["state"] != "done":
            time.sleep(0.5)
        bad = 0
        for g in JOBS[jid]["steps"]:
            for st in g:
                print("  %-7s %s %s" % (st["state"], st["label"], st["msg"]))
                bad += st["state"] == "failed"
        return 1 if bad else 0
    if cmd == "save":
        print(repo_save("cli", " ".join(rest) or "Saved from the command line")); return 0
    if cmd == "pull":
        print(repo_pull("cli")); return 0
    if cmd == "backup":
        sub = rest[0] if rest else ""
        if sub == "list":
            fs = sorted((f for f in os.listdir(BACKUPS) if f.endswith(".tar.gz")), reverse=True) if os.path.isdir(BACKUPS) else []
            for f in fs:
                st_ = os.stat(os.path.join(BACKUPS, f))
                print("%-40s %8d KB  %s" % (f, st_.st_size // 1024, time.strftime("%Y-%m-%d %H:%M", time.localtime(st_.st_mtime))))
            print("%d backup(s) in %s" % (len(fs), BACKUPS))
            return 0
        if sub:
            print("usage: pvr backup          make a backup now\n       pvr backup list     the backups there are")
            return 1
        print("Backup %s made." % make_backup()); return 0
    del getpass
    print("unknown command - pvr help")
    return 1
