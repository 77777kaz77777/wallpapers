"""ControlYard - addons (split from server.py; see server.py for the program)."""
import os
import re
import shutil
import signal
import subprocess
import threading
from .core import (DATA, PVEError, inv)
from .content import (addon_meta, read_text)


def run_addon(user, course, f, ids, buf):
    meta = addon_meta(read_text(f), os.path.basename(f))
    # the add-on gets its course's guests: a table (vmid node type name) so qm / pct find a guest without
    # asking Proxmox, and the list of VMIDs it may touch (ICS_SCOPE) - nothing outside its course
    import tempfile
    scope = sorted(inv.course_ids(course))
    run_dir = tempfile.mkdtemp(prefix="addon-")
    table = os.path.join(run_dir, "guests")
    with open(table, "w") as t:
        for v in scope:
            g = inv.guests.get(v)
            if g:
                t.write("%d %s %s %s\n" % (v, g["node"], g["type"], re.sub(r"\s+", "_", g["name"] or "-")))
    env = dict(os.environ, COURSE=course, PVE_RANGE_FOLDER=course, GUESTS=" ".join(map(str, ids)),
               PVE_RANGE_API="1", PVE_RANGE_GUI="1", PVE_RANGE_USER=user, LC_PVERANGE_USER=user,
               ICS_SCOPE=" ".join(map(str, scope)), ICS_GUESTS_FILE=table, TMPDIR=run_dir,
               ICS_NODE=meta["node"] or (sorted({inv.guests[v]["node"] for v in scope if v in inv.guests} or set(inv.nodes))[:1] or [""])[0],
               ICS_KIND=meta["kind"],
               PVE_RANGE_DATA=DATA, PATH="/usr/local/lib/ics-ranges/api:" + os.environ.get("PATH", ""))
    try:
        return _run_addon(f, env, buf)
    finally:
        shutil.rmtree(run_dir, ignore_errors=True)


ADDON_LIMIT = int(os.environ.get("ICS_ADDON_LIMIT", "1800"))   # seconds an add-on may run
MCSNOOP_RE = re.compile(r"^(\s*)echo\s+([01])\s*>\s*/sys/class/net/([A-Za-z0-9_.-]+)/bridge/multicast_snooping\s*$", re.M)


def _run_addon(f, env, buf):
    text = read_text(f) or ""
    new = text.replace("\r\n", "\n").replace("\r", "\n")   # saved on Windows: Unix line ends
    # the host's /sys isn't in the container: "echo 1 > /sys/class/net/vmbr1/bridge/multicast_snooping"
    # becomes "mcsnoop vmbr1 on" - it runs on the host through the node key
    new = MCSNOOP_RE.sub(lambda m: '%secho "(on the host: mcsnoop %s %s)"; mcsnoop %s %s' % (m.group(1), m.group(3), "on" if m.group(2) == "1" else "off",
                                                                                     m.group(3), "on" if m.group(2) == "1" else "off"), new)
    if new != text:
        f = os.path.join(env["TMPDIR"], "addon.sh")
        with open(f, "w") as fh:
            fh.write(new)
    # its own process group, so a stop ends everything the script started too
    p = subprocess.Popen(["bash", f], cwd="/tmp", env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         start_new_session=True)
    timed_out = []

    def watchdog():   # 30 minutes, whether or not the script prints anything
        timed_out.append(1)
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except OSError:
            pass
    timer = threading.Timer(ADDON_LIMIT, watchdog)
    timer.daemon = True
    timer.start()
    size, cut = 0, False
    try:
        for line in p.stdout:
            size += len(line)
            if size < 400_000:
                buf.append(line)
            elif not cut:
                cut = True
                buf.append("\n[more than 400 KB of output - the rest isn't shown]\n")
        rc = p.wait()
    finally:
        timer.cancel()
        try:   # nothing it started lives on after it
            os.killpg(p.pid, signal.SIGKILL)
        except OSError:
            pass
    if timed_out:
        limit = "%d minutes" % (ADDON_LIMIT // 60) if ADDON_LIMIT >= 120 else "%d seconds" % ADDON_LIMIT
        buf.append("\n[stopped after %s - with everything it started]\n" % limit)
        raise PVEError("stopped after %s - add-ons may run that long at most" % limit)
    if rc:
        raise PVEError("the add-on ended with exit code %d" % rc)
    return ""
