#!/bin/sh
# Start-up: HTTPS certificate and the port-mirroring key on first start, then the server.
set -e
if [ ! -f /app/server.py ]; then
    echo "entrypoint.sh starts ICS Ranges inside its container - don't run it by hand."
    echo "Start it with:  ./setup.sh   (or: docker compose up -d --build)"
    exit 1
fi
D=${DATA_DIR:-/data}
mkdir -p "$D/tls" "$D/ssh"
chmod 700 "$D/ssh"
if [ ! -s "$D/tls/cert.pem" ]; then
    san="DNS:ics-ranges,DNS:localhost"
    [ -n "$KEY_FROM" ] && san="$san,IP:$KEY_FROM"
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -subj "/CN=ics-ranges" \
        -addext "subjectAltName=$san" -keyout "$D/tls/key.pem" -out "$D/tls/cert.pem" 2>/dev/null
    chmod 600 "$D/tls/key.pem"
    echo "Made an HTTPS certificate for this page (self-signed)."
fi
if [ ! -s "$D/ssh/ovs_ed25519" ]; then
    ssh-keygen -q -t ed25519 -N "" -C "ics-ranges-ovs" -f "$D/ssh/ovs_ed25519" ||
        echo "Couldn't make the port-mirroring key - mirroring stays off."
fi
if [ -s "$D/ssh/ovs_ed25519.pub" ]; then
    # The key may run only: ovs-vsctl ... (port mirroring) and qm enroll-efi-keys <vmid> (EFI keys).
    # The command is never handed to a shell, so ; | $( ) can't add anything.
    from=""
    [ -n "$KEY_FROM" ] && from="from=\"$KEY_FROM\","
    cat >"$D/ssh/node-key.txt" <<KEYEOF
sed -i '/pve-range-gui-ovs\$/d; /ics-ranges-ovs\$/d' /etc/pve/priv/authorized_keys
cat >>/etc/pve/priv/authorized_keys <<'KEY'
${from}restrict,command="c=\$SSH_ORIGINAL_COMMAND; case \\"\$c\\" in 'ovs-vsctl '*) exec \$c ;; 'qm enroll-efi-keys '*) v=\${c#qm enroll-efi-keys }; case \\"\$v\\" in ''|*[!0-9]*) ;; *) exec qm enroll-efi-keys \\"\$v\\" ;; esac ;; esac; echo only ovs-vsctl and qm enroll-efi-keys >&2; exit 1" $(cat "$D/ssh/ovs_ed25519.pub")
KEY
KEYEOF
    echo "------------------------------------------------------------------------------"
    echo " Optional - the node key, for port mirroring and EFI keys (the API can't do them)."
    echo " It can ONLY run ovs-vsctl and 'qm enroll-efi-keys <vmid>'. Add it once - easiest:"
    echo
    echo "     ./setup.sh node-key 192.168.77.77      (any node's IP; asks for its root password)"
    echo
    echo " Or in the web page: Settings, Node key - Copy or Download."
    echo " Or print just the lines:  docker compose exec ics-ranges pvr node-key"
    echo "------------------------------------------------------------------------------"
fi
exec python3 /app/server.py
