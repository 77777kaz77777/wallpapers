# ICS Ranges – User guide

For ICS Ranges 3.0.0 – the web console for the Proxmox training ranges. For instructors and admins.
To install, update or publish ICS Ranges, see [SETUP-GUIDE.md](SETUP-GUIDE.md).

- [1. Getting started](#1-getting-started)
- [2. Courses and guests](#2-courses-and-guests)
- [3. Running a class](#3-running-a-class)
- [4. Power and snapshots](#4-power-and-snapshots)
- [5. The Add-ons panel and the Network tab](#5-the-add-ons-panel-and-the-network-tab)
- [6. Class guides](#6-class-guides)
- [7. Add-ons](#7-add-ons)
- [8. Build – network, disks, migration, EFI keys](#8-build--network-disks-migration-efi-keys)
- [9. Storage and disks](#9-storage-and-disks)
- [10. Mixed courses](#10-mixed-courses)
- [11. Admin – users, roles, course map, activity](#11-admin--users-roles-course-map-activity)
- [12. Admin – settings, node key, groups, themes](#12-admin--settings-node-key-groups-themes)
- [13. Save & share and backups](#13-save--share-and-backups)
- [14. Software updates](#14-software-updates)
- [15. Your account](#15-your-account)
- [16. Command line (pvr)](#16-command-line-pvr)
- [17. Troubleshooting](#17-troubleshooting)

---

## 1. Getting started

**Open ICS Ranges** at `https://<ics-ranges-host>:8443` (in the lab: `https://192.168.77.91:8443`).
Each kit has its own certificate, so the browser warns the first time – accept it.

**Sign in** with the name and password your admin gave you, plus the 6-digit code from your
authenticator app if 2FA is on for you.

- Five wrong passwords lock your name for 10 minutes – an admin can unlock it at once.
- After 15 minutes without activity you are signed out.
- On a brand-new install, the first visit asks for the first admin, who then adds everyone else.

**The screen**

| Where | What |
|---|---|
| Left bar | The ICS Ranges logo and version, your courses with *running / total* guests, the admin pages you may use, **Help**, and at the bottom **Account** and **Sign out** |
| Top of a course | Its name, how many guests run and are off, **Refresh** |
| **Class** panel | **Ready for class?**, the class snapshot, **Start class** and **End class** |
| **Add-ons** panel | A button per add-on: mirrors to the sensors (**Activate** / **Deactivate**, is the copy arriving?) and scripts made into buttons (**Run**) |
| Tabs | **Guests**, **Class guide**, **Storage and disks** – admins also **Add-ons** and **Network** |

Colour always means a state: **green** running or done · **grey** off · **amber, blinking** busy ·
**red** failed or not mirrored.

**Who can do what** – the roles ICS Ranges starts with; an admin can change them (section 11):

| | admin | instructor | viewer |
|---|:-:|:-:|:-:|
| Ready for class? | ✓ | ✓ | ✓ |
| Start class, End class, Power on / off | ✓ | ✓ | |
| Add-ons panel: see the add-ons and whether the mirrors deliver | ✓ | ✓ | ✓ |
| Add-ons panel: Activate / Deactivate mirrors, Run add-on buttons | ✓ | ✓ | |
| Add-ons tab (make VM, host and mirror add-ons), Network tab | ✓ | | |
| Read class guides, Storage and disks | ✓ | | ✓ |
| Snapshots (and Restore in Start class), write class guides, run and make add-ons | ✓ | | |
| Network, disks, migration, EFI keys | ✓ | | |
| Users, roles, course map, settings, Save & share, Software updates, kit backup | ✓ | | |

You only see your own courses and the buttons your role allows. **Help** in the left bar lists
exactly what you can do.

---

## 2. Courses and guests

**Pick a course** in the left bar. Everything you do stays inside that course.

Courses come from the VMIDs, read as **AABCDD** – AA the course, B the version (or module, rack),
C the group, DD the number:

| VMIDs | Course |
|---|---|
| below 100000 | Management |
| 40xxxx | SANS |
| 50xxxx | 612 |
| 51xxxx | 613 |
| 52xxxx | NetWars |
| 53xxxx | 727 |

**The Guests tab** lists the course's guests by group (*Services*, *Lvl 3 Servers*,
*Enterprise Clients* …): status lamp, VMID, name and meaning (`613 v0 Enterprise Clients #01`),
VM or container, node and snapshots (a dashed one includes memory). It refreshes every
10 seconds by itself; **Refresh** reads it at once.

**Select guests** for power, snapshots, build actions and add-ons:

- tick them, or tick the header box for every guest shown;
- type in **Filter** – name, VMID, tag or node;
- or **Select…**:

| Select by | Example |
|---|---|
| VMID range | `510400-510430, 510500` |
| Group (from the VMID) | *Enterprise Clients* |
| Proxmox tag | `sensor` |
| Name pattern | `ews\|ows` |
| Node | pve2 |
| Saved group | a list an admin saved (section 12) |
| Running / off / every guest / nothing | – |

Tick *Add to what's already selected* to combine several choices.

---

## 3. Running a class

**End class** resets the guests to the class snapshot (normally *ClassStart*) and switches them
off. **Start class** powers them on for the next class.

### Before class – Ready for class?

**Ready for class?** at the top of the Class panel checks the course and answers green, amber or
red for each point – with the guests concerned and what to do. At the top it sums up:
*Ready for class*, *Ready, with N warnings*, or *Not ready – N problems to fix first*.

| Check | Red or amber when |
|---|---|
| Proxmox answers | Proxmox can't be reached, or a node with guests of this course is off |
| Class snapshot | Guests don't have it – Start / End class can't reset them (**Take a snapshot on these**) |
| Snapshot age | Some guests' copy is more than a week older than the others' |
| Locked guests | A guest is locked, e.g. by a backup still running – it can't be started or restored |
| Network | A NIC is disconnected – that guest can't talk on that network |
| Mirrors | An active mirror add-on doesn't deliver – its sensor is off, or the mirror is gone after a restart |
| Storage | A storage the course uses is 85 % full or more |
| Running now | (information) how many guests run – before class they are usually off |

**Check again** after fixing something. It only reads – nothing is changed. Instructors and viewers
can run it too.

### Start class and End class

1. In the **Class** panel check the **Class snapshot** – the list shows how many guests have each.
2. Press **Start class** or **End class**. The course's class guide is shown at the top.
3. The guests are listed **by group** (*Services*, *Lvl 3 Servers* …). Each group has its own tick –
   untick a group to leave all its guests out, or untick single guests (e.g. Kali boxes, servers
   students worked on). Left-out guests are dimmed.
4. **Review the steps** – every step, in stages that run at the same time, with notes on what is
   skipped and why. Nothing has run yet. Then **Run** and watch each step.

| Window | Columns | Does |
|---|---|---|
| End class (everyone) | **Reset** | Resets each ticked guest to the snapshot and switches it off. A guest without the snapshot is only switched off |
| Start class (instructors) | **Start** | Powers the ticked guests on as they are – End class already reset them |
| Start class (admins, and roles with *Restore snapshots*) | **Restore** and **Start** | Restore first, power on, or both – per guest |

The buttons say what they will do for you: Start class shows *Power the guests on* (instructors) or
*Restore the snapshot, then power on* (admins); End class shows *Reset to the snapshot and switch off*.

**Sensors:** Start class doesn't touch the mirrors – after starting the sensors, press **Activate** on
each mirror (or **Re-activate all**) in the Add-ons panel (section 5).

**End class – guests without the class snapshot:** they can't be reset, so a ticked one is only
switched off. If any such guest is running, the window asks how: *shut down gracefully* (forced off
after the shutdown timeout, 180 seconds by default) or *power off at once*. Unticked guests are
left exactly as they are.

Containers start before VMs. A snapshot **with memory** brings the guest back running, so it isn't
started twice.

---

## 4. Power and snapshots

Select guests first. Every action shows its steps for review before it runs.

- **Power on** starts them as they are – nothing is restored.
- **Power off** asks how: *shut down gracefully* (forced off after the timeout) or *power off at once*.

**Snapshots…** (admins by default):

| Choice | Options |
|---|---|
| Take a new snapshot | A name starting with a letter. Running guests: *leave running*, *shut down first* (cleanest; they stay off) or *shut down after*. *Include the memory* of running VMs. *Replace* one with the same name. |
| Restore a snapshot | Which one, then afterwards: *leave them*, *power them on* or *make sure they're off*. Guests without it are left alone. |
| Delete a snapshot | From every selected guest that has it. |

---

## 5. The Add-ons panel and the Network tab

### The Add-ons panel (everyone)

Right of the Class panel: **a button for each add-on** an admin made for this course.

**Mirror add-ons** copy the traffic on a bridge to a sensor. Each sensor is its own button:

| Shown | Means |
|---|---|
| grey · *Off* | Not copying – press **Activate** |
| green · *Active · traffic flowing (≈ 173 packets/s)* | Working – the sensor gets the copy |
| green · *Active · 302 packets copied so far* | Working – the rate shows at the next refresh |
| amber · *Active · no traffic right now* | The mirror is in place, but nothing is talking on the bridge at the moment |
| red · *Active, but … is off* / *the mirror is missing* | Start the sensor, then **Activate** again (mirrors disappear when a sensor restarts or a host reboots) |

- **Activate** – the sensor's NIC is connected and its firewall turned off (its MAC stays), then this
  one mirror is added to the bridge. Other mirrors on the bridge are never touched. The sensor must be
  running.
- **Deactivate** – removes this one mirror.
- **Check traffic** – watches for 4 seconds and says plainly whether the copy reaches the sensor:
  *✓ Traffic reaches 501402 612-Srv-Dragos-Sensor-1 net1: 710 packets in 4 seconds (≈ 178/s).*
- **Re-activate all** – after a reboot or a sensor restart: every active mirror of the course again.

**Script buttons** (VM or host add-ons an admin marked as buttons) have **Run**.

### The Network tab (admins)

The course's network cards on one bridge at a time, **by group** (a tick per group), with a filter:

| Column | Ticked means |
|---|---|
| **Firewall** | The Proxmox firewall filters this NIC. It often blocks multicast and industrial protocols – untick where traffic must flow freely |
| **Connected** | The virtual cable is plugged in. Untick to pull it – e.g. to cut a segment during an exercise |
| **VLAN** | The VLAN tag the NIC's traffic carries (1–4094); empty for none. Guests that should talk need the same tag |

**Review the changes** lists only what actually changes, then **Run**. Disconnected NICs are listed at
the top, with **Connect them…** (untick any that should stay disconnected). Port mirroring isn't here –
it's in **Add-ons → Port mirroring**.

---

## 6. Class guides

Each course can have a class guide – how it is run, which snapshot, what to keep, which add-ons to
use. It shows on the **Class guide** tab and at the top of the Start class and End class windows.

| Button | Does |
|---|---|
| Write a guide / Edit | Opens the editor; a new guide starts from a template. `#` makes a heading, `-` a list item, `**bold**`, `*italic*`, `` `code` `` and `[text](https://…)` a link |
| Upload | A `.md` or `.txt` file |
| Import | From a web address, e.g. a file on Gitea or GitHub |
| Download / Delete | Save it to your computer / remove it |

---

## 7. Add-ons

An add-on is a job set up once and run with one click. Admins make them on the **Add-ons** tab, which
has three tabs:

| Tab | Holds | Typical use |
|---|---|---|
| **VM add-ons** | Scripts or steps that work on the course's guests (`qm`, `pct`, `pvesh`) | Reset student desktops, snapshot before changes, health check |
| **Host add-ons** | Scripts for a Proxmox host – `ovs-vsctl` works there (through the node key) | Your own Open vSwitch commands |
| **Port mirroring** | Mirror add-ons, built from drop-downs | Copy a bridge's traffic to a sensor |

Any add-on can be ticked **Show as a button for instructors** – it then appears in the Add-ons panel of
the course (section 5). That's how a script you already have becomes a button: paste it, tick, save.

### Port mirroring – mirror add-ons (admins)

**Add-ons → Port mirroring → New mirror…**, then pick from the lists:

| Field | Choose |
|---|---|
| Name / What it's for | What instructors see on the button, e.g. *Dragos Sensor 1* |
| For | This course, or all courses |
| Host, Bridge | Where the traffic is – an **Open vSwitch** bridge (Linux bridges are shown, but can't mirror) |
| What to copy | **Everything on the bridge**, or **only some ports** – VM NICs or physical NICs – with *to and from them*, *only to them* or *only from them* |
| Send the copy to | The sensor: a VM's NIC (this course's VMs first, then others on the bridge), or a **physical NIC** with a sensor appliance behind it |
| Options | *Turn the firewall off on that NIC (and connect it)*, *Let multicast through* (IGMP snooping off while active), *Show as a button for instructors* |

The line at the bottom says what it will do, e.g. **everything on vmbr2 on pve1 ⟶ 501402 612-Srv-Dragos-Sensor-1 net1**.

**From a script…** – paste the script you use now (`qm set … firewall=0`, `ovs-vsctl … create mirror …`).
Each mirror in it becomes its own mirror add-on – its own button. If the script's `qm set` line would
give the NIC a new MAC address (`virtio,bridge=…` without a MAC), it says so: the add-on turns the
firewall off and keeps the MAC.

### Run an add-on

1. **Add-ons** → **Run** next to it.
2. If it works on guests and none are ticked on the Guests tab, a window asks which – tick them
   (or **All** / **Running**) and press **Run on these**. If guests are ticked, it uses those.
3. Check the steps, then **Run**. You see the result for each guest, live.

### Make an add-on (admins by default)

**Add-ons → VM add-ons → New VM add-on**. The quickest way: **Start from an example** at the top – one click fills
in everything, then change what you like:

| Example | Does |
|---|---|
| Reset student desktops | Restore *ClassStart*, wait 10 seconds, power on one by one |
| Snapshot before changes | A snapshot named *Before-<today's date>* |
| Power on one by one | 30 seconds apart – so servers don't all boot at once |
| Shut down gracefully | Forced off after 3 minutes |
| Health check | State and IP addresses |
| Enroll EFI keys | Secure Boot keys on UEFI VMs that are off |
| Remove a snapshot | Delete one snapshot from the selected guests |

Or fill in the form yourself:

| Field | What to put |
|---|---|
| Name | What it's called in the list, e.g. *Reset student desktops* |
| What it does | One line, shown under the name |
| Runs on | **The guests you select before pressing Run** – most add-ons. **These guests every time** – a fixed list, e.g. `510101-510105, 521001`. **No particular guests** – add-ons that only wait or run your own commands |
| For | Only this course, or all courses |

Then **Build it from steps**: choose **+ Add a step…**. Each step runs on all the guests, then the
next one starts. ↑ ↓ change the order, ✕ removes a step.

| Step | Options |
|---|---|
| Power on | Seconds between guests – 0 starts them all at once |
| Shut down | Seconds to wait before forcing them off |
| Power off at once | – |
| Restore a snapshot | Which snapshot, e.g. *ClassStart* – guests without it are skipped |
| Take a snapshot | Its name – `{date}` becomes today's date, e.g. *Before-{date}*; with or without memory |
| Delete a snapshot | Which snapshot |
| Show their state | – |
| Show IP addresses | – (running VMs with the QEMU guest agent) |
| Enroll EFI keys | – (UEFI VMs that are off; needs the node key) |
| Wait | Seconds |
| Your own commands | Any commands; `$id` is the guest |

**Save add-on.** VMs and containers are handled for you, and each guest's result shows when it
runs: *started*, *already running*, *restored*, *skipped* (with the reason) or *FAILED*.
**Edit** opens the steps again.

**Example – reset the student desktops:** Name *Reset student desktops* · Runs on *the guests you
select* · steps: **Restore a snapshot** *ClassStart* → **Wait** *10* → **Power on**
*5 seconds between guests*. Before class: **Run**, tick the desktops, **Run on these**.

### Write the script yourself

For anything the steps don't cover, choose **Write the script** in the same window. You write only
the commands – name, *Runs on* and *For* stay in the form.

**Paste a script you already have** – straight into the box, with or without its `#!/bin/bash` and
`# NAME:` / `# DESC:` / `# GUESTS:` lines: those go into the form by themselves, the commands stay in
the box. Then **Save add-on**.

**It only touches its own course.** When an add-on runs, `qm`, `pct` and `pvesh` work only on the
guests of its course – for an add-on *for all courses*, the course you run it in. A command on any
other guest is refused (*guest 500102 isn't in 613 – an add-on only works on the guests of its
course*) and the add-on is marked failed, so nothing in another course changes by accident. `qm list`
shows only the course's guests; `pvesh` may read anything but change only the course's guests.
Below the box, ICS Ranges lists the guests a script names and warns about any outside the course –
before you save.

`qm` is for VMs and `pct` for containers, as on a node: `qm status` on a container answers
*510001 is a container – use pct*. Scripts built from steps pick the right one by themselves. The **Insert** buttons add common
pieces (*For each guest*, *Power on*, *Snapshot*, *Only if running* …); **What you can use** lists
everything that works.

```bash
for id in $GUESTS; do
    echo "== $id"
    qm start "$id"
done
```

| Works | Doesn't (it runs in the ICS Ranges container, not on a node) |
|---|---|
| `$GUESTS` – the guests' VMIDs; `$COURSE` – this course | `sudo`, or questions that wait for typing |
| `qm` (VMs) and `pct` (containers): start, shutdown, stop, reboot, status, config, set, snapshot, rollback, delsnapshot, listsnapshot, migrate, guest cmd | Files or `ssh` on the nodes |
| `qm enroll-efi-keys <vmid>` (with the node key), `pvesh`, `jq`, `curl` | `qm unlock`, `qm terminal`, `pct enter` |
| `ovs-vsctl` – runs on the host of a guest port named in it (`tap501402i1`), or `ovs-vsctl --node=pve1 …` | Spaces inside one `ovs-vsctl` argument |

### Host add-ons

**Add-ons → Host add-ons → New host add-on**: a name, **Runs on host** (pick the Proxmox host), and the
script – paste it. `ovs-vsctl` runs on that host through the node key; `qm`, `pct` and `pvesh` work as
in every add-on (only on the course's guests). A host add-on works on the whole host, so its
`ovs-vsctl` may name any port – e.g. a sensor in another course. Tick **Show as a button for
instructors** to give it a **Run** button in the Add-ons panel.

**Write the script** also shows the script that steps make – start from steps, finish by hand.
**Upload** and **Import** take an existing `.sh` file; add-ons written for pve-range work unchanged.
An add-on stops after 30 minutes.

---

## 8. Build – network, disks, migration, EFI keys

Select guests, then **Build…** (admins by default).

- **Network settings** – for one NIC or every NIC: the **bridge**, the **VLAN tag** (empty removes
  it), the **Proxmox firewall**, the **NIC model** for VMs. *Keep as it is* leaves a setting alone;
  the MAC address is always kept.
- **Move / convert disks** – to another storage, optionally as **qcow2** (snapshots on directory
  storages). Raw-only storages (LVM, ZFS, Ceph) keep raw. *Delete the old disk* frees the space
  after a successful move. Running VMs move live; containers must be off.
- **Migrate** – tick one or more nodes; with several, **Round-robin** or **Blocks**. Running VMs
  move live with their disks; running containers restart on the new node.
- **EFI keys for Secure Boot** – UEFI VMs that are **switched off**:

| How | Notes |
|---|---|
| Enroll the keys (recommended) | Keeps the VM's boot entries; needs the node key |
| New EFI disk with the keys | No node key needed; boot entries start empty (most systems boot anyway); the old EFI disk stays as *unused* so you can switch back |

---

## 9. Storage and disks

The **Storage and disks** tab (admins and viewers by default) lists every Proxmox storage – type,
shared or not, which disk formats it holds – and every disk in the course: VMID, guest, disk,
storage, format and size. Use it to spot raw disks on directory storages (no snapshots there)
before converting them with **Build… → Move / convert disks**.

---

## 10. Mixed courses

A mixed course is a course made of guests from several courses – for example a workshop with
servers from 613 and clients from NetWars.

1. **Course map → New mixed course…**
2. **Name** (letters, digits, `-` `_` `.`, no spaces) and a **Description** for the left bar.
3. **Runs**: *Kept until deleted*, or *One-shot – ends on* a date – it disappears by itself then.
4. Pick the guests – listed by course, then by group, each with a tick for all of it and a count
   (*1 of 7*). Open a course to see its groups. Filter by name, VMID or group, or type VMIDs under
   **Add by VMID** (`510101-510105, 521031`). **Select all shown** ticks everything the filter shows;
   **Deselect all** starts again from nothing.
5. **Save course** – it appears in the left bar, marked *mixed* or *one-shot*.

A mixed course works like any course: Start / End class, power, snapshots, its own class guide and
add-ons. The groups on its Guests tab say where each guest comes from (*613 · Services*). The guests
also stay in their own courses. Under **Users**, a person can be given just the mixed course.

---

## 11. Admin – users, roles, course map, activity

**Users** – **Add a user** (name, role, one or more courses or *All courses*; a strong password is
shown **once**), **Change** (role, courses, turn 2FA off), **New password** (signs them out
everywhere), **Unlock**, **Delete** (not yourself, not the last admin).

**Roles** – a grid of permissions × roles. Tick what each role may do, **New role** for your own,
**×** to delete one nobody has, **Save roles**. *admin* always has everything.

**Course map** – how VMIDs become courses and groups, plus the mixed courses (section 10).

```
folder 51 613      ICS613            # AA 51 is the course 613
sub    51 4 Enterprise Clients       # in 613, C 4 is Enterprise Clients
module 52 1 Grid                     # in NetWars, B 1 is the module Grid
msub   52 2 1 Clients - Level 4      # in NetWars module 2, C 1 has its own name
bname  40 Rack                       # in SANS, an unnamed B shows as "Rack 2"
```

Guests whose VMIDs aren't in the map belong to no course; the Course map page lists them.
**Load the shipped map** puts back the map ICS Ranges comes with (press **Save map** to use it).

**Activity** – every sign-in and every step that ran, newest first, with names. The log is kept to
a few MB; older entries move to a second file.

---

## 12. Admin – settings, node key, groups, themes

**Settings → Running classes** (for everyone):

| Setting | Meaning |
|---|---|
| Class snapshot | Chosen first in the Class panel (*ClassStart*) |
| Protected guests | VMIDs and ranges never shown or touched – e.g. the ICS Ranges host itself and Gitea |
| Graceful shutdown timeout | Seconds before a guest is forced off (180) |
| Steps at once | Starts, stops and restores side by side (8) |
| Pause between starts | 0 = all at once; more = one after another |
| Sensor names | Ticked automatically when setting up mirrors |
| Backups to keep | Automatic backups kept (30) |
| Show the class guide | Before Start class and End class |

**Node key** – port mirroring and EFI keys can't go through the Proxmox API, so they use one SSH
key that may run **only** `ovs-vsctl` and `qm enroll-efi-keys <vmid>`. Easiest: on the ICS Ranges
host run `./setup.sh node-key <node IP>`. Or **Copy** / **Download** the lines and run them once as
root on any one node.

**Saved groups** – named VMID lists (`Kali boxes = 510801-510830`) for **Select… → Saved group**.

**Colour themes** – everyone picks light or dark under Account; admins make their own here
(**New theme**, **Try it**, **Save themes**). Status colours never change.

**Kit backup** (admins) – the whole kit in one encrypted file, and restoring from one (section 13).

---

## 13. Save & share and backups

Add-ons, class guides, roles, the course map, mixed courses, settings, mirrors, groups and themes
are **saved automatically** after every change (never users or passwords).

**Your repository** (Gitea, GitHub or GitLab):

1. Create an empty repository, e.g. `ics-ranges-content`, and a token that may **write** to it.
2. **Save & share**: the address (e.g. `http://192.168.77.93:3000/kaz/ics-ranges-content.git`),
   branch, user name and token; tick *Don't check the certificate* for a self-signed Gitea.
3. **Connect and upload** – tested first; from then on every change is uploaded by itself.

**History** shows what was saved, by whom and when; **Save now** adds your own message;
**Get latest** loads what others changed. **Backups** – one after every change, plus
**Make a backup**; **Download** keeps a copy; **Restore** brings an older state back (the current
state is backed up first).

### Kit backup – the whole kit in one file (admins)

**Settings → Kit backup** puts everything that makes up the kit in **one encrypted file**: users
(with passwords and 2FA), roles, settings, the course map, mixed courses, mirrors, groups, themes,
class guides, add-ons, the history, the activity log, the HTTPS certificate, the node key and the
Proxmox settings.

- **Download kit file** – choose a password (10 or more characters) and type it twice. Without the
  password nobody can open the file – you neither, so keep both somewhere safe.
- **Restore from a kit file…** – pick the file, type its password. ICS Ranges first shows what is in
  it (made when, by whom, which version, which users) and asks before changing anything. What is
  here now is kept as a kit file in the backups, so a restore can be undone. Everyone signs in again
  afterwards, with the kit's users.

To rebuild or swap a kit on a **new host**, use `./setup.sh import <file>` there – it can also take
over the kit's Proxmox settings (see SETUP-GUIDE.md).

---

## 14. Software updates

Admins install a newer – or an older – ICS Ranges version on **Software updates**, from the releases
in the `ics-ranges-app` repository.

**Turn it on (once per kit)** – the page shows three steps until all are ticked:

1. **Connect the repository** – address (`http://192.168.77.93:3000/kaz/ics-ranges-app`), your Gitea
   user name and a **read-only** token → **Connect**.
2. **Let the host install updates** – press **Copy** next to the command shown and run it once on
   the kit: `cd /opt/ics-ranges && sudo ./setup.sh updater`.
3. **Versions to install** – appears once a release is published (with `release.sh`).

**Update:** **Versions → Check again** → **Update to v…** → confirm. The page shows each step –
*waiting for the host → downloading → checking → installing* – restarts for about a minute and
reloads with the new version. Users, courses and content stay, and everyone stays signed in. Pages
open elsewhere (other instructors) show a blue bar and reload at their next click.

**Go back to v…** installs an older version the same way. A version that doesn't start is replaced
by the previous one automatically.

**What's new** under each version tells what changed – from the release's notes, or, where those are
missing, from the changelog that comes with ICS Ranges (`CHANGELOG.md`).

**Versions kept on this kit** – the last 5 versions installed here are kept (marked *kept here*).
Going back to one of them needs no download – it also works when the repository can't be reached;
then the page lists just the kept versions. Versions installed from a USB stick with
`./setup.sh update` are kept too.

A **new** marker next to *Software updates* shows when a newer version exists. If the host hasn't
started an update after 45 seconds, the page says so and what to run.

**Publishing a version** (on the machine with the source): `release.sh /path/to/ics-ranges.zip`
adds it to Gitea and asks whether to publish it – see [SETUP-GUIDE.md](SETUP-GUIDE.md), section 10.

---

## 15. Your account

**Account** at the bottom of the left bar:

- **Password** – the current one and a new one of at least 10 characters.
- **Two-factor sign-in** – **Set up 2FA** shows a key; add it in your authenticator app as
  *by key, time-based* (it shows as *ICS Ranges*), type the 6-digit code, **Turn 2FA on**. To turn
  it off you need your password; if you lose your phone, an admin can turn it off.
- **Colours** – as set by the admin, light, dark, or one of the admin's themes; kept per computer.

The kit's clock must be right (NTP), or 2FA codes are refused.

---

## 16. Command line (pvr)

On the ICS Ranges host, in `/opt/ics-ranges` (whoever can run these counts as admin):

```bash
sudo docker compose exec ics-ranges pvr help
```

| Command | Does |
|---|---|
| `pvr courses` · `pvr list --course 613` | Courses; a course's guests, state, snapshots |
| `pvr storage --course 613` · `pvr mirror-status` · `pvr guide --course 613` | Storage and disks; mirrors; the class guide |
| `pvr run class_start --course 612 --yes` | Run an action – also `class_end`, `power_on`, `power_off`, `snap_take`, `snap_restore`, `snap_delete`, `mirror_apply`; options `--snapshot`, `--ids`, `--hard`, `--after start`. Without `--yes` it shows the steps and asks |
| `pvr users` · `pvr users add amy --role instructor --courses 613,NetWars` | List; add (prints a password) |
| `pvr users passwd NAME` · `role` · `courses` · `del` | New password (e.g. a lost admin password); change; remove |
| `pvr roles` · `pvr save "message"` · `pvr pull` · `pvr backup` | Roles; Save & share from the shell |
| `pvr update` · `pvr update install v2.8.1` · `pvr update connect URL USER` | Software updates |
| `pvr node-key` | The lines that put the node key on a node |
| `pvr kit export FILE` · `pvr kit import FILE` | The whole kit in one encrypted file, and back |

---

## 17. Troubleshooting

| You see | What to do |
|---|---|
| *That name and password don't match* / *Too many wrong attempts* | Check the name; an admin can **Unlock** you on the Users page |
| *Sign in again – your session ended* | You were idle 15 minutes |
| A blue bar: *ICS Ranges was updated to …* | ICS Ranges was updated while the page was open – press **Reload now**, or just go to another page and it reloads by itself. You stay signed in |
| *There are no guests in any of your courses* | Ask an admin to check your courses (Users) – or the Proxmox token can't see the guests |
| *your role can't do this* | The button needs a permission your role lacks – ask an admin |
| A red step with *task failed* | The text after it is Proxmox's reason (guest locked, storage full …) |
| A red step with *HTTP 403 … SDN.Use* | On a node: `pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser` |
| *the node key isn't set up* / *only allows ovs-vsctl* | An admin runs `./setup.sh node-key <node IP>` on the host (or the lines from Settings → Node key) |
| A mirror add-on stays red after **Activate** | Its sensor must run, on the add-on's host, and its NIC must be on that Open vSwitch bridge |
| *Active · no traffic right now* | The mirror is in place – nothing talks on the bridge at the moment. **Check traffic** while the class runs |
| An add-on says `ovs-vsctl: which host?` | Make it a host add-on and pick the host, or write `ovs-vsctl --node=pve1 …` |
| Traffic or multicast doesn't reach a guest | **Network** tab: is the NIC **Connected**? Do the guests have the same **VLAN**? Untick **Firewall** on it. For multicast to sensors: the mirror add-on's *Let multicast through* |
| Software updates: *The repository can't be reached* | Only the versions kept on this kit are listed – they install without a download |
| EFI keys: *is running – switch it off first* | Power the VM off, then run it again |
| An add-on step says *FAILED* | The lines above it show why; for scripts, check for placeholders like `<vm-id>` |
| Software updates stays on *Waiting for the host's updater* | On the host: `sudo ./setup.sh updater status`, then `sudo ./setup.sh updater` |
| Red box *Proxmox isn't answering* at the top of the left bar | The Proxmox nodes are off or can't be reached. ICS Ranges shows the last known guests, and Users, Settings, Software updates etc. still work; starting, stopping and snapshots wait. It tries again every 15 seconds and the box goes away by itself |
| Start class doesn't offer *Restore* | Your role starts guests as they are; End class resets them. An admin can give the role *Restore snapshots* |
| Ready for class? says *Locked guests* | Usually a backup or snapshot is still running – wait and **Check again**. A lock that stays: an admin runs `qm unlock <vmid>` on the node |
| Ready for class? says *Storage – nearly full* | Delete old snapshots, or move disks to another storage (**Build… → Move / convert disks**) |
| Ready for class? lists guests without the class snapshot | Take it on them (**Take a snapshot on these**), or untick them in Start / End class |
| Kit restore: *wrong password, or not an ICS Ranges kit file* | The password must be the one chosen when the file was made – and the file must be a `.icskit` from ICS Ranges |

Admins see what ran and its result under **Activity**; the log on the host:
`sudo docker compose logs ics-ranges`.
