# ICS Ranges – what's new

Newest first. Each section is used as the release notes when the version is published with
`release.sh`, and is shown under **What's new** on Software updates.

## 3.1.4

- **IGMP snooping from add-ons:** `mcsnoop vmbr1 on|off|show` sets or shows it on a Linux bridge or an Open vSwitch bridge of the host. In an add-on, `echo 1|0 > /sys/class/net/<bridge>/bridge/multicast_snooping` (which can't reach the host from the container) is run as `mcsnoop <bridge> on|off`.
- The node key may also run `ics-mcsnoop <bridge> 0|1|show` – checked bridge name and value, that one file only. **Put the node key on a node again** (`./setup.sh node-key <IP>`) to use it; until then `mcsnoop` on a Linux bridge says so.
- The add-on editor says when a script uses host-only things (`/sys`, `/etc/network`, `ip link`, `sysctl` …) that an add-on can't reach.

## 3.1.3

- The Class panel is back as in 3.0.4: **Ready for class?** in the panel heading, the class snapshot, **Start class** and **End class** – no step numbers, no result badge. The rest of 3.1 stays: the guest toolbar, *Network, disks & more…*, *↻ Refresh* and the Network tab's count.

## 3.1.2

- The Class panel's first step looks like the other two: **1 · Check** on one line, the description in the same grey, and the last result as a small badge (*✓ Ready · 14:45*, *2 warnings · 14:45*, *1 problem · 14:45*) instead of coloured text. The panels at the top no longer stretch to each other's height.

## 3.1.1

- The **Network** tab's red count shows as soon as the page has loaded (it only appeared after something else redrew the page).
- The last mentions of *Build…* (the readiness check's storage tip, the README) say **Network, disks & more…**.

## 3.1.0

**Easier to find your way**
- The Class panel is the class routine in three numbered steps – **1 · Ready for class?**, **2 · Start class**, **3 · End class** – all real buttons. Step 1 shows the last check's result in colour (*ready ✓*, *ready, 3 warnings*, *1 problem to fix*). The class snapshot sits in the panel's heading.
- The guest toolbar: **Select…** and the filter on the left; on the right how many guests are ticked (with **Clear**) – or *Tick guests to work on them* – and the actions, greyed out until guests are ticked and saying why.
- **Build…** is now **Network, disks & more…**; the toolbar's **Add-ons…** is now **Run an add-on…** – it lists the VM add-ons that work on the ticked guests.
- **↻ Refresh** is a real button; the **Network** tab shows a red count when NICs are disconnected.

## 3.0.4

- `release.sh`: a version whose tag is only in the local copy (an earlier run that didn't reach Gitea, or a tag deleted in Gitea) is no longer reported as "already in Gitea" – the leftover is cleared and the version added properly. `publish` needs the tag in Gitea and says so.

## 3.0.3

- Fixed: **Connect them…** showed *Nothing to do* and connected nothing – its server part was lost in an earlier change. Restored; an action the server doesn't know now fails with a message instead of doing nothing quietly, and both tests check that Connect them plans its steps.

## 3.0.2

- **No more random refreshing:** background updates only redraw the Add-ons panel, and only when something in it changed. An open tab (Network, Add-ons, Class guide, Storage) stays as it is – no reloading, nothing typed is lost; after an action it shows the new state.
- **Faster:** the mirror status is read every 30 seconds (and right after an action) instead of every 10; SSH connections to a host are reused for a minute instead of a new handshake for every command; several open pages share one status reading. Measured with realistic SSH: 16 → 5 requests and the slowest from 1.7 s to 0.09 s in 40 quiet seconds.

## 3.0.1

- Port mirroring: every physical NIC of the host is listed – *on the bridge*, *free* (added to the bridge while the mirror is active, taken off again on Deactivate) or *used by another bridge* (greyed out, never touched).
- Mirror add-ons no longer change IGMP snooping – the option is gone.

## 3.0.0

**Add-ons, rebuilt around buttons**
- **The Add-ons panel** (where Network add-ons was): a button per add-on for instructors. Mirror add-ons have **Activate / Deactivate** and say in plain words whether the copy reaches the sensor (*Active · traffic flowing (≈ 173 packets/s)*, *Off*, or what's wrong); **Check traffic** watches for 4 seconds; **Re-activate all** after a reboot. Script add-ons marked as buttons have **Run**.
- **The Add-ons tab** (admins) has three tabs: **VM add-ons** (on the course's guests), **Host add-ons** (on a Proxmox host – `ovs-vsctl` works there through the node key) and **Port mirroring**.
- **Port mirroring from drop-downs:** host → bridge → what to copy (everything, or chosen VM / physical NICs and direction) → where the copy goes (a VM NIC or a physical NIC) → firewall off, button for instructors. The line at the bottom shows what it will do.
- **From a script…** turns an `ovs-vsctl … create mirror …` script into mirror add-ons – one per sensor, each its own button – and warns when a `qm set … virtio,…` line would change the NIC's MAC address.
- Each mirror is its own Open vSwitch mirror, added next to the others – switching one never touches another.
- Any add-on can be **shown as a button for instructors** – paste a script you have, tick, save.
- Mirrors saved before become mirror add-ons (one per sensor), kept active.

**Network**
- **The Network tab** (admins): per NIC the firewall, connected and VLAN, the disconnected NICs with **Connect them…** – mirroring moved to Add-ons. The IGMP snooping button is gone; it is an option of each mirror add-on.

**Fixed**
- `ovs-vsctl: command not found` in add-ons – there is an `ovs-vsctl` for add-ons now.
- Scripts saved on Windows (CRLF line ends) gave odd errors such as *guest 501402 isn't in 612* – they are converted to Unix line ends when saved and run.
- A delete with a longer address than intended (e.g. `/api/users/name/x`) deleted the item – now refused.
- *Ready for class?* checks the mirror add-ons.

## 2.9.5

**Add-ons**
- Paste a script straight in: header lines (`#!/bin/bash`, `# NAME:` …) go into the form by themselves.
- An add-on only touches the guests of its course: `qm`, `pct` and `pvesh` on any other guest are refused when it runs; `qm list` shows only the course's guests. The editor warns about guests outside the course before you save.
- Much faster: commands no longer ask Proxmox for the whole guest list each time – a Health check on 26 guests went from 43 s to 10 s (364 → 77 Proxmox calls). Add-ons saved earlier get about twice as fast without a change.
- Fixed: on a container, the state stayed empty – `qm config` on a container wrongly succeeded; `qm` / `pct` now fail on the wrong kind of guest (*510001 is a container – use pct*), and errors are never hidden.

## 2.9.4

- **Network add-ons:** disconnected NICs are listed one line per guest (not a wall of red), with a note when they belong to sensors – a sensor only sees traffic with its capture NIC connected and mirrored.
- **Connect them…** plugs the virtual cables back in, in one step – untick any that should stay disconnected; firewall, VLAN and mirrors stay as they are.

## 2.9.3

- **Course map 612:** group 4 is iDMZ – File Servers, 5 iDMZ – Jump Hosts, 6 NSM. A saved map with the 2.9.0 lines (4 NSM / 6 iDMZ – File Servers) or the old "6 NSM (future)" is changed once, automatically – nothing else in it.

## 2.9.2

**Network add-ons**
- VLAN tag per NIC – set, change or remove it right in Network add-ons → Change….
- IGMP snooping shows its real state, read from the bridge, not only what was chosen before.
- Filter the NICs by name or VMID, and **Sensors only** in one click.
- The panel lists disconnected NICs (in red) and how many NICs have the firewall off – not only the mirrors.
- **Ready for class?** warns about disconnected NICs.

**Release notes**
- `CHANGELOG.md`: what's new in every version. `release.sh` publishes the version's section as its release notes; Software updates shows it under **What's new**, also for versions only kept on the kit.

## 2.9.1

- End class: the part for guests without the class snapshot is clear now – it only appears when such a guest is ticked and running, says how many, and shows the real shutdown timeout.
- Clearer wording in the Start / End class windows, the review notes, the class guide editor, kit backup, mixed courses and New add-on.

## 2.9.0

- **Network add-ons** (was: Sensors): per bridge port mirroring to sensor NICs and IGMP snooping (Open vSwitch); per NIC the Proxmox firewall and whether the virtual cable is connected (any bridge). Grouped, a tick per group, the steps shown first.
- **Add-ons:** New add-on starts from examples – Reset student desktops, Snapshot before changes, Power on one by one, Shut down gracefully, Health check, Enroll EFI keys, Remove a snapshot.
- **Mixed courses:** guests by course and group, a tick and a count at both levels, **Select all shown** and **Deselect all**.
- **Software updates:** the last 5 installed versions are kept on the kit – going back needs no download, also offline. `./setup.sh update` keeps its version too.
- Course map 612: groups 4 and 6 swapped (4 NSM, 6 iDMZ – File Servers) – changed back in 2.9.3.

## 2.8.1

- Browser test: `tests/ui-test.sh` sets up Playwright in its own Python environment (no *externally-managed-environment* error on Debian 13) and uses the system's Chromium.

## 2.8.0

- **Ready for class?** in the Class panel: Proxmox and nodes, the class snapshot on every guest and its age, locked guests, nearly full storage, running guests, sensors – green / amber / red, with the guests concerned, what to do, and shortcuts.
- **Kit backup:** the whole kit (users with passwords and 2FA, settings, guides, add-ons, history, keys, Proxmox settings) in one encrypted file – Settings → Kit backup, `./setup.sh export` / `import`, `pvr kit`.
- **Browser test** `tests/ui-test.py`: opens every page and window and checks for script errors and broken text – changes nothing.

## 2.7.5

- Plain Markdown guides: `USER-GUIDE.md` (using it) and the new `SETUP-GUIDE.md` (installing, Proxmox token, updates, publishing, troubleshooting).

## 2.7.4

- Fixed: the **Snapshots…** window showed "[object HTMLLabelElement]" instead of its options.
- Class guides show **bold**, *italic*, `code` and links.

## 2.7.3

- After an update nobody needs to clear the browser cache: file names carry the version, open pages show a bar and reload at the next click.
- Updates and restarts no longer sign anyone out (sign-ins are kept on disk as fingerprints only).

## 2.7.2

- End class has one **Reset** tick per guest for everyone, admins too.

## 2.7.1

- Sensors are only handled in the Sensors panel again (not in Start class).
- IGMP snooping can be turned on and off; the choice is kept when the mirrors are re-applied.

## 2.7.0

- Start / End class list the guests **by group**, with a tick per group.
- Instructors: Start class only powers on; End class resets (restore + switch off).
- Sensors panel in words – running · mirrored · packets – and when the mirrors were last put back.
- IGMP snooping shown per sensor bridge.
- When Proxmox is off, the page still opens with the last known guests and a notice; admin pages work.

## 2.6.1

- Add-on **Run** with no guests ticked asks which guests.
- In-app Help covers add-ons and mixed courses; `USER-GUIDE.md` added.

## 2.6.0

- Add-ons made from a form and **steps** (Power on, Shut down, Restore / Take / Delete a snapshot, Wait, Show IP addresses, Enroll EFI keys, your own commands) – or the script, with insert buttons.
- Opening a large course is faster; the activity log is rotated at 5 MB.

## 2.5.2

- The host updater runs through `bash` – a lost execute permission can't stop it; updates restore the permissions.
- Software updates warns when the host hasn't started an update after 45 seconds.
- The packages keep their execute permissions.

## 2.5.1

- Bad or unexpected requests are refused with a clear message and never wipe the course map, groups or themes.
- Updates work offline (Docker reuses downloaded packages); checksum files made on Windows are accepted; going back removes files a failed version added; `pvr` shows one-line errors.

## 2.5.0

- **Mixed courses:** guests from several courses as a course of their own – kept, or one-shot until a date.
- `release.sh` to publish versions; Software updates set up with one command (`sudo ./setup.sh updater`).
- Faster: one Proxmox call per refresh; the page is only redrawn when something changed.
- Fixed: updates from a private Gitea failed with HTTP 404.

## 2.4.1 and earlier

- 2.4: Software updates from the web page through a host updater.
- 2.3: renamed from pve-range GUI to ICS Ranges; node key for port mirroring and EFI keys.
