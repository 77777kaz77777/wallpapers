# ICS Ranges – what's new

Newest first. Each section is used as the release notes when the version is published with
`release.sh`, and is shown under **What's new** on Software updates.

## 3.3.1

- Health page: *Quorate: Yes* is gone – only the cluster's name shows; *No quorum* appears only if the cluster loses it.

## 3.3.0

**Health at a glance**
- A **Health** page in the left bar, for everyone, like the Proxmox Datacenter summary: status, cluster and quorum, nodes online and offline, VMs and containers running and stopped, storage 85% full or more. A green / amber / red dot next to *Health* is checked every minute.
- **TrueNAS health** on the same page: every pool (ONLINE / DEGRADED, how full, free space), active alerts by level, version and uptime. It talks to TrueNAS 25.04+ through the WebSocket API (JSON-RPC – REST is deprecated there and removed in TrueNAS 26) and to older TrueNAS through REST. Set up under **Settings → TrueNAS** with a read-only API key, over HTTPS; **Test** says what it found or why not. The key is never sent back to the page.
- *Ready for class?* checks TrueNAS too, when it is set up.

## 3.2.2

- **The server is split into modules** (`app/ics/`: core, content, share, netops, addons, updates, mirrors, plans, readiness, kit, web, cli) instead of one 3,900-line `server.py` – done mechanically by the Python parser, so nothing changes in what it does: all three test suites pass as before, and every `pvr` command gives exactly the same output. `app/server.py` starts it and keeps the version line the updater reads. Old code from before 3.0 that nothing used is gone.
- Software updates: installing a version kept on the kit no longer first announces *Downloading … from* the repository (which may not be answering) – it says *Using the copy kept on this kit* from the start. Checked with Gitea unreachable: the kept versions are listed, going back and forth between them works, and a version that isn't kept is refused with *can't reach the repository*.

## 3.2.1

- Documentation checked against the program, section by section: README and feature list (instructors read the class guides, the Backups page, VLAN per group), and the project status (`docs/STATUS.md`).
- Settings page: the node key's note names what uses it (mirror add-ons, host add-ons, EFI keys); *Sensor names* says what it does now.

## 3.2.0

**No more duplicates**
- **Network settings in one place:** firewall, connected and VLAN are on the **Network** tab – now with a VLAN field per group that fills in all its NICs. *Network, disks & more* keeps what only it can do: **move a NIC to another bridge, or change its model**.
- **One Backups page** in the left bar: automatic backups (undo a mistake) and the kit backup (the whole kit in one encrypted file), with a line on which is for what. Save & share keeps the repository and history; Settings no longer holds the kit backup. The newest five automatic backups are shown, **Show all** for the rest.
- Two examples that repeated buttons are gone: *Power on one by one* (Power on with the pause setting) and *Remove a snapshot* (Snapshots… → Delete). Their steps stay in the step builder.

## 3.1.8

**Things that made no sense**
- Instructors couldn't read the class guide, so *Show the class guide first* did nothing for them – anyone who may run classes can read the guides now.
- The Network tab came with the mirror permission and needed it to save, while *Change network settings* alone couldn't even open it – it now belongs to *Change network settings*.
- A role allowed to make mirror add-ons but not scripts couldn't reach Port mirroring – the Add-ons tab now shows the tabs a role may use.
- The mirror permissions still described the system before 3.0 – now *See the Add-ons panel*, *Activate / Deactivate mirrors*, *Make mirror add-ons*.

**Removed**
- What was left of the mirror system before 3.0: the `/api/mirrors` endpoint, its status and grouping code, the IGMP action (no button since 3.0.1 – `mcsnoop` does it) and the mirror part of the Network tab's save – which could still replace all mirrors on a bridge, mirror add-ons included, if an old page sent it. The one-time conversion of old saved mirrors stays.

## 3.1.7

**Fixed**
- A class guide or add-on saved without any text (e.g. from an old page or a script) was emptied – now refused: *nothing to save*.
- The **sensor pattern** in Settings had no effect – it now decides which guests count as sensors (panel notes, the mirror builder), next to the `sensor` tag.
- A password reset – `pvr users passwd`, an admin in Users – now signs out the pages signed in with the old password; your own change keeps your page signed in and signs out the others.
- `pvr backup list` lists the backups (it made a new one); `pvr run` without `--course` or with an unknown course says so (it said *Nothing to do*); an unknown action is called unknown, not a permission problem; `pvr kit` checks what it's asked before asking for the password; `pvr users role` and `pvr update install` explain how to use them.

**Testing**
- The API test also checks: guide saves without text, unknown actions, and that a shell password reset signs out open pages (the course's own guide is put back).

## 3.1.6

**Add-ons – fixed**
- The 30-minute limit now also stops add-ons that hang without printing anything, together with everything they started.
- Output beyond 400 KB says it was cut instead of ending silently.
- *Power on one by one* waits only between guests it actually starts (it waited after every guest, even skipped ones).
- `qm clone` and `pvesh … --newid` can't create a guest in another course; fixed VMIDs and picked guests of another course are refused before running, saying which.
- Deleting an active mirror add-on also takes a physical NIC it added off the bridge; changing an active one says *Changed since it was activated* and offers **Activate**.
- Add-on names must start with a letter or digit (`....sh` became a hidden file); Upload and Import choose a valid name.
- `qm list` / `pct list` no longer end with an error when the course has no guest of that kind.

**Add-ons – new**
- `qm` / `pct` `list` print like on a node (header and columns), `qm wait` / `pct wait`, `qm clone` within the course, `pvesm list <storage>`, `pvesh --output-format json-pretty`.

**Testing**
- `tests/addon-test.sh`: about 45 checks of add-ons on a running kit – safe on a real kit (reads only, removes what it makes). On 3.1.5 it finds the 10 bugs fixed here.

## 3.1.5

- `pvr mirror-status` shows the mirror add-ons – active or off, whether the copy arrives, and their ids (it still read the mirrors from before 3.0). Mirrors can be switched from the shell: `pvr run mirror_on|mirror_off --course C --id ID`.
- Documentation brought up to date: the feature list, README, user guide, setup guide (what uses the node key, renewing it after 3.1.4) and the in-app Help.

## 3.1.4

- **IGMP snooping from add-ons:** `mcsnoop vmbr1 on|off|show` sets or shows it on a Linux bridge or an Open vSwitch bridge of the host. In an add-on, `echo 1|0 > /sys/class/net/<bridge>/bridge/multicast_snooping` (which can't reach the host from the container) is run as `mcsnoop <bridge> on|off`.
- The node key may also run `ics-mcsnoop <bridge> 0|1|show` – checked bridge name and value, that one file only. **Put the node key on a node again** (`./setup.sh node-key <IP>`) to use it; until then `mcsnoop` on a Linux bridge says so.
- The add-on editor says when a script uses host-only things (`/sys`, `/etc/network`, `ip link`, `sysctl` …) that an add-on can't reach.

## 3.1.3

- The Class panel is back as in 3.0.4: **Ready for class?** in the panel heading, the class snapshot, **Start class** and **End class** – no step numbers, no result badge. The rest of 3.1 stays: the guest toolbar, *Network, disks & more…*, *↻ Refresh* and the Network tab's count.

## 3.1.2

- The Class panel's first step looks like the other two: **1 · Check** on one line, the description in the same grey, and the last result as a small badge (*✓ Ready · 14:45*, *2 warnings · 14:45*, *1 problem · 14:45*) instead of coloured text. The panels at the top no longer stretch to each other's height.

## 3.1.1

- The **Network** tab's red count shows as soon as the page has loaded (it only appeared after something else redrew the page).
- The last mentions of *Build…* (the readiness check's storage tip, the README) say **Network, disks & more…**.

## 3.1.0

**Easier to find your way**
- The Class panel is the class routine in three numbered steps – **1 · Ready for class?**, **2 · Start class**, **3 · End class** – all real buttons. Step 1 shows the last check's result in colour (*ready ✓*, *ready, 3 warnings*, *1 problem to fix*). The class snapshot sits in the panel's heading.
- The guest toolbar: **Select…** and the filter on the left; on the right how many guests are ticked (with **Clear**) – or *Tick guests to work on them* – and the actions, greyed out until guests are ticked and saying why.
- **Build…** is now **Network, disks & more…**; the toolbar's **Add-ons…** is now **Run an add-on…** – it lists the VM add-ons that work on the ticked guests.
- **↻ Refresh** is a real button; the **Network** tab shows a red count when NICs are disconnected.

## 3.0.4

- `release.sh`: a version whose tag is only in the local copy (an earlier run that didn't reach Gitea, or a tag deleted in Gitea) is no longer reported as "already in Gitea" – the leftover is cleared and the version added properly. `publish` needs the tag in Gitea and says so.

## 3.0.3

- Fixed: **Connect them…** showed *Nothing to do* and connected nothing – its server part was lost in an earlier change. Restored; an action the server doesn't know now fails with a message instead of doing nothing quietly, and both tests check that Connect them plans its steps.

## 3.0.2

- **No more random refreshing:** background updates only redraw the Add-ons panel, and only when something in it changed. An open tab (Network, Add-ons, Class guide, Storage) stays as it is – no reloading, nothing typed is lost; after an action it shows the new state.
- **Faster:** the mirror status is read every 30 seconds (and right after an action) instead of every 10; SSH connections to a host are reused for a minute instead of a new handshake for every command; several open pages share one status reading. Measured with realistic SSH: 16 → 5 requests and the slowest from 1.7 s to 0.09 s in 40 quiet seconds.

## 3.0.1

- Port mirroring: every physical NIC of the host is listed – *on the bridge*, *free* (added to the bridge while the mirror is active, taken off again on Deactivate) or *used by another bridge* (greyed out, never touched).
- Mirror add-ons no longer change IGMP snooping – the option is gone.

## 3.0.0

**Add-ons, rebuilt around buttons**
- **The Add-ons panel** (where Network add-ons was): a button per add-on for instructors. Mirror add-ons have **Activate / Deactivate** and say in plain words whether the copy reaches the sensor (*Active · traffic flowing (≈ 173 packets/s)*, *Off*, or what's wrong); **Check traffic** watches for 4 seconds; **Re-activate all** after a reboot. Script add-ons marked as buttons have **Run**.
- **The Add-ons tab** (admins) has three tabs: **VM add-ons** (on the course's guests), **Host add-ons** (on a Proxmox host – `ovs-vsctl` works there through the node key) and **Port mirroring**.
- **Port mirroring from drop-downs:** host → bridge → what to copy (everything, or chosen VM / physical NICs and direction) → where the copy goes (a VM NIC or a physical NIC) → firewall off, button for instructors. The line at the bottom shows what it will do.
- **From a script…** turns an `ovs-vsctl … create mirror …` script into mirror add-ons – one per sensor, each its own button – and warns when a `qm set … virtio,…` line would change the NIC's MAC address.
- Each mirror is its own Open vSwitch mirror, added next to the others – switching one never touches another.
- Any add-on can be **shown as a button for instructors** – paste a script you have, tick, save.
- Mirrors saved before become mirror add-ons (one per sensor), kept active.

**Network**
- **The Network tab** (admins): per NIC the firewall, connected and VLAN, the disconnected NICs with **Connect them…** – mirroring moved to Add-ons. The IGMP snooping button is gone; it is an option of each mirror add-on.

**Fixed**
- `ovs-vsctl: command not found` in add-ons – there is an `ovs-vsctl` for add-ons now.
- Scripts saved on Windows (CRLF line ends) gave odd errors such as *guest 501402 isn't in 612* – they are converted to Unix line ends when saved and run.
- A delete with a longer address than intended (e.g. `/api/users/name/x`) deleted the item – now refused.
- *Ready for class?* checks the mirror add-ons.

## 2.9.5

**Add-ons**
- Paste a script straight in: header lines (`#!/bin/bash`, `# NAME:` …) go into the form by themselves.
- An add-on only touches the guests of its course: `qm`, `pct` and `pvesh` on any other guest are refused when it runs; `qm list` shows only the course's guests. The editor warns about guests outside the course before you save.
- Much faster: commands no longer ask Proxmox for the whole guest list each time – a Health check on 26 guests went from 43 s to 10 s (364 → 77 Proxmox calls). Add-ons saved earlier get about twice as fast without a change.
- Fixed: on a container, the state stayed empty – `qm config` on a container wrongly succeeded; `qm` / `pct` now fail on the wrong kind of guest (*510001 is a container – use pct*), and errors are never hidden.

## 2.9.4

- **Network add-ons:** disconnected NICs are listed one line per guest (not a wall of red), with a note when they belong to sensors – a sensor only sees traffic with its capture NIC connected and mirrored.
- **Connect them…** plugs the virtual cables back in, in one step – untick any that should stay disconnected; firewall, VLAN and mirrors stay as they are.

## 2.9.3

- **Course map 612:** group 4 is iDMZ – File Servers, 5 iDMZ – Jump Hosts, 6 NSM. A saved map with the 2.9.0 lines (4 NSM / 6 iDMZ – File Servers) or the old "6 NSM (future)" is changed once, automatically – nothing else in it.

## 2.9.2

**Network add-ons**
- VLAN tag per NIC – set, change or remove it right in Network add-ons → Change….
- IGMP snooping shows its real state, read from the bridge, not only what was chosen before.
- Filter the NICs by name or VMID, and **Sensors only** in one click.
- The panel lists disconnected NICs (in red) and how many NICs have the firewall off – not only the mirrors.
- **Ready for class?** warns about disconnected NICs.

**Release notes**
- `CHANGELOG.md`: what's new in every version. `release.sh` publishes the version's section as its release notes; Software updates shows it under **What's new**, also for versions only kept on the kit.

## 2.9.1

- End class: the part for guests without the class snapshot is clear now – it only appears when such a guest is ticked and running, says how many, and shows the real shutdown timeout.
- Clearer wording in the Start / End class windows, the review notes, the class guide editor, kit backup, mixed courses and New add-on.

## 2.9.0

- **Network add-ons** (was: Sensors): per bridge port mirroring to sensor NICs and IGMP snooping (Open vSwitch); per NIC the Proxmox firewall and whether the virtual cable is connected (any bridge). Grouped, a tick per group, the steps shown first.
- **Add-ons:** New add-on starts from examples – Reset student desktops, Snapshot before changes, Power on one by one, Shut down gracefully, Health check, Enroll EFI keys, Remove a snapshot.
- **Mixed courses:** guests by course and group, a tick and a count at both levels, **Select all shown** and **Deselect all**.
- **Software updates:** the last 5 installed versions are kept on the kit – going back needs no download, also offline. `./setup.sh update` keeps its version too.
- Course map 612: groups 4 and 6 swapped (4 NSM, 6 iDMZ – File Servers) – changed back in 2.9.3.

## 2.8.1

- Browser test: `tests/ui-test.sh` sets up Playwright in its own Python environment (no *externally-managed-environment* error on Debian 13) and uses the system's Chromium.

## 2.8.0

- **Ready for class?** in the Class panel: Proxmox and nodes, the class snapshot on every guest and its age, locked guests, nearly full storage, running guests, sensors – green / amber / red, with the guests concerned, what to do, and shortcuts.
- **Kit backup:** the whole kit (users with passwords and 2FA, settings, guides, add-ons, history, keys, Proxmox settings) in one encrypted file – Settings → Kit backup, `./setup.sh export` / `import`, `pvr kit`.
- **Browser test** `tests/ui-test.py`: opens every page and window and checks for script errors and broken text – changes nothing.

## 2.7.5

- Plain Markdown guides: `USER-GUIDE.md` (using it) and the new `SETUP-GUIDE.md` (installing, Proxmox token, updates, publishing, troubleshooting).

## 2.7.4

- Fixed: the **Snapshots…** window showed "[object HTMLLabelElement]" instead of its options.
- Class guides show **bold**, *italic*, `code` and links.

## 2.7.3

- After an update nobody needs to clear the browser cache: file names carry the version, open pages show a bar and reload at the next click.
- Updates and restarts no longer sign anyone out (sign-ins are kept on disk as fingerprints only).

## 2.7.2

- End class has one **Reset** tick per guest for everyone, admins too.

## 2.7.1

- Sensors are only handled in the Sensors panel again (not in Start class).
- IGMP snooping can be turned on and off; the choice is kept when the mirrors are re-applied.

## 2.7.0

- Start / End class list the guests **by group**, with a tick per group.
- Instructors: Start class only powers on; End class resets (restore + switch off).
- Sensors panel in words – running · mirrored · packets – and when the mirrors were last put back.
- IGMP snooping shown per sensor bridge.
- When Proxmox is off, the page still opens with the last known guests and a notice; admin pages work.

## 2.6.1

- Add-on **Run** with no guests ticked asks which guests.
- In-app Help covers add-ons and mixed courses; `USER-GUIDE.md` added.

## 2.6.0

- Add-ons made from a form and **steps** (Power on, Shut down, Restore / Take / Delete a snapshot, Wait, Show IP addresses, Enroll EFI keys, your own commands) – or the script, with insert buttons.
- Opening a large course is faster; the activity log is rotated at 5 MB.

## 2.5.2

- The host updater runs through `bash` – a lost execute permission can't stop it; updates restore the permissions.
- Software updates warns when the host hasn't started an update after 45 seconds.
- The packages keep their execute permissions.

## 2.5.1

- Bad or unexpected requests are refused with a clear message and never wipe the course map, groups or themes.
- Updates work offline (Docker reuses downloaded packages); checksum files made on Windows are accepted; going back removes files a failed version added; `pvr` shows one-line errors.

## 2.5.0

- **Mixed courses:** guests from several courses as a course of their own – kept, or one-shot until a date.
- `release.sh` to publish versions; Software updates set up with one command (`sudo ./setup.sh updater`).
- Faster: one Proxmox call per refresh; the page is only redrawn when something changed.
- Fixed: updates from a private Gitea failed with HTTP 404.

## 2.4.1 and earlier

- 2.4: Software updates from the web page through a host updater.
- 2.3: renamed from pve-range GUI to ICS Ranges; node key for port mirroring and EFI keys.
