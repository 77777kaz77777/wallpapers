# ICS Ranges – what's new

Newest first. Each section is used as the release notes when the version is published with
`release.sh`, and is shown under **What's new** on Software updates.

## 2.9.5

**Add-ons**
- Paste a script straight in: header lines (`#!/bin/bash`, `# NAME:` …) go into the form by themselves.
- An add-on only touches the guests of its course: `qm`, `pct` and `pvesh` on any other guest are refused when it runs; `qm list` shows only the course's guests. The editor warns about guests outside the course before you save.
- Much faster: commands no longer ask Proxmox for the whole guest list each time – a Health check on 26 guests went from 43 s to 10 s (364 → 77 Proxmox calls). Add-ons saved earlier get about twice as fast without a change.
- Fixed: on a container, the state stayed empty – `qm config` on a container wrongly succeeded; `qm` / `pct` now fail on the wrong kind of guest (*510001 is a container – use pct*), and errors are never hidden.

## 2.9.4

- **Network add-ons:** disconnected NICs are listed one line per guest (not a wall of red), with a note when they belong to sensors – a sensor only sees traffic with its capture NIC connected and mirrored.
- **Connect them…** plugs the virtual cables back in, in one step – untick any that should stay disconnected; firewall, VLAN and mirrors stay as they are.

## 2.9.3

- **Course map 612:** group 4 is iDMZ – File Servers, 5 iDMZ – Jump Hosts, 6 NSM. A saved map with the 2.9.0 lines (4 NSM / 6 iDMZ – File Servers) or the old "6 NSM (future)" is changed once, automatically – nothing else in it.

## 2.9.2

**Network add-ons**
- VLAN tag per NIC – set, change or remove it right in Network add-ons → Change….
- IGMP snooping shows its real state, read from the bridge, not only what was chosen before.
- Filter the NICs by name or VMID, and **Sensors only** in one click.
- The panel lists disconnected NICs (in red) and how many NICs have the firewall off – not only the mirrors.
- **Ready for class?** warns about disconnected NICs.

**Release notes**
- `CHANGELOG.md`: what's new in every version. `release.sh` publishes the version's section as its release notes; Software updates shows it under **What's new**, also for versions only kept on the kit.

## 2.9.1

- End class: the part for guests without the class snapshot is clear now – it only appears when such a guest is ticked and running, says how many, and shows the real shutdown timeout.
- Clearer wording in the Start / End class windows, the review notes, the class guide editor, kit backup, mixed courses and New add-on.

## 2.9.0

- **Network add-ons** (was: Sensors): per bridge port mirroring to sensor NICs and IGMP snooping (Open vSwitch); per NIC the Proxmox firewall and whether the virtual cable is connected (any bridge). Grouped, a tick per group, the steps shown first.
- **Add-ons:** New add-on starts from examples – Reset student desktops, Snapshot before changes, Power on one by one, Shut down gracefully, Health check, Enroll EFI keys, Remove a snapshot.
- **Mixed courses:** guests by course and group, a tick and a count at both levels, **Select all shown** and **Deselect all**.
- **Software updates:** the last 5 installed versions are kept on the kit – going back needs no download, also offline. `./setup.sh update` keeps its version too.
- Course map 612: groups 4 and 6 swapped (4 NSM, 6 iDMZ – File Servers) – changed back in 2.9.3.

## 2.8.1

- Browser test: `tests/ui-test.sh` sets up Playwright in its own Python environment (no *externally-managed-environment* error on Debian 13) and uses the system's Chromium.

## 2.8.0

- **Ready for class?** in the Class panel: Proxmox and nodes, the class snapshot on every guest and its age, locked guests, nearly full storage, running guests, sensors – green / amber / red, with the guests concerned, what to do, and shortcuts.
- **Kit backup:** the whole kit (users with passwords and 2FA, settings, guides, add-ons, history, keys, Proxmox settings) in one encrypted file – Settings → Kit backup, `./setup.sh export` / `import`, `pvr kit`.
- **Browser test** `tests/ui-test.py`: opens every page and window and checks for script errors and broken text – changes nothing.

## 2.7.5

- Plain Markdown guides: `USER-GUIDE.md` (using it) and the new `SETUP-GUIDE.md` (installing, Proxmox token, updates, publishing, troubleshooting).

## 2.7.4

- Fixed: the **Snapshots…** window showed "[object HTMLLabelElement]" instead of its options.
- Class guides show **bold**, *italic*, `code` and links.

## 2.7.3

- After an update nobody needs to clear the browser cache: file names carry the version, open pages show a bar and reload at the next click.
- Updates and restarts no longer sign anyone out (sign-ins are kept on disk as fingerprints only).

## 2.7.2

- End class has one **Reset** tick per guest for everyone, admins too.

## 2.7.1

- Sensors are only handled in the Sensors panel again (not in Start class).
- IGMP snooping can be turned on and off; the choice is kept when the mirrors are re-applied.

## 2.7.0

- Start / End class list the guests **by group**, with a tick per group.
- Instructors: Start class only powers on; End class resets (restore + switch off).
- Sensors panel in words – running · mirrored · packets – and when the mirrors were last put back.
- IGMP snooping shown per sensor bridge.
- When Proxmox is off, the page still opens with the last known guests and a notice; admin pages work.

## 2.6.1

- Add-on **Run** with no guests ticked asks which guests.
- In-app Help covers add-ons and mixed courses; `USER-GUIDE.md` added.

## 2.6.0

- Add-ons made from a form and **steps** (Power on, Shut down, Restore / Take / Delete a snapshot, Wait, Show IP addresses, Enroll EFI keys, your own commands) – or the script, with insert buttons.
- Opening a large course is faster; the activity log is rotated at 5 MB.

## 2.5.2

- The host updater runs through `bash` – a lost execute permission can't stop it; updates restore the permissions.
- Software updates warns when the host hasn't started an update after 45 seconds.
- The packages keep their execute permissions.

## 2.5.1

- Bad or unexpected requests are refused with a clear message and never wipe the course map, groups or themes.
- Updates work offline (Docker reuses downloaded packages); checksum files made on Windows are accepted; going back removes files a failed version added; `pvr` shows one-line errors.

## 2.5.0

- **Mixed courses:** guests from several courses as a course of their own – kept, or one-shot until a date.
- `release.sh` to publish versions; Software updates set up with one command (`sudo ./setup.sh updater`).
- Faster: one Proxmox call per refresh; the page is only redrawn when something changed.
- Fixed: updates from a private Gitea failed with HTTP 404.

## 2.4.1 and earlier

- 2.4: Software updates from the web page through a host updater.
- 2.3: renamed from pve-range GUI to ICS Ranges; node key for port mirroring and EFI keys.
