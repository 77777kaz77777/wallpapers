#!/usr/bin/env python3
"""ICS Ranges test simulator - a small Proxmox with guests tagged fake-range, for the API test (gui-test.py)."""
# a small simulated Proxmox API for testing ICS Ranges
import json, os, re, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
TOKEN = "PVEAPIToken=pverange@pve!range=secret"
G = {}
def add(v, node, typ, name, status, snaps=("ClassStart",), tags=""):
    G[v] = dict(node=node, type=typ, name=name, status=status, tags=tags, snaps=list(snaps),
                config={"name" if typ == "qemu" else "hostname": name, "scsi0" if typ == "qemu" else "rootfs": "local-lvm:vm-%d-disk-0,size=32G" % v, "net0": "virtio=AA:00:00:00:%02X:01,bridge=vmbr0" % (v % 256)})
add(105, "pve1", "lxc", "gitea", "running", ())
for i in range(1, 7): add(500100 + i, "pve1" if i % 2 else "pve2", "qemu", "612-srv%02d" % i, "stopped")
add(510001, "pve1", "lxc", "ews01", "stopped", (), tags="fake-range;613"); add(510002, "pve1", "qemu", "sensor01", "running", tags="sensor;fake-range")
add(510101, "pve2", "qemu", "srv01", "stopped", tags="fake-range"); add(510201, "pve2", "qemu", "win-ews01", "stopped", ()); add(510202, "pve2", "qemu", "win-ews02", "running", ())
for i in range(1, 4): add(521000 + i, "pve1", "qemu", "grid%02d" % i, "stopped")
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, data):
        b = json.dumps({"data": data}).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self): self.any("GET")
    def do_POST(self): self.any("POST")
    def do_PUT(self): self.any("PUT")
    def do_DELETE(self): self.any("DELETE")
    def any(self, m):
        if self.headers.get("Authorization") != TOKEN: return self.send(401, None)
        u = urllib.parse.urlparse(self.path); p = u.path.replace("/api2/json", "")
        n = int(self.headers.get("Content-Length") or 0); body = dict(urllib.parse.parse_qsl(self.rfile.read(n).decode())) if n else {}
        q = dict(urllib.parse.parse_qsl(u.query)); q.update(body)
        if p == "/version": return self.send(200, {"version": "9.2.11", "release": "9.2"})
        if re.match(r"^/nodes/[^/]+/(qemu|lxc)/\d+/feature$", p):   # can it take snapshots? SIM_NOSNAP=510001,...
            vid = p.split("/")[4]
            return self.send(200, {"hasFeature": 0 if vid in os.environ.get("SIM_NOSNAP", "").split(",") else 1, "nodes": []})
        if p == "/nodes": return self.send(200, [{"node": "pve1", "status": "online"}, {"node": "pve2", "status": "online"}])
        if re.match(r"^/nodes/[^/]+/storage/[^/]+/content$", p): return self.send(200, [{"volid": "local-lvm:vm-510101-disk-0", "format": "raw", "content": "images", "size": 1 << 35, "vmid": 510101}])
        if p == "/cluster/status": return self.send(200, [{"type": "node", "name": "pve1", "ip": "10.0.0.1", "online": 1}, {"type": "node", "name": "pve2", "ip": "10.0.0.2", "online": 1}])
        if p == "/cluster/resources":
            out = [{"type": "node", "node": n, "status": "online", "id": "node/" + n} for n in ("pve1", "pve2")]
            if q.get("type") != "node":
                out += [{"type": g["type"], "vmid": v, "name": g["name"], "node": g["node"], "status": g["status"], "tags": g["tags"], "template": 0, "id": "%s/%d" % (g["type"], v)} for v, g in G.items()]
            if q.get("type") == "vm": out = [x for x in out if x["type"] != "node"]
            return self.send(200, out)
        if p in ("/storage", "/nodes/pve1/storage", "/nodes/pve2/storage"): return self.send(200, [{"storage": "local-lvm", "type": "lvmthin", "content": "images,rootdir", "shared": 0}, {"storage": "local", "type": "dir", "content": "iso,backup", "shared": 0}])
        m = re.match(r"^/nodes/([^/]+)/tasks/([^/]+)/status$", p)
        if m: return self.send(200, {"status": "stopped", "exitstatus": "OK"})
        m = re.match(r"^/nodes/([^/]+)/(qemu|lxc)$", p)
        if m: return self.send(200, [{"vmid": v, "name": g["name"], "status": g["status"]} for v, g in G.items() if g["node"] == m.group(1) and g["type"] == m.group(2)])
        m = re.match(r"^/nodes/([^/]+)/(qemu|lxc)/(\d+)(/.*)?$", p)
        if m:
            v = int(m.group(3)); g = G.get(v); rest = m.group(4) or ""
            if not g: return self.send(500, None)
            upid = "UPID:%s:0:0:0:x:%d:root@pam:" % (g["node"], v)
            if rest == "/config":
                if m_ := (m == "PUT"): pass
                if self.command == "GET": return self.send(200, g["config"])
                g["config"].update({k: v_ for k, v_ in q.items() if k != "delete"}); return self.send(200, None)
            if rest == "/status/current": return self.send(200, {"status": g["status"], "name": g["name"]})
            sm = re.match(r"^/status/(start|stop|shutdown|reboot)$", rest)
            if sm: g["status"] = "running" if sm.group(1) in ("start", "reboot") else "stopped"; return self.send(200, upid)
            if rest == "/snapshot":
                if self.command == "GET": return self.send(200, [{"name": s, **({"vmstate": 1} if False else {})} for s in g["snaps"]] + [{"name": "current"}])
                g["snaps"].append(q.get("snapname", "x")); return self.send(200, upid)
            sm = re.match(r"^/snapshot/([^/]+)(/rollback)?$", rest)
            if sm:
                if sm.group(2):   # like Proxmox: a snapshot without memory leaves the guest off
                    g["status"] = "stopped"
                    return self.send(200, upid)
                if self.command == "DELETE" and sm.group(1) in g["snaps"]: g["snaps"].remove(sm.group(1))
                return self.send(200, upid)
            if rest.startswith("/agent/"): return self.send(500, None)
        return self.send(501, None)
ThreadingHTTPServer(("127.0.0.1", int(os.environ.get("SIM_PORT", "18006"))), H).serve_forever()
