"""ICS Ranges test simulator - a stand-in TrueNAS: HTTPS + WebSocket JSON-RPC 2.0 at /api/current, or REST /api/v2.0 (MODE=rest).
State in $SIM_DIR/truenas-state.json: {"pool": "ONLINE|DEGRADED", "used": 0.5, "alerts": [...], "key": "..."}"""
import base64, hashlib, json, os, socketserver, ssl, struct, sys, threading, http.server
SIMDIR = os.environ.get("SIM_DIR", "/tmp/ics-sim")
PORT = int(os.environ.get("SIM_TN_PORT", "18444")); MODE = os.environ.get("SIM_TN_MODE", "ws")
def state():
    try: return json.load(open(os.path.join(SIMDIR, "truenas-state.json")))
    except Exception: return {}
def answer(method, params, authed):
    s = state()
    if method == "auth.login_ex":
        p = params[0]
        ok = p.get("api_key") == s.get("key", "good-key") and p.get("username") == s.get("user", "icsranges")
        return {"response_type": "SUCCESS" if ok else "AUTH_ERR"}, True if ok else False
    if not authed: return {"__error__": "Not authenticated"}, False
    size = 4 * 2**40
    if method == "system.info": return {"hostname": "truenas-lab", "version": "TrueNAS-25.10.1", "uptime_seconds": 3 * 86400 + 5 * 3600}, True
    if method == "pool.query":
        st = s.get("pool", "ONLINE")
        return [{"name": "tank", "status": st, "healthy": st == "ONLINE", "warning": False, "size": size, "allocated": int(size * s.get("used", 0.42)), "free": int(size * (1 - s.get("used", 0.42)))},
                {"name": "fast", "status": "ONLINE", "healthy": True, "warning": False, "size": 2**40, "allocated": int(2**40 * 0.30), "free": int(2**40 * 0.70)}], True
    if method == "alert.list": return s.get("alerts", []), True
    return {"__error__": "Method %s not found" % method}, True
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path.startswith("/api/v2.0/"):
            if MODE != "rest": self.send_response(410); self.end_headers(); return
            if self.headers.get("Authorization") != "Bearer " + state().get("key", "good-key"): self.send_response(401); self.end_headers(); return
            m = {"/api/v2.0/system/info": "system.info", "/api/v2.0/pool": "pool.query", "/api/v2.0/alert/list": "alert.list"}.get(self.path)
            r, _ = answer(m, [], True); b = json.dumps(r).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path != "/api/current" or MODE == "rest" or self.headers.get("Upgrade", "").lower() != "websocket":
            self.send_response(404); self.end_headers(); return
        acc = base64.b64encode(hashlib.sha1((self.headers["Sec-WebSocket-Key"] + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        self.send_response(101); self.send_header("Upgrade", "websocket"); self.send_header("Connection", "Upgrade"); self.send_header("Sec-WebSocket-Accept", acc); self.end_headers()
        r, w, authed = self.rfile, self.wfile, False
        def send(text):
            d = text.encode(); n = len(d)
            head = bytes([0x81]) + (bytes([n]) if n < 126 else (bytes([126]) + struct.pack(">H", n) if n < 65536 else bytes([127]) + struct.pack(">Q", n)))
            w.write(head + d); w.flush()
        send(json.dumps({"jsonrpc": "2.0", "method": "collection_update", "params": {"msg": "noise"}}))   # an event first, like a real one
        while True:
            hdr = r.read(2)
            if len(hdr) < 2: return
            op, n = hdr[0] & 0x0F, hdr[1] & 0x7F
            if n == 126: n = struct.unpack(">H", r.read(2))[0]
            elif n == 127: n = struct.unpack(">Q", r.read(8))[0]
            mask = r.read(4); data = bytes(b ^ mask[i % 4] for i, b in enumerate(r.read(n)))
            if op == 0x8: return
            m = json.loads(data)
            if os.environ.get("SIM_TN_SLOW") and m["method"] != "auth.login_ex":
                import time as _t; _t.sleep(float(os.environ["SIM_TN_SLOW"]))   # a slow TrueNAS
            res, ok = answer(m["method"], m.get("params") or [], authed)
            if m["method"] == "auth.login_ex": authed = ok
            if isinstance(res, dict) and "__error__" in res:
                send(json.dumps({"jsonrpc": "2.0", "id": m["id"], "error": {"code": -32601, "message": res["__error__"]}}))
            else:
                send(json.dumps({"jsonrpc": "2.0", "id": m["id"], "result": res}))
class S(socketserver.ThreadingMixIn, http.server.HTTPServer): daemon_threads = True
srv = S(("127.0.0.1", PORT), H)
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(os.path.join(SIMDIR, "truenas-cert.pem"), os.path.join(SIMDIR, "truenas-key.pem"))
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
srv.serve_forever()
