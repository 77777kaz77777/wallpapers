#!/usr/bin/env python3
"""pve_sim.py - a simulated Proxmox VE cluster for ICS Ranges' demo mode.

Answers the Proxmox API calls ICS Ranges and its add-on commands make, with a realistic range:
two nodes, the 612 / 613 / NetWars / 727 courses and Management, ClassStart snapshots, sensors on an
Open vSwitch bridge, guest-agent IP addresses, and tasks that take a few seconds like real ones.
A few faults are built in on purpose (a guest without ClassStart, a locked guest, a nearly full
storage) so the readiness check has something to find.

Nothing here touches a real Proxmox. Standard library only. Listens on 127.0.0.1:18006 (plain HTTP).
"""
import json
import os
import random
import re
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("SIM_PORT", "18006"))
NODES = ["pve1", "pve2"]
LOCK = threading.RLock()
G = {}          # vmid -> guest
TASKS = {}      # upid -> {node, done_at, effect, log}
NOW = time.time()


def mac(v, n):
    return "BC:24:11:%02X:%02X:%02X" % ((v >> 16) & 255, (v >> 8) & 255, (v + n) & 255)


def add(v, name, typ="qemu", node=None, status="stopped", snaps=("ClassStart",), ram=False, tags="", nics=1,
        sensor_nic=False, uefi=False, lock="", disk_gb=40, storage="local-lvm"):
    node = node or NODES[v % 2]
    cfg = {"name" if typ == "qemu" else "hostname": name, "cores": 2 if typ == "lxc" else 4,
           "memory": 1024 if typ == "lxc" else 4096}
    if typ == "qemu":
        cfg["scsi0"] = "%s:vm-%d-disk-0,size=%dG" % (storage, v, disk_gb)
        cfg["ostype"] = "win11" if "ews" in name or "ows" in name or "client" in name else "l26"
        for n in range(nics):
            cfg["net%d" % n] = "virtio=%s,bridge=vmbr%d,firewall=1" % (mac(v, n), 1 if n == 0 else 0)
        if sensor_nic:
            cfg["net%d" % nics] = "virtio=%s,bridge=vmbr2" % mac(v, nics)
        if uefi:
            cfg["bios"] = "ovmf"
            cfg["efidisk0"] = "%s:vm-%d-disk-1,efitype=4m,pre-enrolled-keys=1,size=4M" % (storage, v)
    else:
        cfg["rootfs"] = "%s:subvol-%d-disk-0,size=%dG" % (storage, v, disk_gb // 4 or 8)
        cfg["net0"] = "name=eth0,bridge=vmbr1,hwaddr=%s,ip=dhcp,firewall=1" % mac(v, 0)
    if lock:
        cfg["lock"] = lock
    G[v] = {"vmid": v, "name": name, "type": typ, "node": node, "status": status, "tags": tags, "config": cfg,
            "snaps": [{"name": s, "vmstate": 1 if (ram and typ == "qemu") else 0,
                       "snaptime": int(NOW - 86400 * (12 + (v % 5))), "description": ""} for s in snaps]}


def build_range():
    # Management (VMIDs below 100000)
    add(105, "gitea", "lxc", "pve1", "running", snaps=())
    add(110, "ics-ranges", "lxc", "pve1", "running", snaps=())
    add(119, "kali-instructor", node="pve2", snaps=())
    # 612 - 50BCDD: C0 Services, C1 Lvl 3 Servers, C2 Lvl 3 EWS, C3 Lvl 3 OWS, C4 iDMZ File, C5 iDMZ Jump, C6 NSM
    add(500001, "612-ntp", "lxc")
    for i, n in enumerate(["dc01", "historian", "license", "data", "hmi"], 1):
        add(500100 + i, "612-srv-" + n, uefi=True)
    for i in range(1, 4):
        add(500200 + i, "612-ews%02d" % i, uefi=True)
    for i in range(1, 3):
        add(500300 + i, "612-ows%02d" % i, uefi=True)
    add(500401, "612-dmz-fs")
    add(500501, "612-dmz-rdg01")
    add(500502, "612-dmz-rdg02")
    add(500601, "612-sensor", tags="sensor", ram=True, sensor_nic=True)
    # 613 - 51BCDD: C0 Services, C1 Enterprise Servers, C2 ICS Servers, C3 ABB Servers, C4 Enterprise Clients,
    #               C5 iDMZ Jump Hosts, C6 EWS Clients, C7 ABB Clients
    add(510001, "613-ntp", "lxc")
    add(510002, "613-sensor", tags="sensor", ram=True, sensor_nic=True)
    for i, n in enumerate(["dc01", "fs01", "wsus"], 1):
        add(510100 + i, "613-" + n)
    add(510201, "613-historian")
    add(510202, "613-opc")
    add(510301, "613-abb-800xa", disk_gb=120)
    for i in range(1, 11):
        # a fault on purpose: client 10 has no ClassStart
        add(510400 + i, "613-client%02d" % i, snaps=() if i == 10 else ("ClassStart",))
    add(510501, "613-jump01")
    add(510502, "613-jump02", lock="backup")   # a fault on purpose: locked by a backup
    for i in range(1, 5):
        add(510600 + i, "613-ews%02d" % i, uefi=True)
    for i in range(1, 3):
        add(510700 + i, "613-abb-ows%02d" % i)
    # NetWars - 52BCDD: modules 0 Mgmt, 1 Grid, 2 Cookie
    add(520001, "nw-scoreboard", "lxc")
    for i in range(1, 4):
        add(521000 + i, "nw-grid-srv%02d" % i)
    for i in range(1, 7):
        add(521100 + i, "nw-grid-l3-%02d" % i)
    for i in range(1, 5):
        add(521200 + i, "nw-grid-l4-%02d" % i)
    add(522001, "nw-cookie-srv")
    for i in range(1, 5):
        add(522100 + i, "nw-cookie-l4-%02d" % i)
    # 727 - 53BCDD: C0 Services, C1 Dragos Servers, C2 EWS Clients
    add(530001, "727-ntp", "lxc")
    add(530101, "727-dragos-sitestore", disk_gb=200)
    add(530102, "727-dragos-sensor", tags="sensor", sensor_nic=True)
    for i in range(1, 5):
        add(530200 + i, "727-ews%02d" % i, uefi=True)


STORAGE = {
    # name: type, shared, content, total GiB per node, used fraction per node
    "local": ("dir", 0, "iso,vztmpl,backup", 100, {"pve1": 0.31, "pve2": 0.28}),
    "local-lvm": ("lvmthin", 0, "images,rootdir", 2000, {"pve1": 0.58, "pve2": 0.93}),   # pve2 nearly full on purpose
    "nfs-iso": ("nfs", 1, "iso,backup", 4000, {"pve1": 0.41, "pve2": 0.41}),
}


def upid(node, kind, v):
    return "UPID:%s:%08X:%08X:%08X:%s:%s:root@pam:" % (node, random.randint(1, 0xFFFFFF), random.randint(1, 0xFFFF),
                                                       int(time.time()), kind, v)


def task(node, kind, v, secs, effect):
    u = upid(node, kind, v)
    with LOCK:
        TASKS[u] = {"node": node, "done_at": time.time() + secs, "effect": effect, "done": False,
                    "log": ["%s %s started" % (kind, v)]}
    return u


def tick():   # apply what finished tasks change
    while True:
        time.sleep(0.2)
        with LOCK:
            for t in TASKS.values():
                if not t["done"] and time.time() >= t["done_at"]:
                    t["done"] = True
                    try:
                        t["effect"]()
                        t["log"].append("TASK OK")
                    except Exception as e:   # noqa
                        t["log"].append("TASK ERROR: %s" % e)


def agent_ips(g):
    v = g["vmid"]
    return {"result": [{"name": "lo", "ip-addresses": [{"ip-address-type": "ipv4", "ip-address": "127.0.0.1", "prefix": 8}]},
                       {"name": "Ethernet0", "hardware-address": mac(v, 0).lower(),
                        "ip-addresses": [{"ip-address-type": "ipv4", "ip-address": "10.%d.%d.%d" % (v // 10000 % 100, v // 100 % 100, v % 100 + 10), "prefix": 24}]}]}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def send(self, code, data=None, err=None):
        b = json.dumps({"data": data} if err is None else {"data": None, "errors": err}).encode()
        self.send_response(code, err if isinstance(err, str) else None)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")

    def do_PUT(self):
        self.handle_any("PUT")

    def do_DELETE(self):
        self.handle_any("DELETE")

    def handle_any(self, m):
        if os.environ.get("SIM_DELAY"):
            time.sleep(float(os.environ["SIM_DELAY"]))
        if not self.headers.get("Authorization", "").startswith("PVEAPIToken="):
            return self.send(401, err="no token")
        u = urllib.parse.urlparse(self.path)
        p = u.path.replace("/api2/json", "")
        if os.environ.get("SIM_LOG"):
            open(os.environ["SIM_LOG"], "a").write(m + " " + p + "\n")
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode() if n else ""
        q = dict(urllib.parse.parse_qsl(u.query))
        if raw:
            q.update(dict(urllib.parse.parse_qsl(raw)) if not raw.startswith("{") else json.loads(raw))
        with LOCK:
            return self.route(m, p, q)

    def route(self, m, p, q):
        if p == "/version":
            return self.send(200, {"version": "9.2.11", "release": "9.2", "repoid": "demo"})
        if p == "/nodes":
            return self.send(200, [{"node": n, "status": "online", "type": "node", "cpu": 0.12, "maxcpu": 32,
                                    "mem": 68 << 30, "maxmem": 256 << 30, "uptime": 864000} for n in NODES])
        if p == "/cluster/status":
            return self.send(200, [{"type": "cluster", "name": "demo", "quorate": 1, "nodes": len(NODES)}] +
                             [{"type": "node", "name": n, "ip": "10.0.0.%d" % (i + 1), "online": 1, "local": int(i == 0)} for i, n in enumerate(NODES)])
        if p == "/cluster/resources":
            out = []
            if q.get("type") in (None, "node"):
                out += [{"type": "node", "node": n, "id": "node/" + n, "status": "online", "maxcpu": 32, "maxmem": 256 << 30} for n in NODES]
            if q.get("type") in (None, "vm"):
                out += [{"type": g["type"], "vmid": v, "id": "%s/%d" % (g["type"], v), "name": g["name"], "node": g["node"],
                         "status": g["status"], "tags": g["tags"], "template": 0, "maxmem": g["config"]["memory"] << 20,
                         "maxdisk": 40 << 30} for v, g in sorted(G.items())]
            if q.get("type") in (None, "storage"):
                for n in NODES:
                    for s, (t, sh, c, tot, used) in STORAGE.items():
                        out.append({"type": "storage", "id": "storage/%s/%s" % (n, s), "storage": s, "node": n, "status": "available",
                                    "maxdisk": tot << 30, "disk": int(tot * used[n]) << 30, "shared": sh, "plugintype": t, "content": c})
            return self.send(200, out)
        if p == "/storage":
            return self.send(200, [{"storage": s, "type": t, "shared": sh, "content": c} for s, (t, sh, c, _, _) in STORAGE.items()])
        mm = re.match(r"^/nodes/([^/]+)/storage$", p)
        if mm:
            n = mm.group(1)
            return self.send(200, [{"storage": s, "type": t, "shared": sh, "content": c, "active": 1, "enabled": 1,
                                    "total": tot << 30, "used": int(tot * used.get(n, 0.5)) << 30,
                                    "avail": (tot << 30) - (int(tot * used.get(n, 0.5)) << 30), "used_fraction": used.get(n, 0.5)}
                                   for s, (t, sh, c, tot, used) in STORAGE.items()])
        if re.match(r"^/nodes/[^/]+/(qemu|lxc)/\d+/feature$", p):   # can it take snapshots? SIM_NOSNAP=510001,...
            vid = p.split("/")[4]
            return self.send(200, {"hasFeature": 0 if vid in os.environ.get("SIM_NOSNAP", "").split(",") else 1, "nodes": []})
        mm = re.match(r"^/nodes/([^/]+)/storage/([^/]+)/content$", p)
        if mm and m == "GET":
            out = [{"volid": "%s:vm-%d-disk-0" % (mm.group(2), v), "format": "raw", "content": "images", "size": 42949672960, "vmid": v}
                   for v in sorted(G) if not q.get("vmid") or str(v) == q.get("vmid")][:50]
            return self.send(200, out)
        mm = re.match(r"^/nodes/([^/]+)/network$", p)
        if mm:
            return self.send(200, [{"iface": "eno1", "type": "eth", "active": 1}, {"iface": "eno2", "type": "OVSPort", "ovs_bridge": "vmbr2", "active": 1},
                                   {"iface": "eno3", "type": "eth", "active": 1},
                                   {"iface": "vmbr0", "type": "bridge", "active": 1, "bridge_ports": "eno1", "cidr": "10.0.0.%d/24" % (NODES.index(mm.group(1)) + 1)},
                                   {"iface": "vmbr1", "type": "bridge", "active": 1, "comments": "range network"},
                                   {"iface": "vmbr2", "type": "OVSBridge", "active": 1, "ovs_ports": "eno2", "comments": "sensor mirror bridge"}])
        mm = re.match(r"^/nodes/([^/]+)/tasks/([^/]+)/(status|log)$", p)
        if mm:
            t = TASKS.get(urllib.parse.unquote(mm.group(2)))
            if not t:
                return self.send(404, err="no such task")
            if mm.group(3) == "log":
                return self.send(200, [{"n": i + 1, "t": line} for i, line in enumerate(t["log"])])
            return self.send(200, {"status": "stopped" if t["done"] else "running", "exitstatus": "OK" if t["done"] else None,
                                   "node": t["node"], "upid": mm.group(2)})
        mm = re.match(r"^/nodes/([^/]+)/(qemu|lxc)$", p)
        if mm:
            return self.send(200, [{"vmid": v, "name": g["name"], "status": g["status"], "tags": g["tags"]}
                                   for v, g in sorted(G.items()) if g["node"] == mm.group(1) and g["type"] == mm.group(2)])
        mm = re.match(r"^/nodes/([^/]+)/(qemu|lxc)/(\d+)(/.*)?$", p)
        if mm:
            return self.guest(m, mm.group(1), mm.group(2), int(mm.group(3)), mm.group(4) or "", q)
        return self.send(501, err="not simulated: %s %s" % (m, p))

    def guest(self, m, node, typ, v, rest, q):
        g = G.get(v)
        if not g or g["type"] != typ:
            return self.send(500, err="Configuration file 'nodes/%s/%s/%d.conf' does not exist" % (node, typ, v))
        if g["node"] != node:
            return self.send(500, err="%d is on %s" % (v, g["node"]))
        cfg = g["config"]
        busy = lambda: "lock" in cfg   # noqa
        if rest == "/config":
            if m == "GET":
                return self.send(200, dict(cfg, digest="demo"))
            if busy() and cfg["lock"] != "backup":
                return self.send(500, err="VM is locked (%s)" % cfg["lock"])
            for k in (q.get("delete") or "").split(","):
                if k in cfg:
                    j = 0
                    while "unused%d" % j in cfg:
                        j += 1
                    cfg["unused%d" % j] = cfg.pop(k).split(",")[0]
            for k, val in q.items():
                if k in ("delete", "digest"):
                    continue
                if k.startswith("efidisk") and ":1," in val:
                    val = val.replace(":1,", ":vm-%d-disk-9," % v, 1)
                cfg[k] = val
            return self.send(200, None)
        if rest == "/status/current":
            return self.send(200, {"status": g["status"], "name": g["name"], "vmid": v, "qmpstatus": g["status"],
                                   "lock": cfg.get("lock")})
        sm = re.match(r"^/status/(start|stop|shutdown|reboot|suspend|resume)$", rest)
        if sm and m == "POST":
            if busy():
                return self.send(500, err="VM %d is locked (%s)" % (v, cfg["lock"]))
            act = sm.group(1)
            want = "stopped" if act in ("stop", "shutdown") else "running"

            def eff(g=g, want=want):
                g["status"] = want
            return self.send(200, task(node, "qm" + act if typ == "qemu" else "vz" + act, v, 3 if act == "shutdown" else 2, eff))
        if rest == "/snapshot":
            if m == "GET":
                return self.send(200, [dict(s) for s in g["snaps"]] + [{"name": "current", "parent": g["snaps"][-1]["name"] if g["snaps"] else None,
                                                                       "running": int(g["status"] == "running")}])
            if busy():
                return self.send(500, err="VM %d is locked (%s)" % (v, cfg["lock"]))
            name = q.get("snapname", "")
            if any(s["name"] == name for s in g["snaps"]):
                return self.send(500, err="snapshot name '%s' already used" % name)

            def eff(g=g, name=name, ram=q.get("vmstate") in ("1", 1, True)):
                g["snaps"].append({"name": name, "vmstate": 1 if ram else 0, "snaptime": int(time.time()), "description": ""})
            return self.send(200, task(node, "qmsnapshot", v, 2, eff))
        sm = re.match(r"^/snapshot/([^/]+)(/rollback)?$", rest)
        if sm:
            name = urllib.parse.unquote(sm.group(1))
            s = next((x for x in g["snaps"] if x["name"] == name), None)
            if not s:
                return self.send(500, err="snapshot '%s' does not exist" % name)
            if sm.group(2) and m == "POST":
                if busy():
                    return self.send(500, err="VM %d is locked (%s)" % (v, cfg["lock"]))

                def eff(g=g, s=s):   # like Proxmox: back running only with a memory snapshot
                    g["status"] = "running" if s.get("vmstate") else "stopped"
                return self.send(200, task(node, "qmrollback", v, 3, eff))
            if m == "DELETE":
                def eff(g=g, name=name):
                    g["snaps"] = [x for x in g["snaps"] if x["name"] != name]
                return self.send(200, task(node, "qmdelsnapshot", v, 2, eff))
            if m == "GET":
                return self.send(200, s)
        if rest == "/migrate" and m == "POST":
            target = q.get("target")
            if target not in NODES:
                return self.send(400, err="no such node")

            def eff(g=g, target=target):
                g["node"] = target
            return self.send(200, task(node, "qmigrate", v, 5, eff))
        if rest in ("/move_disk", "/move_volume") and m == "POST":
            disk, store = q.get("disk") or q.get("volume"), q.get("storage")

            def eff(cfg=cfg, disk=disk, store=store, fmt=q.get("format")):
                if disk in cfg:
                    parts = cfg[disk].split(",")
                    vol = parts[0].split(":", 1)[1]
                    if fmt == "qcow2" and not vol.endswith(".qcow2"):
                        vol = "%d/%s.qcow2" % (v, vol.split("/")[-1])
                    cfg[disk] = ",".join([store + ":" + vol] + parts[1:])
            return self.send(200, task(node, "qmmove", v, 4, eff))
        if rest.startswith("/agent/"):
            if g["status"] != "running" or typ != "qemu":
                return self.send(500, err="QEMU guest agent is not running")
            if rest.endswith("network-get-interfaces"):
                return self.send(200, agent_ips(g))
            if rest.endswith("ping"):
                return self.send(200, {})
            return self.send(200, {"result": {}})
        return self.send(501, err="not simulated: %s %s" % (m, rest))


def main():
    build_range()
    threading.Thread(target=tick, daemon=True).start()
    print("Simulated Proxmox: %d guests on %s - http://127.0.0.1:%d" % (len(G), ", ".join(NODES), PORT), flush=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()


if __name__ == "__main__":
    main()
