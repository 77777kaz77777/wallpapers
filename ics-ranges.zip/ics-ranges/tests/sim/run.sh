#!/usr/bin/env bash
# Run the ICS Ranges tests against simulators - no Proxmox, Open vSwitch or TrueNAS needed.
#
#   tests/sim/run.sh                 the API test, the add-on test and the browser test (course 613)
#   tests/sim/run.sh api addon       only these (api | addon | browser)
#   tests/sim/run.sh --full          the browser test on every course (slower)
#
# Everything runs on 127.0.0.1 from this package's own files, with fresh test data in a temporary
# folder that is removed afterwards (kept, with the logs, if a test failed). Needs python3, jq, curl
# and openssl; the browser test also needs what tests/ui-test.sh needs (Playwright + Chromium).
#
# The simulators (here in tests/sim):
#   pve_sim.py      a Proxmox cluster - 2 nodes, the courses 612, 613, NetWars, 727, Linux and Open
#                   vSwitch bridges, snapshots, tasks (for the add-on and browser tests)
#   pve_mini.py     a small Proxmox with guests tagged fake-range (for the API test's real actions)
#   bin/ssh         stands in for ssh to a node: ovs-vsctl (mirrors, ports, IGMP), ics-mcsnoop
#   truenas_sim.py  a TrueNAS 25.x: HTTPS, WebSocket JSON-RPC (auth, pools, alerts), REST mode
# Real-world cases from kits are kept in: 510001 can't take snapshots, TrueNAS is set up.
set -u
HERE=$(cd "$(dirname "$(readlink -f "$0")")" && pwd)
PKG=$(cd "$HERE/../.." && pwd)
APP=$PKG/app
WANT=() FULL=0
for a in "$@"; do case $a in --full) FULL=1 ;; api | addon | browser) WANT+=("$a") ;; -h | --help) sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;; *) echo "unknown: $a"; exit 2 ;; esac; done
((${#WANT[@]})) || WANT=(api addon browser)
for t in python3 jq curl openssl; do command -v $t >/dev/null || { echo "missing: $t"; exit 2; }; done

export SIM_DIR
SIM_DIR=$(mktemp -d /tmp/ics-sim.XXXXXX)
P_SIM=28006 P_MINI=28007 P_TN=28444 P_KIT_API=28443 P_KIT=28445
PIDS=() FAILED=0 RESULTS=()
cleanup() {
    for p in "${PIDS[@]}"; do kill "$p" 2>/dev/null; done
    wait 2>/dev/null
    if ((FAILED)); then echo "Logs and test data kept in $SIM_DIR"; else rm -rf "$SIM_DIR"; fi
}
trap cleanup EXIT
start() {   # name, then the command - runs in the background, log in $SIM_DIR/<name>.log
    local name=$1; shift
    "$@" >"$SIM_DIR/$name.log" 2>&1 &
    PIDS+=($!)
}
wait_port() {
    for _ in $(seq 1 40); do curl -s -o /dev/null "$1" && return 0; curl -sk -o /dev/null "$1" && return 0; sleep 0.25; done
    echo "nothing answers at $1 - see $SIM_DIR"; FAILED=1; exit 1
}

echo "Simulators and test kits in $SIM_DIR"
# TrueNAS: a self-signed certificate, healthy pools
openssl req -x509 -newkey rsa:2048 -nodes -keyout "$SIM_DIR/truenas-key.pem" -out "$SIM_DIR/truenas-cert.pem" -days 2 -subj "/CN=truenas.sim" 2>/dev/null
echo '{"key": "sim-key", "user": "icsranges", "pool": "ONLINE", "used": 0.42, "alerts": []}' >"$SIM_DIR/truenas-state.json"
SIM_TN_PORT=$P_TN start truenas python3 "$HERE/truenas_sim.py"
SIM_PORT=$P_MINI SIM_NOSNAP=510001 start pve_mini python3 "$HERE/pve_mini.py"
SIM_PORT=$P_SIM SIM_NOSNAP=510001 start pve_sim python3 "$HERE/pve_sim.py"
wait_port "http://127.0.0.1:$P_MINI/api2/json/version"; wait_port "http://127.0.0.1:$P_SIM/api2/json/version"; wait_port "https://127.0.0.1:$P_TN/"

kit() {   # name, port, Proxmox port, token - a kit with its own data, the node key and TrueNAS set up
    local name=$1 port=$2 pport=$3 token=$4 data=$SIM_DIR/data-$1
    mkdir -p "$data/ssh" "$data/priv" "$SIM_DIR/upd-$name"
    : >"$data/ssh/ovs_ed25519"   # the node key (bin/ssh stands in for the nodes)
    printf '{"url": "https://127.0.0.1:%s", "user": "icsranges", "key": "sim-key", "verify": false}' "$P_TN" >"$data/priv/truenas.json"
    chmod 600 "$data/priv/truenas.json"
    KIT_ENV=(PATH="$HERE/bin:$PATH" SIM_PVE_URL="http://127.0.0.1:$pport" ICS_API_DIR="$PKG/api" DATA_DIR="$data"
             UPDATES_DIR="$SIM_DIR/upd-$name" PORT="$port" PVE_API_URL="http://127.0.0.1:$pport" PVE_API_TOKEN="$token")
    (cd "$APP" && exec env "${KIT_ENV[@]}" python3 server.py >"$SIM_DIR/kit-$name.log" 2>&1) &   # exec: stopping it stops the server
    PIDS+=($!)
    wait_port "http://127.0.0.1:$port/"
}
result() { RESULTS+=("$(printf '%-14s %s' "$1" "$2")"); [[ $2 == *" 0 failed"* ]] || FAILED=1; }

if [[ " ${WANT[*]} " == *" api "* ]]; then
    kit api "$P_KIT_API" "$P_MINI" 'pverange@pve!range=secret'
    curl -s -X POST -H 'X-PVR: 1' -H 'Content-Type: application/json' "http://127.0.0.1:$P_KIT_API/api/setup" \
        -d '{"user": "sim-admin", "password": "sim-password-123"}' >/dev/null   # a kit has its first admin
    echo "== API test (gui-test.py) against the small simulator"
    GT_URL="http://127.0.0.1:$P_KIT_API" GT_APP="$APP" DATA_DIR="$SIM_DIR/data-api" \
        GT_PVR="env ${KIT_ENV[*]} python3 $APP/server.py" python3 "$PKG/tests/gui-test.py" >"$SIM_DIR/api-test.out" 2>&1
    grep -E '^  (FAIL|SKIP)' "$SIM_DIR/api-test.out"
    result "API test" "$(grep -E '[0-9]+ passed' "$SIM_DIR/api-test.out" | tail -1 | sed 's/^ *//')"
fi
if [[ " ${WANT[*]} " == *" addon "* || " ${WANT[*]} " == *" browser "* ]]; then
    kit main "$P_KIT" "$P_SIM" 'icsranges@pve!sim=x'
    curl -s -X POST -H 'X-PVR: 1' -H 'Content-Type: application/json' "http://127.0.0.1:$P_KIT/api/setup" \
        -d '{"user": "sim-admin", "password": "sim-password-123"}' >/dev/null
fi
if [[ " ${WANT[*]} " == *" addon "* ]]; then
    echo "== add-on test (addon-test.py) against the cluster simulator"
    ADDON_PASSWORD=sim-password-123 python3 "$PKG/tests/addon-test.py" "http://127.0.0.1:$P_KIT" sim-admin --course 613 >"$SIM_DIR/addon-test.out" 2>&1
    grep -E '^  (FAIL|SKIP)' "$SIM_DIR/addon-test.out"
    result "add-on test" "$(grep -E '[0-9]+ passed' "$SIM_DIR/addon-test.out" | tail -1 | sed 's/^ *//')"
fi
if [[ " ${WANT[*]} " == *" browser "* ]]; then
    if python3 -c "import playwright" 2>/dev/null; then
        echo "== browser test (ui-test.py) against the cluster simulator"
        course=(--course 613); ((FULL)) && course=()
        UI_PASSWORD=sim-password-123 python3 "$PKG/tests/ui-test.py" "http://127.0.0.1:$P_KIT" sim-admin "${course[@]}" >"$SIM_DIR/browser-test.out" 2>&1
        grep -E '^  FAIL' "$SIM_DIR/browser-test.out"
        result "browser test" "$(grep -E '[0-9]+ passed' "$SIM_DIR/browser-test.out" | tail -1 | sed 's/^ *//')"
    else
        RESULTS+=("$(printf '%-14s %s' "browser test" "not run - no Playwright here (tests/ui-test.sh sets it up)")")
    fi
fi
echo; echo "===================================="
printf '%s\n' "${RESULTS[@]}"
echo "===================================="
exit $FAILED
