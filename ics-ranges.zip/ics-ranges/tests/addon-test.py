#!/usr/bin/env python3
"""Add-on test for ControlYard - checks everything about add-ons on a running kit.

    python3 tests/addon-test.py https://127.0.0.1:8443 kaz [--course 613]
    ADDON_PASSWORD=... python3 tests/addon-test.py URL USER           # without asking

Safe on a real kit: it makes its own test add-ons and a test instructor, runs only commands that
read (status, config, list - never start, stop, snapshot or change a guest), defines a mirror
add-on without switching it on, and removes everything it made again, also after a failure.

Checks:
  commands  qm / pct list like on a node, status, config, pvesh json-pretty, pvesm status and list,
            qm wait, the wrong tool (pct on a VM), commands that need a node shell
  rules     guests of other courses refused - in qm, pvesh, clones, fixed VMIDs and picked guests
  roles     an instructor runs buttons of their course only, and sees only the buttons
  scripts   Windows line ends, header lines, more than 400 KB of output
  host      a host add-on's ovs-vsctl and mcsnoop (read-only) - skipped without a node key
  mirrors   a mirror add-on made from a script, changed and deleted (never switched on)
  input     bad add-on names and paths refused
"""
import getpass
import http.cookiejar
import json
import os
import random
import ssl
import string
import sys
import time
import urllib.error
import urllib.request

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if len(args) < 2:
    sys.exit(__doc__)
URL, USER = args[0].rstrip("/"), args[1]
COURSE = sys.argv[sys.argv.index("--course") + 1] if "--course" in sys.argv else ""
PASSWORD = os.environ.get("ADDON_PASSWORD") or os.environ.get("UI_PASSWORD") or getpass.getpass("Password for %s: " % USER)
RND = "".join(random.choice(string.ascii_lowercase) for _ in range(5))
CTX = ssl.create_default_context()
CTX.check_hostname, CTX.verify_mode = False, ssl.CERT_NONE   # the kit's own certificate

passed, failed, skipped = [], [], []


def ok(name):
    passed.append(name)
    print("  PASS  " + name)


def bad(name, why=""):
    failed.append(name)
    print("  FAIL  %s%s" % (name, ("  - " + why[:300]) if why else ""))


def skip(name, why):
    skipped.append(name)
    print("  SKIP  %s - %s" % (name, why))


def check(cond, name, why=""):
    ok(name) if cond else bad(name, why)
    return cond


class Client:
    def __init__(self):
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
                                              urllib.request.HTTPSHandler(context=CTX))

    def call(self, method, path, body=None, timeout=120):
        r = urllib.request.Request(URL + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                   headers={"X-PVR": "1", "Content-Type": "application/json"})
        try:
            with self.op.open(r, timeout=timeout) as f:
                return f.status, json.loads(f.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read() or b"{}")
            except ValueError:
                return e.code, {}


admin = Client()
st, _ = admin.call("POST", "/api/login", {"user": USER, "password": PASSWORD})
if st != 200:
    sys.exit("Can't sign in as %s (HTTP %d)" % (USER, st))
made_addons, made_mirrors, made_users = [], [], []


def save(name, text, course=None):
    course = course or COURSE
    st, r = admin.call("PUT", "/api/addons/%s/%s" % (course, name), {"text": text})
    if st == 200:
        made_addons.append((course, name))
    return st, r


def run(name, ids=(), who=None, course=None):
    """Plan and run an add-on; returns (state, message, output) - or (None, error, '') if it can't be planned."""
    who, course = who or admin, course or COURSE
    st, p = who.call("POST", "/api/plan", {"action": "addon_run", "course": course, "scope": course, "file": name, "ids": list(ids)})
    if st != 200:
        return None, p.get("error", "HTTP %d" % st), ""
    st, j = who.call("POST", "/api/plan/%s/run" % p["id"])
    t0 = time.time()
    while time.time() - t0 < 300:
        st, s = who.call("GET", "/api/job/" + j["job"])
        if s.get("state") == "done":
            step = s["groups"][0][0]
            return step["state"], step.get("msg", ""), step.get("out") or ""
        time.sleep(0.7)
    return "timeout", "no result after 5 minutes", ""


def header(name, kind="vm", guests="no", extra=""):
    return "#!/usr/bin/env bash\n# NAME: %s\n# GUESTS: %s\n%s%s" % (name, guests, "# KIND: host\n" if kind == "host" else "", extra)


try:
    # ------------------------------------------------------------------ the course and its guests
    st, cs = admin.call("GET", "/api/courses")
    courses = [c for c in (cs.get("courses", cs) if isinstance(cs, dict) else cs) if isinstance(c, dict)]
    if not COURSE:   # the course with the most guests - the most to check
        def size(c):
            n = c.get("count", c.get("guests", 0))
            return n if isinstance(n, int) else len(n or [])
        COURSE = max(courses, key=size)["name"] if courses else ""
    st, cd = admin.call("GET", "/api/course/" + urllib.request.quote(COURSE))
    guests = cd.get("guests", []) if st == 200 else []
    if not guests:
        sys.exit("Course %s has no guests (or can't be read) - pick one with --course" % COURSE)
    vm = next((g for g in guests if g.get("type") == "qemu"), None)
    ct = next((g for g in guests if g.get("type") == "lxc"), None)
    other = None   # a guest of another course, for the course rules
    for c in courses:
        if c["name"] != COURSE and not c.get("mixed"):
            st, od = admin.call("GET", "/api/course/" + urllib.request.quote(c["name"]))
            mine = {g["vmid"] for g in guests}
            other = next((g for g in od.get("guests", []) if g["vmid"] not in mine), None) if st == 200 else None
            if other:
                break
    print("Add-on test on %s - course %s: %d guests (VM %s, container %s), another course's guest %s\n" % (
        URL, COURSE, len(guests), vm and vm["vmid"], ct and ct["vmid"], other and other["vmid"]))

    # ------------------------------------------------------------------ commands (read only)
    print("Commands")
    # the whole output first, then its first lines - a cut-off pipe would change the exit code
    lines = ["t() { echo \"### $*\"; o=$(\"$@\" 2>&1); rc=$?; printf '%s\\n' \"$o\" | head -6; echo \"-> exit $rc\"; }",
             "t qm list", "t pct list", "t pvesh get /version --output-format json-pretty", "t pvesm status", "t qm terminal 1"]
    if vm:
        lines += ["t qm status %d" % vm["vmid"], "t qm config %d" % vm["vmid"], "t pct status %d" % vm["vmid"]]
        if vm["status"] == "stopped":
            lines.append("t qm wait %d --timeout 5" % vm["vmid"])
    if ct:
        lines += ["t pct status %d" % ct["vmid"], "t qm status %d" % ct["vmid"]]
    st, sl = admin.call("GET", "/api/storages?course=" + COURSE)
    sl = sl.get("storages", []) if isinstance(sl, dict) else (sl if isinstance(sl, list) else [])
    stor = next((x.get("storage") for x in sl if isinstance(x, dict) and x.get("storage")), "")
    if stor:
        lines.append("t pvesm list %s" % stor)
    if other:
        lines += ["t qm status %d" % other["vmid"], "t pvesh get /nodes/%s/%s/%d/config" % (other["node"], other["type"], other["vmid"])]
        if vm:
            lines += ["t qm clone %d %d" % (vm["vmid"], other["vmid"]),
                      "t pvesh create /nodes/%s/qemu/%d/clone --newid %d" % (vm["node"], vm["vmid"], other["vmid"])]
    save("at-%s-cmds.sh" % RND, header("Add-on test commands") + "\n".join(lines) + "\n")
    state, msg, out = run("at-%s-cmds.sh" % RND)
    blocks = {}
    for b in out.split("### ")[1:]:
        head, _, rest = b.partition("\n")
        blocks[head.strip()] = rest
    def res(cmd):
        b = blocks.get(cmd, "")
        code = b.rsplit("-> exit ", 1)[-1].strip() if "-> exit " in b else "?"
        return code, b
    check(state in ("ok", "failed") and blocks, "the command add-on runs (%s)" % state, msg or out[:200])
    code, b = res("qm list")
    check(code == "0" and b.lstrip().startswith("VMID NAME"), "qm list prints like on a node (header VMID NAME …)", b[:150])
    code, b = res("pct list")
    check(code == "0" and b.startswith("VMID") and "Status" in b.split("\n")[0], "pct list prints like on a node (VMID Status Lock Name)", b[:150])
    code, b = res("pvesh get /version --output-format json-pretty")
    check(code == "0" and b.startswith("{\n"), "pvesh --output-format json-pretty", b[:120])
    code, b = res("pvesm status")
    check(code == "0" and b.startswith("Name"), "pvesm status", b[:120])
    code, b = res("qm terminal 1")
    check(code != "0" and "not possible from the container" in b, "commands needing a node shell say so", b[:150])
    if stor:
        code, b = res("pvesm list %s" % stor)
        check(code == "0" and b.startswith("Volid"), "pvesm list %s" % stor, b[:150])
    else:
        skip("pvesm list", "no storage found for %s" % COURSE)
    if vm:
        code, b = res("qm status %d" % vm["vmid"])
        check(code == "0" and b.startswith("status: "), "qm status of a VM", b[:100])
        code, b = res("qm config %d" % vm["vmid"])
        check(code == "0" and ": " in b, "qm config of a VM", b[:100])
        code, b = res("pct status %d" % vm["vmid"])
        check(code != "0" and "is a VM - use qm" in b, "pct on a VM says: use qm", b[:120])
        if vm["status"] == "stopped":
            code, b = res("qm wait %d --timeout 5" % vm["vmid"])
            check(code == "0", "qm wait on a stopped VM returns at once", b[:120])
    else:
        skip("qm on a VM", "the course has no VM")
    if ct:
        code, b = res("qm status %d" % ct["vmid"])
        check(code != "0" and "is a container - use pct" in b, "qm on a container says: use pct", b[:120])
        code, b = res("pct status %d" % ct["vmid"])
        check(code == "0" and b.startswith("status: "), "pct status of a container", b[:100])
    else:
        skip("pct on a container", "the course has no container")

    # ------------------------------------------------------------------ course rules
    print("\nCourse rules")
    if other:
        o = other["vmid"]
        code, b = res("qm status %d" % o)
        check(code != "0" and "isn't in %s" % COURSE in b, "qm on another course's guest is refused", b[:150])
        code, b = res("pvesh get /nodes/%s/%s/%d/config" % (other["node"], other["type"], o))
        check(code != "0" and "isn't in" in b, "pvesh on another course's guest is refused", b[:150])
        if vm:
            code, b = res("qm clone %d %d" % (vm["vmid"], o))
            check(code != "0" and "isn't in" in b, "qm clone into another course is refused", b[:150])
            code, b = res("pvesh create /nodes/%s/qemu/%d/clone --newid %d" % (vm["node"], vm["vmid"], o))
            check(code != "0" and "isn't in" in b, "pvesh clone with --newid in another course is refused", b[:150])
        save("at-%s-fixed.sh" % RND, header("Add-on test fixed", extra="# IDS: %d\n" % o) + "echo hi\n")
        state, msg, _ = run("at-%s-fixed.sh" % RND)
        check(state is None and "isn't in" in msg, "fixed VMIDs of another course are refused before running", msg)
        save("at-%s-guests.sh" % RND, header("Add-on test guests", guests="yes") + "echo $GUESTS\n")
        state, msg, _ = run("at-%s-guests.sh" % RND, ids=[o])
        check(state is None and "isn't in" in msg, "picking another course's guest is refused, saying so", msg)
    else:
        skip("course rules", "no other course with guests to test against")

    # ------------------------------------------------------------------ scripts
    print("\nScripts")
    st, _ = save("at-%s-crlf.sh" % RND, header("Add-on test CRLF").replace("\n", "\r\n") + "echo crlf-ok\r\n")
    st, r = admin.call("GET", "/api/addons/%s/at-%s-crlf.sh" % (COURSE, RND))
    check("\r" not in r.get("text", "x"), "Windows line ends are turned into Unix ones when saved")
    state, msg, out = run("at-%s-crlf.sh" % RND)
    check(state == "ok" and "crlf-ok" in out, "a script saved with Windows line ends runs", msg + out[:100])
    st, lst = admin.call("GET", "/api/addons?course=" + COURSE)
    me = next((a for a in lst.get("addons", []) if a.get("file") == "at-%s-crlf.sh" % RND), {})
    check(me.get("name") == "Add-on test CRLF", "the header lines are read (name)", str(me)[:150])
    save("at-%s-loud.sh" % RND, header("Add-on test loud") + "head -c 450000 /dev/zero | tr '\\0' x | fold -w 100\n")
    state, msg, out = run("at-%s-loud.sh" % RND)
    check(state == "ok" and "the rest isn't shown" in out, "more than 400 KB of output is cut - and says so", msg)
    save("at-%s-exit.sh" % RND, header("Add-on test exit") + "echo before\nexit 3\n")
    state, msg, out = run("at-%s-exit.sh" % RND)
    check(state == "failed" and "exit code 3" in msg and "before" in out, "an add-on that fails shows its exit code and output", msg)

    # ------------------------------------------------------------------ roles
    print("\nRoles")
    st, u = admin.call("POST", "/api/users", {"name": "at-%s" % RND, "role": "instructor", "courses": [COURSE]})
    if st == 200 and u.get("password"):
        made_users.append("at-%s" % RND)
        ins = Client()
        ins.call("POST", "/api/login", {"user": "at-%s" % RND, "password": u["password"]})
        save("at-%s-nobutton.sh" % RND, header("Add-on test not a button") + "echo hi\n")
        save("at-%s-button.sh" % RND, header("Add-on test button", extra="# BUTTON: yes\n") + "echo button-ok\n")
        st, lst = ins.call("GET", "/api/addons?course=" + COURSE)
        names = [a.get("name") for a in lst.get("addons", [])]
        check(st == 200 and "Add-on test button" in names and "Add-on test not a button" not in names,
              "an instructor sees the buttons only", str(names)[:200])
        state, msg, out = run("at-%s-nobutton.sh" % RND, who=ins)
        check(state is None and "can't" in msg, "an instructor can't run an add-on that isn't a button", msg)
        state, msg, out = run("at-%s-button.sh" % RND, who=ins)
        check(state == "ok" and "button-ok" in out, "an instructor runs a button", msg)
        st, _ = ins.call("PUT", "/api/addons/%s/at-%s-x.sh" % (COURSE, RND), {"text": "echo x\n"})
        check(st == 403, "an instructor can't write add-ons", "HTTP %d" % st)
        other_course = next((c["name"] for c in courses if c["name"] != COURSE), "")
        if other_course:
            st, _ = ins.call("POST", "/api/plan", {"action": "addon_run", "course": other_course, "scope": other_course, "file": "x.sh", "ids": []})
            check(st == 403, "an instructor can't run add-ons of a course that isn't theirs", "HTTP %d" % st)
    else:
        bad("a test instructor can be made", str(u)[:150])

    # ------------------------------------------------------------------ host add-ons
    print("\nHost add-ons")
    st, hb = admin.call("GET", "/api/bridgeports")
    nodes = hb.get("nodes", {}) if st == 200 else {}
    node = (vm or ct or guests[0])["node"]
    lbr = (nodes.get(node, {}).get("linux") or [""])[0]
    obr = (nodes.get(node, {}).get("ovs") or [""])[0]
    hl = ["# NODE: %s" % node, "t() { echo \"### $*\"; o=$(\"$@\" 2>&1); rc=$?; printf '%s\\n' \"$o\" | head -4; echo \"-> exit $rc\"; }", "t ovs-vsctl --version"]
    if lbr:
        hl.append("t mcsnoop %s show" % lbr)
    if obr:
        hl.append("t mcsnoop %s show" % obr)
    hl.append("t ovs-vsctl 'two words'")
    save("at-%s-host.sh" % RND, header("Add-on test host", kind="host") + "\n".join(hl) + "\n")
    st, lst = admin.call("GET", "/api/addons?course=" + COURSE)
    me = next((a for a in lst.get("addons", []) if a.get("file") == "at-%s-host.sh" % RND), {})
    check(me.get("kind") == "host" and me.get("node") == node, "a host add-on is listed as host add-on with its host", str(me)[:150])
    state, msg, out = run("at-%s-host.sh" % RND)
    blocks = {}
    for b in out.split("### ")[1:]:
        h_, _, rest = b.partition("\n")
        blocks[h_.strip()] = rest
    v = blocks.get("ovs-vsctl --version", "")
    if "no node key" in v or "Permission denied" in v or "Could not resolve" in v or "timed out" in v:
        skip("ovs-vsctl and mcsnoop on the host", "the node key isn't set up on %s - %s" % (node, v.strip()[:100]))
    else:
        check("-> exit 0" in v and "ovs-vsctl" in v.lower(), "ovs-vsctl runs on the host through the node key", v[:150])
        for br in (lbr, obr):
            if not br:
                continue
            m_ = blocks.get("mcsnoop %s show" % br, "")
            if "from before ICS Ranges 3.1.4" in m_:
                skip("mcsnoop %s show" % br, "the node key on %s is older - put it there again: ./setup.sh node-key <IP>" % node)
            else:
                check("-> exit 0" in m_ and "IGMP snooping on %s" % br in m_, "mcsnoop %s show (%s)" % (br, "Linux bridge" if br == lbr else "Open vSwitch"), m_[:150])
    w = blocks.get("ovs-vsctl 'two words'", blocks.get("ovs-vsctl two words", ""))
    check("has a space" in w, "ovs-vsctl refuses an argument with a space", w[:120])

    # ------------------------------------------------------------------ mirror add-ons (never switched on)
    print("\nMirror add-ons")
    if obr:
        st, r = admin.call("POST", "/api/madd/parse", {"course": COURSE, "text":
            "qm set 999 --net1 virtio,bridge=%s,firewall=0\novs-vsctl -- --id=@p get port atest0 -- --id=@m create mirror name=x select-all=true output-port=@p -- set bridge %s mirrors=@m" % (obr, obr)})
        check(st == 200 and len(r.get("addons", [])) == 1 and any("MAC" in n for n in r.get("notes", [])),
              "a mirror script is read - and the MAC warning given", str(r)[:200])
        body = {"name": "Add-on test %s" % RND, "course": COURSE, "node": node, "bridge": obr, "source": {"all": True},
                "dest": {"kind": "phys", "iface": "atest0"}, "button": False}
        st, r = admin.call("POST", "/api/madd", body)
        mid = r.get("id")
        if check(st == 200 and mid, "a mirror add-on is made (not switched on)", str(r)[:150]):
            made_mirrors.append(mid)
            body["source"] = {"all": False, "ports": [{"kind": "phys", "iface": "atest1"}], "dir": "in"}
            st, _ = admin.call("PUT", "/api/madd/" + mid, body)
            st, v_ = admin.call("GET", "/api/madd?course=" + COURSE)
            me = next((m for m in v_.get("addons", []) if m["id"] == mid), {})
            check(me and not me.get("active") and "atest1" in me.get("equation", ""), "it is changed, and stays off", str(me)[:200])
            st, _ = admin.call("DELETE", "/api/madd/%s/x" % mid)
            check(st == 400, "a delete with a longer address is refused", "HTTP %d" % st)
    else:
        skip("mirror add-ons", "no Open vSwitch bridge on %s" % node)

    # ------------------------------------------------------------------ input
    print("\nInput")
    for nm in ("../x.sh", "a b.sh", "x.txt", "%2e%2e%2fx.sh", "." * 3 + ".sh"):
        st, _ = admin.call("PUT", "/api/addons/%s/%s" % (COURSE, urllib.request.quote(nm, safe="%")), {"text": "echo x\n"})
        if st == 200:   # saved after all: remove it again
            made_addons.append((COURSE, urllib.request.quote(nm, safe="%")))
        check(st in (400, 403, 404), "a bad add-on name is refused: %s" % nm, "HTTP %d" % st)
    st, _ = admin.call("PUT", "/api/addons/../etc/x.sh", {"text": "echo x\n"})
    check(st in (400, 403, 404), "a path outside the add-ons is refused", "HTTP %d" % st)
finally:
    # ------------------------------------------------------------------ clean up
    for c, n in made_addons:
        admin.call("DELETE", "/api/addons/%s/%s" % (c, n))
    for mid in made_mirrors:
        admin.call("DELETE", "/api/madd/" + mid)
    for u in made_users:
        admin.call("DELETE", "/api/users/" + u)
    print("\n %d passed, %d failed, %d skipped" % (len(passed), len(failed), len(skipped)))
    for f in failed:
        print("  - " + f)
sys.exit(1 if failed else 0)
