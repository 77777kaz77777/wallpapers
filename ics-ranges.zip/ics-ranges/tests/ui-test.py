#!/usr/bin/env python3
"""ui-test.py - opens every page and window of ICS Ranges in a real browser and checks them.

It catches what the API test (gui-test.sh) can't see: a window that shows "[object HTMLElement]",
"undefined" or "NaN", a script error, a button that leads nowhere, a request that fails.
It only OPENS and CLOSES windows - nothing is started, stopped or changed - so it is safe on a
real kit (it only adds "readiness check" lines to Activity).

Easiest - tests/ui-test.sh sets up Playwright in its own Python environment on the first run:
    ./tests/ui-test.sh https://127.0.0.1:8443 kaz
(On Debian 12/13 first: sudo apt-get install -y python3-venv chromium)
Or by hand, with Playwright already installed:
    python3 tests/ui-test.py https://192.168.77.91:8443 kaz    # asks for the password
    UI_PASSWORD=... python3 tests/ui-test.py URL USER          # without asking
Options: --course 613 (only that course)  --headed (watch it)  --shots DIR (a picture of every window)
"""
import asyncio
import getpass
import os
import re
import sys

try:
    from playwright.async_api import async_playwright
except ImportError:
    sys.exit("Playwright is missing - use tests/ui-test.sh, which installs it in its own environment:\n"
             "    ./tests/ui-test.sh https://127.0.0.1:8443 <admin user>")

args = [a for a in sys.argv[1:] if not a.startswith("--")]
opts = sys.argv[1:]
if len(args) < 2:
    sys.exit("Usage: python3 tests/ui-test.py https://<kit>:8443 <admin user>   [--course 613] [--headed] [--shots DIR]")
URL = args[0].rstrip("/")
USER = args[1]
try:
    PASSWORD = os.environ.get("UI_PASSWORD") or getpass.getpass("Password for %s: " % USER)
except (EOFError, KeyboardInterrupt):
    sys.exit("No password - type it when asked, or set UI_PASSWORD")
ONLY = opts[opts.index("--course") + 1] if "--course" in opts else None
SHOTS = opts[opts.index("--shots") + 1] if "--shots" in opts else None
BAD_TEXT = re.compile(r"\[object [A-Za-z]+\]|\bundefined\b|\bNaN\b")

passed = failed = 0
problems = []


def ok(msg):
    global passed
    passed += 1
    print("  PASS  " + msg, flush=True)


def bad(msg):
    global failed
    failed += 1
    problems.append(msg)
    print("  FAIL  " + msg, flush=True)


class Checker:
    def __init__(self, page):
        self.page = page
        self.errors = []
        page.on("pageerror", lambda e: self.errors.append("script error: %s" % str(e)[:200]))
        page.on("console", lambda m: self.errors.append("console: %s" % m.text[:200])
                if m.type == "error" and not re.search(r"status of (401|403|404|409|502)", m.text) else None)
        page.on("response", lambda r: self.errors.append("server error %d on %s" % (r.status, r.url.split("/", 3)[-1][:80]))
                if r.status >= 500 else None)
        self.n = 0

    async def look(self, what, where="body"):
        """No errors since the last look, and no broken text in what is on screen."""
        await self.page.wait_for_timeout(350)
        loc = self.page.locator("dialog[open]") if where == "dialog" else self.page.locator(where).first
        try:
            text = await loc.inner_text(timeout=4000)
        except Exception:   # noqa
            text = ""
        broken = BAD_TEXT.findall(text)
        errs, self.errors = self.errors, []
        self.n += 1
        if SHOTS:
            os.makedirs(SHOTS, exist_ok=True)
            await self.page.screenshot(path=os.path.join(SHOTS, "%03d-%s.png" % (self.n, re.sub(r"[^a-z0-9]+", "-", what.lower())[:50])))
        if broken or errs:
            bad("%s: %s" % (what, "; ".join(errs + ["shows '%s'" % b for b in sorted(set(broken))])))
            await self.page.screenshot(path="/tmp/ui-test-fail-%d.png" % self.n)
        else:
            ok(what)

    async def close(self):
        await self.page.keyboard.press("Escape")
        await self.page.wait_for_timeout(250)
        if await self.page.locator("dialog[open]").count():   # a window without Escape: its Cancel / Close button
            for t in ("Cancel", "Close"):
                b = self.page.locator("dialog[open] button:has-text('%s')" % t)
                if await b.count():
                    await b.first.click()
                    break
            await self.page.wait_for_timeout(250)


async def dialog_from(c, button, what, where=None):
    """Click a button, check the window it opens, close it. Returns False if the button isn't there."""
    p = c.page
    b = (where or p).locator(button).first
    if not await b.count() or not await b.is_enabled():
        return False
    await b.click()
    try:
        await p.wait_for_selector("dialog[open]", timeout=8000)
    except Exception:   # noqa
        bad("%s: no window opened" % what)
        return True
    await c.look(what, "dialog")
    await c.close()
    return True


async def course(c, name):
    p = c.page
    print("\n=== course %s" % name, flush=True)
    await p.goto(URL + "/#/course/" + name)
    await p.wait_for_selector("main", timeout=15000)
    await p.wait_for_timeout(1500)
    await c.look("course %s" % name, "main")
    if await dialog_from(c, "button:has-text('Ready for class?')", "Ready for class? %s" % name):
        pass
    await p.wait_for_timeout(200)
    for b, w in (("button.bigbtn.start", "Start class %s" % name), ("button.bigbtn.end", "End class %s" % name)):
        await dialog_from(c, b, w)
    await dialog_from(c, "button:has-text('Select…')", "Select… %s" % name)
    # tick two guests, then the windows that work on selected guests
    boxes = p.locator("main table tbody input[type=checkbox]")
    if await boxes.count() >= 2:
        await boxes.nth(0).check()
        await boxes.nth(1).check()
        snap = p.locator("button:has-text('Snapshots…')").first
        if await snap.count() and await snap.is_enabled():
            await snap.click()
            await p.wait_for_selector("dialog[open]")
            sel = p.locator("dialog[open] select").first
            for opt in await sel.locator("option").all():
                v = await opt.get_attribute("value")
                await sel.select_option(v)
                await c.look("Snapshots… %s – %s" % (name, v), "dialog")
            await c.close()
        build = p.locator("button:has-text('Build…')").first
        if await build.count() and await build.is_enabled():
            await build.click()
            await p.wait_for_selector("dialog[open]")
            sel = p.locator("dialog[open] select").first
            for opt in await sel.locator("option").all():
                v = await opt.get_attribute("value")
                await sel.select_option(v)
                await c.look("Build… %s – %s" % (name, v), "dialog")
            await c.close()
        await dialog_from(c, "button:has-text('Power off')", "Power off %s" % name)
        await boxes.nth(0).uncheck()
        await boxes.nth(1).uncheck()
    na = p.locator(".panel:has(h2:has-text('Network add-ons')) button:has-text('Change…')").first
    if await na.count():   # every bridge of the course, one after another
        await na.click()
        await p.wait_for_selector("dialog[open]")
        sel = p.locator("dialog[open] select").first
        for opt in (await sel.locator("option").all())[:6]:
            v = await opt.get_attribute("value")
            await sel.select_option(v)
            await c.look("Network add-ons %s – %s" % (name, (await opt.inner_text()).split(" – ")[0]), "dialog")
        await c.close()
    for tab in ("Class guide", "Add-ons", "Storage and disks", "Guests"):
        t = p.locator("button[role=tab]:has-text('%s')" % tab)
        if not await t.count():
            continue
        await t.first.click()
        await p.wait_for_timeout(700)
        await c.look("%s tab %s" % (tab, name), "main")
        if tab == "Add-ons":
            if await p.locator("button:has-text('New add-on')").count():
                await p.click("button:has-text('New add-on')")
                await p.wait_for_selector("dialog[open]")
                add = p.locator("dialog[open] .addon-add select")
                if await add.count():
                    for v in ("snap_restore", "wait", "start", "custom"):
                        await add.select_option(v)
                await c.look("New add-on – steps %s" % name, "dialog")
                st = p.locator("dialog[open] button[role=tab]:has-text('Write the script')")
                if await st.count():
                    await st.click()
                    await c.look("New add-on – script %s" % name, "dialog")
                await c.close()
            run = p.locator("main table tbody button:has-text('Run')")
            if await run.count():
                await run.first.click()
                await p.wait_for_selector("dialog[open]")
                await c.look("Add-on Run – choose guests %s" % name, "dialog")
                await c.close()


async def main():
    print("ICS Ranges browser test – %s as %s" % (URL, USER))
    async with async_playwright() as pw:
        exe = os.environ.get("UI_CHROMIUM")   # the system's Chromium (ui-test.sh finds it), else Playwright's own
        br = await pw.chromium.launch(headless="--headed" not in opts, **({"executable_path": exe} if exe else {}))
        ctx = await br.new_context(ignore_https_errors=True, viewport={"width": 1366, "height": 900})
        page = await ctx.new_page()
        c = Checker(page)
        print("\n=== sign-in")
        await page.goto(URL + "/")
        await page.wait_for_selector("form", timeout=20000)
        await c.look("sign-in page", "form")
        await page.fill("input[name=user]", USER)
        await page.fill("input[name=password]", PASSWORD)
        await page.click("button[type=submit]")
        try:
            await page.wait_for_selector(".rail", timeout=20000)
            ok("signed in as %s" % USER)
        except Exception:   # noqa
            bad("sign-in failed – wrong name or password, or 2FA is on for this user")
            await br.close()
            return
        courses = []
        for a in await page.locator(".rail a[href^='#/course/']").all():
            courses.append((await a.get_attribute("href")).split("/course/", 1)[1])
        print("courses: %s" % ", ".join(courses))
        for name in courses:
            if ONLY and name != ONLY:
                continue
            await course(c, name)
        print("\n=== pages")
        for href, extra in (("#/users", "Add a user"), ("#/roles", "New role"), ("#/map", "New mixed course…"), ("#/activity", None),
                            ("#/share", None), ("#/settings", None), ("#/updates", None), ("#/help", None)):
            if not await page.locator(".rail a[href='%s']" % href).count():
                continue
            await page.goto(URL + "/" + href)
            await page.wait_for_timeout(1200)
            await c.look("page %s" % href[2:], "main")
            if extra and extra != "New role":
                await dialog_from(c, "main button:has-text('%s')" % extra, "%s – %s" % (href[2:], extra))
        acc = page.locator(".rail >> text=Account")
        if await acc.count():
            await acc.first.click()
            await page.wait_for_selector("dialog[open]")
            await c.look("Account", "dialog")
            await c.close()
        await br.close()
    print("\n==================================\n %d passed, %d failed\n==================================" % (passed, failed))
    if problems:
        print("Problems (pictures in /tmp/ui-test-fail-*.png):")
        for p in problems:
            print("  - " + p)
    sys.exit(1 if failed else 0)


asyncio.run(main())
