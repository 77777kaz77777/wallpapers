#!/usr/bin/env bash
# Add-on test for ICS Ranges - safe on a real kit (reads only; removes what it makes).
#   ./tests/addon-test.sh https://127.0.0.1:8443 kaz [--course 613]
#   ADDON_PASSWORD=... ./tests/addon-test.sh URL USER        # without asking
# Needs only python3 (standard library). Output also in /tmp/addon-test.out.
set -o pipefail
cd "$(dirname "$(readlink -f "$0")")" || exit 1
python3 addon-test.py "$@" 2>&1 | tee /tmp/addon-test.out
