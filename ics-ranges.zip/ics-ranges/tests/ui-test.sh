#!/usr/bin/env bash
# ui-test.sh - run the browser test (ui-test.py) without touching the system's Python.
# First run: makes its own Python environment in ~/.cache/ics-ranges-ui-test and installs Playwright there.
#   ./tests/ui-test.sh https://127.0.0.1:8443 kaz          (asks for the password)
#   ./tests/ui-test.sh https://127.0.0.1:8443 kaz --course 613
set -u
here=$(cd "$(dirname "$0")" && pwd)
venv=${UI_TEST_VENV:-$HOME/.cache/ics-ranges-ui-test}
if [[ $# -lt 2 ]]; then
    echo "Usage: $0 https://<kit>:8443 <admin user> [--course 613] [--headed] [--shots DIR]"
    exit 2
fi
if [[ ! -x $venv/bin/python ]]; then
    echo "First run: setting up the browser test in $venv ..."
    if ! python3 -m venv "$venv" 2>/dev/null; then
        rm -rf "$venv"
        echo "Python can't make environments yet. Install it once, then run this again:"
        echo "    sudo apt-get install -y python3-venv chromium      (Debian)"
        echo "    sudo dnf -y install python3 chromium               (Rocky, chromium from EPEL)"
        exit 1
    fi
    "$venv/bin/pip" install -q --upgrade pip playwright || { echo "Installing Playwright failed (needs internet)."; exit 1; }
fi
# a browser: the system's Chromium if there is one, else Playwright's own (downloaded once)
if [[ -z ${UI_CHROMIUM:-} ]]; then
    for b in /usr/bin/chromium /usr/bin/chromium-browser /usr/bin/google-chrome; do
        [[ -x $b ]] && { export UI_CHROMIUM=$b; break; }
    done
fi
if [[ -z ${UI_CHROMIUM:-} ]] && ! ls "$HOME"/.cache/ms-playwright/chromium* >/dev/null 2>&1; then
    echo "No Chromium found - downloading Playwright's (once) ..."
    "$venv/bin/python" -m playwright install chromium || {
        echo "That failed. Easiest on Debian:  sudo apt-get install -y chromium   - then run this again."; exit 1; }
fi
exec "$venv/bin/python" "$here/ui-test.py" "$@"
