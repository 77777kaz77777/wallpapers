#!/usr/bin/env python3
"""gui-test.py - end-to-end test of ICS Ranges through its own web API.

Runs inside the container (started by ../gui-test.sh). Standard library only.
It makes its own test users (removed again), and runs real actions only on guests
tagged "fake-range" in the test course (default 613) - made by range-seed.sh.

Environment:
  GT_URL     the page (default https://127.0.0.1:8443)
  GT_COURSE  the test course (default 613)
  GT_ACTIONS 0 = only check, don't start / stop / snapshot anything (default 1)
  GT_PVR     how to run the pvr command (default: python3 /app/server.py)
"""
import http.cookiejar
import json
import os
import random
import shlex
import ssl
import string
import subprocess
import sys
import time
import urllib.error
import urllib.request

URL = os.environ.get("GT_URL", "https://127.0.0.1:8443").rstrip("/")
COURSE = os.environ.get("GT_COURSE", "613")
ACTIONS = os.environ.get("GT_ACTIONS", "1") != "0"
PVR = shlex.split(os.environ.get("GT_PVR", "python3 /app/server.py"))
TAG = "fake-range"
SNAP = "GT1"
RND = "".join(random.choice(string.ascii_lowercase) for _ in range(5))
ADMIN, INSTR, VICTIM = "gt-admin-" + RND, "gt-instr-" + RND, "gt-lock-" + RND
PW = "Gt-" + "".join(random.choice(string.ascii_letters + string.digits) for _ in range(16))

passed = failed = skipped = 0
CTX = ssl._create_unverified_context()


def ok(msg):
    global passed
    passed += 1
    print("  PASS  " + msg, flush=True)


def bad(msg):
    global failed
    failed += 1
    print("  FAIL  " + msg, flush=True)


def skip(msg):
    global skipped
    skipped += 1
    print("  SKIP  " + msg, flush=True)


def check(cond, msg, why=""):
    if cond:
        ok(msg)
    else:
        bad(msg + ((" - " + why) if why else ""))
    return cond


def step(title):
    print("\n=== " + title, flush=True)


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(self.jar)]
        if URL.startswith("https"):
            handlers.append(urllib.request.HTTPSHandler(context=CTX))
        self.op = urllib.request.build_opener(*handlers)

    def call(self, method, path, body=None, header=True):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(URL + path, data=data, method=method)
        if header:
            req.add_header("X-PVR", "1")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with self.op.open(req, timeout=120) as r:
                raw = r.read()
                return r.status, (json.loads(raw) if raw[:1] in (b"{", b"[") else raw)
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, json.loads(raw)
            except ValueError:
                return e.code, {"error": raw.decode(errors="replace")}

    def login(self, user, pw, code=None):
        b = {"user": user, "password": pw}
        if code:
            b["code"] = code
        return self.call("POST", "/api/login", b)


def pvr(*args):
    p = subprocess.run(PVR + list(args), capture_output=True, text=True, timeout=120)
    return p.returncode, (p.stdout + p.stderr).strip()


def run_plan(c, body, timeout=900):
    """plan -> run -> wait; returns (plan, job) or (error, None)"""
    st, plan = c.call("POST", "/api/plan", body)
    if st != 200:
        return plan.get("error", "HTTP %d" % st), None
    if not plan["count"]:
        return plan, {"ok": 0, "failed": 0, "total": 0, "groups": []}
    st, r = c.call("POST", "/api/plan/%s/run" % plan["id"])
    if st != 200:
        return r.get("error", "HTTP %d" % st), None
    t0 = time.time()
    while time.time() - t0 < timeout:
        st, job = c.call("GET", "/api/job/" + r["job"])
        if st == 200 and job["state"] == "done":
            return plan, job
        time.sleep(1)
    return "the job didn't finish in %d s" % timeout, None


def job_ok(name, res):
    plan, job = res
    if job is None:
        return bad("%s: %s" % (name, plan))
    if job["failed"]:
        why = "; ".join("%s: %s" % (s["label"], s["msg"]) for g in job["groups"] for s in g if s["state"] == "failed")
        return bad("%s: %d of %d steps failed (%s)" % (name, job["failed"], job["total"], why[:400]))
    ok("%s (%d step(s))" % (name, job["total"]))


def course(c, fresh=True):
    st, d = c.call("GET", "/api/course/%s%s" % (COURSE, "?fresh=1" if fresh else ""))
    return d if st == 200 else None


def states(c, ids):
    time.sleep(2)
    d = course(c) or {"guests": []}
    return {g["vmid"]: g for g in d["guests"] if g["vmid"] in ids}


def expect(c, ids, want, what):
    s = states(c, ids)
    wrong = ["%d is %s" % (v, s[v]["status"]) for v in ids if v in s and s[v]["status"] != want]
    check(not wrong, "%s: all %d %s" % (what, len(ids), want), ", ".join(wrong))


SAVED = {"roles": None}


def cleanup():
    """Remove every gt-* test user (also ones left by an interrupted run) and the test role."""
    rc, out = pvr("users")
    for line in out.splitlines():
        name = line.split()[0] if line.split() else ""
        if name.startswith("gt-"):
            pvr("users", "del", name)
    if SAVED["roles"] is not None:
        try:
            with open(os.path.join(os.environ.get("DATA_DIR", "/data"), "roles.json"), "w") as f:
                json.dump(SAVED["roles"], f, indent=2, sort_keys=True)
        except OSError:
            pass


def main():
    print("ICS Ranges test - %s, course %s%s" % (URL, COURSE, "" if ACTIONS else " (checks only)"))
    a = Client()

    # ------------------------------------------------------------------ 1
    step("1. the page and sign-in")
    st, s = a.call("GET", "/api/session")
    check(st == 200 and "signed_in" in s, "the server answers (version %s)" % (s.get("version") if isinstance(s, dict) else "?"))
    if isinstance(s, dict) and s.get("setup"):
        bad("no users yet - open the page once and create the first admin, then run the test again")
        return
    for f in ("/", "/app.js", "/tools.js", "/app.css", "/fonts/barlow-latin-400-normal.woff2"):
        st, _ = a.call("GET", f)
        check(st == 200, "serves %s" % f)
    rc, out = pvr("users", "add", ADMIN, "--role", "admin", "--password", PW)
    check(rc == 0, "test admin %s made with the pvr command" % ADMIN, out)
    st, r = a.login(ADMIN, "wrong-password")
    check(st == 401, "a wrong password is refused")
    st, r = a.login(ADMIN, PW)
    if not check(st == 200 and r.get("ok"), "the test admin signs in", str(r)):
        return
    st, s = a.call("GET", "/api/session")
    check(s.get("role") == "admin" and "settings" in s.get("perms", []), "the session says admin with every permission")
    st, r = a.call("POST", "/api/plan", {"action": "power_on"}, header=False)
    check(st == 403, "a change without the page's own header is refused (cross-site protection)")

    # ------------------------------------------------------------------ 2
    step("2. courses and guests (through the Proxmox API)")
    st, cs = a.call("GET", "/api/courses")
    names = [x["name"] for x in cs] if st == 200 else []
    check(st == 200 and names, "courses found: " + ", ".join("%s (%d)" % (x["name"], x["count"]) for x in cs) if names else "courses found", str(cs)[:200])
    if not check(COURSE in names, "the test course %s is there" % COURSE):
        return
    d = course(a)
    if not check(d is not None, "course %s reads" % COURSE):
        return
    test_ids = [g["vmid"] for g in d["guests"] if TAG in g["tags"]]
    labels_ok = all(g["label"].startswith(COURSE) or g["vmid"] < 100000 for g in d["guests"])
    check(labels_ok, "guests are named from their VMID (e.g. %s)" % (d["guests"][0]["label"] if d["guests"] else "-"))
    check(bool(test_ids), "%d test guest(s) tagged %s: %s" % (len(test_ids), TAG, " ".join(map(str, test_ids))),
          "run range-seed.sh create on a node first")
    vms = [g["vmid"] for g in d["guests"] if g["vmid"] in test_ids and g["type"] == "qemu"]

    # ------------------------------------------------------------------ 3
    step("3. roles, courses per user and lock-out")
    st, r = a.call("POST", "/api/users", {"name": INSTR, "role": "instructor", "courses": [COURSE]})
    ipw = r.get("password") if st == 200 else None
    check(bool(ipw), "an instructor for %s is added with a generated password" % COURSE, str(r))
    i = Client()
    st, r = i.login(INSTR, ipw or "")
    check(st == 200, "the instructor signs in")
    st, s = i.call("GET", "/api/session")
    check(set(s.get("perms", [])) >= {"class_run", "power", "mirror_status", "mirror_apply"}, "instructor may run classes, power and mirrors")
    st, cs2 = i.call("GET", "/api/courses")
    check([x["name"] for x in cs2] == [COURSE], "instructor sees only their course", str([x["name"] for x in cs2]))
    other = next((n for n in names if n != COURSE), None)
    if other:
        st, _ = i.call("GET", "/api/course/" + other)
        check(st == 403, "instructor can't open another course (%s)" % other)
    for what, call in (("take snapshots", ("POST", "/api/plan", {"action": "snap_take", "course": COURSE, "ids": test_ids[:1], "snapshot": "X1"})),
                       ("manage users", ("GET", "/api/users", None)),
                       ("change settings", ("PUT", "/api/settings", {"backup_keep": 30})),
                       ("change network settings", ("POST", "/api/plan", {"action": "network", "course": COURSE, "ids": test_ids[:1], "change": {"vlan": "9"}})),
                       ("use Save & share", ("GET", "/api/git", None))):
        st, _ = i.call(*call)
        check(st == 403, "instructor can't %s" % what)
    if test_ids:   # Start class only powers on for instructors; End class resets
        st, p = i.call("POST", "/api/plan", {"action": "class_start", "course": COURSE, "snapshot": "ClassStart", "restore": test_ids, "start": test_ids})
        check(st == 200 and not any("Restore" in x["label"] for g in p.get("groups", []) for x in g),
              "instructor's Start class doesn't restore (End class resets)", str(p)[:200])
        st, p = i.call("POST", "/api/plan", {"action": "class_end", "course": COURSE, "snapshot": "ClassStart", "restore": test_ids, "off": test_ids})
        check(st == 200 and any("Restore" in x["label"] for g in p.get("groups", []) for x in g) or not p.get("count"),
              "instructor's End class resets (restore + switch off)", str(p)[:200])
    st, _ = a.call("POST", "/api/users", {"name": VICTIM, "role": "viewer", "courses": [COURSE]})
    codes = [a.__class__().login(VICTIM, "wrong-%d" % k)[0] for k in range(6)]
    check(codes[-1] == 429, "6 wrong passwords lock the name out", str(codes))
    st, _ = a.call("POST", "/api/users/%s/unlock" % VICTIM)
    check(st == 200, "an admin unlocks it")
    st, rr = a.call("GET", "/api/roles")
    roles = rr.get("roles", {}) if st == 200 else {}
    SAVED["roles"] = dict(roles)
    roles2 = dict(roles)
    roles2["gt-role-" + RND] = ["overview"]
    st, _ = a.call("PUT", "/api/roles", {"roles": roles2})
    check(st == 200, "a new role can be made")
    st, _ = a.call("PUT", "/api/users/" + VICTIM, {"role": "gt-role-" + RND, "courses": [COURSE]})
    check(st == 200, "a user gets the new role")
    st, r = a.call("PUT", "/api/roles", {"roles": roles})
    check(st == 400, "a role still in use can't be deleted")

    # ------------------------------------------------------------------ 4
    step("4. two-factor sign-in")
    sys.path.insert(0, os.environ.get("GT_APP", "/app"))
    try:
        try:   # for the TOTP code: in ics/core.py since 3.2.2, in server.py before
            import ics.core as S
        except ImportError:
            import server as S
        st, r = a.call("POST", "/api/me/2fa-start")
        st, r2 = a.call("POST", "/api/me/2fa-confirm", {"code": S.totp(r["secret"])})
        check(st == 200, "2FA turned on with a code")
        t = Client()
        st, r3 = t.login(ADMIN, PW)
        check(r3.get("need_code") is True, "sign-in now asks for the code")
        st, r3 = t.login(ADMIN, PW, "000000")
        check(st == 401, "a wrong code is refused")
        st, r3 = t.login(ADMIN, PW, S.totp(r["secret"]))
        check(st == 200, "the right code signs in")
        st, _ = a.call("POST", "/api/me/2fa-off", {"password": PW})
        check(st == 200, "2FA turned off again")
    except Exception as e:   # noqa
        skip("2FA test: %s" % e)

    # ------------------------------------------------------------------ 5
    step("5. plans are checked before anything runs")
    st, p = a.call("POST", "/api/plan", {"action": "network", "course": COURSE, "ids": test_ids, "nic": "all", "change": {"vlan": "77"}})
    check(st == 200 and p.get("count", 0) > 0, "network plan: %d step(s), not run" % p.get("count", 0), str(p)[:200])
    st, stg = a.call("GET", "/api/storages")
    raw = [x["storage"] for x in stg if x.get("raw_only")] if st == 200 else []
    if raw:
        st, p = a.call("POST", "/api/plan", {"action": "disk_move", "course": COURSE, "ids": test_ids, "storage": raw[0], "format": "qcow2"})
        check(st == 400, "qcow2 is refused on %s (raw only)" % raw[0])
    else:
        skip("no raw-only storage to test the format check")
    if len(d["nodes"]) > 1 and test_ids:
        st, p = a.call("POST", "/api/plan", {"action": "migrate", "course": COURSE, "ids": test_ids, "node": d["nodes"][0]})
        check(st == 200, "migrate plan to %s: %d step(s), not run" % (d["nodes"][0], p.get("count", 0)))
    st, p = a.call("POST", "/api/plan", {"action": "class_start", "course": COURSE, "snapshot": "bad name!", "restore": test_ids, "start": test_ids})
    check(st == 400, "a bad snapshot name is refused")

    # ------------------------------------------------------------------ 6
    step("6. class guide and add-on")
    st, g = a.call("GET", "/api/guide/" + COURSE)
    old_guide = g.get("text") if st == 200 else None
    st, _ = a.call("PUT", "/api/guide/" + COURSE, {"text": "# test %s\n- step one\n" % RND})
    st2, g2 = a.call("GET", "/api/guide/" + COURSE)
    check(st == 200 and RND in (g2.get("text") or ""), "class guide written and read back")
    if old_guide is not None:
        a.call("PUT", "/api/guide/" + COURSE, {"text": old_guide})
    else:
        a.call("DELETE", "/api/guide/" + COURSE)
    ok("class guide put back as it was")
    addon = "gt-%s.sh" % RND
    st, _ = a.call("PUT", "/api/addons/%s/%s" % (COURSE, addon), {"text": "#!/usr/bin/env bash\n# NAME: GUI test %s\n# GUESTS: yes\n"
                   "for id in $GUESTS; do echo \"== $id\"; qm status \"$id\" 2>/dev/null || pct status \"$id\"; done\n" % RND})
    st2, lst = a.call("GET", "/api/addons?course=" + COURSE)
    check(st == 200 and any(x["file"] == addon for x in lst.get("addons", [])), "add-on saved and listed")
    if test_ids:
        plan, job = run_plan(a, {"action": "addon_run", "course": COURSE, "scope": COURSE, "file": addon, "ids": test_ids})
        out = job["groups"][0][0].get("out") if job and job["groups"] else ""
        check(job is not None and not job["failed"] and (out or "").count("status:") == len(test_ids),
              "add-on ran on %d guest(s) with qm / pct through the API" % len(test_ids), (out or str(plan))[:300])
    st, _ = a.call("DELETE", "/api/addons/%s/%s" % (COURSE, addon))
    check(st == 200, "add-on deleted")

    # ------------------------------------------------------------------ 7
    step("7. sensors, storage, settings, save & share")
    st, m = a.call("GET", "/api/madd?course=" + COURSE)
    adds = m.get("addons", []) if st == 200 else []
    check(st == 200, "mirror add-ons read (%d for %s)" % (len(adds), COURSE))
    for mm in adds:
        if mm["status"]["state"] in ("problem", "unknown"):
            skip("mirror add-on %s: %s" % (mm["name"], mm["status"]["text"]))
    st, i_m = i.call("GET", "/api/madd?course=" + COURSE)
    check(st == 200, "instructors see the mirror add-ons (their buttons)")
    # a mirror add-on definition - made, read, deleted; never switched on, so nothing changes on the bridge
    st, hb = a.call("GET", "/api/bridgeports")
    node_ovs = next(((n, b["ovs"][0]) for n, b in (hb.get("nodes") or {}).items() if b.get("ovs")), None) if st == 200 else None
    if node_ovs:
        body = {"name": "GUI test mirror %s" % RND, "course": COURSE, "node": node_ovs[0], "bridge": node_ovs[1], "source": {"all": True},
                "dest": {"kind": "phys", "iface": "guitest0"}, "button": False}
        st, r = a.call("POST", "/api/madd", body)
        mid = r.get("id") if st == 200 else None
        check(st == 200 and mid, "a mirror add-on is made (not switched on)", str(r)[:150])
        st, _ = i.call("DELETE", "/api/madd/%s" % mid)
        check(st == 403, "instructors can't delete mirror add-ons")
        st, _ = a.call("DELETE", "/api/madd/%s" % mid)
        check(st == 200, "the mirror add-on is deleted again")
    else:
        skip("no Open vSwitch bridge - mirror add-ons not tried")
    st, nl = a.call("GET", "/api/nics?course=" + COURSE)
    one = next((n for n in (nl.get("nics", []) if st == 200 else [])), None)
    if one:   # planned only, never run: a connect plan must not be empty
        st, pl = a.call("POST", "/api/plan", {"action": "nic_connect", "course": COURSE, "nics": [{"vmid": one["vmid"], "nic": one["nic"]}]})
        check(st == 200 and (pl.get("groups") or pl.get("notes")), "Connect them plans a step or says why not (%d %s)" % (one["vmid"], one["nic"]), str(pl)[:150])
    st, r = a.call("POST", "/api/madd/parse", {"course": COURSE, "text": "ovs-vsctl -- --id=@p get port eno9 -- --id=@m create mirror name=x select-all=true output-port=@p -- set bridge vmbr9 mirrors=@m"})
    check(st == 200 and len(r.get("addons", [])) == 1 and r["addons"][0]["dest"] == {"kind": "phys", "iface": "eno9"}, "a mirror script is read into a mirror add-on", str(r)[:150])
    st, o = a.call("GET", "/api/overview?course=" + COURSE)
    check(st == 200 and o.get("storages"), "storage and disks: %d storages, %d disks" % (len(o.get("storages", [])), len(o.get("disks", []))))
    st, sv = a.call("GET", "/api/settings")
    check(st == 200 and "default_snapshot" in sv.get("settings", {}), "settings read")
    st, gi = a.call("GET", "/api/git")
    check(st == 200, "Save & share reads (%d saves, %d backups, repository: %s)" % (len(gi.get("history", [])), len(gi.get("backups", [])), gi.get("url") or "none"))
    st, r = a.call("POST", "/api/git/backup")
    check(st == 200, "a backup is made")
    st, r = a.call("POST", "/api/git/save", {"message": "GUI test %s" % RND})
    check(st == 200, "save: " + (r.get("report") or r.get("error", "")))

    # ------------------------------------------------------------------ 8
    step("8. real actions on the test guests (%s)" % (" ".join(map(str, test_ids)) or "none"))
    if not ACTIONS:
        skip("GT_ACTIONS=0 - nothing is started or stopped")
    elif not test_ids:
        skip("no guests tagged %s in %s" % (TAG, COURSE))
    else:
        job_ok("take snapshot %s" % SNAP, run_plan(a, {"action": "snap_take", "course": COURSE, "ids": test_ids, "snapshot": SNAP, "replace": True}))
        s = states(a, test_ids)
        missing = [v for v in test_ids if not any(x["name"] == SNAP for x in s.get(v, {}).get("snapshots", []))]
        check(not missing, "every test guest has %s" % SNAP, "missing on " + str(missing))
        job_ok("Start class to %s" % SNAP, run_plan(a, {"action": "class_start", "course": COURSE, "snapshot": SNAP, "restore": test_ids, "start": test_ids}))
        expect(a, test_ids, "running", "after Start class")
        job_ok("power off (hard)", run_plan(a, {"action": "power_off", "course": COURSE, "ids": test_ids, "mode": "stop"}))
        expect(a, test_ids, "stopped", "after power off")
        job_ok("power on", run_plan(a, {"action": "power_on", "course": COURSE, "ids": test_ids}))
        expect(a, test_ids, "running", "after power on")
        job_ok("End class to %s" % SNAP, run_plan(a, {"action": "class_end", "course": COURSE, "snapshot": SNAP, "restore": test_ids, "off": test_ids, "mode": "stop"}))
        expect(a, test_ids, "stopped", "after End class")
        if vms:
            job_ok("restore %s" % SNAP, run_plan(a, {"action": "snap_restore", "course": COURSE, "ids": vms, "snapshot": SNAP}))
        job_ok("delete snapshot %s" % SNAP, run_plan(a, {"action": "snap_delete", "course": COURSE, "ids": test_ids, "snapshot": SNAP}))
        s = states(a, test_ids)
        left = [v for v in test_ids if any(x["name"] == SNAP for x in s.get(v, {}).get("snapshots", []))]
        check(not left, "%s removed again" % SNAP, str(left))
        st, au = a.call("GET", "/api/audit")
        check(st == 200 and any(ADMIN in ln and "Start" in ln for ln in au.get("lines", [])), "the activity log shows what ran, with the user's name")

    # ------------------------------------------------------------------ 9
    step("9. bad requests change nothing")
    st, before = a.call("GET", "/api/vmidmap")
    st0, g0 = a.call("GET", "/api/groups")
    worst = 0
    for m, p_, body in (("PUT", "/api/settings", []), ("POST", "/api/plan", None), ("PUT", "/api/mixed/x", {"vmids": "abc"}),
                        ("PUT", "/api/guide/" + COURSE, {"text": 5}), ("PUT", "/api/users/" + ADMIN, {"role": []}),
                        ("POST", "/api/session", {}), ("PUT", "/api/updates/connect", {"url": 5})):
        st, _ = a.call(m, p_, body)
        worst = max(worst, st)
    check(worst < 500, "wrong kinds of data are answered with an error, never a crash (worst HTTP %d)" % worst)
    st1, _ = a.call("DELETE", "/api/vmidmap")
    st2, _ = a.call("PUT", "/api/vmidmap", {})
    st3, _ = a.call("PUT", "/api/vmidmap", {"text": "# nothing"})
    st4, _ = a.call("PUT", "/api/groups", {})
    st5, _ = a.call("DELETE", "/api/themes")
    _, after = a.call("GET", "/api/vmidmap")
    _, g1 = a.call("GET", "/api/groups")
    check((st1, st2, st3, st4, st5) == (400, 400, 400, 400, 400) and before.get("text") == after.get("text") and g0 == g1,
          "a missing or empty course map, groups or themes is refused - nothing is wiped", str((st1, st2, st3, st4, st5)))
    st, _ = a.call("DELETE", "/api/users/%s/x" % INSTR)
    st2, ul = a.call("GET", "/api/users")
    check(st == 400 and any(u.get("name") == INSTR for u in (ul.get("users") if isinstance(ul, dict) else ul) or []),
          "a delete with a longer address is refused - the user stays", str(st))
    # health at a glance, and the TrueNAS settings (the kit's own are put back afterwards)
    st, hl = a.call("GET", "/api/health")
    check(st == 200 and hl.get("state") in ("ok", "warn", "fail") and "nodes" in hl.get("proxmox", {}) and "guests" in hl.get("proxmox", {}),
          "the health page's data: state, nodes, guests", str(hl)[:150])
    st, tn0 = a.call("GET", "/api/truenas")
    check(st == 200 and "key" not in tn0, "TrueNAS settings are read without the key", str(tn0)[:120])
    st, r = a.call("PUT", "/api/truenas", {"url": "http://truenas.invalid", "user": "x", "key": "k"})
    check(st == 400 and "HTTPS" in r.get("error", ""), "a TrueNAS address over plain HTTP is refused", str(r)[:120])
    if not tn0.get("url"):
        st, r = a.call("PUT", "/api/truenas", {"url": "https://truenas.invalid", "user": "gt", "key": "secret-%s" % RND})
        st2, back = a.call("GET", "/api/truenas")
        check(st == 200 and back.get("has_key") and "secret" not in json.dumps(back), "a saved TrueNAS key is never sent back", str(back)[:120])
        a.call("PUT", "/api/truenas", {"url": ""})   # not set up again, as before
    else:
        skip("TrueNAS key round trip", "this kit has TrueNAS set up - left as it is")
    # a class guide save without text never empties it (the course's own guide is put back afterwards)
    st0, g0 = a.call("GET", "/api/guide/" + COURSE)
    orig = g0.get("text") if st0 == 200 else None
    a.call("PUT", "/api/guide/" + COURSE, {"text": "# gui-test guide %s" % RND})
    st, _ = a.call("PUT", "/api/guide/" + COURSE, {})
    st2, g = a.call("GET", "/api/guide/" + COURSE)
    check(st == 400 and "gui-test guide" in (g.get("text") or ""), "a guide save without text is refused - the guide stays", str(st))
    if orig is None:
        a.call("DELETE", "/api/guide/" + COURSE)
    else:
        a.call("PUT", "/api/guide/" + COURSE, {"text": orig})
    st, r = a.call("POST", "/api/plan", {"action": "made_up", "course": COURSE})
    check(st == 400 and "unknown action" in r.get("error", ""), "an unknown action is said to be unknown", str(r)[:100])
    # a password reset from the shell signs out the pages that were signed in with the old one
    st, vu = a.call("POST", "/api/users", {"name": "gt-pw-" + RND, "role": "viewer", "courses": [COURSE]})
    if st == 200:
        v = Client()
        v.call("POST", "/api/login", {"user": "gt-pw-" + RND, "password": vu["password"]})
        before = v.call("GET", "/api/courses")[0]
        rc, out = pvr("users", "passwd", "gt-pw-" + RND)
        after = v.call("GET", "/api/courses")[0]
        check(before == 200 and rc == 0 and after == 401, "pvr users passwd signs out the open pages of that user", "%s %s %s" % (before, rc, after))
        a.call("DELETE", "/api/users/gt-pw-" + RND)

    # ------------------------------------------------------------------ 10
    step("10. readiness check and kit backup (nothing is changed)")
    st, r = a.call("GET", "/api/ready/" + COURSE)
    names = [c["title"] for c in r.get("checks", [])] if st == 200 else []
    check(st == 200 and "Proxmox answers" in names and any(n.startswith("Class snapshot") for n in names) and "Locked guests" in names and "Storage" in names,
          "Ready for class? checks Proxmox, the class snapshot, locks and storage", str(r)[:200])
    bad_ = [c["title"] + ": " + c["detail"] for c in r.get("checks", []) if c["state"] == "fail"]
    print("        %s - %s" % ("ready" if r.get("ready") else "NOT ready", "; ".join(bad_) or "no problems"))
    st, _ = i.call("GET", "/api/ready/" + COURSE)
    check(st == 200, "instructors can run the readiness check")
    import base64 as b64
    st, blob = a.call("POST", "/api/kit/export", {"password": "gui-test-kit-pw"})
    blob = blob if st == 200 and isinstance(blob, bytes) else b""
    check(st == 200 and blob.startswith(b"Salted__"), "kit file made, and encrypted (%d KB)" % (len(blob) // 1024))
    data = b64.b64encode(blob).decode()
    st, r = a.call("POST", "/api/kit/check", {"data": data, "password": "gui-test-kit-pw"})
    check(st == 200 and ADMIN in r.get("users", []), "the kit file opens with its password and lists the users", str(r)[:150])
    st, r = a.call("POST", "/api/kit/check", {"data": data, "password": "the-wrong-one"})
    check(st == 400, "a wrong kit password is refused")
    st, _ = i.call("POST", "/api/kit/export", {"password": "gui-test-kit-pw"})
    check(st == 403, "instructors can't export a kit")

    # ------------------------------------------------------------------ cleanup
    step("cleanup")
    for u in (INSTR, VICTIM):
        a.call("DELETE", "/api/users/" + u)
    st, _ = a.call("PUT", "/api/roles", {"roles": roles})
    check(st == 200, "test role removed")


if __name__ == "__main__":
    cleanup()   # leftovers of an interrupted run
    try:
        main()
    except Exception as e:   # noqa
        import traceback
        traceback.print_exc()
        bad("the test stopped: %s" % e)
    finally:
        cleanup()
        rc, out = pvr("users")
        check(not any(ln.startswith("gt-") for ln in out.splitlines()), "no test users left")
    print("\n==================================\n %d passed, %d failed, %d skipped\n==================================" % (passed, failed, skipped))
    sys.exit(1 if failed else 0)
