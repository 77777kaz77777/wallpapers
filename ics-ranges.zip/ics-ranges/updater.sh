#!/usr/bin/env bash
# updater.sh - installs the ICS Ranges version an admin picked in the web page.
#
# Runs on the HOST as root, started by systemd (ics-ranges-updater.path) when the web page
# writes updates/request. Set up with:  sudo ./setup.sh updater
#
# It trusts nothing from the web page but the version number:
#   - it downloads that release itself, only from the repository pinned in updater.conf
#   - it checks the checksum, that it really is an ICS Ranges zip, and that its version matches
#   - it runs ./setup.sh update, waits until the new version is healthy, and otherwise
#     puts the previous version back.
set -u
cd "$(dirname "$(readlink -f "$0")")" || exit 1
HERE=$(pwd -P)
U=$HERE/updates
LOG=$U/update.log
TAG="" BY=""

status() {   # STATE message
    printf 'STATE=%s\nVERSION=%s\nMESSAGE=%s\nAT=%s\nBY=%s\n' "$1" "$TAG" "$2" "$(date +%Y-%m-%dT%H:%M:%S)" "$BY" >"$U/status.new" &&
        chmod 644 "$U/status.new" && mv -f "$U/status.new" "$U/status"
    echo "== $1: $2"
}
fail() { status failed "$1"; rm -f "$U/request.running"; exit 1; }
engine() { if docker compose version >/dev/null 2>&1; then echo docker; elif podman compose version >/dev/null 2>&1; then echo podman; else echo docker; fi; }

[[ -f $U/request ]] || exit 0
mv -f "$U/request" "$U/request.running"          # so systemd doesn't start us twice
exec >"$LOG" 2>&1
chmod 644 "$LOG"
echo "ICS Ranges updater - $(date)"

# ---- what was asked for (from the web page - checked strictly)
TAG=$(sed -n 's/^TAG=//p' "$U/request.running" | head -1)
BY=$(sed -n 's/^BY=//p' "$U/request.running" | head -1 | tr -cd 'A-Za-z0-9_.@-' | cut -c1-40)
[[ $TAG =~ ^v?[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)?$ ]] || { TAG=""; fail "bad version in the request"; }
AUTH=$(head -1 "$U/request.token" 2>/dev/null); rm -f "$U/request.token"
[[ -z $AUTH || $AUTH =~ ^[A-Za-z0-9_.@-]{0,64}:[A-Za-z0-9_-]{0,200}$ ]] || fail "bad login in the request"
WANT=${TAG#v}

# ---- where from: only the repository the host allowed
[[ -r $HERE/updater.conf ]] || fail "updater.conf is missing - run: sudo ./setup.sh updater"
REPO=$(sed -n 's/^REPO=//p' "$HERE/updater.conf" | head -1)
INSECURE=$(sed -n 's/^INSECURE=//p' "$HERE/updater.conf" | head -1)
[[ $REPO =~ ^https?://[^[:space:]/]+(/[^[:space:]/]+)*/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || fail "updater.conf has no valid REPO"
CURL=(curl -fsSL --connect-timeout 15 --max-time 600)
[[ $INSECURE == 1 ]] && CURL+=(-k)
[[ $AUTH == *:?* ]] && CURL+=(-u "$AUTH")

# ---- download and check
status downloading "Downloading $TAG from $REPO"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
"${CURL[@]}" -o "$T/ics-ranges.zip" "$REPO/releases/download/$TAG/ics-ranges.zip" || fail "couldn't download ics-ranges.zip of $TAG"
"${CURL[@]}" -o "$T/ics-ranges.zip.sha256" "$REPO/releases/download/$TAG/ics-ranges.zip.sha256" || fail "couldn't download ics-ranges.zip.sha256 of $TAG"
status checking "Checking $TAG"
grep -Eq '^[0-9a-f]{64}  \*?ics-ranges\.zip$' "$T/ics-ranges.zip.sha256" || fail "the .sha256 file isn't a checksum of ics-ranges.zip"
(cd "$T" && sha256sum -c ics-ranges.zip.sha256) || fail "checksum mismatch - the download is damaged or not the released file"
unzip -tq "$T/ics-ranges.zip" >/dev/null || fail "the zip is damaged"
unzip -l "$T/ics-ranges.zip" | grep -q ' ics-ranges/app/server\.py$' || fail "that isn't an ICS Ranges zip"
GOT=$(unzip -p "$T/ics-ranges.zip" ics-ranges/app/server.py | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1)
[[ $GOT == "$WANT" ]] || fail "the zip of $TAG contains version ${GOT:-?}, not $WANT"
NOW=$(sed -n 's/^VERSION = "\(.*\)"$/\1/p' app/server.py | head -1)
echo "Running now: $NOW - installing: $GOT"

# ---- keep the running version, to go back to
status installing "Installing $TAG (was $NOW)"
tar -czf "$U/previous.tgz" --exclude=./.env --exclude=./updates --exclude=./updater.conf . || fail "couldn't keep a copy of the running version"
echo "$NOW" >"$U/previous.version"

healthy() {   # wait until the container runs the version we expect and reports healthy
    local eng h
    eng=$(engine)
    for _ in $(seq 1 40); do
        sleep 4
        h=$($eng inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' ics-ranges 2>/dev/null)
        if [[ $h == healthy || $h == running ]] && $eng logs --tail 40 ics-ranges 2>&1 | grep -q "ICS Ranges $1 on"; then
            return 0
        fi
    done
    return 1
}

if bash ./setup.sh update "$T/ics-ranges.zip" && healthy "$WANT"; then
    status "done" "Updated from $NOW to $GOT"
    rm -f "$U/request.running"
    exit 0
fi

# ---- it didn't come up: put the previous version back
status rolling_back "$TAG didn't start properly - going back to $NOW"
tar -xzf "$U/previous.tgz" -C "$HERE" || fail "couldn't restore $NOW - restore it by hand from updates/previous.tgz"
if command -v docker >/dev/null 2>&1 && [[ $(engine) == docker ]]; then
    docker compose build && docker compose up -d --force-recreate
else
    podman compose build && podman compose up -d --force-recreate
fi
if healthy "$NOW"; then
    fail "$TAG didn't start properly - went back to $NOW (see the log)"
fi
fail "$TAG didn't start, and $NOW didn't come back either - check: docker compose logs ics-ranges"
