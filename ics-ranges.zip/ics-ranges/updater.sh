#!/usr/bin/env bash
# updater.sh - installs the ICS Ranges version an admin picked in the web page.
#
# Runs on the HOST as root, started by systemd (ics-ranges-updater.path) when the web page
# writes updates/request. Set up with:  sudo ./setup.sh updater
#
# It trusts nothing from the web page but the version number:
#   - it downloads that release itself, only from the repository pinned in updater.conf
#   - it checks the checksum, that it really is an ICS Ranges zip, and that its version matches
#   - it runs ./setup.sh update, waits until the new version is healthy, and otherwise
#     puts the previous version back.
set -u
cd "$(dirname "$(readlink -f "$0")")" || exit 1
HERE=$(pwd -P)
U=$HERE/updates
LOG=$U/update.log
TAG="" BY=""

status() {   # STATE message
    printf 'STATE=%s\nVERSION=%s\nMESSAGE=%s\nAT=%s\nBY=%s\n' "$1" "$TAG" "$2" "$(date +%Y-%m-%dT%H:%M:%S)" "$BY" >"$U/status.new" &&
        chmod 644 "$U/status.new" && mv -f "$U/status.new" "$U/status"
    echo "== $1: $2"
}
fail() { status failed "$1"; rm -f "$U/request.running"; exit 1; }
engine() { if docker compose version >/dev/null 2>&1; then echo docker; elif podman compose version >/dev/null 2>&1; then echo podman; else echo docker; fi; }

[[ -f $U/request ]] || exit 0
mv -f "$U/request" "$U/request.running"          # so systemd doesn't start us twice
exec >"$LOG" 2>&1
chmod 644 "$LOG"
echo "ICS Ranges updater - $(date)"

# ---- what was asked for (from the web page - checked strictly)
TAG=$(sed -n 's/^TAG=//p' "$U/request.running" | head -1)
BY=$(sed -n 's/^BY=//p' "$U/request.running" | head -1 | tr -cd 'A-Za-z0-9_.@-' | cut -c1-40)
[[ $TAG =~ ^v?[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)?$ ]] || { TAG=""; fail "bad version in the request"; }
AUTH=$(head -1 "$U/request.token" 2>/dev/null); rm -f "$U/request.token"
[[ -z $AUTH || $AUTH =~ ^[A-Za-z0-9_.@-]{0,64}:[A-Za-z0-9_-]{0,200}$ ]] || fail "bad login in the request"
WANT=${TAG#v}

# ---- where from: only the repository the host allowed
[[ -r $HERE/updater.conf ]] || fail "updater.conf is missing - run: sudo ./setup.sh updater"
REPO=$(sed -n 's/^REPO=//p' "$HERE/updater.conf" | head -1)
INSECURE=$(sed -n 's/^INSECURE=//p' "$HERE/updater.conf" | head -1)
[[ $REPO =~ ^https?://[^[:space:]/]+(/[^[:space:]/]+)*/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || fail "updater.conf has no valid REPO"
CURL=(curl -sSL --connect-timeout 15 --max-time 600)
[[ $INSECURE == 1 ]] && CURL+=(-k)
USER_=${AUTH%%:*} TOKEN=${AUTH#*:}
BASE=${REPO%/*/*} OWNER_REPO=${REPO#"$BASE"/}

# where Gitea keeps each file of the release: the API gives the real download address
# ("browser_download_url", e.g. /attachments/<id>); the short /releases/download/... address
# is tried too. Gitea versions differ in how they accept the token, so both ways are tried.
# versions installed before are kept in updates/cache/<version> (the last 5) - no download needed
CACHE=$U/cache KEEP=5
CACHED=0
[[ -s $CACHE/$TAG/ics-ranges.zip && -s $CACHE/$TAG/ics-ranges.zip.sha256 ]] && CACHED=1
api_json=""
if [[ $CACHED == 1 ]]; then
    :   # nothing to ask the repository
elif [[ -n $TOKEN ]]; then
    api_json=$("${CURL[@]}" -f -H "Authorization: token $TOKEN" "$BASE/api/v1/repos/$OWNER_REPO/releases/tags/$TAG" 2>/dev/null)
else
    api_json=$("${CURL[@]}" -f "$BASE/api/v1/repos/$OWNER_REPO/releases/tags/$TAG" 2>/dev/null)
fi
asset_url() {   # file name -> its browser_download_url from the API answer (no jq needed)
    tr -d '\n' <<<"$api_json" | grep -oE "\"name\": *\"$1\"[^}]*\"browser_download_url\": *\"[^\"]*\"" | head -1 |
        sed -E 's/.*"browser_download_url": *"([^"]*)"/\1/'
}
fetch() {   # file name -> downloads it to $T, trying each address and each way to send the token
    local name=$1 url code type
    local -a urls=() auths=()
    url=$(asset_url "$name"); [[ -n $url ]] && urls+=("$url")
    urls+=("$REPO/releases/download/$TAG/$name")
    if [[ -n $TOKEN ]]; then
        auths=("token" "basic")
    else
        auths=("none")
    fi
    for url in "${urls[@]}"; do
        for a in "${auths[@]}"; do
            case $a in
                token) set -- -H "Authorization: token $TOKEN" ;;
                basic) set -- -u "$USER_:$TOKEN" ;;
                none) set -- ;;
            esac
            read -r code type < <("${CURL[@]}" "$@" -o "$T/$name" -w '%{http_code} %{content_type}\n' "$url" 2>/dev/null)
            if [[ $code == 200 && $type != text/html* ]]; then
                echo "  $name: from $url ($a)"
                return 0
            fi
            echo "  $name: $url ($a) -> HTTP ${code:-?} ${type:-}"
        done
    done
    return 1
}

# ---- download and check
status downloading "Downloading $TAG from $REPO"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
if [[ $CACHED == 1 ]]; then
    status downloading "Using the copy of $TAG kept on this kit"
    echo "  $TAG is kept on this kit ($CACHE/$TAG) - no download"
    cp "$CACHE/$TAG/ics-ranges.zip" "$CACHE/$TAG/ics-ranges.zip.sha256" "$T/" || fail "couldn't read the kept copy of $TAG"
    touch "$CACHE/$TAG"
else
    [[ -n $api_json ]] || echo "  (the API didn't answer for $TAG - trying the direct address only)"
    fetch ics-ranges.zip || fail "couldn't download ics-ranges.zip of $TAG (is it attached to the release? does the token have repository read access?)"
    fetch ics-ranges.zip.sha256 || fail "couldn't download ics-ranges.zip.sha256 of $TAG - attach it to the release"
fi
status checking "Checking $TAG"
# the expected checksum: the first 64 hex digits in the file - also from Windows (capital letters,
# CRLF line ends, a byte-order mark) or a file that holds only the checksum
want=$(LC_ALL=C grep -oiE '[0-9a-f]+' "$T/ics-ranges.zip.sha256" | awk 'length == 64 { print tolower($0); exit }')
[[ ${#want} == 64 ]] || fail "the .sha256 file holds no checksum"
have=$(sha256sum "$T/ics-ranges.zip" | cut -d' ' -f1)
echo "  checksum: $have"
[[ $have == "$want" ]] || fail "checksum mismatch - the download is damaged or not the released file"
unzip -tq "$T/ics-ranges.zip" >/dev/null || fail "the zip is damaged"
unzip -l "$T/ics-ranges.zip" | grep -q ' ics-ranges/app/server\.py$' || fail "that isn't an ICS Ranges zip"
GOT=$(unzip -p "$T/ics-ranges.zip" ics-ranges/app/server.py | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1)
[[ $GOT == "$WANT" ]] || fail "the zip of $TAG contains version ${GOT:-?}, not $WANT"
NOW=$(sed -n 's/^VERSION = "\(.*\)"$/\1/p' app/server.py | head -1)
echo "Running now: $NOW - installing: $GOT"
if [[ $CACHED == 0 ]]; then   # keep it, to go back to later without a download
    mkdir -p "$CACHE/$TAG" && cp "$T/ics-ranges.zip" "$T/ics-ranges.zip.sha256" "$CACHE/$TAG/" && chmod -R a+rX "$CACHE" &&
        echo "  kept a copy in $CACHE/$TAG"
    ls -1dt "$CACHE"/*/ 2>/dev/null | tail -n +$((KEEP + 1)) | while IFS= read -r old; do rm -rf -- "$old" && echo "  removed the oldest kept copy: $(basename "$old")"; done
fi

# ---- keep the running version, to go back to
status installing "Installing $TAG (was $NOW)"
tar -czf "$U/previous.tgz" --exclude=./.env --exclude=./updates --exclude=./updater.conf . || fail "couldn't keep a copy of the running version"
echo "$NOW" >"$U/previous.version"

healthy() {   # wait until the container runs the version we expect and reports healthy
    local eng h
    eng=$(engine)
    for _ in $(seq 1 40); do
        sleep 4
        h=$($eng inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' ics-ranges 2>/dev/null)
        if [[ $h == healthy || $h == running ]] && $eng logs --tail 40 ics-ranges 2>&1 | grep -q "ICS Ranges $1 on"; then
            return 0
        fi
    done
    return 1
}

if bash ./setup.sh update "$T/ics-ranges.zip" && healthy "$WANT"; then
    status "done" "Updated from $NOW to $GOT"
    rm -f "$U/request.running"
    exit 0
fi

# ---- it didn't come up: put the previous version back
status rolling_back "$TAG didn't start properly - going back to $NOW"
# remove files only the new version had, then put the previous files back
tar -tzf "$U/previous.tgz" | sed 's#^\./##' | grep -v '/$' | sort >"$T/old.list" || fail "can't read updates/previous.tgz"
find . -type f ! -path './.env' ! -path './updates/*' ! -path './updater.conf' ! -path './.git/*' | sed 's#^\./##' | sort >"$T/now.list"
comm -13 "$T/old.list" "$T/now.list" | while IFS= read -r f; do rm -f -- "$f" && echo "  removed $f (only in $TAG)"; done
tar -xzf "$U/previous.tgz" -C "$HERE" || fail "couldn't restore $NOW - restore it by hand from updates/previous.tgz"
if command -v docker >/dev/null 2>&1 && [[ $(engine) == docker ]]; then
    docker compose build && docker compose up -d --force-recreate
else
    podman compose build && podman compose up -d --force-recreate
fi
if healthy "$NOW"; then
    fail "$TAG didn't start properly - went back to $NOW (see the log)"
fi
fail "$TAG didn't start, and $NOW didn't come back either - check: docker compose logs ics-ranges"
