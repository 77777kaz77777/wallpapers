#!/usr/bin/env bash
# setup.sh - set up ICS Ranges: write .env, test the Proxmox token, start it.
#   ./setup.sh          step by step
#   ./setup.sh token    only change the API token
#   ./setup.sh test     only test the API connection
#   ./setup.sh update /path/to/ics-ranges.zip
#                       install a new version: unpack it here, rebuild, restart (data is kept)
#   ./setup.sh migrate  move the data of an older pve-range-gui install to ics-ranges
#   ./setup.sh updater  (sudo) turn on Software updates: host + web page in one step
#                       sudo ./setup.sh updater --repo URL --user NAME [--token-file F] [--insecure] [--yes]
#                       (also: updater status | updater remove)
#   ./setup.sh export [FILE] / ./setup.sh import FILE
#                       the whole kit in one encrypted file - users, settings, guides, add-ons, keys
#   ./setup.sh node-key [NODE-IP]
#                       put the node key on a Proxmox node (asks for its root password once)
set -u
cd "$(dirname "$0")" || exit 1
ENVF=.env
[[ -f $ENVF ]] || { cp .env.example "$ENVF"; echo "Created $ENVF"; }
chmod 600 "$ENVF"
B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'
[[ -t 1 ]] || B="" G="" R="" Y="" Z=""

getv() { grep -m1 "^$1=" "$ENVF" | cut -d= -f2-; }
setv() {
    local tmp
    tmp=$(mktemp)
    awk -v k="$1" -v v="$2" 'BEGIN {d = 0} index($0, k "=") == 1 {print k "=" v; d = 1; next} {print} END {if (!d) print k "=" v}' "$ENVF" >"$tmp" && cat "$tmp" >"$ENVF"
    rm -f "$tmp"
}
ask() { local a; read -rp "$1 [$2]: " a; echo "${a:-$2}"; }
host_ip() {
    local a
    a=$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)
    [[ -n $a ]] || a=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "${a:-127.0.0.1}"
}
compose() {
    if docker compose version >/dev/null 2>&1; then docker compose "$@"
    elif podman compose version >/dev/null 2>&1; then podman compose "$@"
    else docker-compose "$@"; fi
}
test_api() {   # token urls
    local url out code
    for url in $2; do
        out=$(curl -sk --connect-timeout 5 --max-time 15 -w '\n%{http_code}' -H "Authorization: PVEAPIToken=$1" "${url%/}/api2/json/version" 2>&1)
        code=${out##*$'\n'}
        case $code in
            200) echo "  ${G}OK${Z}  $url"; return 0 ;;
            401) echo "  ${R}token refused${Z} by $url" ;;
            000) echo "  ${Y}no answer${Z} from $url (wrong address, or port 8006 blocked)" ;;
            *) echo "  ${R}HTTP $code${Z} from $url" ;;
        esac
    done
    return 1
}
create_token() {
    local node out tid val
    node=$(ask "  Node to create it on (IP)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    echo "  Connecting to root@$node - it may ask for root's password once."
    echo "  ${Y}An existing token 'icsranges@pve!gui' is replaced (the old one stops working).${Z}"
    out=$(ssh -o ConnectTimeout=10 "root@$node" '
        pveum user add icsranges@pve --comment "ICS Ranges" 2>/dev/null
        pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor || exit 1
        pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser || exit 1
        pveum user token remove icsranges@pve gui 2>/dev/null
        pveum user token add icsranges@pve gui --privsep 0 --output-format json') || { echo "  ${R}Could not create the token.${Z}"; return 1; }
    tid=$(grep -o '"full-tokenid" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    val=$(grep -o '"value" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    [[ -n $tid && -n $val ]] || { echo "  ${R}Unexpected answer:${Z} $out"; return 1; }
    TOKEN="$tid=$val"
    echo "  ${G}Created${Z} $tid"
}
set_token() {
    local c
    echo
    echo "${B}Proxmox API token${Z}"
    echo "  1) Paste a token I already have  (icsranges@pve!gui=xxxxxxxx-... - a pverange@pve!range=... token works too)"
    echo "  2) Create one now on a node over SSH (needs root's password once)"
    echo "  3) Keep the current one"
    read -rp "Choose [1-3]: " c
    TOKEN=""
    case $c in
        1) read -rsp "  Paste the token (hidden): " TOKEN; echo; TOKEN=$(tr -d '[:space:]' <<<"$TOKEN") ;;
        2) create_token || return 1 ;;
        *) return 0 ;;
    esac
    [[ $TOKEN =~ ^[^@!=]+@[^!=]+![^=]+=.+$ ]] || { echo "  ${R}That doesn't look like USER@REALM!NAME=SECRET.${Z}"; return 1; }
    echo "  Testing it ..."
    test_api "$TOKEN" "$(getv PVE_API_URL)" || { read -rp "  It didn't work. Save it anyway? [y/N] " a; [[ $a == [yY]* ]] || return 1; }
    setv PVE_API_TOKEN "$TOKEN"
    chmod 600 "$ENVF"
    echo "  ${G}Saved${Z} (readable by root only)"
}

engine() { if docker compose version >/dev/null 2>&1; then echo docker; elif podman compose version >/dev/null 2>&1; then echo podman; else echo docker; fi; }

# Earlier versions were called pve-range-gui: move their data to the ics-ranges volume once.
migrate_old() {
    local eng old new
    eng=$(engine)
    old=pve-range-gui_pve-range-gui-data new=ics-ranges_ics-ranges-data
    # an old COMPOSE_PROJECT_NAME would win over compose.yaml's name - drop it
    if grep -q '^COMPOSE_PROJECT_NAME=' "$ENVF" 2>/dev/null; then
        sed -i '/^COMPOSE_PROJECT_NAME=/d' "$ENVF"; echo "  Removed COMPOSE_PROJECT_NAME from .env (compose.yaml names the project now)."
    fi
    $eng volume inspect "$old" >/dev/null 2>&1 || return 0          # nothing old here
    if $eng volume inspect "$new" >/dev/null 2>&1 &&
        $eng run --rm -u 0 --entrypoint sh -v "$new:/to" ics-ranges:latest -c '[ -s /to/users.json ]' 2>/dev/null; then
        return 0                                                    # already moved
    fi
    echo "${B}Moving your data from $old to $new${Z} (users, roles, add-ons, guides, settings, history)"
    compose build || return 1
    $eng rm -f pve-range-gui >/dev/null 2>&1 && echo "  Stopped the old container pve-range-gui."
    compose create || return 1                                      # makes the new volume
    $eng run --rm -u 0 --entrypoint sh -v "$old:/from:ro" -v "$new:/to" ics-ranges:latest -c 'cp -a /from/. /to/' || {
        echo "${R}Copying the data failed - the old volume is untouched.${Z}"; return 1; }
    echo "  ${G}Done.${Z} The old volume $old is kept until you remove it: $eng volume rm $old"
}

# The node key (port mirroring, EFI keys): send the lines straight to a node - nothing to copy
node_key() {
    local node lines
    node=${1:-}
    [[ -n $node ]] || node=$(ask "Proxmox node to add the key on (IP or name)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    lines=$(compose exec -T ics-ranges cat /data/ssh/node-key.txt 2>/dev/null) || true
    [[ -n $lines ]] || { echo "${R}No node key yet${Z} - start ICS Ranges first (./setup.sh)"; return 1; }
    echo "These lines are run as root on $node (it may ask for root's password once):"
    echo
    echo "$lines" | sed 's/^/    /' | cut -c1-110
    echo
    read -rp "Go ahead? [Y/n] " a
    [[ $a == [nN]* ]] && return 1
    if printf '%s\n' "$lines" | ssh -o ConnectTimeout=10 "root@$node" bash; then
        echo "${G}Done.${Z} The key is on $node - the cluster shares it with every node."
        echo "Port mirroring and EFI keys work now (Open vSwitch bridge needed for mirroring)."
    else
        echo "${R}That didn't work.${Z} Copy the lines from the web page instead: Settings, Node key."
        return 1
    fi
}

# The host side of "Software updates" in the web page: a systemd path unit starts
# updater.sh (as root) when the web page writes updates/request.
UNIT_DIR=/etc/systemd/system
updater() {   # [status|remove] | [--repo URL] [--user NAME] [--token-file F] [--insecure] [--yes]
    local here url="" user="" tokfile="" insecure="" yes=0 a c conf cur_url cur_user connected tok
    here=$(pwd -P)
    case ${1:-} in
        status)
            printf 'Updater:     %s\n' "$(systemctl is-enabled ics-ranges-updater.path 2>/dev/null || echo off)"
            printf 'Allows:      %s\n' "$(sed -n 's/^REPO=//p' updater.conf 2>/dev/null)"
            compose exec -T ics-ranges pvr update 2>/dev/null | sed -n '1,3p;5,$p' | sed 's/^/  /'
            [[ -r updates/status ]] && sed 's/^/Last run:    /' updates/status
            return 0 ;;
        remove)
            [[ $(id -u) == 0 ]] || { echo "Run it with sudo."; return 1; }
            systemctl disable --now ics-ranges-updater.path 2>/dev/null
            rm -f "$UNIT_DIR/ics-ranges-updater.path" "$UNIT_DIR/ics-ranges-updater.service" updates/updater.info
            systemctl daemon-reload
            echo "Software updates are off. (updater.conf is kept.)"
            return 0 ;;
    esac
    while (($#)); do
        case $1 in
            --repo) url=${2:-}; shift ;;
            --user) user=${2:-}; shift ;;
            --token-file) tokfile=${2:-}; shift ;;
            --insecure) insecure=1 ;;
            --yes|-y) yes=1 ;;
            *) echo "unknown option $1"; return 2 ;;
        esac
        shift
    done
    [[ $(id -u) == 0 ]] || { echo "${R}Run it with sudo:${Z} sudo ./setup.sh updater"; return 1; }
    command -v systemctl >/dev/null || { echo "${R}This host has no systemd${Z} - update with ./setup.sh update instead."; return 1; }
    [[ $here != *[[:space:]]* ]] || { echo "${R}The folder name has a space in it${Z} - move it, e.g. to /opt/ics-ranges."; return 1; }
    for c in curl unzip sha256sum tar; do command -v $c >/dev/null || { echo "${R}$c is missing${Z} - install it first (apt-get install -y $c / dnf -y install $c)."; return 1; }; done
    echo "${B}Software updates${Z} - admins install newer (or older) versions from the web page."
    echo "The web page only ASKS for a version; this host downloads it itself, only from the"
    echo "repository you allow here, checks it, installs it, and goes back if it doesn't start."
    echo
    # what the web page is connected to already (Software updates), if anything
    conf=$(compose exec -T ics-ranges sh -c 'cat /data/update.json 2>/dev/null' 2>/dev/null)
    cur_url=$(sed -n 's/.*"url": *"\([^"]*\)".*/\1/p' <<<"$conf" | head -1)
    cur_user=$(sed -n 's/.*"user": *"\([^"]*\)".*/\1/p' <<<"$conf" | head -1)
    grep -q '"insecure": *true' <<<"$conf" && [[ -z $insecure ]] && insecure=1
    [[ -z $url ]] && url=${cur_url:-$(sed -n 's/^REPO=//p' updater.conf 2>/dev/null)}
    if ((!yes)) || [[ -z $url ]]; then
        url=$(ask "Repository with the ICS Ranges releases" "${url:-http://192.168.77.93:3000/kaz/ics-ranges-app}")
    fi
    url=${url%/}; url=${url%.git}
    [[ $url =~ ^https?://[^[:space:]/]+(/[^[:space:]/]+)*/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || { echo "${R}That isn't a repository address${Z} (like http://gitea:3000/owner/ics-ranges-app)."; return 1; }
    if [[ $url == https://* && -z $insecure ]] && ((!yes)); then
        read -rp "Check the repository's HTTPS certificate? (no for a self-signed Gitea) [Y/n] " a
        [[ $a == [nN]* ]] && insecure=1
    fi
    [[ $url == https://* ]] || insecure=0
    insecure=${insecure:-0}

    # the web page: connect it now unless it already uses this repository
    connected=0
    [[ -n $cur_url && ${cur_url,,} == "${url,,}" ]] && connected=1
    if ((!connected)); then
        [[ -z $user ]] && user=${cur_user:-$(ask "User name on the repository server" "${SUDO_USER:-kaz}")}
        if [[ -n $tokfile ]]; then tok=$(head -1 "$tokfile")
        else read -rsp "Read-only token for $url (repository: Read): " tok; echo
        fi
        local -a flag=()
        [[ $insecure == 1 ]] && flag=(--insecure)
        printf '%s\n' "$tok" | compose exec -T ics-ranges pvr update connect "$url" "$user" "${flag[@]}" ||
            { echo "${R}The web page couldn't use that repository and token${Z} - nothing was changed."; return 1; }
    else
        echo "  The web page already uses $url."
    fi

    # this host: the repository it allows, the shared folder, the systemd units
    umask 077
    printf 'REPO=%s\nINSECURE=%s\n' "$url" "$insecure" >updater.conf
    umask 022
    mkdir -p updates && chown 1000:1000 updates && chmod 770 updates
    printf 'REPO=%s\nSINCE=%s\n' "$url" "$(date +%Y-%m-%d)" >updates/updater.info && chmod 644 updates/updater.info
    chmod 755 updater.sh
    cat >"$UNIT_DIR/ics-ranges-updater.path" <<UNIT
[Unit]
Description=ICS Ranges - wait for an update request from the web page

[Path]
PathExists=$here/updates/request
Unit=ics-ranges-updater.service

[Install]
WantedBy=multi-user.target
UNIT
    cat >"$UNIT_DIR/ics-ranges-updater.service" <<UNIT
[Unit]
Description=ICS Ranges - install the version an admin picked in the web page

[Service]
Type=oneshot
WorkingDirectory=$here
ExecStart=/bin/bash $here/updater.sh
TimeoutStartSec=1800
UNIT
    systemctl daemon-reload && systemctl reset-failed ics-ranges-updater.service ics-ranges-updater.path 2>/dev/null
    systemctl enable --now ics-ranges-updater.path || return 1
    compose up -d >/dev/null 2>&1 || true     # so the container sees the shared folder
    echo
    echo "${G}Software updates are on.${Z}"
    compose exec -T ics-ranges pvr update 2>/dev/null | sed -n '1p;5,$p' | sed 's/^/  /'
    echo "In the web page: Software updates. On the shell: docker compose exec ics-ranges pvr update"
    echo "Change: sudo ./setup.sh updater · off: sudo ./setup.sh updater remove · publish versions: ./release.sh"
}

kit() {   # export [FILE] | import FILE - the whole kit in one encrypted file
    local f pw pw2 envl k
    case ${1:-} in
        export)
            f=${2:-ics-ranges-kit-$(date +%Y%m%d-%H%M).icskit}
            echo "The kit file holds users (with passwords and 2FA), keys and the Proxmox token - it is encrypted."
            read -rsp "Choose a kit password (10 or more characters): " pw; echo
            read -rsp "The same again: " pw2; echo
            [[ $pw == "$pw2" ]] || { echo "${R}The two passwords differ.${Z}"; return 1; }
            KIT_PASSWORD=$pw compose exec -T -e KIT_PASSWORD ics-ranges pvr kit export - >"$f" || { rm -f "$f"; return 1; }
            chmod 600 "$f"
            echo "${G}Kit saved:${Z} $f ($(du -h "$f" | cut -f1)). Keep it - and its password - somewhere safe." ;;
        import)
            f=${2:-}
            [[ -f $f ]] || { echo "Usage: ./setup.sh import FILE.icskit"; return 2; }
            read -rsp "Kit password: " pw; echo
            compose up -d >/dev/null 2>&1   # it must be running
            sleep 2
            KIT_PASSWORD=$pw compose exec -T -e KIT_PASSWORD ics-ranges pvr kit import - <"$f" || return 1
            envl=$(KIT_PASSWORD=$pw compose exec -T -e KIT_PASSWORD ics-ranges pvr kit env - <"$f")
            if [[ -n $envl ]]; then
                echo
                echo "The kit was connected to Proxmox at: $(sed -n 's/^PVE_API_URL=//p' <<<"$envl")"
                echo "This host uses:                      $(sed -n 's/^PVE_API_URL=//p' "$ENVF")"
                if [[ $(read -rp "Use the kit's Proxmox settings (addresses and token) on this host? [y/N] " a; echo "$a") == [yY]* ]]; then
                    while IFS= read -r line; do
                        k=${line%%=*}
                        [[ $k =~ ^[A-Z_]+$ ]] || continue
                        if grep -q "^$k=" "$ENVF"; then
                            sed -i "s|^$k=.*|$(printf '%s' "$line" | sed 's/[|&\\]/\\&/g')|" "$ENVF"
                        else
                            printf '%s\n' "$line" >>"$ENVF"
                        fi
                    done <<<"$envl"
                    compose up -d --force-recreate >/dev/null && echo "${G}Done${Z} - restarted with the kit's Proxmox settings."
                fi
            fi
            echo "Everyone signs in again, with the kit's users." ;;
        *) echo "Usage: ./setup.sh export [FILE]  |  ./setup.sh import FILE"; return 2 ;;
    esac
}

update() {   # zip - works whatever this folder is called
    local zip=${1:-} here tmp new top
    [[ -f $zip ]] || { echo "Usage: ./setup.sh update /path/to/ics-ranges.zip"; return 1; }
    here=$(pwd -P)
    command -v unzip >/dev/null || { echo "${R}unzip is missing${Z} - apt-get install -y unzip (or dnf install unzip)"; return 1; }
    top=$(unzip -l "$zip" | awk '$4 ~ /^[^\/]+\/app\/server\.py$/ {split($4, p, "/"); print p[1]; exit}')
    [[ $top == ics-ranges || $top == pve-range-gui ]] || { echo "${R}That isn't an ICS Ranges zip (or it's damaged - copy it again).${Z}"; return 1; }
    echo "Running now:   $(grep -m1 '^VERSION' app/server.py | cut -d'"' -f2)"
    tmp=$(mktemp -d)
    unzip -q "$zip" -d "$tmp" || { rm -rf "$tmp"; return 1; }
    rm -rf "$here/ics-ranges" "$here/pve-range-gui"           # a copy unpacked one level too deep
    # new program files over the old ones - .env (your settings) is not in the zip, so it stays
    (cd "$tmp/$top" && tar cf - .) | (cd "$here" && tar xf -) || { rm -rf "$tmp"; return 1; }
    rm -rf "$tmp"
    chmod 755 ./*.sh 2>/dev/null
    if [[ -f $UNIT_DIR/ics-ranges-updater.service ]] && ! grep -q '^ExecStart=/bin/bash ' "$UNIT_DIR/ics-ranges-updater.service" && [[ $(id -u) == 0 ]]; then
        sed -i "s#^ExecStart=.*#ExecStart=/bin/bash $here/updater.sh#" "$UNIT_DIR/ics-ranges-updater.service" &&
            systemctl daemon-reload && systemctl reset-failed ics-ranges-updater.service ics-ranges-updater.path 2>/dev/null
        systemctl start ics-ranges-updater.path 2>/dev/null
    fi
    new=$(grep -m1 '^VERSION' app/server.py | cut -d'"' -f2)
    echo "New files:     $new  (in $here)"
    migrate_old || return 1
    # the folder "Software updates" shares with the host (only usable once: sudo ./setup.sh updater)
    [[ -d updates ]] || { mkdir -p updates && chown 1000:1000 updates 2>/dev/null; chmod 770 updates 2>/dev/null; }
    # no --no-cache: Docker still rebuilds everything after the changed files, but keeps the
    # downloaded system packages - so an update from a USB stick works without internet.
    # (FRESH=1 ./setup.sh update ... rebuilds everything, which needs internet.)
    if [[ ${FRESH:-0} == 1 ]]; then compose build --no-cache || return 1; else compose build || return 1; fi
    compose up -d --force-recreate || return 1
    sleep 4
    compose logs --tail 30 ics-ranges | grep -E 'ICS Ranges [0-9]|Proxmox API' | tail -2
    echo "${G}Updated to $new.${Z} Reload the page - the version shows next to ICS Ranges at the top left."
}

case ${1:-all} in
    update) update "${2:-}"; exit ;;
    updater) shift; updater "$@"; exit ;;
    export | import) kit "$@"; exit ;;
    migrate) migrate_old && compose up -d; exit ;;
    node-key) node_key "${2:-}"; exit ;;
    test) test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"; exit $? ;;
    token) set_token && compose up -d; exit ;;
esac

echo "${B}ICS Ranges - setup${Z}  (Enter keeps the value in brackets)"
echo
v=$(ask "Proxmox API address(es), space-separated" "$(getv PVE_API_URL)")
w=""
for u in ${v//,/ }; do
    if [[ $u != *://* ]]; then if [[ $u == *:* ]]; then u="https://$u"; else u="https://$u:8006"; fi; fi
    w+="$u "
done
setv PVE_API_URL "${w% }"
set_token
ip=$(host_ip)
setv KEY_FROM "$(ask "This Docker host's IP" "$(getv KEY_FROM | sed "s/^$/$ip/")")"
port=$(ask "Port for the web page" "$(getv PORT | sed 's/^$/8443/')")
setv PORT "$port"
echo
echo "${B}Check:${Z}"
test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
echo
read -rp "Build and start it now? [Y/n] " a
if [[ $a != [nN]* ]]; then
    migrate_old || exit 1
    compose up -d --build || exit 1
    sleep 3
    compose logs --tail 20 ics-ranges
    echo
    echo "${B}Open https://$(getv KEY_FROM):$port${Z}"
    echo "The first visit asks you to create the first admin; admins add everyone else from inside."
    echo
    echo "Software updates from your Gitea (admins update ICS Ranges from the web page):"
    echo "  sudo ./setup.sh updater          - any time; publish new versions with ./release.sh"
fi
