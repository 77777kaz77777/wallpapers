# ControlYard – version control on GitHub

How ControlYard's code, versions and each kit's content are kept on GitHub: what lives where, how a
new version is made and published, how kits install it, and the rules that keep it safe.

> **Examples in this document – replace them with your own:** `sansics/icscontrolyard` – the GitHub
> repository · `jsmith` – a GitHub user · `pve-range1` – a ControlYard host · `/opt/controlyard` –
> the kit's folder (`/opt/ics-ranges` on kits not renamed yet).

---

## 1. What lives where

One **private** repository holds everything:

| Where | Holds | Written by | Read by |
|---|---|---|---|
| Branch **`main`** | The program's code | `release.sh` (or you, with git) | Everyone working on ControlYard |
| Tags **`v4.1.2`**, `v4.1.3` … | One per version – the exact code of that version, **never changed** | `release.sh` | The release workflow, `release.sh` |
| **Releases** (one per tag) | The files kits install: `controlyard.zip`, `ics-ranges.zip` and their `.sha256` checksums, with release notes | `release.sh` and/or the release workflow | **Software updates** on every kit |
| Branches **`kit-config`** (or one per kit: `kit-lab1`, `kit-lab2` …) | A kit's content: course map, class guides, add-ons, mirror add-ons, settings | **Save & share** on that kit | That kit (*Get latest*), and you |
| `.github/workflows/` | The automatic checks and releases (section 6) | – | GitHub Actions |

No branch name is fixed anywhere: `release.sh` asks for the code's branch (`main` suggested), and each
kit's Save & share has its own branch setting. More branches can be added any time.

**Never in the repository** – `.gitignore` keeps them out, and Save & share leaves them out: `.env`
(the Proxmox token), passwords and 2FA, the node key, TrueNAS and GitHub tokens, the kit's data.

---

## 2. Version numbers

`MAJOR.MINOR.PATCH`, e.g. **4.1.2**:

| Part | Goes up for | Example |
|---|---|---|
| **MAJOR** | Big changes, or ones that need care when updating | 4.0 – the rename to ControlYard |
| **MINOR** | New features | 4.1 – `setup.sh rename` |
| **PATCH** | Fixes and small improvements | 4.1.2 |

- The version lives in **one place**: the line `VERSION = "4.1.2"` in `app/server.py`. Everything else –
  the page, the release, the updater – reads it from there.
- The tag is the version with a `v`: **`v4.1.2`**. A tag and `app/server.py` must agree – the release
  workflow refuses otherwise.
- **A version number is never reused.** If a published version turns out wrong, the fix is the next
  number (4.1.3) – never a changed 4.1.2. Kits keep copies of versions they installed; two different
  contents under one number would confuse them.

## 3. The changelog

`CHANGELOG.md` has a section per version, newest first:

```markdown
## 4.1.2

- Fixed: …
- New: …
```

That section becomes the **release notes** on GitHub and in **Software updates → What's new**. Write it
for the people running classes: what changed for them, not how it was coded.

---

## 4. Making and publishing a new version

### Usual way – a version you received as a zip

On the ControlYard host (copy the zip **and** its `.sha256` file to `/tmp` first):

```bash
cd /tmp && sha256sum -c controlyard.zip.sha256          # must say: OK
/opt/controlyard/release.sh /tmp/controlyard.zip        # y (add it), y (publish), Enter (notes)
```

`release.sh` then:

1. puts the files into its source folder and **commits** them to `main`,
2. **tags** the commit (`v4.1.2`) and pushes both to GitHub,
3. makes the **release** with the notes from `CHANGELOG.md`,
4. attaches **`controlyard.zip`** and **`ics-ranges.zip`** (the same version in the folder kits from
   before the rename expect) with their **checksums**.

### Your own change

Edit the files in the source folder (e.g. `/home/jsmith/controlyard-src`), raise the version in
`app/server.py`, add the `CHANGELOG.md` section, then:

```bash
/opt/controlyard/release.sh          # commits, tags, pushes, publishes – asks first
```

### With git only

Commit to `main`, then push a tag – the **release workflow** builds and publishes the release by itself
(section 6):

```bash
git tag v4.1.2 && git push origin main v4.1.2
```

### Check

```bash
/opt/controlyard/release.sh list     # every version: published – kits can install it?
```

On GitHub: **Releases** shows the version with **four files**.

---

## 5. Installing, and going back

- **Install:** in ControlYard, **Software updates → Check again → Update to vX.Y.Z**. The kit's host
  downloads the release, checks the checksum, installs, and checks that the new version starts – if it
  doesn't, it **goes back by itself**.
- **Go back:** the same page lists older versions – *Go back to vX.Y.Z*. Each kit keeps copies of the
  last 5 versions it installed, so that works even when GitHub can't be reached.
- On a **renamed** kit, versions **before 4.1.0** can't be installed (they would start the old container
  with the data from before the rename) – the page says so.
- **A broken release** (a file missing): `release.sh publish vX.Y.Z` adds what it lacks – it never
  replaces a file already attached.

---

## 6. The automatic checks and releases (GitHub Actions)

Two workflows in `.github/workflows/` run on GitHub by themselves:

| Workflow | Runs when | Does |
|---|---|---|
| **checks** | A push or pull request changes the program (not kit-content branches) | Python, JavaScript and shell checks; starts the server and checks it answers with its version |
| **release** | A version tag is pushed (`v*.*.*`), or by hand (*Actions → release → Run workflow*) | Checks the tag matches `app/server.py`, runs the checks, builds both zips with checksums, notes from `CHANGELOG.md`, and publishes |

The **release** workflow and `release.sh` work together: when `release.sh` pushes a tag, the workflow
**waits 90 seconds** so `release.sh` can publish first, then only **completes** the release – it adds a
missing zip together with its own checksum, keeps every file already attached, and replaces a checksum
that doesn't match its zip. Whatever order things happen in, every zip ends up with its own checksum.

A **red ✗** next to a commit means a check failed – click it to see which. Fix it before publishing.

**Settings this needs** (*repository → Settings → Actions → General*):

- *Actions permissions*: allow actions (the organization may have to allow it too).
- *Workflow permissions*: the release workflow asks for **contents: write** in its file; if the
  organization limits workflows to read-only, the release step fails – `release.sh` still publishes,
  the workflow then only shows a red ✗.

---

## 7. Each kit's content (Save & share)

- Each kit saves its content to **its own branch** – `kit-config`, or `kit-lab1`, `kit-lab2` … for
  several kits. In ControlYard: **Save & share** → address `https://github.com/sansics/icscontrolyard.git`,
  the branch, user and token → **Connect**. The first save makes the branch.
- Save & share **refuses a branch that holds the program** (any branch with `app/server.py`), so a kit's
  content can never land on `main`.
- Every change on the kit is saved and uploaded; **Get latest** loads what others changed; the branch's
  history on GitHub shows who changed what, and when.
- To copy one kit's content to another: connect the second kit to the first kit's branch, **Get latest**,
  then connect it back to its own branch.

### What a kit's branch holds

| Saved by Save & share – only what the kit has | Never saved there |
|---|---|
| Add-ons (`addons/`), class guides (`guides/`) | Users, passwords, 2FA |
| Mirror add-ons (`mirroring/`) – whether one is **switched on** stays each kit's own | The node key, the Proxmox, TrueNAS and GitHub tokens |
| Roles and the course map (`settings/`) | The activity log |
| Settings, saved groups, colour themes, mixed courses – once changed or made | |

A file appears only once the kit has it – a kit without class guides has no `guides/` folder. **Get
latest** first saves the kit's own content, then brings in what others changed: nothing on the kit is
lost, and a mirror add-on new to a kit arrives switched **off**.

**Save & share isn't the complete backup** – for that, use the **Backups** page: the automatic backups
(everything, kept on the kit) and the **kit backup** (everything, encrypted, one file to keep elsewhere).

### Making a kit's branch – without the program's code

A kit's branch must hold **only that kit's content** – never the program. The way to get that: **let
ControlYard create the branch.** A branch made on GitHub (*Create branch*, or *Branches → New branch*)
is always a **copy of `main` – code and all**; ControlYard then refuses it in Save & share (*"the branch
kit-config holds the program's code"*).

1. **If the branch already exists on GitHub with the code, delete it:** the repository → branch menu →
   *View all branches* → the **bin icon** next to it. This doesn't touch `main` or anything else. (The
   *Kit content* ruleset of section 9 blocks deleting `kit-*` branches – switch it off for a moment.)
2. **Let ControlYard create it:** **Save & share** → address `https://github.com/sansics/icscontrolyard.git`,
   branch `kit-config`, user, token → **Connect**. Connecting saves at once; **the first save makes the
   branch** – with only the kit's content, and a history of its own (nothing in common with `main`).
3. **Check:** on GitHub, pick `kit-config` in the branch menu. You should see only the kit's content –
   course map, class guides, add-ons, mirror add-ons, settings – and **no** `app/`, `api/` or `setup.sh`.

To keep it that way:

- **Never create kit branches on GitHub** – always let Save & share make them, also for more kits later
  (`kit-lab1`, `kit-lab2` …).
- **Never merge between `main` and a kit branch** – if GitHub offers *Compare & pull request* between
  them, ignore it. They are meant to stay apart.
- **`main` stays the default branch** (*Settings → General → Default branch*), so the repository's front
  page shows the program.
- A branch with the program **and** a kit's content isn't possible on purpose: updates of the program
  would overwrite the content, and the content would travel into every kit's update.

---

## 8. People, permissions and tokens

**People** (*repository → Settings → Collaborators and teams*):

| Role | For | May |
|---|---|---|
| **Admin** | Whoever owns ControlYard | Everything, including settings and rules |
| **Write** | Whoever publishes versions | Push code and tags, make releases |
| **Read** | Everyone else who looks at it | Read only |

**Tokens** – kept on the ControlYard host only, never in the repository:

| Used by | Needs | Best | Where the organization blocks those |
|---|---|---|---|
| Software updates (`setup.sh updater`) | Read | Fine-grained token for this repository, *Contents: Read-only*, 1 year | Classic token, scope `repo` |
| `release.sh`, Save & share | Write | Fine-grained token, *Contents: Read and write*, 6 months | Classic token, scope `repo` |

- In an **organization**, a fine-grained token's *Resource owner* is the organization, and it may have to
  be **approved** first. If GitHub shows **Configure SSO** next to a token, **Authorize** it.
- A classic token may write to every repository its owner can reach – give it an expiry date.
- Renewing: `guides/3-renew-tokens.md`.

---

## 9. Protection rules (recommended)

*Repository → Settings → Rules → Rulesets → New ruleset*:

| Ruleset | Target | Rules |
|---|---|---|
| **Program branch** | Branch `main` | Block **force pushes**, restrict **deletions** |
| **Versions** | Tags matching `v*` | Restrict **updates** and **deletions** – a published version can't be changed or removed by accident |
| **Kit content** | Branches matching `kit-*` | Restrict **deletions** |

Don't require pull requests on `main` unless the person publishing may bypass it – `release.sh` pushes
to `main` directly.

---

## 10. Checklist – a new version

1. The version in `app/server.py` is raised, and `CHANGELOG.md` has its section.
2. The checks are green (on GitHub: no red ✗), or locally:
   `python3 -m pyflakes app/server.py app/ics/*.py` and `shellcheck *.sh`.
3. Published: `release.sh /tmp/controlyard.zip` (or `release.sh` / a tag) – **Releases** shows four
   files.
4. Installed on one kit first: **Software updates → Update**; then the tests on that kit:

   ```bash
   cd /opt/controlyard && ./gui-test.sh
   ./tests/addon-test.sh https://127.0.0.1:8443 admin --course 613
   ./tests/ui-test.sh https://127.0.0.1:8443 admin
   ```

5. Then the other kits.

---

## 11. Quick reference

| Task | Command / where |
|---|---|
| Publish a version from a zip | `/opt/controlyard/release.sh /tmp/controlyard.zip` |
| Publish your own changes | `/opt/controlyard/release.sh` |
| Add missing files to a release | `/opt/controlyard/release.sh publish v4.1.2` |
| Notes for releases that have none | `/opt/controlyard/release.sh notes` |
| Versions and whether kits can install them | `/opt/controlyard/release.sh list` |
| Change repository, user, token or branch | `/opt/controlyard/release.sh setup` |
| Point a kit's updates at the repository | `cd /opt/controlyard && sudo ./setup.sh updater` |
| Publish by hand on GitHub | *Actions → release → Run workflow* → the tag |
| A kit's content | ControlYard → **Save & share** |

## 12. If something goes wrong

| You see | Cause – do |
|---|---|
| No version in Software updates | No **release** for it – `git push` copies code and tags, not releases: `release.sh publish vX.Y.Z` |
| *HTTP 401* from `release.sh` / `setup.sh` | Enter kept an old address or token – type the address, paste the token; or the token expired |
| *403 – Write access not granted* | The token may not write: scope / *Contents: Read and write*, SSO authorized |
| *no such repository (or the token can't see it)* | The token can't see the private repository |
| Red ✗ on *release* – *the tag is vX, app/server.py says Y* | The tag and the version disagree – make a new version with matching numbers |
| Red ✗ on *release* – permission | The organization limits workflows to read-only – `release.sh` publishes anyway |
| *the zip of vX contains version …* (Software updates) | The release has the wrong zip – publish a new version; don't change the old one |
| Save & share: *the branch … holds the program's code* | The branch was made on GitHub (a copy of `main`) – delete it there and let Save & share make it (section 7, *Making a kit's branch*) |
