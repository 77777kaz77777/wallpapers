#!/usr/bin/env bash
# release.sh - add a new ControlYard version to your repository (GitHub or Gitea), and publish it as a release
# that kits can install from "Software updates" - it asks before publishing.
#
#   ./release.sh /path/to/controlyard.zip  a new version you were sent as a zip (ics-ranges.zip works too)
#   ./release.sh                           a new version from your changes in the source folder
#   ./release.sh publish v2.4.2            publish a version that is already in the repository - or add
#                                          what its release is missing (e.g. the .sha256 file)
#   ./release.sh list                      versions in the repository and whether kits can install them
#   ./release.sh notes                     release notes from CHANGELOG.md for releases that have none
#   ./release.sh setup                     change the repository, user name, token or branch
#
# Needs: git, curl, unzip, sha256sum. The first run asks for the repository and a token
# that may WRITE to it (GitHub: a fine-grained token for this repository, Contents: Read and write;
# Gitea: Settings -> Applications -> repository: Read and Write); the branch for the code is asked too;
# they are kept in ~/.config/controlyard/release.conf (only you can read it).
set -u
CONF=${CY_RELEASE_CONF:-${ICS_RELEASE_CONF:-$HOME/.config/controlyard/release.conf}}
OUT=${CY_RELEASE_DIR:-${ICS_RELEASE_DIR:-$HOME/controlyard-releases}}
if [[ ! -e $CONF && -f $HOME/.config/ics-ranges/release.conf ]]; then   # from before the rename: moved over once
    mkdir -p "$(dirname "$CONF")" && mv "$HOME/.config/ics-ranges/release.conf" "$CONF" && rmdir "$HOME/.config/ics-ranges" 2>/dev/null
    echo "Settings moved to $CONF (from ~/.config/ics-ranges)."
fi
if [[ -t 1 ]]; then B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'; else B="" G="" R="" Y="" Z=""; fi
die() { echo "${R}$*${Z}" >&2; exit 1; }
ask() { local a; read -rp "$1 [$2] " a; echo "${a:-$2}"; }
changelog_section() {   # version -> its "## <version>" section of CHANGELOG.md (source folder first, else next to this script)
    local f
    for f in "${SRC:-}/CHANGELOG.md" "$(dirname "$(readlink -f "$0")")/CHANGELOG.md"; do
        [[ -f $f ]] || continue
        awk -v v="$1" '/^## /{p=($2==v); next} p' "$f" | sed -e '/./,$!d' | sed -e ':a' -e '/^\n*$/{$d;N;ba' -e '}'
        return
    done
}
yes_no() { local a; read -rp "$1 [y/N] " a; [[ $a == [yY]* ]]; }
yes_No() { local a; read -rp "$1 [Y/n] " a; [[ $a != [nN]* ]]; }
for c in git curl unzip sha256sum; do command -v $c >/dev/null || die "$c is missing - install it first (apt-get install -y $c / dnf -y install $c)"; done

# ------------------------------------------------------------------ settings
REPO="" USER_="" TOKEN="" INSECURE=0 SRC="$HOME/controlyard-src" GIT_URL=""
load_conf() { [[ -r $CONF ]] && . "$CONF"; GIT_URL=${GIT_URL:-$REPO.git}; }
derive() {   # GitHub or Gitea - from the address
    BASE=${REPO%/*/*}; OWNER_REPO=${REPO#"$BASE"/}
    if [[ $BASE == "${GH_WEB:-https://github.com}" ]]; then   # GH_WEB / GH_API / GH_UPLOADS: only for tests
        HOST_NAME=GitHub API="${GH_API:-https://api.github.com}/repos/$OWNER_REPO" UPLOAD="${GH_UPLOADS:-https://uploads.github.com}/repos/$OWNER_REPO"
        AUTH_HDR="Authorization: Bearer $TOKEN" PAGE="per_page"
    else
        HOST_NAME=Gitea API="$BASE/api/v1/repos/$OWNER_REPO" UPLOAD=$API
        AUTH_HDR="Authorization: token $TOKEN" PAGE="limit"
    fi
}
CURL=(curl -sS --connect-timeout 15 --max-time 900)
code="" body=""
api() {   # METHOD PATH [curl args...] -> $code, $body
    local m=$1 p=$2 out
    shift 2
    local -a k=()
    [[ $INSECURE == 1 ]] && k=(-k)
    out=$("${CURL[@]}" "${k[@]}" -X "$m" -H "$AUTH_HDR" -H "Accept: application/json" "$@" -w $'\n%{http_code}' "${BASE_URL:-$API}$p") || out=$'\n000'
    code=${out##*$'\n'}
    body=${out%$'\n'*}
}
git_() { git -c http.extraHeader="Authorization: Basic $(printf '%s:%s' "$USER_" "$TOKEN" | base64 -w0)" \
             -c http.sslVerify="$([[ $INSECURE == 1 ]] && echo false || echo true)" "$@"; }

setup() {
    load_conf
    echo "${B}Where the ControlYard versions go${Z} (the same repository kits update from - GitHub or Gitea)"
    REPO=$(ask "Repository address, e.g. https://github.com/<you>/<repo>" "${REPO:-}"); REPO=${REPO%/}; REPO=${REPO%.git}
    [[ $REPO =~ ^https?://[^[:space:]/]+(/[^[:space:]/]+)*/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || die "That isn't a repository address."
    USER_=$(ask "Your user name there" "${USER_:-${USER:-kaz}}")
    local t
    read -rsp "Token that may WRITE to the repository (Enter keeps the saved one): " t; echo
    [[ -n $t ]] && TOKEN=$t
    [[ -n $TOKEN ]] || die "A token is needed."
    INSECURE=0
    [[ $REPO == https://* && $REPO != "${GH_WEB:-https://github.com}"/* ]] && ! yes_No "Check the server's HTTPS certificate? (no for a self-signed Gitea)" && INSECURE=1
    SRC=$(ask "Source folder (a Git copy of the repository, made if missing)" "$SRC")
    GIT_URL=$REPO.git
    derive
    api GET ""
    [[ $code == 200 ]] || die "The repository answered HTTP $code - check the address and the token."
    grep -Eq '"push": *true' <<<"$body" || die "That token may read but not WRITE to the repository - give it Contents: Read and write."
    BRANCH=$(ask "Branch for the program's code (the repository's default is suggested; other branches - e.g. the kits' content - stay untouched)" "${BRANCH:-$(default_branch)}")
    [[ $BRANCH =~ ^[A-Za-z0-9._/-]{1,100}$ ]] || die "That isn't a branch name."
    save_conf
    echo "${G}Saved${Z} in $CONF"
}
default_branch() { api GET ""; grep -oE '"default_branch": *"[^"]*"' <<<"$body" | head -1 | sed -E 's/.*: *"(.*)"/\1/'; }
save_conf() {
    mkdir -p "$(dirname "$CONF")"
    (umask 077; printf 'REPO=%q\nUSER_=%q\nTOKEN=%q\nINSECURE=%q\nSRC=%q\nBRANCH=%q\n' "$REPO" "$USER_" "$TOKEN" "$INSECURE" "$SRC" "$BRANCH" >"$CONF")
}
ready() {
    load_conf
    [[ -n $REPO && -n $TOKEN ]] || setup
    load_conf; derive
    if [[ -z ${BRANCH:-} ]]; then   # set up before branches were a setting: the repository's default, once
        BRANCH=$(default_branch); [[ -n $BRANCH ]] || die "Couldn't read the repository's default branch - run: ./release.sh setup"
        save_conf; echo "Branch for the code: $BRANCH (change it: ./release.sh setup)"
    fi
}

# ------------------------------------------------------------------ the Git copy
ensure_src() {
    if [[ -d $SRC/.git ]]; then
        # always the repository set up now - also after a move (e.g. from Gitea to GitHub)
        if [[ $(git -C "$SRC" remote get-url origin 2>/dev/null) != "$GIT_URL" ]]; then
            git -C "$SRC" remote set-url origin "$GIT_URL" 2>/dev/null || git -C "$SRC" remote add origin "$GIT_URL"
            echo "The source folder now sends to $GIT_URL"
        fi
        git_ -C "$SRC" fetch -q origin --tags 2>/dev/null || echo "${Y}Couldn't fetch from $HOST_NAME - working with the local copy.${Z}"
    elif [[ -n $(git_ ls-remote "$GIT_URL" 2>/dev/null) ]]; then
        echo "Making the source folder $SRC from $HOST_NAME ..."
        git_ clone -q "$GIT_URL" "$SRC" || die "couldn't clone $GIT_URL"
    else
        echo "The repository is empty - starting the source folder $SRC."
        mkdir -p "$SRC" && git -C "$SRC" init -q -b "$BRANCH" && git -C "$SRC" remote add origin "$GIT_URL"
    fi
    # work on the configured branch: as it is in the repository, or a new one from the current state
    if git -C "$SRC" rev-parse -q --verify "refs/remotes/origin/$BRANCH" >/dev/null; then
        git -C "$SRC" checkout -q -B "$BRANCH" "origin/$BRANCH" || die "couldn't switch $SRC to the branch $BRANCH"
    elif [[ $(git -C "$SRC" symbolic-ref -q --short HEAD 2>/dev/null) != "$BRANCH" ]]; then
        git -C "$SRC" checkout -q -B "$BRANCH" 2>/dev/null || git -C "$SRC" symbolic-ref HEAD "refs/heads/$BRANCH"
    fi
    [[ -f $SRC/.gitignore ]] || printf '.env\n*.zip\n__pycache__/\nupdates/\nupdater.conf\n' >"$SRC/.gitignore"
}
version_in() { sed -n 's/^VERSION = "\(.*\)"$/\1/p' "$1" 2>/dev/null | head -1; }
ver_ok() { [[ $1 =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)?$ ]]; }
tag_in_repo() { [[ -n $(git_ ls-remote --tags "$GIT_URL" "refs/tags/v$1" 2>/dev/null) ]]; }
tag_local() { git -C "$SRC" rev-parse -q --verify "refs/tags/v$1" >/dev/null; }
# a tag only in the local copy is a leftover (an earlier run that didn't reach the repository, or a tag deleted
# there) - it doesn't block making the version again
drop_local_leftover() {
    if tag_local "$1" && ! tag_in_repo "$1"; then
        echo "${Y}v$1 is only in your local copy ($SRC), not in $HOST_NAME - a leftover from an earlier run. Making it again.${Z}"
        git -C "$SRC" tag -d "v$1" >/dev/null
    fi
}
latest_tag() { git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname | head -1; }
next_patch() { local v=${1#v}; [[ $v =~ ^([0-9]+)\.([0-9]+)\.([0-9]+) ]] && echo "${BASH_REMATCH[1]}.${BASH_REMATCH[2]}.$((BASH_REMATCH[3] + 1))" || echo "1.0.0"; }

commit_tag_push() {   # version
    local v=$1 n
    git -C "$SRC" add -A
    n=$(git -C "$SRC" status --porcelain | wc -l)
    echo "Changed files: $n"
    git -C "$SRC" status --short | head -15 | sed 's/^/   /'
    ((n > 15)) && echo "   ... and $((n - 15)) more"
    yes_No "Add version $v to $HOST_NAME (commit, tag v$v, push)?" || { git -C "$SRC" reset -q; die "Nothing was changed in $HOST_NAME."; }
    git -C "$SRC" -c user.name="${GIT_AUTHOR_NAME:-$USER_}" -c user.email="${GIT_AUTHOR_EMAIL:-$USER_@controlyard.local}" \
        commit -q -m "ControlYard $v" --allow-empty || die "commit failed"
    git -C "$SRC" -c user.name="$USER_" -c user.email="$USER_@controlyard.local" tag -a "v$v" -m "ControlYard $v" || die "tag failed"
    git_ -C "$SRC" push -q origin "HEAD:$BRANCH" || die "push to $HOST_NAME ($BRANCH) failed"
    git_ -C "$SRC" push -q origin "v$v" || die "pushing the tag failed"
    echo "${G}Version $v is in $HOST_NAME${Z} (tag v$v)."
}
sha_file() { (cd "$1" && sha256sum "$2.zip" >"$2.zip.sha256"); }   # folder, name

# ------------------------------------------------------------------ publish (or complete) a release
asset_names() { grep -oE '"name": *"[^"]*"' <<<"$1" | sed -E 's/"name": *"(.*)"/\1/'; }
asset_url() { tr -d '\n' <<<"$1" | grep -oE "\"name\": *\"$2\"[^}]*\"browser_download_url\": *\"[^\"]*\"" | head -1 | sed -E 's/.*"browser_download_url": *"([^"]*)"/\1/'; }
json_str() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\t'/\\t}; s=${s//$'\r'/}; s=${s//$'\n'/\\n}; printf '"%s"' "$s"; }

publish() {   # vX.Y.Z
    local tag=v${1#v} v rid rel dir url notes prev have
    v=${tag#v}
    ver_ok "$v" || die "usage: ./release.sh publish v2.4.2"
    ensure_src
    if ! tag_in_repo "$v"; then
        tag_local "$v" && die "$tag is only in your local copy ($SRC), not in $HOST_NAME - add it again: ./release.sh <zip of $tag>"
        die "There is no tag $tag in $HOST_NAME - add the version first: ./release.sh <zip>"
    fi
    dir=$OUT/$tag
    mkdir -p "$dir"
    api GET "/releases/tags/$tag"
    if [[ $code == 200 ]]; then
        rel=$body
        echo "Release $tag exists - checking its files."
    elif [[ $code == 404 ]]; then
        prev=$(git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname | grep -A1 -x "$tag" | sed -n 2p)
        notes=$(changelog_section "$v")
        if [[ -n $notes ]]; then
            echo "Release notes for $v - from CHANGELOG.md:"
            sed 's/^/    /' <<<"$notes" | head -25
            echo "Enter publishes these; or type one line to use instead:"
        else
            notes=$(git -C "$SRC" log --pretty='- %s' ${prev:+"$prev..$tag"} 2>/dev/null | grep -Ev "^- (ControlYard|ICS Ranges) $v\$" | head -20)
            echo "Release notes - what's new in $v (CHANGELOG.md has no section '## $v'). One line, or Enter for: ${notes:-"ControlYard $v"}"
        fi
        read -rp "> " url
        [[ -n $url ]] && notes=$url
        api POST "/releases" -H "Content-Type: application/json" \
            --data "{\"tag_name\":\"$tag\",\"name\":\"ControlYard $v\",\"body\":$(json_str "${notes:-ControlYard $v}"),\"draft\":false,\"prerelease\":false}"
        if [[ $code == 409 || $code == 422 ]]; then   # made meanwhile - e.g. by the GitHub workflow on the tag: use it
            api GET "/releases/tags/$tag"
            [[ $code == 200 ]] && echo "The release was made meanwhile (the repository's workflow?) - completing it."
        fi
        [[ $code == 201 || $code == 200 ]] || die "$HOST_NAME refused to make the release (HTTP $code): ${body:0:200}"
        rel=$body
        echo "Release $tag made."
    else
        die "$HOST_NAME answered HTTP $code for $tag - check the token."
    fi
    rid=$(grep -oE '"id": *[0-9]+' <<<"$rel" | head -1 | grep -oE '[0-9]+$')
    have=$(asset_names "$rel")

    # two release files, the same version: controlyard.zip, and ics-ranges.zip for kits not renamed yet
    # (their updater knows only that name). Each: the one already attached (so its checksum matches),
    # else ours, else built from the tag.
    local n f up=0 url
    for n in controlyard ics-ranges; do
        if grep -qx "$n.zip" <<<"$have"; then
            if [[ $HOST_NAME == GitHub ]]; then   # through the API: works for private repositories too
                url=$(tr -d '\n' <<<"$rel" | grep -oE "\"url\": *\"[^\"]*/releases/assets/[0-9]+\"[^}]*\"name\": *\"$n.zip\"" | head -1 | sed -E 's/^"url": *"([^"]*)".*/\1/')
                "${CURL[@]}" -fL -H "$AUTH_HDR" -H "Accept: application/octet-stream" -o "$dir/$n.zip" "$url" ||
                    die "couldn't download the attached $n.zip to make its checksum"
            else
                local -a k=(); [[ $INSECURE == 1 ]] && k=(-k)
                url=$(asset_url "$rel" "$n.zip")
                "${CURL[@]}" "${k[@]}" -f -H "Authorization: token $TOKEN" -o "$dir/$n.zip" "$url" ||
                    "${CURL[@]}" "${k[@]}" -f -u "$USER_:$TOKEN" -o "$dir/$n.zip" "$url" ||
                    die "couldn't download the attached $n.zip to make its checksum"
            fi
        elif [[ ! -s $dir/$n.zip ]]; then
            echo "Building $n.zip from tag $tag ..."
            git -C "$SRC" archive --format=zip --prefix="$n/" -o "$dir/$n.zip" "$tag" || die "git archive failed"
        fi
        unzip -tq "$dir/$n.zip" >/dev/null || die "$dir/$n.zip is damaged"
        [[ $(unzip -p "$dir/$n.zip" "$n/app/server.py" | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1) == "$v" ]] ||
            die "$n.zip for $tag doesn't contain version $v (or not in a folder $n/)"
        sha_file "$dir" "$n"
        for f in "$n.zip" "$n.zip.sha256"; do
            if grep -qx "$f" <<<"$have"; then
                echo "  $f: already attached"
                continue
            fi
            if [[ $HOST_NAME == GitHub ]]; then
                BASE_URL=$UPLOAD api POST "/releases/$rid/assets?name=$f" -H "Content-Type: application/octet-stream" --data-binary "@$dir/$f"
            else
                api POST "/releases/$rid/assets?name=$f" -F "attachment=@$dir/$f"
            fi
            [[ $code == 201 || $code == 200 ]] || die "uploading $f failed (HTTP $code): ${body:0:200}"
            echo "  $f: attached"
            up=1
        done
    done
    api GET "/releases/tags/$tag"
    have=$(asset_names "$body")
    for f in controlyard.zip controlyard.zip.sha256 ics-ranges.zip ics-ranges.zip.sha256; do
        grep -qx "$f" <<<"$have" || die "the release still lacks $f - check it in $HOST_NAME: $REPO/releases/tag/$tag"
    done
    ((up)) && echo
    echo "${G}Release $tag is published${Z}: $REPO/releases/tag/$tag"
    echo "Kits: Software updates -> Check again -> Update to $tag"
    echo "The files are also in $dir (for a USB stick)."
}

ask_publish() {   # version
    local v=$1
    echo
    if yes_no "Publish v$v as a release now, so kits can install it?"; then
        publish "v$v"
    else
        echo "Not published - kits don't see v$v yet. Publish it any time with:  ./release.sh publish v$v"
        echo "Its files are in $OUT/v$v."
    fi
}

# ------------------------------------------------------------------ new versions
from_zip() {   # zip
    local zip=$1 v t dir
    [[ -f $zip ]] || die "no such file: $zip"
    unzip -tq "$zip" >/dev/null || die "$zip is damaged - copy it again"
    local top
    top=$(unzip -l "$zip" | awk '$4 ~ /^[^\/]+\/app\/server\.py$/ {split($4, p, "/"); print p[1]; exit}')
    [[ $top == controlyard || $top == ics-ranges ]] || die "$zip isn't a ControlYard zip"
    v=$(unzip -p "$zip" "$top/app/server.py" | sed -n 's/^VERSION = "\(.*\)"$/\1/p' | head -1)
    ver_ok "$v" || die "can't read the version in $zip"
    echo "${B}ControlYard $v${Z} from $zip"
    ensure_src
    drop_local_leftover "$v"
    tag_in_repo "$v" && die "v$v is already in $HOST_NAME (its tag is there). To publish its release - or add what it is missing: ./release.sh publish v$v"
    t=$(mktemp -d)
    unzip -q "$zip" -d "$t" || die "unzip failed"
    find "$SRC" -mindepth 1 -maxdepth 1 ! -name .git ! -name .gitignore -exec rm -rf {} +
    cp -a "$t/$top/." "$SRC/" && rm -rf "$t"
    commit_tag_push "$v"
    dir=$OUT/v$v; mkdir -p "$dir"; cp "$zip" "$dir/$top.zip"; sha_file "$dir" "$top"
    ask_publish "$v"
}

from_folder() {
    local cur last v dir
    ensure_src
    [[ -f $SRC/app/server.py ]] || die "$SRC has no ControlYard files yet - start with a zip: ./release.sh /path/to/controlyard.zip"
    last=$(latest_tag)
    if [[ -n $last && -z $(git -C "$SRC" status --porcelain) && $(git -C "$SRC" rev-parse HEAD) == "$(git -C "$SRC" rev-list -n1 "$last")" ]]; then
        die "Nothing changed in $SRC since $last. Change files there first, or use: ./release.sh /path/to/controlyard.zip"
    fi
    cur=$(version_in "$SRC/app/server.py")
    echo "${B}A new version from your changes in $SRC${Z} (last version in $HOST_NAME: ${last:-none}, the files say ${cur:-?})"
    v=$(ask "Version number for it" "$(next_patch "${last:-$cur}")")
    ver_ok "$v" || die "versions look like 2.4.2"
    drop_local_leftover "$v"
    tag_in_repo "$v" && die "v$v is already in $HOST_NAME - pick another number"
    sed -i "s/^VERSION = \".*\"$/VERSION = \"$v\"/" "$SRC/app/server.py"
    commit_tag_push "$v"
    dir=$OUT/v$v; mkdir -p "$dir"
    git -C "$SRC" archive --format=zip --prefix=controlyard/ -o "$dir/controlyard.zip" "v$v" || die "git archive failed"
    sha_file "$dir"
    ask_publish "$v"
}

list() {
    ensure_src
    api GET "/releases?$PAGE=50"
    [[ $code == 200 ]] || die "$HOST_NAME answered HTTP $code"
    local tags t
    tags=$(git -C "$SRC" tag -l 'v[0-9]*' --sort=-v:refname)
    echo "${B}Versions in $HOST_NAME${Z}"
    for t in $tags; do
        api GET "/releases/tags/$t"
        if [[ $code != 200 ]]; then echo "  $t   ${Y}not published${Z} - ./release.sh publish $t"
        elif asset_names "$body" | grep -Eqx '(controlyard|ics-ranges)\.zip\.sha256' && asset_names "$body" | grep -Eqx '(controlyard|ics-ranges)\.zip'; then echo "  $t   ${G}published - kits can install it${Z}"
        else echo "  $t   ${Y}published, but missing a file${Z} - ./release.sh publish $t"
        fi
    done
    [[ -n $tags ]] || echo "  none yet"
}

notes() {   # [vX] - release notes from CHANGELOG.md for releases that have none (or only their title)
    local only=${1#v} n=0 rid tag v body cur
    api GET "/releases?$PAGE=50"
    [[ $code == 200 ]] || { echo "${R}Couldn't read the releases (HTTP $code).${Z}"; return 1; }
    while IFS=$'\t' read -r rid tag cur; do
        v=${tag#v}
        [[ -n $only && $v != "$only" ]] && continue
        if [[ -n $cur && $cur != "ControlYard $v" && $cur != "ICS Ranges $v" && -z $only ]]; then
            echo "  $tag has notes - left as they are"; continue
        fi
        body=$(changelog_section "$v")
        [[ -n $body ]] || { echo "  $tag - CHANGELOG.md has no section '## $v'"; continue; }
        api PATCH "/releases/$rid" -H "Content-Type: application/json" --data "{\"body\":$(json_str "$body")}"
        if [[ $code == 200 ]]; then echo "  ${G}$tag${Z} - release notes added"; n=$((n + 1)); else echo "  ${R}$tag - HTTP $code${Z}"; fi
    done < <(python3 -c 'import json,sys
for r in json.load(sys.stdin):
    print("%s\t%s\t%s" % (r["id"], r.get("tag_name", ""), (r.get("body") or "").strip().replace("\n", " ")[:200]))' <<<"$body")
    echo "$n release(s) got their notes from CHANGELOG.md."
}

case ${1:-} in
    setup) setup ;;
    publish) ready; publish "${2:-}" ;;
    list) ready; list ;;
    notes) ready; notes "${2:-}" ;;
    -h|--help|help) sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//' ;;
    "") ready; from_folder ;;
    *) ready; from_zip "$1" ;;
esac
