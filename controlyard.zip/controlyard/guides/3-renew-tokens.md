# Guide 3 – Token expiry and renewal

> **Examples in this guide – replace them with your own:**
> `jsmith` – your GitHub user name · `pve-range1` – the ControlYard host ·
> `sansics/icscontrolyard` – the GitHub repository

ControlYard uses a GitHub token in three places on pve-range1: **release.sh** (publishing),
**Software updates** (`setup.sh updater`) and **Save & share**. Tokens expire – this is how to plan
for it and renew them in a few minutes.

---

## How long should a token last?

| Token | Used by | Expiry |
|---|---|---|
| Classic token (now) | all three | **6 months** |
| Later: fine-grained, *read* | Software updates | **1 year** – it can only read |
| Later: fine-grained, *write* | release.sh, Save & share | **90 days – 1 year** (6 months if unsure) |

Avoid *No expiration*: a token that never expires stays usable forever if it ever leaks.

GitHub emails you a few days before a token expires. A calendar reminder a week before helps too.

## What happens when it expires

| Where | What you notice | Your kit |
|---|---|---|
| Software updates | *"no such repository (or the token can't see it)"* | Keeps running normally |
| release.sh | *HTTP 401* when publishing | Nothing changes |
| Save & share | Uploading fails | The data on the kit stays safe |

---

## Renewing – step by step

**1. Make a new token** on GitHub with the same settings as the old one (classic: scope **`repo`**;
expiry e.g. 6 months). If GitHub shows **Configure SSO** next to it: **Authorize** for `sansics`.
Copy it straight away.

**2. Software updates** – on pve-range1:

```bash
cd /opt/controlyard && sudo ./setup.sh updater
```

**Type** `https://github.com/sansics/icscontrolyard`, user `jsmith`, **paste** the new token.

**3. release.sh:**

```bash
/opt/controlyard/release.sh setup
```

**Type** the address, user `jsmith`, **paste** the new token; press **Enter** at *Source
folder* and *Branch* (they stay as they are).

**4. Save & share** – browser: **Save & share** → enter the **new token** (address, branch
`kit-config` and user stay the same) → **Connect**.

**5. Check** – browser: **Software updates → Check again** lists the versions;
`/opt/controlyard/release.sh list` shows them too.

**6. Delete the old token** on GitHub: **Settings → Developer settings → Personal access tokens**.

> At every question, **Enter keeps the old value** – that is what you want for folders and branches,
> but not for the token: always **paste** the new one.
