# Guide 2 – Move from Gitea to GitHub

> **Examples in this guide – replace them with your own:**
> `jsmith` – your GitHub user name (and your user on the host) · `pve-range1` – the ControlYard host ·
> `sansics/icscontrolyard` – the GitHub repository · `http://192.168.77.93:3000/jsmith/ics-ranges-app` –
> the old Gitea repository

For the repository **`https://github.com/sansics/icscontrolyard`**, with a **classic token**.
Commands run on **pve-range1** unless it says *browser*. Do Guide 1 first (the kit on 4.1.3).

> **Important at every question:** pressing **Enter** keeps the value in the brackets – the old **Gitea**
> address and token. **Type** the GitHub address and **paste** the token.

---

## Part 1 – On GitHub (browser)

**1. The repository** `sansics/icscontrolyard` must be **Private** (a *Private* label next to its name)
and **empty** to start with.

**2. Create a classic token:** your picture → **Settings → Developer settings → Personal access
tokens → Tokens (classic) → Generate new token (classic)**

- Note: `controlyard`
- Expiration: **6 months** (see Guide 3)
- Scope: tick **`repo`**
- **Generate token**, **copy it straight away** (it is shown once) and keep it somewhere safe

**3. If GitHub shows *Configure SSO*** next to the token: click it → **Authorize** for `sansics`.
Otherwise GitHub answers *403*.

---

## Part 2 – Copy the code and versions from Gitea

**4. Get everything from Gitea:**

```bash
cd /tmp && git clone --mirror http://192.168.77.93:3000/jsmith/ics-ranges-app.git gitea-copy.git
```

**5. Send it to GitHub:**

```bash
cd /tmp/gitea-copy.git
git push --all https://github.com/sansics/icscontrolyard.git
git push --tags https://github.com/sansics/icscontrolyard.git
```

*Username:* `jsmith` – *Password:* **the classic token** (not your GitHub password).

Check: the repository page on GitHub shows the files.

> This copies the **code and version tags only – not the releases**. Software updates needs
> releases; they are made in Part 3.

---

## Part 3 – Publish versions to GitHub

**6. Point `release.sh` at GitHub:**

```bash
/opt/controlyard/release.sh setup
```

| Question | Answer |
|---|---|
| Repository address | **Type:** `https://github.com/sansics/icscontrolyard` |
| Your user name there | `jsmith` |
| Token | **Paste** the classic token |
| Source folder | **Type:** `/home/jsmith/controlyard-src` (a new folder – a clean start; from 4.1.3 an old one would also switch over by itself) |
| Branch | **Enter** (`main`) |

**7. See what GitHub has:**

```bash
/opt/controlyard/release.sh list
```

**8. Create the release:**

```bash
/opt/controlyard/release.sh publish v4.1.3
```

Press **Enter** at the notes. It ends with *"Release v4.1.3 is published: …"*.

If it says there is **no tag v4.1.3**, that version never reached Gitea – publish it from the zip instead
(copy `ics-ranges.zip` to `/tmp` first): `/opt/controlyard/release.sh /tmp/ics-ranges.zip` → **y**, **y**, **Enter**.

**Check** – `github.com/sansics/icscontrolyard/releases` shows **v4.1.3** with four files:
`controlyard.zip`, `controlyard.zip.sha256`, `ics-ranges.zip`, `ics-ranges.zip.sha256`.

---

## Part 4 – Let the kit update from GitHub

**9. Point the kit's updates at GitHub:**

```bash
cd /opt/controlyard && sudo ./setup.sh updater
```

**Type** `https://github.com/sansics/icscontrolyard`, user `jsmith`, **paste** the classic token.

**10. Check** – *browser*: **Software updates → Check again**. It should list **v4.1.3 – current**.
No *Update* button is right: there's nothing newer yet. It appears when you publish the next version.

---

## Part 5 – Save & share (only if you use it, browser)

**11.** **Save & share** – fill in, then **Connect**:

| Field | Value |
|---|---|
| Address | `https://github.com/sansics/icscontrolyard.git` |
| Branch | **`kit-config`** – never `main` (that holds the program; ControlYard refuses it anyway) |
| User | `jsmith` |
| Token | the classic token |

It saves straight away and creates the `kit-config` branch on GitHub – with only the kit's content.

> **Don't create `kit-config` on GitHub yourself** – a branch made there is a copy of `main`, with the
> program's code, and Save & share refuses it. If you already did: delete it (*branch menu → View all
> branches → bin icon*) and connect again. Check afterwards: the `kit-config` branch on GitHub has **no**
> `app/`, `api/` or `setup.sh`.

---

## Part 6 – Finish

**12.** Publishing from now on – the same as before, now to GitHub:
`/opt/controlyard/release.sh /tmp/controlyard.zip` → **y**, **y**, **Enter** → Software updates.

**13.** Once an update from GitHub has worked: delete your **Gitea tokens**, switch the Gitea VM off –
keep it a few weeks before deleting it.

**14.** Tidy up on pve-range1:

```bash
rm -rf /tmp/gitea-copy.git /home/jsmith/ics-ranges-src
```

**15.** If you added an SSH key to GitHub while trying, and don't use it: remove it under
**Settings → SSH and GPG keys**.

---

## About the classic token

It can write to **every** repository you can access, and it is stored on the kit. So: give it an expiry
date, keep it only on pve-range1, and later replace it with two **fine-grained tokens** limited to
`icscontrolyard` (one *Contents: Read-only* for updates, one *Contents: Read and write* for publishing
and Save & share). An owner of `sansics` has to allow those first: **Organization settings →
Personal access tokens → Settings → Allow access via fine-grained personal access tokens**.

## If something goes wrong

| You see | Cause – do |
|---|---|
| *HTTP 401* from `release.sh` or `setup.sh` | Enter kept the **old Gitea address or token** – run it again, **type** the address and **paste** the token. Or the token is wrong/expired |
| *403 – Write access to repository not granted* | The token isn't allowed to write: classic token needs the **`repo`** scope, and **Configure SSO → Authorize** for `sansics` |
| *Permission denied (publickey)* | That is SSH, not needed here – use the HTTPS commands with the token |
| No releases on GitHub | `git push` doesn't copy releases – do Part 3, step 8 |
| No update in Software updates | Right if the kit already runs the newest release (*current*); otherwise check the address on that page is GitHub (step 9) |
| *no such repository (or the token can't see it)* | The token can't see the private repository – scope `repo`, SSO authorized |
| *"the branch … holds the program's code"* (Save & share) | Use `kit-config` – and if that one was made on GitHub, delete it there and connect again |
