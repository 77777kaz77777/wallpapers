# Guide 1 – Update to ControlYard 4.1 and rename the kit

> **Examples in this guide – replace them with your own:**
> `jsmith` – your user name on the ControlYard host · `pve-range1` – the ControlYard host

Two parts: first the usual update, then the rename. Everything happens on **pve-range1** and in the
browser. Allow about 15 minutes.

---

## Part 1 – Update to 4.1 (here: 4.1.3)

**1. Download** `ics-ranges.zip` **and** `ics-ranges.zip.sha256` (version 4.1.3) to your PC.

**2. Copy it to pve-range1** – on your PC:

```bash
scp ics-ranges.zip ics-ranges.zip.sha256 jsmith@pve-range1:/tmp/
```

**3. Check it arrived intact** – on pve-range1:

```bash
cd /tmp && sha256sum -c ics-ranges.zip.sha256
```

It must say **`ics-ranges.zip: OK`**. If not, copy it again.

**4. Publish it:**

```bash
/opt/ics-ranges/release.sh /tmp/ics-ranges.zip
```

Answer **y**, then **y**, then press **Enter**.

**5. Install it** – in the browser: **Software updates → Check again → Update to v4.1.3**. Wait about
a minute; the page reloads and shows **ControlYard 4.1.3** at the top left.

---

## Part 2 – Rename the kit (once, about two minutes)

**6. Make a safety copy** – in the browser: **Backups → Kit backup** → choose a password →
**Download kit file**. Keep the file on your PC.

**7. Rename** – on pve-range1:

```bash
cd /opt/ics-ranges && sudo ./setup.sh rename
```

It shows what it will do – answer **y**. It counts through steps **1/6 … 6/6** and ends with
**"Renamed."**

| Step | What happens |
|---|---|
| Checks | The data is there, nothing in the way, enough free disk space |
| 1 | A backup of the data as a file next to the folder (`controlyard-rename-backup-<date>.tgz`) |
| 2–3 | The old container stops; the new one (`controlyard`) is built |
| 4 | The data is **copied** to the new volume and compared – the old one isn't touched |
| 5 | The folder moves to `/opt/controlyard` (`/opt/ics-ranges` stays as a link); the host services are renamed |
| 6 | ControlYard starts and is checked: it answers, with the same users |

If any step fails, **everything is put back by itself** and it says which step – send a screenshot.

**8. Check** – open ControlYard at the **same address as always**. Sign in, look at a course, the
add-ons and Health.

**9. Tidy up** – after a few days, once you're happy:

```bash
cd /opt/controlyard && sudo ./setup.sh rename --cleanup
```

Answer **y**. This deletes the old copy of the data that the rename kept for safety.

---

## What's different afterwards

- The kit's folder is **`/opt/controlyard`** – `/opt/ics-ranges` still works (a link).
- Docker commands use the new name, e.g. `docker compose logs controlyard`.
- New versions arrive as **`controlyard.zip`**: `/opt/controlyard/release.sh /tmp/controlyard.zip`.
- Versions before 4.1.0 can't be installed any more – Software updates says so.
- Already on 4.1.0? Part 1 is the same with 4.1.3; the rename works from 4.1.0 on.
- Add-ons keep working unchanged.

## If something goes wrong

| You see | Do |
|---|---|
| Step 3 doesn't say `OK` | Copy both files again |
| *"v4.1.3 is already in …"* in step 4 | It's published already – go on with step 5 |
| The rename stops at a step | Everything was put back; send a screenshot of the output |
| *"Not enough free space"* | Free some disk space (it needs about twice the data) and run it again |
