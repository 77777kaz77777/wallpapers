#!/usr/bin/env bash
# setup.sh - set up pve-range GUI: write .env, test the Proxmox token, start it.
#   ./setup.sh          step by step
#   ./setup.sh token    only change the API token
#   ./setup.sh test     only test the API connection
#   ./setup.sh update /path/to/pve-range-gui.zip
#                       install a new version: unpack it here, rebuild, restart (data is kept)
set -u
cd "$(dirname "$0")" || exit 1
ENVF=.env
[[ -f $ENVF ]] || { cp .env.example "$ENVF"; echo "Created $ENVF"; }
chmod 600 "$ENVF"
B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'
[[ -t 1 ]] || B="" G="" R="" Y="" Z=""

getv() { grep -m1 "^$1=" "$ENVF" | cut -d= -f2-; }
setv() {
    local tmp
    tmp=$(mktemp)
    awk -v k="$1" -v v="$2" 'BEGIN {d = 0} index($0, k "=") == 1 {print k "=" v; d = 1; next} {print} END {if (!d) print k "=" v}' "$ENVF" >"$tmp" && cat "$tmp" >"$ENVF"
    rm -f "$tmp"
}
ask() { local a; read -rp "$1 [$2]: " a; echo "${a:-$2}"; }
host_ip() {
    local a
    a=$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)
    [[ -n $a ]] || a=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "${a:-127.0.0.1}"
}
compose() {
    if docker compose version >/dev/null 2>&1; then docker compose "$@"
    elif podman compose version >/dev/null 2>&1; then podman compose "$@"
    else docker-compose "$@"; fi
}
test_api() {   # token urls
    local url out code
    for url in $2; do
        out=$(curl -sk --connect-timeout 5 --max-time 15 -w '\n%{http_code}' -H "Authorization: PVEAPIToken=$1" "${url%/}/api2/json/version" 2>&1)
        code=${out##*$'\n'}
        case $code in
            200) echo "  ${G}OK${Z}  $url"; return 0 ;;
            401) echo "  ${R}token refused${Z} by $url" ;;
            000) echo "  ${Y}no answer${Z} from $url (wrong address, or port 8006 blocked)" ;;
            *) echo "  ${R}HTTP $code${Z} from $url" ;;
        esac
    done
    return 1
}
create_token() {
    local node out tid val
    node=$(ask "  Node to create it on (IP)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    echo "  Connecting to root@$node - it may ask for root's password once."
    echo "  ${Y}An existing token 'pverange@pve!gui' is replaced (the old one stops working).${Z}"
    out=$(ssh -o ConnectTimeout=10 "root@$node" '
        pveum user add pverange@pve --comment "pve-range" 2>/dev/null
        pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor || exit 1
        pveum acl modify /sdn/zones --users pverange@pve --roles PVESDNUser || exit 1
        pveum user token remove pverange@pve gui 2>/dev/null
        pveum user token add pverange@pve gui --privsep 0 --output-format json') || { echo "  ${R}Could not create the token.${Z}"; return 1; }
    tid=$(grep -o '"full-tokenid" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    val=$(grep -o '"value" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    [[ -n $tid && -n $val ]] || { echo "  ${R}Unexpected answer:${Z} $out"; return 1; }
    TOKEN="$tid=$val"
    echo "  ${G}Created${Z} $tid"
}
set_token() {
    local c
    echo
    echo "${B}Proxmox API token${Z}"
    echo "  1) Paste a token I already have  (pverange@pve!range=xxxxxxxx-... - the one pve-range-docker uses works too)"
    echo "  2) Create one now on a node over SSH (needs root's password once)"
    echo "  3) Keep the current one"
    read -rp "Choose [1-3]: " c
    TOKEN=""
    case $c in
        1) read -rsp "  Paste the token (hidden): " TOKEN; echo; TOKEN=$(tr -d '[:space:]' <<<"$TOKEN") ;;
        2) create_token || return 1 ;;
        *) return 0 ;;
    esac
    [[ $TOKEN =~ ^[^@!=]+@[^!=]+![^=]+=.+$ ]] || { echo "  ${R}That doesn't look like USER@REALM!NAME=SECRET.${Z}"; return 1; }
    echo "  Testing it ..."
    test_api "$TOKEN" "$(getv PVE_API_URL)" || { read -rp "  It didn't work. Save it anyway? [y/N] " a; [[ $a == [yY]* ]] || return 1; }
    setv PVE_API_TOKEN "$TOKEN"
    chmod 600 "$ENVF"
    echo "  ${G}Saved${Z} (readable by root only)"
}

update() {   # zip
    local zip=${1:-} here parent new
    [[ -f $zip ]] || { echo "Usage: ./setup.sh update /path/to/pve-range-gui.zip"; return 1; }
    here=$(pwd -P); parent=$(dirname "$here")
    command -v unzip >/dev/null || { echo "${R}unzip is missing${Z} - apt-get install -y unzip (or dnf install unzip)"; return 1; }
    unzip -l "$zip" | grep -q ' pve-range-gui/app/server.py$' || { echo "${R}That isn't a pve-range-gui zip.${Z}"; return 1; }
    echo "Running now:   $(grep -m1 '^VERSION' app/server.py | cut -d'"' -f2)"
    echo "Unpacking into $parent ..."
    if [[ $(basename "$here") != pve-range-gui ]]; then
        echo "${R}This folder must be called pve-range-gui.${Z}"; return 1
    fi
    rm -rf "$here/pve-range-gui"   # a copy unpacked one level too deep
    (cd "$parent" && unzip -oq "$zip") || return 1
    new=$(grep -m1 '^VERSION' app/server.py | cut -d'"' -f2)
    echo "New files:     $new"
    compose build --no-cache || return 1
    compose up -d || return 1
    sleep 4
    compose logs --tail 30 pve-range-gui | grep -E 'pve-range GUI|Proxmox API' | tail -2
    echo "${G}Updated to $new.${Z} Reload the page - the version shows next to pve-range at the top left."
}

case ${1:-all} in
    update) update "${2:-}"; exit ;;
    test) test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"; exit $? ;;
    token) set_token && compose up -d; exit ;;
esac

echo "${B}pve-range GUI - setup${Z}  (Enter keeps the value in brackets)"
echo
v=$(ask "Proxmox API address(es), space-separated" "$(getv PVE_API_URL)")
w=""
for u in ${v//,/ }; do
    if [[ $u != *://* ]]; then if [[ $u == *:* ]]; then u="https://$u"; else u="https://$u:8006"; fi; fi
    w+="$u "
done
setv PVE_API_URL "${w% }"
set_token
ip=$(host_ip)
setv KEY_FROM "$(ask "This Docker host's IP" "$(getv KEY_FROM | sed "s/^$/$ip/")")"
port=$(ask "Port for the web page" "$(getv PORT | sed 's/^$/8443/')")
setv PORT "$port"
echo
echo "${B}Check:${Z}"
test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
echo
read -rp "Build and start it now? [Y/n] " a
if [[ $a != [nN]* ]]; then
    compose up -d --build || exit 1
    sleep 3
    compose logs --tail 20 pve-range-gui
    echo
    echo "${B}Open https://$(getv KEY_FROM):$port${Z}"
    echo "The first visit asks you to create the first admin; admins add everyone else from inside."
fi
