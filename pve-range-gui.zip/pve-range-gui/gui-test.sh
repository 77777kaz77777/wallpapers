#!/usr/bin/env bash
# gui-test.sh - test pve-range GUI end to end. Run on the Docker host, in this folder:
#     ./gui-test.sh                 # course 613, with real actions on the fake range
#     ./gui-test.sh NetWars         # another course
#     ./gui-test.sh 613 --check     # only checks - nothing is started, stopped or snapshotted
# Real actions only touch guests tagged "fake-range" (made by range-seed.sh on a node).
# Full output: /tmp/gui-test.out
cd "$(dirname "$0")" || exit 1
COURSE=${1:-613}
ACTIONS=1
[[ ${2:-} == --check ]] && ACTIONS=0
OUT=/tmp/gui-test.out
if docker compose version >/dev/null 2>&1; then DC=(docker compose) ENG=docker
elif podman compose version >/dev/null 2>&1; then DC=(podman compose) ENG=podman
else DC=(docker-compose) ENG=docker; fi
pass=0 fail=0
ok()  { echo "  PASS  $*"; pass=$((pass + 1)); }
bad() { echo "  FAIL  $*"; fail=$((fail + 1)); }

{
echo "=== 0. the container"
st=$($ENG inspect -f '{{.State.Status}}' pve-range-gui 2>/dev/null)
[[ $st == running ]] && ok "pve-range-gui is running" || { bad "pve-range-gui is '${st:-missing}' - start it: ${DC[*]} up -d --build"; exit 1; }
health=$($ENG inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' pve-range-gui 2>/dev/null)
[[ -z $health || $health == healthy || $health == starting ]] && ok "health: ${health:-no check}" || bad "health: $health"
port=$(grep -m1 '^PORT=' .env 2>/dev/null | cut -d= -f2); port=${port:-8443}
hdr=$(curl -sk -m 10 -D - -o /dev/null "https://127.0.0.1:$port/")
grep -q '^HTTP/[0-9.]* 200' <<<"$hdr" && ok "the page answers on https://127.0.0.1:$port" || bad "the page doesn't answer on port $port"
for h in Content-Security-Policy X-Frame-Options X-Content-Type-Options; do
    grep -qi "^$h:" <<<"$hdr" && ok "security header $h is set" || bad "security header $h missing"
done
curl -s -m 5 -o /dev/null "http://127.0.0.1:$port/" && bad "the page also answers without HTTPS" || ok "plain HTTP is not served"
"${DC[@]}" logs pve-range-gui 2>/dev/null | grep -q 'Proxmox API OK' && ok "the start-up log says Proxmox API OK" ||
    bad "no 'Proxmox API OK' in the log - check PVE_API_URL / PVE_API_TOKEN (./setup.sh test)"
echo
"${DC[@]}" exec -T -e GT_COURSE="$COURSE" -e GT_ACTIONS="$ACTIONS" pve-range-gui python3 - <tests/gui-test.py
rc=$?
echo
echo " container checks: $pass passed, $fail failed"
((rc == 0 && fail == 0))
} 2>&1 | tee "$OUT"
exit "${PIPESTATUS[0]}"
