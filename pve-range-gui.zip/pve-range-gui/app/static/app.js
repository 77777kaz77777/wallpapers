"use strict";
/* pve-range GUI - front end. Talks only to its own server (/api/...). */

const S = {
  session: null, courses: [], course: null, data: null, mirrors: null, overview: null,
  selected: new Set(), filter: "", tab: "guests", timer: null,
};
const can = p => S.session && S.session.perms.includes(p);

/* ---------- tiny DOM helper: text is always set as text, never as HTML ---------- */
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") throw new Error("no html");
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat(9)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}
const svg = d => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 20 20"); s.setAttribute("aria-hidden", "true"); const p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", d); s.append(p); return s; };
const ICON_START = "M6 3.5v13l11-6.5z", ICON_END = "M4.5 4.5h11v11h-11z";
const lamp = (state, label) => h("span", { class: "lamp " + state, role: "img", "aria-label": label || state });
const plural = (n, one, many) => n + " " + (n === 1 ? one : (many || one + "s"));

function toast(msg, err) {
  const t = h("div", { class: "toast" + (err ? " err" : "") }, msg);
  document.getElementById("toasts").append(t);
  setTimeout(() => t.remove(), err ? 7000 : 3500);
}

async function api(method, path, body) {
  const r = await fetch(path, {
    method, credentials: "same-origin",
    headers: Object.assign({ "X-PVR": "1" }, body ? { "Content-Type": "application/json" } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let j = {};
  try { j = await r.json(); } catch (e) { /* empty */ }
  if (r.status === 401 && !path.startsWith("/api/login")) { S.session = null; render(); throw new Error(j.error || "Sign in again."); }
  if (!r.ok && !j.need_code) throw new Error(j.error || ("Request failed (" + r.status + ")"));
  return j;
}
const fail = e => toast(e.message || String(e), true);

/* ---------- dialogs ---------- */
function dialog(build) {
  const d = h("dialog");
  document.body.append(d);
  const close = () => { d.close(); d.remove(); };
  d.addEventListener("cancel", e => { if (d.dataset.busy) e.preventDefault(); else setTimeout(() => d.remove(), 0); });
  build(d, close);
  d.showModal();
  const first = d.querySelector("[autofocus]") || d.querySelector("input, select, button.primary");
  if (first) first.focus();
  return d;
}

/* ================================================================== sign-in */
function renderSignin(setup) {
  const err = h("p", { class: "error", role: "alert" });
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true, autofocus: true });
  const pw = h("input", { type: "password", name: "password", autocomplete: setup ? "new-password" : "current-password", required: true });
  const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", pattern: "[0-9 ]{6,7}" });
  const codeField = h("label", { class: "field", hidden: true }, "6-digit code from your authenticator app", code);
  const btn = h("button", { class: "btn primary", type: "submit" }, setup ? "Create admin and sign in" : "Sign in");
  const form = h("form", {
    onsubmit: async e => {
      e.preventDefault(); err.textContent = ""; btn.disabled = true;
      try {
        if (setup) {
          await api("POST", "/api/setup", { user: user.value, password: pw.value });
        } else {
          const r = await api("POST", "/api/login", { user: user.value, password: pw.value, code: code.value });
          if (r.need_code) { codeField.hidden = false; code.focus(); if (r.error) err.textContent = r.error; btn.disabled = false; return; }
        }
        await boot();
      } catch (ex) { err.textContent = ex.message; }
      btn.disabled = false;
    },
  },
    h("div", { class: "mark" }, lamp("running", "online"), h("h1", {}, "pve-range")),
    setup ? h("p", { class: "muted" }, "No users yet. Create the first admin – admins add everyone else from inside.") : null,
    h("label", { class: "field" }, "Name", user),
    h("label", { class: "field" }, "Password", setup ? h("span", { class: "hint" }, "At least 10 characters") : null, pw),
    codeField, err, btn);
  return h("div", { class: "signin" }, form);
}

/* ================================================================== frame */
function rail() {
  const route = location.hash;
  const link = (href, ...kids) => h("a", { href, "aria-current": route === href ? "page" : false }, ...kids);
  const admin = [];
  if (can("users")) admin.push(link("#/users", h("span", { class: "name" }, "Users")));
  if (can("settings")) admin.push(link("#/roles", h("span", { class: "name" }, "Roles")), link("#/map", h("span", { class: "name" }, "Course map")));
  if (can("users")) admin.push(link("#/activity", h("span", { class: "name" }, "Activity")));
  if (can("save")) admin.push(link("#/share", h("span", { class: "name" }, "Save & share")));
  if (can("settings")) admin.push(link("#/settings", h("span", { class: "name" }, "Settings")));
  admin.push(link("#/help", h("span", { class: "name" }, "Help")));
  return h("aside", { class: "rail" },
    h("div", { class: "brand" }, lamp("running", "online"), h("h1", {}, "pve-range"), h("span", { class: "ver" }, S.session.version)),
    h("nav", { "aria-label": "Courses" },
      h("div", { class: "group-label" }, "Courses"),
      S.courses.length ? S.courses.map(c => link("#/course/" + encodeURIComponent(c.name),
        h("span", { class: "name" }, c.name),
        h("span", { class: "count" }, lamp(c.running ? "running" : "", c.running + " running"), c.running + "/" + c.count),
        h("span", { class: "desc" }, c.desc || "\u00a0"))) : h("p", { class: "muted small pad-x" }, "No courses with guests for you."),
      admin.length ? [h("div", { class: "group-label" }, admin.length > 1 ? "Manage" : ""), admin.map(a => { a.classList.add("simple"); return a; })] : null),
    h("div", { class: "me" },
      h("div", { class: "who" }, h("b", {}, S.session.user), h("span", {}, S.session.role)),
      h("button", { class: "btn quiet", type: "button", onclick: accountDialog, title: "Your password and 2FA" }, "Account"),
      h("button", { class: "btn quiet", type: "button", onclick: signOut }, "Sign out")));
}

async function signOut() {
  try { await api("POST", "/api/logout"); } catch (e) { /* ignore */ }
  S.session = null; render();
}

function render() {
  const root = document.getElementById("root");
  clearInterval(S.timer);
  if (!S.session) { root.replaceChildren(renderSignin(S.setup)); return; }
  const r = location.hash.replace(/^#\//, "").split("/");
  let main;
  if (r[0] === "users" && can("users")) main = pageUsers();
  else if (r[0] === "roles" && can("settings")) main = pageRoles();
  else if (r[0] === "map" && can("settings")) main = pageMap();
  else if (r[0] === "activity" && can("users")) main = pageActivity();
  else if (r[0] === "share" && can("save")) main = pageShare();
  else if (r[0] === "settings" && can("settings")) main = pageSettings();
  else if (r[0] === "help") main = pageHelp();
  else {
    const name = decodeURIComponent(r[1] || "");
    const c = S.courses.find(x => x.name === name) || S.courses[0];
    if (c && name !== c.name) { location.replace("#/course/" + encodeURIComponent(c.name)); return; }
    main = c ? pageCourse(c) : h("main", {}, h("p", {}, "There are no guests in any of your courses. Ask an admin to check your courses."));
  }
  root.replaceChildren(h("div", { class: "app" }, rail(), main));
}
window.addEventListener("hashchange", () => { S.selected.clear(); S.data = null; S.mirrors = null; S.overview = null; S.tab = "guests"; render(); });

/* ================================================================== course page */
function pageCourse(c) {
  const main = h("main", { "aria-busy": "true" }, h("p", { class: "muted" }, "Reading the course…"));
  if (!S.data || S.data.course !== c.name) loadCourse(c.name);
  else { fillCourse(main, c); }
  S.timer = setInterval(() => { if (!document.hidden && !document.querySelector("dialog[open]")) loadCourse(c.name, true); }, 10000);
  return main;
}

async function loadCourse(name, quiet) {
  try {
    const [data, courses] = await Promise.all([
      api("GET", "/api/course/" + encodeURIComponent(name) + (quiet ? "" : "?fresh=1")),
      api("GET", "/api/courses"),
    ]);
    S.courses = courses;
    S.data = data;
    if (can("mirror_status") && (!quiet || !S.mirrors)) api("GET", "/api/mirrors?course=" + encodeURIComponent(name)).then(m => { S.mirrors = m; refill(); }).catch(() => {});
    refill();
  } catch (e) { if (!quiet) fail(e); }
}
function refill() {
  const main = document.querySelector("main");
  const c = S.courses.find(x => x.name === (S.data && S.data.course));
  if (!main || !c || /^#\/(users|roles|map|activity|share|settings|help)/.test(location.hash)) return;
  const keepFocus = document.activeElement && document.activeElement.id;
  const rail_ = document.querySelector(".rail");
  if (rail_) rail_.replaceWith(rail());
  fillCourse(main, c);
  if (keepFocus) { const el = document.getElementById(keepFocus); if (el) { el.focus(); if (el.setSelectionRange && el.value) el.setSelectionRange(el.value.length, el.value.length); } }
}

function fillCourse(main, c) {
  const d = S.data, gs = d.guests;
  const running = gs.filter(g => g.status === "running").length;
  main.removeAttribute("aria-busy");
  const kids = [
    h("div", { class: "head" },
      h("div", { class: "title" }, h("h1", {}, c.name), h("div", { class: "sub" }, c.desc || "")),
      h("div", { class: "strip" },
        h("span", {}, h("b", {}, running), "running"),
        h("span", {}, h("b", {}, gs.length - running), "off"),
        h("button", { class: "btn quiet", type: "button", onclick: () => loadCourse(c.name) }, "Refresh"))),
  ];
  const top = [];
  if (can("class_run")) top.push(faceplate(c));
  if (can("mirror_status")) top.push(mirrorPanel(c));
  if (top.length) kids.push(h("div", { class: "cols" + (top.length === 1 ? " one" : "") }, top));
  const tabs = [["guests", "Guests"]];
  if (can("guide_read")) tabs.push(["guide", "Class guide"]);
  if (can("addons_run")) tabs.push(["addons", "Add-ons"]);
  if (can("overview")) tabs.push(["storage", "Storage and disks"]);
  if (tabs.length > 1) kids.push(h("div", { class: "tabs", role: "tablist" }, tabs.map(([k, t]) =>
    h("button", { role: "tab", type: "button", "aria-selected": S.tab === k ? "true" : "false", onclick: () => { S.tab = k; refill(); } }, t))));
  kids.push(S.tab === "storage" ? storagePanel(c) : S.tab === "guide" ? guidePanel(c) : S.tab === "addons" ? addonPanel(c) : guestPanel(c));
  main.replaceChildren(...kids);
}

/* ---------- the class faceplate ---------- */
function snapshotSelect(id) {
  const sel = h("select", { id });
  const list = S.data.snapshots;
  if (!list.length) sel.append(h("option", { value: "" }, "No snapshots in this course"));
  for (const s of list) sel.append(h("option", { value: s.name }, s.name + " (" + plural(s.count, "guest") + (s.ram ? ", " + s.ram + " with memory" : "") + ")"));
  const want = (S.session.settings && S.session.settings.default_snapshot) || "ClassStart";
  const pref = list.find(s => s.name === want) || list[0];
  if (pref) sel.value = pref.name;
  if (S.snap && list.find(s => s.name === S.snap)) sel.value = S.snap;
  sel.addEventListener("change", () => { S.snap = sel.value; });
  return sel;
}
function faceplate(c) {
  const sel = snapshotSelect("snap-pick");
  const none = !S.data.snapshots.length;
  return h("section", { class: "panel" },
    h("header", {}, h("h2", {}, "Class")),
    h("div", { class: "body faceplate" },
      h("div", { class: "snap" }, h("label", { for: "snap-pick" }, "Class snapshot"), sel),
      h("div", { class: "big" },
        h("button", { class: "bigbtn start", type: "button", disabled: none, onclick: () => classDialog(c, "start", sel.value) },
          h("span", { class: "glyph" }, svg(ICON_START)), h("span", { class: "t" }, "Start class"),
          h("span", { class: "d" }, "Restore the snapshot, then power on")),
        h("button", { class: "bigbtn end", type: "button", disabled: none, onclick: () => classDialog(c, "end", sel.value) },
          h("span", { class: "glyph" }, svg(ICON_END)), h("span", { class: "t" }, "End class"),
          h("span", { class: "d" }, "Restore the snapshot, then switch off")))));
}

async function classDialog(c, what, snap) {
  let guide = null;
  if (can("guide_read") && S.session.settings && S.session.settings.show_guide) {
    try { guide = (await api("GET", "/api/guide/" + encodeURIComponent(c.name))).text; } catch (e) { /* no guide */ }
  }
  const gs = S.data.guests;
  const has = g => g.snapshots.some(s => s.name === snap);
  const ram = g => g.snapshots.some(s => s.name === snap && s.ram);
  const rows = gs.map(g => ({ g, restore: h("input", { type: "checkbox", checked: has(g), disabled: !has(g), "aria-label": "Restore " + g.vmid }),
    incl: h("input", { type: "checkbox", checked: true, "aria-label": (what === "start" ? "Start " : "Switch off ") + g.vmid }) }));
  const all = (key, on) => rows.forEach(r => { if (!r[key].disabled) r[key].checked = on; });
  const mode = what === "end" ? [h("input", { type: "radio", name: "mode", value: "shutdown", checked: true }), h("input", { type: "radio", name: "mode", value: "stop" })] : null;
  dialog((d, close) => {
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const restore = rows.filter(r => r.restore.checked).map(r => r.g.vmid);
      const power = rows.filter(r => r.incl.checked).map(r => r.g.vmid);
      const body = { action: what === "start" ? "class_start" : "class_end", course: c.name, snapshot: snap, restore,
        title: (what === "start" ? "Start class " : "End class ") + c.name };
      body[what === "start" ? "start" : "off"] = power;
      if (what === "end") body.mode = mode[1].checked ? "stop" : "shutdown";
      close(); planDialog(body);
    } },
      h("header", {}, h("h2", {}, (what === "start" ? "Start class" : "End class") + " – " + c.name),
        h("p", { class: "muted small" }, "Snapshot " + snap + ". Untick guests to keep as they are, for example Kali or servers.")),
      h("div", { class: "content pick" },
        guide ? h("details", { class: "guidebox", open: true }, h("summary", {}, "Class guide for " + c.name), h("div", { class: "guidetext" }, renderGuide(guide))) : null,
        h("table", {},
          h("thead", {}, h("tr", {},
            h("th", {}, "Guest"), h("th", {}, "Snapshot"),
            h("th", {}, h("label", { class: "check" }, h("input", { type: "checkbox", checked: true, onchange: e => all("restore", e.target.checked), "aria-label": "Restore all" }), "Restore")),
            h("th", {}, h("label", { class: "check" }, h("input", { type: "checkbox", checked: true, onchange: e => all("incl", e.target.checked), "aria-label": "All" }), what === "start" ? "Start" : "Switch off")))),
          h("tbody", {}, rows.map(r => h("tr", {},
            h("td", {}, lamp(r.g.status), " ", h("span", { class: "vmid" }, r.g.vmid), " ", r.g.name),
            h("td", { class: "muted small" }, has(r.g) ? (ram(r.g) ? "has it, with memory" : "has it") : "doesn't have it"),
            h("td", {}, r.restore), h("td", {}, r.incl))))),
        what === "end" ? h("div", {}, h("h3", { class: "gap-top" }, "Guests you keep as they are"),
          h("p", { class: "muted small" }, "Restored guests are switched off at once. For the others:"),
          h("div", { class: "radio-row" },
            h("label", { class: "check" }, mode[0], "Shut down gracefully (forced off after the timeout)"),
            h("label", { class: "check" }, mode[1], "Power off at once"))) : null),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"),
        h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- plan → review → run, live ---------- */
async function planDialog(body) {
  let plan;
  try { plan = await api("POST", "/api/plan", body); } catch (e) { fail(e); return; }
  dialog((d, close) => {
    const content = h("div", { class: "content" });
    const left = h("span", { class: "left" });
    const run = h("button", { class: "btn primary", type: "button", autofocus: true, disabled: !plan.count }, plan.count ? "Run " + plural(plan.count, "step") : "Nothing to do");
    const cancel = h("button", { class: "btn", type: "button", onclick: close }, "Cancel");
    const stage = (g, i, total, live) => h("div", { class: "stage" },
      total > 1 ? h("h3", {}, "Stage " + (i + 1), h("span", { class: "muted" }, g.length > 1 ? plural(g.length, "step") + " at once" : "1 step")) : null,
      h("ul", { class: "steps" }, g.map(s => h("li", { class: live ? s.state : "" },
        lamp(live ? (s.state === "running" ? "running-step" : s.state) : "waiting", live ? s.state : "waiting"),
        h("span", {}, s.label), h("span", { class: "node" }, s.node + (live && s.secs ? " " + s.secs + " s" : "")),
        live && s.msg ? h("span", { class: "msg" }, s.msg) : null,
        live && s.out ? h("pre", { class: "out" }, s.out) : null))));
    const notes = n => n && n.length ? h("ul", { class: "notes" }, n.map(x => h("li", {}, x))) : null;
    content.append(...[notes(plan.notes), ...plan.groups.map((g, i) => stage(g, i, plan.groups.length, false))].filter(Boolean));
    run.addEventListener("click", async () => {
      run.disabled = true; cancel.disabled = true; d.dataset.busy = "1";
      let job;
      try { job = (await api("POST", "/api/plan/" + plan.id + "/run")).job; } catch (e) { fail(e); delete d.dataset.busy; cancel.disabled = false; return; }
      const tick = async () => {
        let j;
        try { j = await api("GET", "/api/job/" + job); } catch (e) { setTimeout(tick, 1500); return; }
        const done = j.state === "done";
        const head = h("div", { class: "result " + (!done ? "busy" : j.failed ? "failed" : "ok") },
          !done ? "Running – " + j.ok + " of " + j.total + " done" :
            j.failed ? j.ok + " succeeded, " + j.failed + " failed. The failed steps show why." : "All " + plural(j.total, "step") + " done in " + j.secs + " s.");
        content.replaceChildren(...[head, notes(j.notes), ...j.groups.map((g, i) => stage(g, i, j.groups.length, true))].filter(Boolean));
        left.textContent = done ? "" : "You can leave this open; it updates by itself.";
        if (!done) { setTimeout(tick, 700); return; }
        delete d.dataset.busy;
        run.replaceWith(h("button", { class: "btn primary", type: "button", onclick: close }, "Close"));
        cancel.remove();
        S.selected.clear();
        if (S.data) loadCourse(S.data.course);
      };
      tick();
    });
    d.append(h("div", { class: "dlg" }, h("header", {}, h("h2", {}, plan.title)), content, h("footer", {}, left, cancel, run)));
  });
}

/* ---------- mirrors ---------- */
function mirrorPanel(c) {
  const ms = S.mirrors;
  const body = h("div", { class: "body" });
  if (!ms) body.append(h("p", { class: "empty" }, "Reading the mirrors…"));
  else if (!ms.length) body.append(h("p", { class: "empty" }, can("mirror_setup") ? "No mirrors set up for this course. Set them up to copy a bridge's traffic to the sensors." : "No mirrors set up for this course."));
  for (const m of ms || []) {
    const live = new Map((m.mirrors || []).map(x => [x.port, x]));
    body.append(h("div", { class: "mirror" },
      h("div", { class: "where" }, m.bridge + " on " + m.node),
      m.error ? h("p", { class: "small error-text" }, m.error) : null,
      h("ul", {}, m.entries.map(e => {
        const on = live.get(e.port);
        return h("li", {}, lamp(on ? "running" : e.status === "running" ? "failed" : "", on ? "mirrored" : "not mirrored"),
          h("span", {}, e.vmid + " " + e.name + " " + e.nic),
          h("span", { class: "pk small" }, on ? on.packets.toLocaleString() + " packets" : e.status !== "running" ? "sensor is off" : "not mirrored"));
      }))));
  }
  return h("section", { class: "panel" },
    h("header", {}, h("h2", {}, "Sensors"),
      can("mirror_setup") ? h("button", { class: "btn quiet", type: "button", onclick: () => mirrorSetup(c) }, "Set up") : null,
      can("mirror_apply") && ms && ms.length ? h("button", { class: "btn", type: "button", onclick: () => planDialog({ action: "mirror_apply", course: c.name, title: "Re-apply mirrors – " + c.name }) }, "Re-apply mirrors") : null),
    body);
}

async function mirrorSetup(c) {
  let r;
  try { r = await api("GET", "/api/nics?course=" + encodeURIComponent(c.name)); } catch (e) { fail(e); return; }
  const pairs = [];
  for (const [node, brs] of Object.entries(r.bridges)) for (const b of brs) pairs.push({ node, bridge: b });
  dialog((d, close) => {
    if (!pairs.length) {
      d.append(h("div", { class: "dlg" }, h("header", {}, h("h2", {}, "Set up mirrors")),
        h("div", { class: "content" }, h("p", {}, "No node has an Open vSwitch bridge. Create one in Proxmox: node, System, Network, Create, OVS Bridge.")),
        h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close }, "Close"))));
      return;
    }
    const where = h("select", {}, pairs.map((p, i) => h("option", { value: i }, p.bridge + " on " + p.node)));
    const list = h("div");
    const existing = S.mirrors || [];
    const draw = () => {
      const p = pairs[where.value];
      const saved = existing.find(m => m.node === p.node && m.bridge === p.bridge);
      const nics = r.nics.filter(n => n.node === p.node && n.bridge === p.bridge);
      list.replaceChildren(nics.length ? h("table", {}, h("tbody", {}, nics.map(n => h("tr", {},
        h("td", {}, h("input", { type: "checkbox", value: n.vmid + ":" + n.nic, checked: saved ? saved.entries.some(e => e.vmid === n.vmid && e.nic === n.nic) : n.sensor, "aria-label": n.vmid + " " + n.nic })),
        h("td", {}, h("span", { class: "vmid" }, n.vmid), " " + n.name), h("td", {}, n.nic),
        h("td", { class: "muted small" }, n.sensor ? "sensor" : "", n.firewall ? " firewall on – it's turned off when mirrors are applied" : ""))))) :
        h("p", { class: "muted" }, "No guest in this course has a NIC on this bridge."));
    };
    where.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: async e => {
      e.preventDefault();
      const p = pairs[where.value];
      const entries = [...list.querySelectorAll("input:checked")].map(i => ({ vmid: +i.value.split(":")[0], nic: i.value.split(":")[1] }));
      try { await api("PUT", "/api/mirrors", { node: p.node, bridge: p.bridge, entries }); toast(entries.length ? "Mirrors saved. Re-apply them to start copying traffic." : "Mirrors removed."); close(); S.mirrors = null; loadCourse(c.name); } catch (ex) { fail(ex); }
    } },
      h("header", {}, h("h2", {}, "Set up mirrors – " + c.name), h("p", { class: "muted small" }, "Pick the bridge, then the sensor NICs that should receive its traffic. Sensors are ticked for you.")),
      h("div", { class: "content" }, h("label", { class: "field" }, "Bridge", where), list),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save mirrors"))));
  });
}

/* ---------- guests ---------- */
function guestPanel(c) {
  const gs = S.data.guests;
  const f = S.filter.toLowerCase();
  const shown = gs.filter(g => !f || (g.vmid + " " + g.name + " " + g.label + " " + g.node + " " + g.tags.join(" ")).toLowerCase().includes(f));
  const sel = [...S.selected].filter(v => gs.some(g => g.vmid === v));
  const selG = gs.filter(g => S.selected.has(g.vmid));
  const pick = (v, on) => { if (on) S.selected.add(v); else S.selected.delete(v); refill(); };
  const allBox = h("input", { type: "checkbox", "aria-label": "Select all shown", checked: shown.length && shown.every(g => S.selected.has(g.vmid)),
    onchange: e => { shown.forEach(g => e.target.checked ? S.selected.add(g.vmid) : S.selected.delete(g.vmid)); refill(); } });
  const snapsOk = can("snap_take") || can("snap_restore") || can("snap_delete");
  const hint = can("power") && snapsOk ? "Select guests for power and snapshots" : can("power") ? "Select guests to power on or off" : snapsOk ? "Select guests for snapshots" : "";
  const tools = [h("span", { class: "sel" }, sel.length ? plural(sel.length, "guest") + " selected" : hint)];
  if (can("power")) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => planDialog({ action: "power_on", course: c.name, ids: sel, title: "Power on – " + plural(sel.length, "guest") }) }, "Power on"),
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => powerOffDialog(c, sel) }, "Power off"));
  if (snapsOk) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => snapDialog(c, selG) }, "Snapshots…"));
  if (can("network") || can("disks") || can("migrate")) tools.push(
    h("button", { class: "btn", type: "button", disabled: !sel.length, onclick: () => buildDialog(c, selG) }, "Build…"));
  if (can("addons_run")) tools.push(
    h("button", { class: "btn", type: "button", onclick: () => { S.tab = "addons"; refill(); } }, "Add-ons…"));
  tools.push(h("button", { class: "btn quiet", type: "button", onclick: () => selectDialog(c) }, "Select…"));
  tools.push(h("input", { type: "search", id: "guest-filter", class: "grow", placeholder: "Filter: name, VMID, tag, node", "aria-label": "Filter guests", value: S.filter,
    oninput: e => { S.filter = e.target.value; refill(); } }));
  const groups = new Map();
  for (const g of shown) { if (!groups.has(g.group)) groups.set(g.group, []); groups.get(g.group).push(g); }
  const body = h("tbody");
  for (const [name, list] of groups) {
    const on = list.filter(g => g.status === "running").length;
    body.append(h("tr", { class: "grp" }, h("td", { colspan: 7 }, name, h("span", { class: "muted" }, on + " of " + list.length + " running"))));
    for (const g of list) {
      const box = h("input", { type: "checkbox", checked: S.selected.has(g.vmid), "aria-label": "Select " + g.vmid, onchange: e => pick(g.vmid, e.target.checked) });
      body.append(h("tr", { class: "g" + (S.selected.has(g.vmid) ? " on" : "") },
        h("td", { class: "chk" }, box),
        h("td", { class: "lampcell" }, lamp(g.status, g.status)),
        h("td", { class: "vmid num" }, g.vmid),
        h("td", {}, g.name, h("div", { class: "muted small" }, g.label)),
        h("td", { class: "kind" }, g.type === "lxc" ? "Container" : "VM"),
        h("td", {}, g.node),
        h("td", {}, h("div", { class: "chips" }, g.snapshots.map(s => h("span", { class: "chip" + (s.ram ? " mem" : ""), title: s.ram ? "with memory" : "" }, s.name + (s.ram ? " + memory" : "")))))));
    }
  }
  if (!shown.length) body.append(h("tr", {}, h("td", { colspan: 7, class: "muted" }, f ? "Nothing matches the filter." : "No guests.")));
  return h("section", { class: "panel" },
    h("div", { class: "toolbar" }, tools),
    h("div", { class: "tablewrap" }, h("table", {},
      h("thead", {}, h("tr", {}, h("th", { class: "chk" }, allBox), h("th", {}, h("span", { class: "sr" }, "")), h("th", { class: "num" }, "VMID"), h("th", {}, "Name"), h("th", {}, "Type"), h("th", {}, "Node"), h("th", {}, "Snapshots"))),
      body)));
}

function powerOffDialog(c, ids) {
  dialog((d, close) => {
    const a = h("input", { type: "radio", name: "m", checked: true }), b = h("input", { type: "radio", name: "m" });
    d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); planDialog({ action: "power_off", course: c.name, ids, mode: b.checked ? "stop" : "shutdown", title: "Power off – " + plural(ids.length, "guest") }); } },
      h("header", {}, h("h2", {}, "Power off " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("div", { class: "radio-row stacked" },
        h("label", { class: "check" }, a, "Shut down gracefully – forced off if the guest doesn't react"),
        h("label", { class: "check" }, b, "Power off at once, like pulling the plug"))),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

function snapDialog(c, gs) {
  const ids = gs.map(g => g.vmid);
  const names = [...new Set(gs.flatMap(g => g.snapshots.map(s => s.name)))].sort();
  dialog((d, close) => {
    const opts = [];
    if (can("snap_take")) opts.push(["take", "Take a new snapshot"]);
    if (can("snap_restore") && names.length) opts.push(["restore", "Restore a snapshot"]);
    if (can("snap_delete") && names.length) opts.push(["delete", "Delete a snapshot"]);
    const what = h("select", {}, opts.map(([v, t]) => h("option", { value: v }, t)));
    const name = h("input", { type: "text", value: "T" + new Date().toISOString().slice(5, 10).replace("-", ""), pattern: "[A-Za-z][A-Za-z0-9_-]{0,39}" });
    const pick = h("select", {}, names.map(n => h("option", { value: n }, n + " (" + gs.filter(g => g.snapshots.some(s => s.name === n)).length + " of " + gs.length + ")")));
    const mem = h("input", { type: "checkbox" });
    const repl = h("input", { type: "checkbox" });
    const afterLeave = h("input", { type: "radio", name: "after", checked: true }), afterStart = h("input", { type: "radio", name: "after" }), afterOff = h("input", { type: "radio", name: "after" });
    const whenRun = h("input", { type: "radio", name: "when", checked: true }), whenFirst = h("input", { type: "radio", name: "when" }), whenAfter = h("input", { type: "radio", name: "when" });
    const fields = h("div");
    const draw = () => fields.replaceChildren(what.value === "take"
      ? [h("label", { class: "field" }, "Name", h("span", { class: "hint" }, "Starts with a letter; letters, digits, - and _"), name),
         h("div", { class: "field" }, h("span", {}, "Running guests"), h("div", { class: "radio-row stacked" },
           h("label", { class: "check" }, whenRun, "Leave them running"),
           h("label", { class: "check" }, whenFirst, "Shut them down first – cleanest disks, they stay off"),
           h("label", { class: "check" }, whenAfter, "Shut them down after the snapshot"))),
         h("label", { class: "check" }, mem, "Include the memory of running VMs (they come back running when restored)"),
         h("label", { class: "check gap-top" }, repl, "Replace a snapshot with the same name")]
      : [h("label", { class: "field" }, "Snapshot", pick),
         what.value === "restore" ? h("div", { class: "field" }, h("span", {}, "Afterwards"), h("div", { class: "radio-row stacked" },
           h("label", { class: "check" }, afterLeave, "Leave them as the snapshot left them"),
           h("label", { class: "check" }, afterStart, "Power them on"),
           h("label", { class: "check" }, afterOff, "Make sure they're off"))) : null]);
    what.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => {
      e.preventDefault(); close();
      const w = what.value, snap = w === "take" ? name.value : pick.value;
      planDialog({ action: "snap_" + w, course: c.name, ids, snapshot: snap, ram: mem.checked && !whenFirst.checked, replace: repl.checked,
        after: afterStart.checked ? "start" : afterOff.checked ? "off" : "leave",
        when: whenFirst.checked ? "off_first" : whenAfter.checked ? "off_after" : "running",
        title: (w === "take" ? "Take snapshot " : w === "restore" ? "Restore " : "Delete snapshot ") + snap + " – " + plural(ids.length, "guest") });
    } },
      h("header", {}, h("h2", {}, "Snapshots – " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("label", { class: "field" }, "What", what), fields),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- storage and disks ---------- */
function storagePanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading storages and disks…")));
  const fill = o => {
    p.replaceChildren(
      h("header", {}, h("h2", {}, "Storages")),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Storage", "Type", "Shared", "Disk formats", "Content"].map(x => h("th", {}, x)))),
        h("tbody", {}, o.storages.map(s => h("tr", {}, h("td", {}, s.storage), h("td", {}, s.type), h("td", {}, s.shared ? "yes" : "no"), h("td", {}, s.formats), h("td", { class: "muted small" }, s.content)))))),
      h("header", {}, h("h2", {}, "Disks in " + c.name)),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["VMID", "Guest", "Disk", "Storage", "Format", "Size"].map(x => h("th", {}, x)))),
        h("tbody", {}, o.disks.map(x => h("tr", {}, h("td", { class: "vmid" }, x.vmid), h("td", {}, x.name), h("td", {}, x.disk), h("td", {}, x.storage), h("td", {}, x.format), h("td", {}, x.size)))))));
  };
  if (S.overview && S.overview.course === c.name) fill(S.overview);
  else api("GET", "/api/overview?course=" + encodeURIComponent(c.name)).then(o => { o.course = c.name; S.overview = o; fill(o); }).catch(fail);
  return p;
}

/* ================================================================== admin: users */
function courseChecks(selected) {
  const all = h("input", { type: "checkbox", checked: selected === "*" });
  const boxes = S.courses.map(c => h("input", { type: "checkbox", value: c.name, checked: selected !== "*" && (selected || []).includes(c.name) }));
  const sync = () => boxes.forEach(b => { b.disabled = all.checked; });
  all.addEventListener("change", sync); sync();
  const el = h("div", { class: "radio-row" }, h("label", { class: "check" }, all, "All courses (also new ones)"),
    S.courses.map((c, i) => h("label", { class: "check" }, boxes[i], c.name)));
  el.value = () => all.checked ? "*" : boxes.filter(b => b.checked).map(b => b.value);
  return el;
}
function roleSelect(roles, value) {
  return h("select", {}, Object.keys(roles).concat("admin").map(r => h("option", { value: r, selected: r === value }, r)));
}
function pageUsers() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Users"), h("div", { class: "sub" }, "Who may sign in, their role and their courses."))));
  const panel = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading users…")));
  main.append(panel);
  Promise.all([api("GET", "/api/users"), api("GET", "/api/roles")]).then(([us, rr]) => {
    const roles = rr.roles;
    panel.replaceChildren(
      h("header", {}, h("h2", {}, plural(us.length, "user")), h("button", { class: "btn primary", type: "button", onclick: () => userDialog(null, roles) }, "Add a user")),
      h("div", { class: "tablewrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Name", "Role", "Courses", "2FA", ""].map(x => h("th", {}, x)))),
        h("tbody", {}, us.map(u => h("tr", {},
          h("td", { class: "vmid" }, u.name, u.name === S.session.user ? h("span", { class: "muted small" }, " (you)") : null),
          h("td", {}, u.role), h("td", {}, u.courses === "*" ? "All" : u.courses.join(", ")), h("td", {}, u.twofa ? "on" : "off"),
          h("td", {}, h("div", { class: "actions" },
            h("button", { class: "btn quiet", type: "button", onclick: () => userDialog(u, roles) }, "Change"),
            h("button", { class: "btn quiet", type: "button", onclick: () => newPassword(u.name) }, "New password"),
            h("button", { class: "btn quiet", type: "button", onclick: () => api("POST", "/api/users/" + encodeURIComponent(u.name) + "/unlock").then(() => toast(u.name + " can sign in again.")).catch(fail) }, "Unlock"),
            u.name !== S.session.user ? h("button", { class: "btn danger", type: "button", onclick: () => deleteUser(u.name) }, "Delete") : null))))))));
  }).catch(fail);
  return main;
}
function userDialog(u, roles) {
  dialog((d, close) => {
    const name = h("input", { type: "text", required: true, pattern: "[A-Za-z0-9_.\\-]{1,32}", autofocus: !u });
    const role = roleSelect(roles, u ? u.role : "instructor");
    const courses = courseChecks(u ? u.courses : []);
    const twofa = u && u.twofa ? h("input", { type: "checkbox" }) : null;
    d.append(h("form", { onsubmit: async e => {
      e.preventDefault();
      const c = courses.value();
      if (c !== "*" && !c.length && role.value !== "admin") { toast("Pick at least one course.", true); return; }
      try {
        if (u) {
          const b = { role: role.value, courses: role.value === "admin" ? "*" : c };
          if (twofa && twofa.checked) b.twofa = false;
          await api("PUT", "/api/users/" + encodeURIComponent(u.name), b);
          toast(u.name + " changed."); close();
        } else {
          const r = await api("POST", "/api/users", { name: name.value, role: role.value, courses: role.value === "admin" ? "*" : c });
          close(); showPassword(name.value, r.password, "added");
        }
        render();
      } catch (ex) { fail(ex); }
    } },
      h("header", {}, h("h2", {}, u ? "Change " + u.name : "Add a user")),
      h("div", { class: "content" },
        u ? null : h("label", { class: "field" }, "Name", h("span", { class: "hint" }, "Letters, digits, . _ -"), name),
        h("label", { class: "field" }, "Role", h("span", { class: "hint" }, "What they may do – change roles under Roles"), role),
        h("div", { class: "field" }, h("span", {}, "Courses"), courses),
        twofa ? h("label", { class: "check" }, twofa, "Turn 2FA off (they set it up again from Account)") : null,
        u ? null : h("p", { class: "muted small" }, "A strong password is made for them and shown once.")),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, u ? "Save changes" : "Add user"))));
  });
}
function showPassword(name, pw, what) {
  dialog((d, close) => d.append(h("div", { class: "dlg" },
    h("header", {}, h("h2", {}, name + (what === "added" ? " added" : " has a new password"))),
    h("div", { class: "content" }, h("p", {}, "Give this password to " + name + ". It is shown only now."), h("div", { class: "pw" }, pw)),
    h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close, autofocus: true }, "Done")))));
}
async function newPassword(name) {
  if (!confirm("Make a new password for " + name + "? Their old one stops working.")) return;
  try { const r = await api("POST", "/api/users/" + encodeURIComponent(name) + "/password"); showPassword(name, r.password); } catch (e) { fail(e); }
}
async function deleteUser(name) {
  if (!confirm("Delete " + name + "? They can't sign in any more.")) return;
  try { await api("DELETE", "/api/users/" + encodeURIComponent(name)); toast(name + " deleted."); render(); } catch (e) { fail(e); }
}

/* ================================================================== admin: roles */
function pageRoles() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Roles"), h("div", { class: "sub" }, "What each role may do. Admins may always do everything."))));
  const panel = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading roles…")));
  main.append(panel);
  api("GET", "/api/roles").then(rr => {
    const roles = rr.roles, perms = rr.perms;
    const newRole = () => {
      const n = (prompt("Name of the new role (small letters, digits, - and _):") || "").trim().toLowerCase();
      if (!n) return;
      if (!/^[a-z][a-z0-9_-]{0,23}$/.test(n) || n === "admin" || roles[n]) { toast("Choose another name.", true); return; }
      roles[n] = []; draw();
    };
    const delRole = r => { if (confirm("Delete the role " + r + "?")) { delete roles[r]; draw(); } };
    const toggle = (r, k, on) => { roles[r] = on ? [...new Set([...roles[r], k])] : roles[r].filter(x => x !== k); };
    const names = () => Object.keys(roles);
    const headRow = () => h("tr", {}, h("th", {}, "Permission"), h("th", {}, "admin"),
      names().map(r => h("th", {}, r, " ", h("button", { class: "btn quiet small", type: "button", title: "Delete the role " + r, onclick: () => delRole(r) }, "×"))));
    const permRow = (k, label) => h("tr", {},
      h("td", {}, label),
      h("td", {}, h("input", { type: "checkbox", checked: true, disabled: true, "aria-label": "admin: " + label })),
      names().map(r => h("td", {}, h("input", { type: "checkbox", checked: roles[r].includes(k), "aria-label": r + ": " + label,
        onchange: e => toggle(r, k, e.target.checked) }))));
    const draw = () => panel.replaceChildren(
      h("header", {}, h("h2", {}, plural(names().length + 1, "role")),
        h("button", { class: "btn", type: "button", onclick: newRole }, "New role"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/roles", { roles }).then(() => toast("Roles saved.")).catch(fail) }, "Save roles")),
      h("div", { class: "tablewrap" }, h("table", { class: "matrix" },
        h("thead", {}, headRow()),
        h("tbody", {}, Object.entries(perms).map(([k, label]) => permRow(k, label))))));
    draw();
  }).catch(fail);
  return main;
}

/* ================================================================== admin: course map, activity */
function pageMap() {
  const ta = h("textarea", { "aria-label": "VMID map", spellcheck: "false" });
  api("GET", "/api/vmidmap").then(r => { ta.value = r.text; }).catch(fail);
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Course map"), h("div", { class: "sub" }, "How VMIDs become courses and groups."))),
    h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "VMID map"), h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/vmidmap", { text: ta.value }).then(() => { toast("Course map saved."); S.data = null; boot(); }).catch(fail) }, "Save map")),
      h("div", { class: "body" },
        h("p", { class: "muted small" }, "A VMID is read as AABCDD: AA the course, B the version or module, C the group, DD the number. VMIDs below 100000 are Management. Lines: folder AA NAME description – sub AA C group name – module AA B module name."),
        ta)));
}
function pageActivity() {
  const pre = h("pre", { class: "log" }, "Reading…");
  api("GET", "/api/audit").then(r => { pre.textContent = r.lines.join("\n") || "Nothing yet."; }).catch(fail);
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Activity"), h("div", { class: "sub" }, "Sign-ins and everything that ran, newest first."))),
    h("section", { class: "panel" }, h("div", { class: "body" }, pre)));
}

/* ================================================================== account: password, 2FA */
function accountDialog() {
  dialog((d, close) => {
    const old = h("input", { type: "password", autocomplete: "current-password" }), nw = h("input", { type: "password", autocomplete: "new-password" });
    const twofaBox = h("div");
    const draw2fa = () => {
      if (S.session.twofa) {
        const pw = h("input", { type: "password", autocomplete: "current-password" });
        twofaBox.replaceChildren(h("p", {}, "2FA is on."), h("label", { class: "field" }, "Your password, to turn it off", pw),
          h("button", { class: "btn danger", type: "button", onclick: () => api("POST", "/api/me/2fa-off", { password: pw.value }).then(() => { S.session.twofa = false; toast("2FA is off."); draw2fa(); }).catch(fail) }, "Turn 2FA off"));
      } else {
        twofaBox.replaceChildren(h("p", { class: "muted" }, "Sign-in also asks for a code from an authenticator app."),
          h("button", { class: "btn", type: "button", onclick: async () => {
            try {
              const r = await api("POST", "/api/me/2fa-start");
              const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code" });
              twofaBox.replaceChildren(h("p", {}, "In your authenticator app, add an account by key and enter:"), h("div", { class: "pw" }, r.secret.replace(/(.{4})/g, "$1 ").trim()),
                h("p", { class: "muted small gap-top" }, "Account name: pve-range, time-based."),
                h("label", { class: "field" }, "Then type the 6-digit code it shows", code),
                h("button", { class: "btn primary", type: "button", onclick: () => api("POST", "/api/me/2fa-confirm", { code: code.value }).then(() => { S.session.twofa = true; toast("2FA is on."); draw2fa(); }).catch(fail) }, "Turn 2FA on"));
              code.focus();
            } catch (e) { fail(e); }
          } }, "Set up 2FA"));
      }
    };
    draw2fa();
    const themeNames = [["", "As set by the admin"], ["light", "Light"], ["dark", "Dark"]].concat(Object.keys(S.session.themes || {}).map(n => [n, n]));
    let curTheme = ""; try { curTheme = localStorage.getItem("pvr-theme") || ""; } catch (e) { /* ignore */ }
    const theme = h("select", {}, themeNames.map(([v, t]) => h("option", { value: v, selected: curTheme === v }, t)));
    theme.addEventListener("change", () => { try { localStorage.setItem("pvr-theme", theme.value); } catch (e) { /* private mode */ } applyTheme(); });
    d.append(h("div", { class: "dlg" },
      h("header", {}, h("h2", {}, "Account – " + S.session.user)),
      h("div", { class: "content" },
        h("h3", {}, "Password"),
        h("label", { class: "field" }, "Current password", old), h("label", { class: "field" }, "New password", h("span", { class: "hint" }, "At least 10 characters"), nw),
        h("button", { class: "btn", type: "button", onclick: () => api("POST", "/api/me/password", { old: old.value, new: nw.value }).then(() => { toast("Password changed."); old.value = nw.value = ""; }).catch(fail) }, "Change password"),
        h("h3", { class: "gap-top" }, "Two-factor sign-in"), twofaBox,
        h("h3", { class: "gap-top" }, "Colours"), h("label", { class: "field" }, "Theme on this computer", theme)),
      h("footer", {}, h("button", { class: "btn primary", type: "button", onclick: close }, "Close"))));
  });
}
function applyTheme() {
  let t = "";
  try { t = localStorage.getItem("pvr-theme") || ""; } catch (e) { /* ignore */ }
  if (!t && S.session && S.session.settings) t = S.session.settings.default_theme || "";
  const root = document.documentElement;
  for (const v of ["--canvas", "--panel", "--panel-2", "--ink", "--line", "--line-2", "--action", "--focus"]) root.style.removeProperty(v);
  const custom = S.session && S.session.themes && S.session.themes[t];
  if (custom) {
    root.dataset.theme = custom.dark ? "dark" : "light";
    const mix = (a, b, p) => { const x = parseInt(a.slice(1), 16), y = parseInt(b.slice(1), 16); const c = i => Math.round(((x >> i) & 255) * (1 - p) + ((y >> i) & 255) * p); return "#" + [16, 8, 0].map(i => c(i).toString(16).padStart(2, "0")).join(""); };
    root.style.setProperty("--canvas", custom.canvas); root.style.setProperty("--panel", custom.panel);
    root.style.setProperty("--panel-2", mix(custom.panel, custom.ink, 0.06)); root.style.setProperty("--ink", custom.ink);
    root.style.setProperty("--line", custom.line); root.style.setProperty("--line-2", mix(custom.line, custom.panel, 0.45));
    root.style.setProperty("--action", custom.action); root.style.setProperty("--focus", custom.action);
  } else if (t === "light" || t === "dark") root.dataset.theme = t;
  else delete root.dataset.theme;
}

/* ================================================================== start */
async function boot() {
  applyTheme();
  try {
    const s = await api("GET", "/api/session");
    if (!s.signed_in) { S.session = null; S.setup = s.setup; render(); return; }
    S.session = s;
    applyTheme();
    S.courses = await api("GET", "/api/courses");
    render();
  } catch (e) { document.getElementById("root").replaceChildren(h("div", { class: "signin" }, h("p", {}, "Can't reach pve-range: " + e.message))); }
}
boot();
