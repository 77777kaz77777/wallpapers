"use strict";
/* pve-range GUI - part 2: class guides, add-ons, picking guests, build actions,
   save & share, settings, help. Uses the helpers from app.js. */

/* ---------- files to and from the computer ---------- */
function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type: type || "text/plain" }));
  const a = h("a", { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function pickFile(accept) {
  return new Promise((ok, no) => {
    const i = h("input", { type: "file", accept: accept || "" });
    i.addEventListener("change", () => {
      const f = i.files[0];
      if (!f) return no(new Error("no file"));
      if (f.size > 1000000) return no(new Error("The file is larger than 1 MB."));
      const r = new FileReader();
      r.onload = () => ok({ name: f.name, text: String(r.result) });
      r.onerror = () => no(new Error("Couldn't read the file."));
      r.readAsText(f);
    });
    i.click();
  });
}
function askText(title, label, value, hint) {
  return new Promise(ok => {
    dialog((d, close) => {
      const inp = h("input", { type: "text", value: value || "", autofocus: true });
      d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); ok(inp.value.trim()); } },
        h("header", {}, h("h2", {}, title)),
        h("div", { class: "content" }, h("label", { class: "field" }, label, hint ? h("span", { class: "hint" }, hint) : null, inp)),
        h("footer", {}, h("button", { class: "btn", type: "button", onclick: () => { close(); ok(null); } }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "OK"))));
    });
  });
}

/* ---------- class guide: shown as simple formatted text ---------- */
function renderGuide(text) {
  const out = [];
  let list = null, para = [];
  const flush = () => { if (para.length) { out.push(h("p", {}, para.join(" "))); para = []; } if (list) { out.push(list); list = null; } };
  for (const raw of (text || "").split("\n")) {
    const line = raw.replace(/\s+$/, "");
    let m;
    if (!line.trim()) { flush(); continue; }
    if ((m = line.match(/^(#{1,3})\s+(.*)$/))) { flush(); out.push(h(m[1].length === 1 ? "h2" : "h3", {}, m[2])); continue; }
    if ((m = line.match(/^\s*(?:[-*]|\d+[.)])\s+(.*)$/))) { if (para.length) { out.push(h("p", {}, para.join(" "))); para = []; } if (!list) list = h(/^\s*\d/.test(line) ? "ol" : "ul"); list.append(h("li", {}, m[1])); continue; }
    if (list) { out.push(list); list = null; }
    para.push(line.trim());
  }
  flush();
  return out;
}
function guidePanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading the class guide…")));
  const show = text => {
    const edit = can("guide_edit");
    const head = h("header", {}, h("h2", {}, "Class guide – " + c.name),
      text != null ? h("button", { class: "btn quiet", type: "button", onclick: () => download(c.name + ".md", text) }, "Download") : null,
      edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { try { const f = await pickFile(".md,.txt,text/*"); await save(f.text); } catch (e) { if (e.message !== "no file") fail(e); } } }, "Upload") : null,
      edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { const u = await askText("Import a class guide", "Web address", "", "A raw file on GitHub or Gitea – a normal page address works too"); if (u) save(null, u); } }, "Import") : null,
      edit && text != null ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Delete the class guide for " + c.name + "?")) api("DELETE", "/api/guide/" + encodeURIComponent(c.name)).then(() => show(null)).catch(fail); } }, "Delete") : null,
      edit ? h("button", { class: "btn primary", type: "button", onclick: () => editor(text) }, text != null ? "Edit" : "Write a guide") : null);
    p.replaceChildren(head, h("div", { class: "body guidetext" }, text != null ? renderGuide(text) :
      h("p", { class: "muted" }, edit ? "No class guide yet. Write down how this course is run: the steps, what to keep, which add-ons to use." : "No class guide for this course yet.")));
  };
  const save = async (text, url) => {
    try { const r = await api("PUT", "/api/guide/" + encodeURIComponent(c.name), url ? { url } : { text }); toast("Class guide saved."); show(r.text); } catch (e) { fail(e); }
  };
  const editor = text => dialog((d, close) => {
    const ta = h("textarea", { "aria-label": "Class guide", spellcheck: "true" });
    ta.value = text != null ? text : "# " + c.name + " – how this class is run\n\n## Before class\n- \n\n## Start class\n- Snapshot: ClassStart\n- Keep as they are: \n\n## During class\n- \n\n## End class\n- \n";
    d.append(h("form", { onsubmit: e => { e.preventDefault(); close(); save(ta.value); } },
      h("header", {}, h("h2", {}, "Class guide – " + c.name), h("p", { class: "muted small" }, "# for headings, - for lists. Paste text in here too.")),
      h("div", { class: "content" }, ta),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save guide"))));
  });
  api("GET", "/api/guide/" + encodeURIComponent(c.name)).then(r => show(r.text)).catch(fail);
  return p;
}

/* ---------- add-ons ---------- */
function addonPanel(c) {
  const p = h("section", { class: "panel" }, h("div", { class: "body" }, h("p", { class: "muted" }, "Reading add-ons…")));
  const edit = can("addons_edit");
  const load = () => api("GET", "/api/addons?course=" + encodeURIComponent(c.name)).then(r => {
    const sel = [...S.selected];
    const rows = r.addons.map(a => h("tr", {},
      h("td", {}, h("b", {}, a.name), h("div", { class: "muted small" }, a.desc || a.file)),
      h("td", { class: "small" }, a.scope === "_all" ? "All courses" : a.scope),
      h("td", { class: "small" }, a.guests ? (sel.length ? "on " + plural(sel.length, "selected guest") : "needs selected guests") : "no guests"),
      h("td", {}, h("div", { class: "actions" },
        h("button", { class: "btn", type: "button", disabled: a.guests && !sel.length,
          onclick: () => planDialog({ action: "addon_run", course: c.name, scope: a.scope, file: a.file, ids: a.guests ? sel : [], title: a.name + " – " + c.name }) }, "Run"),
        h("button", { class: "btn quiet", type: "button", onclick: () => api("GET", "/api/addons/" + a.scope + "/" + a.file).then(x => download(a.file, x.text)).catch(fail) }, "Download"),
        edit ? h("button", { class: "btn quiet", type: "button", onclick: () => api("GET", "/api/addons/" + a.scope + "/" + a.file).then(x => editor(a.scope, a.file, x.text)).catch(fail) }, "Edit") : null,
        edit ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Delete the add-on " + a.name + "?")) api("DELETE", "/api/addons/" + a.scope + "/" + a.file).then(load).catch(fail); } }, "Delete") : null))));
    p.replaceChildren(
      h("header", {}, h("h2", {}, "Add-ons – " + c.name),
        edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { try { const f = await pickFile(".sh,text/*"); editor(c.name, f.name.replace(/[^A-Za-z0-9_.-]/g, "-").replace(/(\.sh)?$/, ".sh"), f.text, true); } catch (e) { if (e.message !== "no file") fail(e); } } }, "Upload") : null,
        edit ? h("button", { class: "btn quiet", type: "button", onclick: async () => { const u = await askText("Import an add-on", "Web address of the script", "", "A raw file on GitHub or Gitea"); if (!u) return; const n = (u.split("/").pop() || "addon").replace(/[^A-Za-z0-9_.-]/g, "-").replace(/(\.sh)?$/, ".sh"); api("PUT", "/api/addons/" + encodeURIComponent(c.name) + "/" + n, { url: u }).then(x => editor(c.name, n, x.text)).catch(fail); } }, "Import") : null,
        edit ? h("button", { class: "btn primary", type: "button", onclick: () => editor(c.name, "", r.template, true) }, "New add-on") : null),
      r.addons.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Add-on", "For", "Runs on", ""].map(x => h("th", {}, x)))), h("tbody", {}, rows))) :
        h("div", { class: "body" }, h("p", { class: "muted" }, edit ? "No add-ons yet. An add-on is a script that runs here with the Proxmox API – qm, pct and pvesh work in it." : "No add-ons for this course.")),
      h("div", { class: "body muted small" }, "Select guests on the Guests tab first for add-ons that work on guests."));
  }).catch(fail);
  const editor = (scope, file, text, isNew) => dialog((d, close) => {
    const name = h("input", { type: "text", value: file, pattern: "[A-Za-z0-9_.\\-]{1,61}\\.sh", required: true, readonly: !isNew });
    const where = h("select", {}, h("option", { value: c.name, selected: scope !== "_all" }, "Only " + c.name), h("option", { value: "_all", selected: scope === "_all" }, "All courses"));
    const ta = h("textarea", { "aria-label": "Script", spellcheck: "false" });
    ta.value = text || "";
    d.append(h("form", { onsubmit: async e => {
      e.preventDefault();
      const f = name.value.trim();
      try {
        if (!isNew && where.value !== scope) await api("PUT", "/api/addons/" + scope + "/" + f, { text: ta.value, move_to: where.value });
        else await api("PUT", "/api/addons/" + encodeURIComponent(where.value) + "/" + f, { text: ta.value });
        toast("Add-on saved."); close(); load();
      } catch (ex) { fail(ex); }
    } },
      h("header", {}, h("h2", {}, isNew ? "New add-on" : "Edit " + file),
        h("p", { class: "muted small" }, "The # NAME, # DESC and # GUESTS lines at the top say how it shows in the list. $GUESTS holds the selected VMIDs.")),
      h("div", { class: "content" },
        h("div", { class: "cols" }, h("label", { class: "field" }, "File name", name), h("label", { class: "field" }, "For", where)), ta),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Save add-on"))));
  });
  load();
  return p;
}

/* ---------- picking guests: range, tag, name, node, saved group ---------- */
async function selectDialog(c) {
  let groups = {};
  try { groups = await api("GET", "/api/groups"); } catch (e) { /* none */ }
  const gs = S.data.guests;
  const tags = [...new Set(gs.flatMap(g => g.tags))].sort(), nodes = [...new Set(gs.map(g => g.node))].sort();
  const subs = [...new Set(gs.map(g => g.group))];
  const ranges = text => { const out = new Set(); for (const part of (text || "").split(/[\s,]+/)) { const m = part.match(/^(\d+)(?:-(\d+))?$/); if (m) for (let v = +m[1]; v <= +(m[2] || m[1]) && v - m[1] < 100000; v++) out.add(v); } return out; };
  dialog((d, close) => {
    const how = h("select", {}, [["range", "VMID range"], ["sub", "Group (from the VMID)"], ["tag", "Proxmox tag"], ["name", "Name pattern"], ["node", "Node"], ["saved", "Saved group"], ["running", "Running guests"], ["off", "Guests that are off"], ["all", "Every guest"], ["none", "Nothing (clear)"]]
      .filter(([k]) => k !== "saved" || Object.keys(groups).length).filter(([k]) => k !== "tag" || tags.length).map(([v, t]) => h("option", { value: v }, t)));
    const add = h("input", { type: "checkbox" });
    const val = h("div");
    let input = null;
    const draw = () => {
      const k = how.value;
      input = k === "range" ? h("input", { type: "text", placeholder: "510400-510430, 510500" }) :
        k === "name" ? h("input", { type: "text", placeholder: "ews|ows" }) :
        k === "tag" ? h("select", {}, tags.map(t => h("option", {}, t))) :
        k === "node" ? h("select", {}, nodes.map(t => h("option", {}, t))) :
        k === "sub" ? h("select", {}, subs.map(t => h("option", {}, t))) :
        k === "saved" ? h("select", {}, Object.entries(groups).map(([n, r]) => h("option", { value: r }, n + " (" + r + ")"))) : null;
      val.replaceChildren(input ? h("label", { class: "field" }, "Which", input) : "");
    };
    how.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => {
      e.preventDefault();
      const k = how.value, v = input ? input.value : "";
      let re = null;
      if (k === "name") { try { re = new RegExp(v, "i"); } catch (ex) { toast("That name pattern isn't valid.", true); return; } }
      const r = k === "range" || k === "saved" ? ranges(v) : null;
      const match = g => k === "range" || k === "saved" ? r.has(g.vmid) : k === "name" ? re.test(g.name) : k === "tag" ? g.tags.includes(v) : k === "node" ? g.node === v :
        k === "sub" ? g.group === v : k === "running" ? g.status === "running" : k === "off" ? g.status !== "running" : k === "all";
      if (!add.checked) S.selected.clear();
      if (k !== "none") gs.filter(match).forEach(g => S.selected.add(g.vmid));
      close(); S.tab = "guests"; refill();
      toast(plural(S.selected.size, "guest") + " selected.");
    } },
      h("header", {}, h("h2", {}, "Select guests")),
      h("div", { class: "content" }, h("label", { class: "field" }, "By", how), val, h("label", { class: "check" }, add, "Add to what's already selected")),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Select"))));
  });
}

/* ---------- build: network, disks, migration ---------- */
async function buildDialog(c, gs) {
  const ids = gs.map(g => g.vmid);
  const opts = [];
  if (can("network")) opts.push(["network", "Network settings – bridge, VLAN, firewall, NIC model"]);
  if (can("disks")) opts.push(["disks", "Move / convert disks"]);
  if (can("migrate")) opts.push(["migrate", "Migrate to another node"]);
  let bridges = {}, storages = [];
  try {
    if (can("network")) bridges = await api("GET", "/api/bridges");
    if (can("disks")) storages = await api("GET", "/api/storages");
  } catch (e) { fail(e); }
  dialog((d, close) => {
    const what = h("select", {}, opts.map(([v, t]) => h("option", { value: v }, t)));
    const box = h("div");
    let collect = null;
    const draw = () => {
      if (what.value === "network") {
        const allBr = [...new Set(Object.values(bridges).flat())].sort();
        const nic = h("select", {}, h("option", { value: "all" }, "Every NIC"), [0, 1, 2, 3, 4, 5].map(n => h("option", { value: "net" + n }, "net" + n)));
        const br = h("select", {}, h("option", { value: "" }, "Keep as it is"), allBr.map(b => h("option", {}, b)));
        const vlanKeep = h("input", { type: "checkbox", checked: true }), vlan = h("input", { type: "text", placeholder: "e.g. 20 – empty removes the tag", disabled: true });
        vlanKeep.addEventListener("change", () => { vlan.disabled = vlanKeep.checked; });
        const fw = h("select", {}, [["", "Keep as it is"], ["on", "On"], ["off", "Off"]].map(([v, t]) => h("option", { value: v }, t)));
        const model = h("select", {}, [["", "Keep as it is"], ["virtio", "VirtIO"], ["e1000", "Intel E1000"], ["e1000e", "Intel E1000E"], ["vmxnet3", "VMware vmxnet3"], ["rtl8139", "Realtek RTL8139"]].map(([v, t]) => h("option", { value: v }, t)));
        box.replaceChildren(h("label", { class: "field" }, "NIC", nic), h("label", { class: "field" }, "Bridge", br),
          h("div", { class: "field" }, h("span", {}, "VLAN tag"), h("label", { class: "check" }, vlanKeep, "Keep as it is"), vlan),
          h("label", { class: "field" }, "Proxmox firewall", fw), h("label", { class: "field" }, "NIC model (VMs)", h("span", { class: "hint" }, "The MAC address is kept"), model));
        collect = () => ({ action: "network", nic: nic.value, change: { bridge: br.value || null, vlan: vlanKeep.checked ? null : vlan.value, firewall: fw.value || null, model: model.value || null }, title: "Network settings – " + plural(ids.length, "guest") });
      } else if (what.value === "disks") {
        const st = h("select", {}, storages.map(s => h("option", { value: s.storage }, s.storage + " (" + s.type + (s.raw_only ? ", raw only" : "") + ")")));
        const fmt = h("select", {}, [["keep", "Keep the format"], ["qcow2", "qcow2 – snapshots on directory storage"], ["raw", "raw"]].map(([v, t]) => h("option", { value: v }, t)));
        const del = h("input", { type: "checkbox", checked: true });
        box.replaceChildren(h("label", { class: "field" }, "To storage", st), h("label", { class: "field" }, "Format", h("span", { class: "hint" }, "Storages marked raw only keep raw"), fmt),
          h("label", { class: "check" }, del, "Delete the old disk after a successful move"),
          h("p", { class: "muted small gap-top" }, "Running VMs move live. Containers have to be off."));
        collect = () => ({ action: "disk_move", storage: st.value, format: fmt.value, delete: del.checked, title: "Move disks to " + st.value + " – " + plural(ids.length, "guest") });
      } else {
        const node = h("select", {}, (S.data.nodes || []).map(n => h("option", {}, n)));
        box.replaceChildren(h("label", { class: "field" }, "To node", node), h("p", { class: "muted small" }, "Running VMs move live with their disks; running containers restart on the new node."));
        collect = () => ({ action: "migrate", node: node.value, title: "Migrate to " + node.value + " – " + plural(ids.length, "guest") });
      }
    };
    what.addEventListener("change", draw); draw();
    d.append(h("form", { onsubmit: e => { e.preventDefault(); const b = collect(); b.course = c.name; b.ids = ids; close(); planDialog(b); } },
      h("header", {}, h("h2", {}, "Build – " + plural(ids.length, "guest"))),
      h("div", { class: "content" }, h("label", { class: "field" }, "What", what), box),
      h("footer", {}, h("button", { class: "btn", type: "button", onclick: close }, "Cancel"), h("button", { class: "btn primary", type: "submit" }, "Review the steps"))));
  });
}

/* ---------- save & share ---------- */
function pageShare() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Save & share"),
    h("div", { class: "sub" }, "Add-ons, class guides, roles, the course map, mirrors, groups and themes are saved after every change."))));
  const body = h("div");
  main.append(body);
  const run = async (fn, label) => { try { const r = await fn(); toast(r.report || label); draw(); } catch (e) { fail(e); } };
  const draw = () => api("GET", "/api/git").then(g => {
    const url = h("input", { type: "text", value: g.url, placeholder: "https://gitea.lab/team/pve-range.git" });
    const user = h("input", { type: "text", value: g.user, autocomplete: "off" });
    const tok = h("input", { type: "password", placeholder: g.has_token ? "saved – leave empty to keep it" : "token with write access", autocomplete: "new-password" });
    const branch = h("input", { type: "text", value: g.branch || "main" });
    const insecure = h("input", { type: "checkbox", checked: g.insecure });
    body.replaceChildren(
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "Your repository"), g.url ? h("span", { class: "muted small" }, "connected") : null),
        h("form", { class: "body", onsubmit: e => { e.preventDefault(); run(() => api("PUT", "/api/git/connect", { url: url.value, user: user.value, token: tok.value, branch: branch.value, insecure: insecure.checked })); } },
          h("p", { class: "muted small" }, "Gitea, GitHub or GitLab. Make an empty repository and a token that may write to it, then connect. The connection is tested first – if it fails, nothing changes."),
          h("div", { class: "cols" }, h("label", { class: "field" }, "Repository address", url), h("label", { class: "field" }, "Branch", branch)),
          h("div", { class: "cols" }, h("label", { class: "field" }, "User name", user), h("label", { class: "field" }, "Token", tok)),
          h("label", { class: "check" }, insecure, "Don't check the server's HTTPS certificate (self-signed Gitea in the lab)"),
          g.ssh_key ? h("div", { class: "gap-top" }, h("p", { class: "small" }, "For an SSH address, add this key to the repository as a deploy key with write access:"), h("div", { class: "pw small" }, g.ssh_key)) : null,
          h("div", { class: "actions gap-top" },
            g.url ? h("button", { class: "btn danger", type: "button", onclick: () => { if (confirm("Disconnect the repository? Nothing is deleted.")) run(() => api("PUT", "/api/git/connect", { url: "" })); } }, "Disconnect") : null,
            h("button", { class: "btn primary", type: "submit" }, g.url ? "Save connection" : "Connect and upload")))),
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "History"),
          h("button", { class: "btn", type: "button", onclick: async () => { const m = await askText("Save now", "What changed?", "Saved from the GUI"); if (m) run(() => api("POST", "/api/git/save", { message: m })); } }, "Save now"),
          g.url ? h("button", { class: "btn", type: "button", onclick: () => { if (confirm("Load the add-ons, class guides and settings from the repository? What isn't saved there yet is replaced.")) run(() => api("POST", "/api/git/pull")); } }, "Get latest") : null),
        g.history.length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, g.history.map(x => h("tr", {}, h("td", {}, x.what), h("td", { class: "small" }, x.who), h("td", { class: "muted small" }, x.when)))))) :
          h("div", { class: "body muted" }, "Nothing saved yet.")),
      h("section", { class: "panel" },
        h("header", {}, h("h2", {}, "Backups"), h("button", { class: "btn", type: "button", onclick: () => run(() => api("POST", "/api/git/backup")) }, "Make a backup")),
        g.backups.length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, g.backups.map(b => h("tr", {}, h("td", {}, b.replace(/^backup-(\d{4})(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d).*$/, "$1-$2-$3 $4:$5:$6")),
          h("td", {}, h("div", { class: "actions" },
            h("a", { class: "btn quiet", href: "/api/git/backup/" + b, download: b }, "Download"),
            h("button", { class: "btn quiet", type: "button", onclick: () => { if (confirm("Restore this backup? A backup of the state now is made first.")) run(() => api("POST", "/api/git/restore", { name: b })); } }, "Restore")))))))) :
          h("div", { class: "body muted" }, "No backups yet. One is made after every change; how many are kept is under Settings.")));
  }).catch(fail);
  draw();
  return main;
}

/* ---------- settings: settings, saved groups, colour themes ---------- */
function pageSettings() {
  const main = h("main", { class: "page" }, h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Settings"), h("div", { class: "sub" }, "For everyone who uses pve-range."))));
  const a = h("div"), b = h("div"), t = h("div");
  main.append(a, b, t);
  api("GET", "/api/settings").then(r => {
    const s = r.settings;
    const f = {
      default_snapshot: h("input", { type: "text", value: s.default_snapshot }),
      shutdown_timeout: h("input", { type: "text", inputmode: "numeric", value: s.shutdown_timeout }),
      max_parallel: h("input", { type: "text", inputmode: "numeric", value: s.max_parallel }),
      protected: h("input", { type: "text", value: s.protected, placeholder: "100-105, 9001" }),
      sensor_pattern: h("input", { type: "text", value: s.sensor_pattern }),
      backup_keep: h("input", { type: "text", inputmode: "numeric", value: s.backup_keep }),
      show_guide: h("input", { type: "checkbox", checked: s.show_guide }),
    };
    a.replaceChildren(h("section", { class: "panel" }, h("header", {}, h("h2", {}, "Running classes")),
      h("form", { class: "body", onsubmit: e => { e.preventDefault();
        const v = {}; for (const [k, el] of Object.entries(f)) v[k] = el.type === "checkbox" ? el.checked : el.value;
        api("PUT", "/api/settings", v).then(() => { toast("Settings saved."); S.session.settings.default_snapshot = v.default_snapshot; S.session.settings.show_guide = v.show_guide; }).catch(fail); } },
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Class snapshot", h("span", { class: "hint" }, "Chosen first in the Class panel"), f.default_snapshot),
          h("label", { class: "field" }, "Protected guests", h("span", { class: "hint" }, "Never shown, never touched – e.g. this Docker host"), f.protected)),
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Graceful shutdown timeout (seconds)", h("span", { class: "hint" }, "Then the guest is forced off"), f.shutdown_timeout),
          h("label", { class: "field" }, "Steps at once", h("span", { class: "hint" }, "Starts, stops and restores in parallel"), f.max_parallel)),
        h("div", { class: "cols" },
          h("label", { class: "field" }, "Sensor names", h("span", { class: "hint" }, "Guests with these names (or the tag sensor) are ticked when setting up mirrors"), f.sensor_pattern),
          h("label", { class: "field" }, "Backups to keep", f.backup_keep)),
        h("label", { class: "check" }, f.show_guide, "Show the class guide before Start class and End class"),
        h("div", { class: "actions gap-top" }, h("button", { class: "btn primary", type: "submit" }, "Save settings")))));
  }).catch(fail);
  api("GET", "/api/groups").then(groups => {
    const draw = () => b.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Saved groups"), h("span", { class: "muted small" }, "Pick them under Select… on the Guests tab"),
        h("button", { class: "btn", type: "button", onclick: async () => { const n = await askText("New group", "Name", ""); if (!n) return; const r = await askText("New group", "VMIDs and ranges", "", "e.g. 510400-510430, 510500"); if (!r) return; groups[n] = r; draw(); } }, "New group"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/groups", { groups }).then(() => toast("Groups saved.")).catch(fail) }, "Save groups")),
      Object.keys(groups).length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, Object.entries(groups).map(([n, r]) => h("tr", {}, h("td", {}, h("b", {}, n)), h("td", {}, r),
        h("td", {}, h("div", { class: "actions" }, h("button", { class: "btn danger", type: "button", onclick: () => { delete groups[n]; draw(); } }, "Remove")))))))) :
        h("div", { class: "body muted" }, "No saved groups.")));
    draw();
  }).catch(fail);
  api("GET", "/api/themes").then(themes => {
    const names = { canvas: "Background", panel: "Panels", ink: "Text", line: "Lines", action: "Buttons and links" };
    const draw = () => t.replaceChildren(h("section", { class: "panel" },
      h("header", {}, h("h2", {}, "Colour themes"), h("span", { class: "muted small" }, "Status colours stay the same – they mean something"),
        h("button", { class: "btn", type: "button", onclick: async () => { const n = await askText("New theme", "Name", ""); if (!n) return; themes[n] = { canvas: "#000000", panel: "#111111", ink: "#ffffff", line: "#444444", action: "#5b9be6", dark: true }; draw(); } }, "New theme"),
        h("button", { class: "btn primary", type: "button", onclick: () => api("PUT", "/api/themes", { themes }).then(() => { toast("Themes saved."); S.session.themes = themes; applyTheme(); }).catch(fail) }, "Save themes")),
      Object.keys(themes).length ? h("div", { class: "tablewrap" }, h("table", {},
        h("thead", {}, h("tr", {}, h("th", {}, "Theme"), Object.values(names).map(x => h("th", {}, x)), h("th", {}, "Dark"), h("th", {}, ""))),
        h("tbody", {}, Object.entries(themes).map(([n, c]) => h("tr", {}, h("td", {}, h("b", {}, n)),
          Object.keys(names).map(k => h("td", {}, h("input", { type: "color", value: c[k], "aria-label": n + " " + names[k], oninput: e => { c[k] = e.target.value; } }))),
          h("td", {}, h("input", { type: "checkbox", checked: !!c.dark, "aria-label": n + " is dark", onchange: e => { c.dark = e.target.checked; } })),
          h("td", {}, h("div", { class: "actions" },
            h("button", { class: "btn quiet", type: "button", onclick: () => { S.session.themes = themes; try { localStorage.setItem("pvr-theme", n); } catch (e) { /* ignore */ } applyTheme(); } }, "Try it"),
            h("button", { class: "btn danger", type: "button", onclick: () => { delete themes[n]; draw(); } }, "Remove"))))))) ) :
        h("div", { class: "body muted" }, "No own themes. Light and dark are built in; everyone picks under Account.")));
    draw();
  }).catch(fail);
  return main;
}

/* ---------- help: only what you can use ---------- */
function pageHelp() {
  const items = [
    ["class_run", "Start class", "Restores the class snapshot on the guests you tick, then powers them on – containers first, then VMs. Guests with a memory snapshot come back running by themselves."],
    ["class_run", "End class", "Restores the snapshot and switches everything off. Restored guests go off at once; guests you keep get a graceful shutdown or are powered off."],
    ["power", "Power on / off", "For the selected guests, as they are – nothing is restored."],
    ["snap_take", "Take a snapshot", "Snapshots… on the Guests tab. Leave running guests running, shut them down first (cleanest), or after; optionally with memory."],
    ["snap_restore", "Restore a snapshot", "Snapshots… → Restore. Guests without that snapshot are left alone."],
    ["snap_delete", "Delete a snapshot", "Snapshots… → Delete."],
    ["mirror_status", "Mirror status", "The Sensors panel shows each sensor NIC: green when its mirror runs, with the packets sent; red when the sensor runs but isn't mirrored."],
    ["mirror_apply", "Re-apply mirrors", "Mirrors disappear when a sensor restarts or a node reboots – do this after Start class."],
    ["mirror_setup", "Set up mirrors", "Sensors → Set up: pick the Open vSwitch bridge and the sensor NICs. Untick all to remove the mirrors."],
    ["guide_read", "Class guide", "The Class guide tab: how this course is run."],
    ["guide_edit", "Write the class guide", "Write, upload or import it from a web address."],
    ["addons_run", "Add-ons", "The Add-ons tab: scripts that run with the Proxmox API. Select guests first for add-ons that work on guests; the output shows live."],
    ["addons_edit", "Make add-ons", "New, upload, import, edit, move to all courses. qm, pct and pvesh work in them."],
    ["network", "Network settings", "Build… → bridge, VLAN tag, firewall, NIC model for the selected guests. The MAC address is kept."],
    ["disks", "Move / convert disks", "Build… → another storage, and qcow2 for snapshots on directory storage."],
    ["migrate", "Migrate", "Build… → move guests to another node, running VMs live."],
    ["overview", "Storage and disks", "The tab with storages and every disk of the course."],
    ["save", "Save & share", "Every change is saved; connect Gitea or GitHub to keep a copy there; backups can be restored."],
    ["users", "Users", "Add people, give them a role and their courses; passwords are made for them."],
    ["settings", "Roles and settings", "What each role may do, the course map, protected guests, groups and colour themes."],
  ].filter(([p]) => can(p));
  return h("main", { class: "page" },
    h("div", { class: "head" }, h("div", { class: "title" }, h("h1", {}, "Help"), h("div", { class: "sub" }, "What you can do here, as " + S.session.role + "."))),
    h("section", { class: "panel" }, h("div", { class: "body guidetext" },
      h("p", {}, "Pick a course on the left. Everything you do stays inside that course, and every action shows its steps before anything runs."),
      items.map(([, t, d]) => [h("h3", {}, t), h("p", {}, d)]),
      h("h3", {}, "Selecting guests"), h("p", {}, "Tick them, or use Select… for a VMID range, a group from the VMID, a tag, a name, a node or a saved group."),
      h("h3", {}, "Your account"), h("p", {}, "Account at the bottom left: change your password, turn on a code from an authenticator app, pick light or dark."))));
}
