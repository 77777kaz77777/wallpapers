#!/usr/bin/env python3
"""pve-range GUI - a web console for running Proxmox training ranges.

Talks to Proxmox only through its API (token), plus one optional SSH key that may run
nothing but ovs-vsctl (port mirroring). Python standard library only.
"""
import base64
import concurrent.futures as cf
import hashlib
import hmac
import http.server
import json
import os
import re
import secrets
import ssl
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

VERSION = "2.1"
DATA = os.environ.get("DATA_DIR", "/data")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
PORT = int(os.environ.get("PORT", "8443"))
API_URLS = [u.rstrip("/") for u in os.environ.get("PVE_API_URL", "").replace(",", " ").split() if u]
API_TOKEN = os.environ.get("PVE_API_TOKEN", "")
PARALLEL = int(os.environ.get("MAX_PARALLEL", "8"))
SHUTDOWN_TIMEOUT = int(os.environ.get("SHUTDOWN_TIMEOUT", "180"))
IDLE = int(os.environ.get("SESSION_IDLE", "900"))
OVS_KEY = os.path.join(DATA, "ssh", "ovs_ed25519")

PERMS = {
    "class_run": "Start class / End class",
    "power": "Power on / off",
    "snap_take": "Take snapshots",
    "snap_restore": "Restore snapshots",
    "snap_delete": "Delete snapshots",
    "mirror_status": "See port-mirror status",
    "mirror_apply": "Re-apply port mirrors",
    "mirror_setup": "Set up and remove port mirrors",
    "guide_read": "Read class guides",
    "guide_edit": "Write and edit class guides",
    "addons_run": "Run add-ons",
    "addons_edit": "Create and edit add-ons",
    "overview": "Storage and disks",
    "network": "Change network settings",
    "disks": "Move and convert disks",
    "migrate": "Migrate guests",
    "save": "Save & share (repository, backups)",
    "users": "Manage users",
    "settings": "Roles, course map, groups, themes and settings",
}
DEFAULT_ROLES = {
    "instructor": ["class_run", "power", "mirror_status", "mirror_apply"],
    "viewer": ["overview", "mirror_status", "guide_read"],
}
DEFAULT_MAP = """\
folder 10 Mgmt      Management
folder 11 Office    Office
folder 12 Security  Security
folder 20 Lab       Lab
folder 40 SANS      SANS
folder 50 612       ICS612
folder 51 613       ICS613
folder 52 NetWars   NetWars v5
folder 53 727       ICS727 (draft)
folder 99 Templates Templates
sub 50 0 Mgmt
sub 50 1 Lvl 3 Servers
sub 50 2 Lvl 3 EWS
sub 50 3 Lvl 3 OWS
sub 50 4 iDMZ File Servers
sub 50 5 iDMZ Jump Hosts
sub 50 6 NSM
sub 51 0 Mgmt
sub 51 1 Enterprise Servers
sub 51 2 ICS Servers
sub 51 3 ABB Servers
sub 51 4 Enterprise Clients
sub 51 5 JumpHost Clients
sub 51 6 ICS EWS
sub 51 7 ABB OWS
module 52 0 Mgmt
module 52 1 Grid
module 52 2 Cookie
module 52 3 Injection
sub 52 0 Servers
sub 52 1 Clients L3
sub 52 2 Clients L4
sub 53 0 Mgmt
sub 53 1 Enterprise
sub 53 2 DMZ
sub 53 3 ICS
"""
LOCK = threading.RLock()
COOKIE_FLAGS = "; Secure"   # cleared only when the server runs without a certificate (testing)


# ---------------------------------------------------------------------------- files
def path(name):
    return os.path.join(DATA, name)


def load_json(name, default):
    try:
        with open(path(name)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, value):
    tmp = path(name + ".new")
    with open(tmp, "w") as f:
        json.dump(value, f, indent=2, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path(name))


def audit(user, text):
    line = "%s  %-14s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), user or "-", text)
    with LOCK, open(path("audit.log"), "a") as f:
        f.write(line)


# ---------------------------------------------------------------------------- Proxmox API
class PVEError(Exception):
    pass


class PVE:
    def __init__(self):
        ca = path("pve-root-ca.pem")
        if os.path.exists(ca):
            self.ctx = ssl.create_default_context(cafile=ca)
            self.ctx.check_hostname = False
        else:   # the nodes' own self-signed certificate
            self.ctx = ssl._create_unverified_context()
        self.good = 0

    def call(self, method, api_path, params=None):
        if not API_URLS or not API_TOKEN:
            raise PVEError("PVE_API_URL and PVE_API_TOKEN must be set in .env")
        params = {k: v for k, v in (params or {}).items() if v is not None}
        body = None
        query = ""
        if method == "GET":
            query = ("?" + urllib.parse.urlencode(params)) if params else ""
        else:
            body = urllib.parse.urlencode(params).encode()
        last = None
        order = API_URLS[self.good:] + API_URLS[:self.good]
        for url in order:
            req = urllib.request.Request(url + "/api2/json" + api_path + query, data=body, method=method)
            req.add_header("Authorization", "PVEAPIToken=" + API_TOKEN)
            if body is not None:
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
            try:
                with urllib.request.urlopen(req, timeout=20, context=self.ctx if url.startswith("https") else None) as r:
                    self.good = API_URLS.index(url)
                    return json.load(r).get("data")
            except urllib.error.HTTPError as e:   # Proxmox answered - no point trying another node
                detail = ""
                try:
                    j = json.loads(e.read() or b"{}")
                    detail = "; ".join("%s: %s" % kv for kv in (j.get("errors") or {}).items())
                except ValueError:
                    pass
                raise PVEError("%s %s -> HTTP %s %s%s" % (method, api_path, e.code, e.reason, (" (" + detail + ")") if detail else ""))
            except (urllib.error.URLError, OSError) as e:
                last = e
        raise PVEError("can't reach the Proxmox API (%s): %s" % (" ".join(API_URLS), last))

    def wait(self, upid):
        node = upid.split(":")[1]
        q = urllib.parse.quote(upid, safe="")
        polls = 0
        while True:
            st = self.call("GET", "/nodes/%s/tasks/%s/status" % (node, q))
            if st.get("status") == "stopped":
                break
            polls += 1
            time.sleep(0.25 if polls <= 8 else 1)
        es = st.get("exitstatus") or ""
        if es == "OK" or es.startswith("WARNINGS"):
            return "" if es == "OK" else es
        log = self.call("GET", "/nodes/%s/tasks/%s/log" % (node, q), {"limit": 500}) or []
        tail = " / ".join(x.get("t", "") for x in log[-4:])
        raise PVEError("task failed: %s%s" % (es or "unknown", (" - " + tail) if tail else ""))

    def task(self, method, api_path, params=None):
        r = self.call(method, api_path, params)
        if isinstance(r, str) and r.startswith("UPID:"):
            return self.wait(r)
        return ""


pve = PVE()


# ---------------------------------------------------------------------------- VMID map
def load_map():
    text = ""
    try:
        with open(path("vmid-map.conf")) as f:
            text = f.read()
    except OSError:
        text = DEFAULT_MAP
    m = {"folder": {}, "desc": {}, "sub": {}, "module": {}}
    for line in text.splitlines():
        p = line.split("#", 1)[0].split()
        if len(p) >= 3 and p[0] == "folder" and p[1].isdigit():
            m["folder"][int(p[1])] = p[2]
            m["desc"][int(p[1])] = " ".join(p[3:])
        elif len(p) >= 4 and p[0] in ("sub", "module") and p[1].isdigit() and p[2].isdigit():
            m[p[0]][(int(p[1]), int(p[2]))] = " ".join(p[3:])
    return m, text


def course_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa = vmid // 10000
    return m["folder"].get(aa, "Group-%d" % aa)


def label_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa, b, c, dd = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10, vmid % 100
    name = m["folder"].get(aa, str(aa))
    sub = m["sub"].get((aa, c), "sub %d" % c)
    if any(k[0] == aa for k in m["module"]):
        return "%s %s %s #%02d" % (name, m["module"].get((aa, b), "module %d" % b), sub, dd)
    return "%s v%d %s #%02d" % (name, b, sub, dd)


def group_of(vmid, m):   # the sub-group heading the GUI groups guests under
    if vmid < 100000:
        return "Management"
    aa, b, c = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10
    sub = m["sub"].get((aa, c), "Sub-group %d" % c)
    if any(k[0] == aa for k in m["module"]):
        return "%s - %s" % (m["module"].get((aa, b), "Module %d" % b), sub)
    return sub


# ---------------------------------------------------------------------------- inventory
class Inventory:
    def __init__(self):
        self.lock = threading.Lock()
        self.res_at = 0
        self.guests = {}
        self.nodes = []
        self.snaps = {}       # vmid -> (time, [ {name, ram} ])
        self.cfgs = {}        # vmid -> (time, {config})

    def refresh(self, force=False):
        with self.lock:
            if not force and time.time() - self.res_at < 3:
                return
            res = pve.call("GET", "/cluster/resources")
            m, _ = load_map()
            guests, nodes = {}, []
            prot = protected_ids()
            for r in res:
                if r.get("type") in ("qemu", "lxc") and int(r.get("vmid", 0)) in prot:
                    continue
                if r.get("type") == "node" and r.get("status") == "online":
                    nodes.append(r["node"])
                elif r.get("type") in ("qemu", "lxc") and not r.get("template"):
                    v = int(r["vmid"])
                    guests[v] = {
                        "vmid": v, "type": r["type"], "node": r["node"], "name": r.get("name") or "-",
                        "status": r.get("status", "unknown"),
                        "tags": [t for t in (r.get("tags") or "").replace(",", ";").split(";") if t],
                        "course": course_of(v, m), "label": label_of(v, m), "group": group_of(v, m),
                    }
            # the live state (the cluster overview can lag a few seconds)
            def live(n_t):
                n, t = n_t
                try:
                    return pve.call("GET", "/nodes/%s/%s" % (n, t)) or []
                except PVEError:
                    return []
            with cf.ThreadPoolExecutor(8) as ex:
                for lst in ex.map(live, [(n, t) for n in nodes for t in ("qemu", "lxc")]):
                    for g in lst:
                        v = int(g["vmid"])
                        if v in guests:
                            guests[v]["status"] = g.get("status", guests[v]["status"])
            self.guests, self.nodes, self.res_at = guests, sorted(nodes), time.time()

    def forget(self, ids):
        for v in ids:
            self.snaps.pop(v, None)
            self.cfgs.pop(v, None)
        self.res_at = 0

    def _snap(self, v):
        g = self.guests[v]
        try:
            lst = pve.call("GET", "/nodes/%s/%s/%d/snapshot" % (g["node"], g["type"], v)) or []
        except PVEError:
            lst = []
        out = [{"name": s["name"], "ram": bool(s.get("vmstate")), "time": s.get("snaptime", 0)}
               for s in lst if s.get("name") != "current"]
        out.sort(key=lambda s: s["time"])
        self.snaps[v] = (time.time(), out)

    def snapshots(self, ids, max_age=300):
        need = [v for v in ids if v in self.guests and (v not in self.snaps or time.time() - self.snaps[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(16) as ex:
                list(ex.map(self._snap, need))
        return {v: self.snaps.get(v, (0, []))[1] for v in ids}

    def _cfg(self, v):
        g = self.guests[v]
        try:
            self.cfgs[v] = (time.time(), pve.call("GET", "/nodes/%s/%s/%d/config" % (g["node"], g["type"], v)) or {})
        except PVEError:
            self.cfgs[v] = (time.time(), {})

    def configs(self, ids, max_age=120):
        need = [v for v in ids if v in self.guests and (v not in self.cfgs or time.time() - self.cfgs[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(16) as ex:
                list(ex.map(self._cfg, need))
        return {v: self.cfgs.get(v, (0, {}))[1] for v in ids}

    def course_ids(self, course):
        prot = protected_ids()
        return sorted(v for v, g in self.guests.items() if g["course"] == course and v not in prot)


inv = Inventory()


# ---------------------------------------------------------------------------- users, roles
def roles():
    r = load_json("roles.json", None)
    if not isinstance(r, dict):
        r = {k: list(v) for k, v in DEFAULT_ROLES.items()}
    r.pop("admin", None)
    return r


def perms_of(role):
    if role == "admin":
        return list(PERMS)
    return [p for p in roles().get(role, []) if p in PERMS]


def users():
    u = load_json("users.json", {})
    return u if isinstance(u, dict) else {}


def hash_pw(pw, salt=None, n=310000):
    salt = salt or secrets.token_hex(16)
    return "pbkdf2_sha256$%d$%s$%s" % (n, salt, hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), n).hex())


def check_pw(pw, stored):
    try:
        _, n, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, salt, int(n)).split("$")[3], h)
    except (ValueError, AttributeError):
        return False


def totp(secret, t=None):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    c = int((t or time.time()) // 30)
    d = hmac.new(key, struct.pack(">Q", c), "sha1").digest()
    o = d[-1] & 15
    return "%06d" % ((struct.unpack(">I", d[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_ok(secret, code):
    code = re.sub(r"\s", "", code or "")
    now = time.time()
    return any(hmac.compare_digest(totp(secret, now + 30 * w), code) for w in (-1, 0, 1))


def gen_password():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(14))


def allowed_courses(u):
    c = u.get("courses", "*")
    return None if c == "*" or u.get("role") == "admin" else set(c)


SESSIONS = {}
FAILS = {}


def failed_recently(key):
    now = time.time()
    FAILS[key] = [t for t in FAILS.get(key, []) if now - t < 600]
    return len(FAILS[key]) >= 5


# ---------------------------------------------------------------------------- settings
DEFAULT_SETTINGS = {
    "default_snapshot": "ClassStart",
    "shutdown_timeout": SHUTDOWN_TIMEOUT,
    "max_parallel": PARALLEL,
    "protected": "",
    "sensor_pattern": "dragos|sensor|tenable|zeek|suricata|snort|onion|nsm",
    "show_guide": True,
    "default_theme": "",
    "backup_keep": 30,
    "start_delay": 0,
}


def settings():
    s = dict(DEFAULT_SETTINGS)
    v = load_json("settings.json", {})
    if isinstance(v, dict):
        s.update({k: v[k] for k in DEFAULT_SETTINGS if k in v})
    return s


def parse_ranges(text):
    """'100-105,9001 9100-9110' -> set of VMIDs"""
    out = set()
    for part in re.split(r"[\s,]+", text or ""):
        m = re.match(r"^(\d+)(?:-(\d+))?$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2) or m.group(1))
            if a <= b and b - a <= 100000:
                out.update(range(a, b + 1))
    return out


def protected_ids():
    return parse_ranges(settings()["protected"])


# ---------------------------------------------------------------------------- shared files: class guides, add-ons
SHARE = os.path.join(DATA, "share")
GUIDES = os.path.join(SHARE, "guides")
ADDONS = os.path.join(SHARE, "addons")
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
ADDON_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}\.sh$")


def guide_file(course):
    if not NAME_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(GUIDES, course + ".md")


def read_text(f):
    try:
        with open(f, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def write_text(f, text, mode=0o640):
    os.makedirs(os.path.dirname(f), exist_ok=True)
    tmp = f + ".new"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, f)


def fetch_url(url, limit=1_000_000):
    """Import a guide or add-on from a web address (GitHub / Gitea raw files)."""
    if not re.match(r"^https?://[^\s]+$", url or ""):
        raise ValueError("give a web address starting with https://")
    url = re.sub(r"^(https://github\.com/[^/]+/[^/]+)/blob/", r"\1/raw/", url)   # GitHub page -> raw file
    url = re.sub(r"^(https?://[^/]+/[^/]+/[^/]+)/src/branch/", r"\1/raw/branch/", url)   # Gitea page -> raw file
    req = urllib.request.Request(url, headers={"User-Agent": "pve-range-gui"})
    try:
        with urllib.request.urlopen(req, timeout=20, context=ssl.create_default_context()) as r:
            data = r.read(limit + 1)
    except (urllib.error.URLError, OSError) as e:
        raise ValueError("couldn't download it: %s" % e)
    if len(data) > limit:
        raise ValueError("that file is larger than 1 MB")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("that isn't a text file")


def addon_dir(course):
    if course != "_all" and not NAME_RE.match(course or ""):
        raise ValueError("bad course name")
    return os.path.join(ADDONS, course)


def addon_meta(text, fname):
    meta = {"name": fname[:-3], "desc": "", "guests": False}
    for line in (text or "").splitlines()[:30]:
        m = re.match(r"^#\s*(NAME|DESC|GUESTS):\s*(.*)$", line)
        if m:
            k, v = m.group(1), m.group(2).strip()
            if k == "NAME":
                meta["name"] = v
            elif k == "DESC":
                meta["desc"] = v
            else:
                meta["guests"] = v.lower() in ("yes", "1", "true")
    return meta


def list_addons(course):
    out = []
    for d in ("_all", course):
        p = addon_dir(d)
        try:
            names = sorted(os.listdir(p))
        except OSError:
            continue
        for f in names:
            if ADDON_RE.match(f):
                meta = addon_meta(read_text(os.path.join(p, f)), f)
                meta.update({"file": f, "scope": d})
                out.append(meta)
    return out


ADDON_TEMPLATE = """#!/usr/bin/env bash
# NAME: My add-on
# DESC: What it does, in one line
# GUESTS: yes
#
# Runs inside pve-range GUI with the Proxmox API. You can use:
#   $GUESTS   the VMIDs picked in the GUI (if GUESTS: yes), e.g. "510101 510102"
#   $COURSE   the course in use
#   qm, pct, pvesh   work as on a node, through the API
for id in $GUESTS; do
    echo "== $id"
    qm status "$id" 2>/dev/null || pct status "$id"
done
"""


# ---------------------------------------------------------------------------- Git: history, your repository, backups
REPO = os.path.join(DATA, "repo")
BACKUPS = os.path.join(DATA, "backups")
GIT_LOCK = threading.Lock()
SAVED = ["roles.json", "vmid-map.conf", "settings.json", "mirrors.json", "groups.json", "themes.json"]


def git_conf():
    c = load_json("git.json", {})
    return c if isinstance(c, dict) else {}


def git_env():
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", HOME=DATA)
    tok = path("priv/git-token")
    if os.path.exists(tok):
        ask = path("priv/askpass.sh")
        if not os.path.exists(ask):
            write_text(ask, "#!/bin/sh\ncat '%s'\n" % tok, 0o700)
        env["GIT_ASKPASS"] = ask
    key = path("ssh/git_ed25519")
    env["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=%s%s" % (
        path("ssh/known_hosts"), (" -o IdentitiesOnly=yes -i " + key) if os.path.exists(key) else "")
    return env


def remote_url(c):
    url, user = c.get("url", ""), c.get("user", "")
    if user and re.match(r"^https?://", url) and "@" not in url.split("/")[2]:
        url = re.sub(r"^(https?://)", r"\1%s@" % urllib.parse.quote(user, safe=""), url)
    return url


def git(*args, check=True, cwd=REPO, timeout=60):
    c = git_conf()
    pre = ["git", "-c", "user.name=pve-range-gui", "-c", "user.email=pve-range@localhost", "-c", "init.defaultBranch=main"]
    if c.get("insecure"):
        pre += ["-c", "http.sslVerify=false"]
    p = subprocess.run(pre + list(args), cwd=cwd, env=git_env(), capture_output=True, text=True, timeout=timeout)
    if check and p.returncode:
        raise PVEError((p.stderr or p.stdout).strip().splitlines()[-1] if (p.stderr or p.stdout).strip() else "git failed")
    return p.stdout


def export_tree(dest):
    """Copy what is shared (no users, no secrets) into dest."""
    import shutil
    for sub in ("addons", "guides"):
        shutil.rmtree(os.path.join(dest, sub), ignore_errors=True)
        src = os.path.join(SHARE, sub)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dest, sub))
    os.makedirs(os.path.join(dest, "settings"), exist_ok=True)
    for f in SAVED:
        s = path(f)
        t = os.path.join(dest, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, t)
        elif os.path.exists(t):
            os.remove(t)
    readme = os.path.join(dest, "README.md")
    if not os.path.exists(readme):
        write_text(readme, "# pve-range\n\nAdd-ons, class guides and settings of pve-range GUI.\n\n"
                   "- `addons/_all/` add-ons for every course, `addons/<course>/` for one course\n"
                   "- `guides/<course>.md` how each course is run\n- `settings/` roles, course map, mirrors, groups, themes\n")


def import_tree(src):
    import shutil
    for sub in ("addons", "guides"):
        s = os.path.join(src, sub)
        if os.path.isdir(s):
            shutil.rmtree(os.path.join(SHARE, sub), ignore_errors=True)
            shutil.copytree(s, os.path.join(SHARE, sub))
    for f in SAVED:
        s = os.path.join(src, "settings", f)
        if os.path.exists(s):
            shutil.copy2(s, path(f))
    inv.forget(list(inv.guests))


def repo_init():
    if not os.path.isdir(os.path.join(REPO, ".git")):
        os.makedirs(REPO, exist_ok=True)
        git("init", "-q")
    c = git_conf()
    url = remote_url(c)
    have = git("remote", check=False).split()
    if url and "origin" not in have:
        git("remote", "add", "origin", url)
    elif url:
        git("remote", "set-url", "origin", url)
    elif "origin" in have:
        git("remote", "remove", "origin")


def repo_save(who, msg):
    """Commit the shared files; push to your repository if one is connected. Returns a short report."""
    with GIT_LOCK:
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        changed = bool(git("status", "--porcelain").strip())
        if changed:
            git("commit", "-q", "-m", msg, "--author", "%s <%s@pve-range>" % (who, who))
        c = git_conf()
        if not c.get("url"):
            return "Saved in the history." if changed else "Nothing new to save."
        br = c.get("branch") or "main"
        if git("ls-remote", "--heads", "origin", br, check=False).strip():
            git("fetch", "-q", "origin", br)
            if git("merge-base", "HEAD", "origin/" + br, check=False).strip() == "":
                git("merge", "-q", "--allow-unrelated-histories", "-X", "ours", "-m", "Join with the repository", "origin/" + br)
            else:
                git("merge", "-q", "-X", "ours", "-m", "Join with the repository", "origin/" + br, check=False)
        git("push", "-q", "origin", "HEAD:" + br, timeout=120)
        return "Saved and uploaded to %s (%s)." % (c["url"], br)


def repo_pull(who):
    with GIT_LOCK:
        c = git_conf()
        if not c.get("url"):
            raise ValueError("connect a repository first")
        repo_init()
        export_tree(REPO)
        git("add", "-A")
        if git("status", "--porcelain").strip():
            git("commit", "-q", "-m", "Before getting the latest", "--author", "%s <%s@pve-range>" % (who, who))
        br = c.get("branch") or "main"
        git("fetch", "-q", "origin", br)
        if git("rev-parse", "--verify", "-q", "HEAD", check=False).strip():
            git("merge", "-q", "--allow-unrelated-histories", "-X", "theirs", "-m", "Latest from the repository", "origin/" + br)
        else:
            git("reset", "-q", "--hard", "origin/" + br)
        import_tree(REPO)
        return "Loaded the latest from %s (%s)." % (c["url"], br)


AUTOSAVE = {"t": None}


def autosave(who, msg):
    """Every change is saved (and uploaded) a moment later, in the background."""
    def go():
        try:
            r = repo_save(who, msg)
            if git_conf().get("url"):
                audit(who, "auto-save: " + r)
        except Exception as e:   # noqa
            audit(who, "auto-save FAILED: %s" % e)
        try:
            if settings().get("backup_keep", 0):
                make_backup(auto=True)
        except Exception:   # noqa
            pass
    t = AUTOSAVE.get("t")
    if t:
        t.cancel()
    AUTOSAVE["t"] = threading.Timer(3, go)
    AUTOSAVE["t"].daemon = True
    AUTOSAVE["t"].start()


def make_backup(auto=False):
    import shutil
    import tarfile
    import tempfile
    os.makedirs(BACKUPS, exist_ok=True)
    name = "backup-%s.tar.gz" % time.strftime("%Y%m%d-%H%M%S")
    with tempfile.TemporaryDirectory() as tmp:
        export_tree(tmp)
        with tarfile.open(os.path.join(BACKUPS, name), "w:gz") as t:
            for x in os.listdir(tmp):
                t.add(os.path.join(tmp, x), arcname=x)
        del shutil
    keep = int(settings().get("backup_keep") or 30)
    files = sorted(f for f in os.listdir(BACKUPS) if f.startswith("backup-"))
    for f in files[:-keep]:
        os.remove(os.path.join(BACKUPS, f))
    return name


def restore_backup(name):
    import tarfile
    import tempfile
    if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", name or ""):
        raise ValueError("bad backup name")
    f = os.path.join(BACKUPS, name)
    if not os.path.exists(f):
        raise KeyError("no such backup")
    with tempfile.TemporaryDirectory() as tmp, tarfile.open(f) as t:
        for m in t.getmembers():
            if m.name.startswith("/") or ".." in m.name.split("/") or not (m.isfile() or m.isdir()):
                raise ValueError("unsafe backup file")
        t.extractall(tmp)
        import_tree(tmp)


# ---------------------------------------------------------------------------- build actions: network, disks, migration, add-ons
def net_split(val):
    parts = [p for p in val.split(",") if p]
    return parts


def net_change(g, val, ch):
    """Change bridge / VLAN / firewall / model of one NIC line, keeping the MAC and the rest."""
    parts = net_split(val)
    kv = []
    for p in parts:
        k, _, v = p.partition("=")
        kv.append([k, v])
    keys = [k for k, _ in kv]
    def setk(k, v):
        if v is None:
            return
        if k in keys:
            if v == "":
                kv[:] = [x for x in kv if x[0] != k]
                keys.remove(k)
            else:
                kv[keys.index(k)][1] = v
        elif v != "":
            kv.append([k, v])
            keys.append(k)
    setk("bridge", ch.get("bridge") or None)
    if "vlan" in ch and ch["vlan"] is not None:
        setk("tag", str(ch["vlan"]).strip())
    if ch.get("firewall") in ("on", "off"):
        setk("firewall", "1" if ch["firewall"] == "on" else "0")
    if ch.get("model") and g["type"] == "qemu" and kv and re.match(r"^[0-9A-Fa-f:]{17}$", kv[0][1] or ""):
        kv[0][0] = ch["model"]
    return ",".join(k + (("=" + v) if v != "" else "") for k, v in kv)


DISK_RE = re.compile(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$")
RAW_ONLY = ("lvm", "lvmthin", "zfspool", "rbd", "iscsi", "iscsidirect", "zfs")


def storage_types():
    return {x["storage"]: x.get("type", "") for x in pve.call("GET", "/storage") or []}


def run_addon(user, course, f, ids, buf):
    env = dict(os.environ, COURSE=course, PVE_RANGE_FOLDER=course, GUESTS=" ".join(map(str, ids)),
               PVE_RANGE_API="1", PVE_RANGE_GUI="1", PVE_RANGE_USER=user, LC_PVERANGE_USER=user,
               PVE_RANGE_DATA=DATA, PATH="/usr/local/lib/pve-range/api:" + os.environ.get("PATH", ""))
    p = subprocess.Popen(["bash", f], cwd="/tmp", env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    t0 = time.time()
    size = 0
    for line in p.stdout:
        size += len(line)
        if size < 400_000:
            buf.append(line)
        if time.time() - t0 > 1800:
            p.kill()
            buf.append("\n[stopped after 30 minutes]\n")
            break
    rc = p.wait()
    if rc:
        raise PVEError("the add-on ended with exit code %d" % rc)
    return ""


# ---------------------------------------------------------------------------- port mirroring (ovs-vsctl over the restricted key)
def node_ip(node):
    for s in pve.call("GET", "/cluster/status") or []:
        if s.get("type") == "node" and s.get("name") == node:
            return s.get("ip")
    raise PVEError("no IP for node %s" % node)


def ovs(node, *args):
    if not os.path.exists(OVS_KEY):
        raise PVEError("port mirroring isn't set up (no key) - see the README")
    cmd = ["ssh", "-n", "-i", OVS_KEY, "-o", "BatchMode=yes", "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=8",
           "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=accept-new",
           "-o", "UserKnownHostsFile=" + os.path.join(DATA, "ssh", "known_hosts"),
           "root@" + node_ip(node), "ovs-vsctl"] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if p.returncode:
        raise PVEError((p.stderr or p.stdout).strip() or "ovs-vsctl failed")
    return p.stdout


def mirrors():
    m = load_json("mirrors.json", [])
    return m if isinstance(m, list) else []


def nic_dev(g, nic):
    n = nic[3:]
    return ("veth%di%s" if g["type"] == "lxc" else "tap%di%s") % (g["vmid"], n)


def mirror_status(node, bridge):
    """The mirrors on a bridge, each with its output port and packets sent."""
    out = {"node": node, "bridge": bridge, "mirrors": [], "error": ""}
    try:
        on = set(re.findall(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", ovs(node, "get", "bridge", bridge, "mirrors")))
        if on:
            ports = json.loads(ovs(node, "--format=json", "--columns=_uuid,name", "list", "port"))["data"]
            pmap = {r[0][1]: r[1] for r in ports}
            rows = json.loads(ovs(node, "--format=json", "--columns=_uuid,name,output_port,statistics", "list", "mirror"))["data"]
            for r in rows:
                if r[0][1] not in on:
                    continue
                port = pmap.get(r[2][1], "?") if r[2][0] == "uuid" else "-"
                stats = dict(r[3][1]) if r[3][0] == "map" else {}
                out["mirrors"].append({"name": r[1], "port": port, "packets": stats.get("tx_packets", 0)})
    except (PVEError, ValueError, KeyError, IndexError, TypeError, subprocess.TimeoutExpired) as e:
        out["error"] = str(e)
    return out


# ---------------------------------------------------------------------------- plans and jobs
PLANS = {}
JOBS = {}


def step(label, node, fn, vmid=None, buf=None):
    return {"label": label, "node": node, "fn": fn, "vmid": vmid, "buf": buf}


def gpath(g):
    return "/nodes/%s/%s/%d" % (g["node"], g["type"], g["vmid"])


def st_rollback(g, snap):
    return step("Restore %d %s to %s" % (g["vmid"], g["name"], snap), g["node"],
                lambda: pve.task("POST", gpath(g) + "/snapshot/%s/rollback" % urllib.parse.quote(snap, safe="")), g["vmid"])


def st_start(g):
    return step("Start %d %s" % (g["vmid"], g["name"]), g["node"], lambda: pve.task("POST", gpath(g) + "/status/start"), g["vmid"])


def st_stop(g, mode):
    if mode == "stop":
        return step("Power off %d %s (hard)" % (g["vmid"], g["name"]), g["node"],
                    lambda: pve.task("POST", gpath(g) + "/status/stop"), g["vmid"])
    return step("Shut down %d %s" % (g["vmid"], g["name"]), g["node"],
                lambda: pve.task("POST", gpath(g) + "/status/shutdown", {"timeout": int(settings()["shutdown_timeout"]), "forceStop": 1}), g["vmid"])


def start_groups(gs):
    """Containers first, then VMs - all at once, or one by one with a pause (Settings)."""
    delay = int(settings().get("start_delay") or 0)
    cts, vms = ct_first(gs)
    if delay <= 0:
        return [[st_start(g) for g in grp] for grp in (cts, vms) if grp]
    out = []
    for g in cts + vms:
        st = st_start(g)
        fn = st["fn"]
        st["fn"] = (lambda fn=fn: (fn(), time.sleep(delay))[0])
        st["label"] += "  (then %d s pause)" % delay
        out.append([st])
    return out


def ct_first(gs):
    return [g for g in gs if g["type"] == "lxc"], [g for g in gs if g["type"] == "qemu"]


def build_plan(user, body):
    a = body.get("action")
    course = body.get("course")
    u = users().get(user, {})
    allow = allowed_courses(u)
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh()
    in_course = set(inv.course_ids(course))
    pick = lambda key: [int(x) for x in body.get(key, []) if int(x) in in_course]
    ids = pick("ids")
    G = inv.guests
    groups, notes = [], []
    need = {"class_start": "class_run", "class_end": "class_run", "power_on": "power", "power_off": "power",
            "snap_take": "snap_take", "snap_restore": "snap_restore", "snap_delete": "snap_delete",
            "mirror_apply": "mirror_apply", "network": "network", "disk_move": "disks", "migrate": "migrate",
            "addon_run": "addons_run"}.get(a)
    if not need or need not in perms_of(u.get("role")):
        raise PermissionError("your role can't do this")

    snap = (body.get("snapshot") or "").strip()
    if a in ("class_start", "class_end", "snap_restore", "snap_delete", "snap_take"):
        if not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", snap):
            raise ValueError("snapshot names start with a letter: letters, digits, - and _")

    if a in ("class_start", "class_end"):
        # restore = guests to roll back; start / off = guests to power on / switch off
        restore, power = pick("restore"), pick("start" if a == "class_start" else "off")
        ids = sorted(set(restore) | set(power))
        snaps = inv.snapshots(ids)
        has = {v: {s["name"]: s for s in snaps.get(v, [])} for v in ids}
        restore = [v for v in restore if snap in has[v]]
        ram = {v for v in restore if G[v]["type"] == "qemu" and has[v][snap]["ram"]}
        if restore:
            groups.append([st_rollback(G[v], snap) for v in restore])
        if a == "class_start":
            start = []
            for v in power:
                if v in ram:
                    notes.append("%d %s: its snapshot includes memory, so the restore brings it back running" % (v, G[v]["name"]))
                elif v not in restore and G[v]["status"] == "running":
                    notes.append("%d %s is already running" % (v, G[v]["name"]))
                else:
                    start.append(G[v])
            groups.extend(start_groups(start))
        else:
            mode = "stop" if body.get("mode") == "stop" else "shutdown"
            restored_on = [G[v] for v in power if v in ram]
            kept_on = [G[v] for v in power if v not in restore and G[v]["status"] == "running"]
            if restored_on:
                groups.append([st_stop(g, "stop") for g in restored_on])
                notes.append("Guests just restored are switched off at once - their state is the snapshot")
            if kept_on:
                groups.append([st_stop(g, mode) for g in kept_on])
            if restore and len(ram) < len(restore):
                notes.append("A restore to a snapshot without memory already leaves the guest off")
    elif a == "power_on":
        todo = [G[v] for v in ids if G[v]["status"] != "running"]
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d already running" % skipped)
        groups.extend(start_groups(todo))
    elif a == "power_off":
        mode = "stop" if body.get("mode") == "stop" else "shutdown"
        todo = [G[v] for v in ids if G[v]["status"] == "running"]
        if len(todo) < len(ids):
            notes.append("%d already off" % (len(ids) - len(todo)))
        cts, vms = ct_first(todo)
        if vms:
            groups.append([st_stop(g, mode) for g in vms])
        if cts:
            groups.append([st_stop(g, mode) for g in cts])
    elif a == "snap_take":
        ram = bool(body.get("ram"))
        when = body.get("when", "running")   # running | off_first | off_after
        existing = inv.snapshots(ids)
        clash = [v for v in ids if any(s["name"] == snap for s in existing.get(v, []))]
        if clash and not body.get("replace"):
            raise ValueError("%d guest(s) already have a snapshot called %s - tick 'replace' to overwrite it" % (len(clash), snap))
        if clash:
            groups.append([step("Delete the old snapshot %s of %d" % (snap, v), G[v]["node"],
                                (lambda g=G[v]: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))), v) for v in clash])
        on = [G[v] for v in ids if G[v]["status"] == "running"]
        if when == "off_first" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
            notes.append("Running guests are shut down first, so their disks are clean")
            ram = False
        groups.append([step("Snapshot %d %s as %s%s" % (v, G[v]["name"], snap, " with memory" if ram and G[v]["type"] == "qemu" and G[v]["status"] == "running" else ""),
                            G[v]["node"],
                            (lambda g=G[v]: pve.task("POST", gpath(g) + "/snapshot",
                                                     {"snapname": snap, "vmstate": 1 if ram and g["type"] == "qemu" and g["status"] == "running" else None})),
                            v) for v in ids])
        if when == "off_after" and on:
            groups.append([st_stop(g, "shutdown") for g in on])
    elif a == "snap_restore":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if len(todo) < len(ids):
            notes.append("%d guest(s) don't have %s" % (len(ids) - len(todo), snap))
        if todo:
            groups.append([st_rollback(g, snap) for g in todo])
        ram = {g["vmid"] for g in todo if g["type"] == "qemu" and any(x["name"] == snap and x["ram"] for x in snaps.get(g["vmid"], []))}
        after = body.get("after", "leave")   # leave | start | off
        if after == "start":
            groups.extend(start_groups([g for g in todo if g["vmid"] not in ram]))
            if ram:
                notes.append("%d guest(s) come back running by themselves (memory snapshot)" % len(ram))
        elif after == "off" and ram:
            groups.append([st_stop(G[v], "stop") for v in sorted(ram)])
            notes.append("Guests restored with memory come back running - they are switched off afterwards")
        elif after == "leave" and ram:
            notes.append("%d guest(s) come back running (memory snapshot); the others stay off" % len(ram))
    elif a == "snap_delete":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if todo:
            groups.append([step("Delete snapshot %s of %d %s" % (snap, g["vmid"], g["name"]), g["node"],
                                (lambda g=g: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))),
                                g["vmid"]) for g in todo])
    elif a == "mirror_apply":
        for mr in mirrors():
            ents = [e for e in mr.get("entries", []) if e.get("vmid") in in_course or body.get("all_saved")]
            if not ents:
                continue
            node, bridge = mr["node"], mr["bridge"]
            all_ents = [e for e in mr.get("entries", []) if e.get("vmid") in G]
            cfgs = inv.configs([e["vmid"] for e in all_ents], max_age=0)
            fw, ovs_args, names = [], [], []
            for k, e in enumerate(all_ents):
                g = G[e["vmid"]]
                cur = cfgs.get(g["vmid"], {}).get(e["nic"], "")
                if not cur:
                    notes.append("%d has no %s - skipped" % (g["vmid"], e["nic"]))
                    continue
                if g["node"] != node:
                    notes.append("%d is on %s, not %s - skipped" % (g["vmid"], g["node"], node))
                    continue
                if g["status"] != "running":
                    notes.append("%d %s isn't running - its port doesn't exist; start it first" % (g["vmid"], g["name"]))
                if "firewall=1" in cur.split(","):
                    new = ",".join("firewall=0" if p == "firewall=1" else p for p in cur.split(","))
                    fw.append(step("Turn the firewall off on %d %s" % (g["vmid"], e["nic"]), node,
                                   (lambda g=g, nic=e["nic"], new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), g["vmid"]))
                ovs_args += ["--", "--id=@p%d" % k, "get", "port", nic_dev(g, e["nic"]),
                             "--", "--id=@m%d" % k, "create", "mirror", "name=m-%d-%s" % (g["vmid"], e["nic"]),
                             "select-all=true", "output-port=@p%d" % k]
                names.append("@m%d" % k)
            if fw:
                groups.append(fw)
            if names:
                args = ovs_args + ["--", "set", "bridge", bridge, "mirrors=" + ",".join(names)]
                groups.append([step("Mirror %s on %s to %d sensor port(s)" % (bridge, node, len(names)), node,
                                    (lambda node=node, args=args: (time.sleep(1 if fw else 0), ovs(node, *args))[1] and "")),
                               None])
        if not groups and not notes:
            notes.append("No saved mirrors for this course - an admin sets them up under Sensors")
    elif a == "network":
        ch = body.get("change") or {}
        if ch.get("bridge") and not re.match(r"^[A-Za-z0-9_.-]+$", ch["bridge"]):
            raise ValueError("bad bridge name")
        if ch.get("vlan") not in (None, "") and not re.match(r"^\d{1,4}$", str(ch["vlan"])):
            raise ValueError("VLAN tags are numbers 1-4094 (empty = no tag)")
        if ch.get("model") and ch["model"] not in ("virtio", "e1000", "e1000e", "rtl8139", "vmxnet3"):
            raise ValueError("bad NIC model")
        nic = body.get("nic") or "all"
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^net\d+$", k) and (nic == "all" or k == nic):
                    new = net_change(G[v], val, ch)
                    if new != val:
                        todo.append(step("%d %s %s: %s" % (v, G[v]["name"], k, new), G[v]["node"],
                                         (lambda g=G[v], k=k, new=new: pve.task("PUT", gpath(g) + "/config", {k: new})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("Nothing to change - the NICs already look like that")
    elif a == "disk_move":
        target, fmt, delete = body.get("storage", ""), body.get("format", "keep"), bool(body.get("delete", True))
        types = storage_types()
        if target not in types:
            raise ValueError("pick a storage")
        if fmt not in ("keep", "raw", "qcow2", "vmdk"):
            raise ValueError("bad format")
        if fmt in ("qcow2", "vmdk") and types[target] in RAW_ONLY:
            raise ValueError("%s (%s) only holds raw disks" % (target, types[target]))
        cfgs = inv.configs(ids, max_age=0)
        todo = []
        for v in ids:
            g = G[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not DISK_RE.match(k) or "media=cdrom" in val or ":" not in val.split(",")[0]:
                    continue
                if body.get("disk") not in (None, "", "all") and k != body["disk"]:
                    continue
                vol = val.split(",")[0]
                cur_fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                want = cur_fmt if fmt == "keep" or types[target] in RAW_ONLY else fmt
                if types[target] in RAW_ONLY:
                    want = "raw"
                if vol.split(":")[0] == target and want == cur_fmt:
                    continue
                if g["type"] == "lxc":
                    if g["status"] == "running":
                        notes.append("%d %s is a running container - switch it off to move %s" % (v, g["name"], k))
                        continue
                    todo.append(step("Move %d %s %s to %s" % (v, g["name"], k, target), g["node"],
                                     (lambda g=g, k=k: pve.task("POST", gpath(g) + "/move_volume", {"volume": k, "storage": target, "delete": 1 if delete else 0})), v))
                else:
                    todo.append(step("Move %d %s %s to %s as %s" % (v, g["name"], k, target, want), g["node"],
                                     (lambda g=g, k=k, want=want: pve.task("POST", gpath(g) + "/move_disk", {"disk": k, "storage": target, "format": want if types[target] not in RAW_ONLY else None, "delete": 1 if delete else 0})), v))
        if todo:
            groups.append(todo)
        else:
            notes.append("No disk needs moving")
    elif a == "migrate":
        targets = body.get("nodes") or [body.get("node", "")]
        if not targets or any(t not in inv.nodes for t in targets):
            raise ValueError("pick nodes that are online")
        how = body.get("spread", "one")   # one | round | blocks
        plan_to = {}
        if how == "round":
            for k, v in enumerate(ids):
                plan_to[v] = targets[k % len(targets)]
        elif how == "blocks":
            per = -(-len(ids) // len(targets))
            for k, v in enumerate(ids):
                plan_to[v] = targets[min(k // per, len(targets) - 1)]
        else:
            plan_to = {v: targets[0] for v in ids}
        todo = []
        for v in ids:
            g = G[v]
            target = plan_to[v]
            if g["node"] == target:
                continue
            if g["type"] == "qemu":
                prm = {"target": target, "online": 1, "with-local-disks": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (live)" if g["status"] == "running" else "")
            else:
                prm = {"target": target, "restart": 1} if g["status"] == "running" else {"target": target}
                label = "Migrate %d %s to %s%s" % (v, g["name"], target, " (restart)" if g["status"] == "running" else "")
            todo.append(step(label, g["node"], (lambda g=g, prm=prm: pve.task("POST", gpath(g) + "/migrate", prm)), v))
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d already where they should be" % skipped)
        if todo:
            groups.append(todo)
    elif a == "addon_run":
        scope, f = body.get("scope", ""), body.get("file", "")
        if not ADDON_RE.match(f or ""):
            raise ValueError("bad add-on")
        if scope not in ("_all", course):
            raise PermissionError("that add-on isn't for this course")
        full = os.path.join(addon_dir(scope), f)
        if not os.path.exists(full):
            raise KeyError("no such add-on")
        meta = addon_meta(read_text(full), f)
        if meta["guests"] and not ids:
            raise ValueError("this add-on works on guests - select some first")
        buf = []
        groups.append([step("Run %s%s" % (meta["name"], (" on " + plural_n(len(ids), "guest")) if meta["guests"] else ""), "container",
                            (lambda: run_addon(user, course, full, ids if meta["guests"] else [], buf)), None, buf)])
    groups = [g for g in groups if g]
    pid = secrets.token_hex(8)
    PLANS[pid] = {"user": user, "title": body.get("title") or a, "groups": groups, "notes": notes,
                  "action": a, "course": course, "at": time.time()}
    return pid


def plural_n(n, word):
    return "%d %s%s" % (n, word, "" if n == 1 else "s")


def plan_view(pid):
    p = PLANS[pid]
    return {"id": pid, "title": p["title"], "notes": p["notes"],
            "groups": [[{"label": s["label"], "node": s["node"]} for s in g] for g in p["groups"]],
            "count": sum(len(g) for g in p["groups"])}


def run_job(jid):
    j = JOBS[jid]
    touched = set()
    with cf.ThreadPoolExecutor(max(1, int(settings()["max_parallel"]))) as ex:
        for gi, grp in enumerate(j["plan"]["groups"]):
            def one(si, s=None):
                s = grp[si]
                st = j["steps"][gi][si]
                st["state"] = "running"
                t0 = time.time()
                try:
                    msg = s["fn"]() or ""
                    st["state"], st["msg"] = "ok", msg
                except Exception as e:   # noqa - show every failure in the GUI
                    st["state"], st["msg"] = "failed", str(e)
                st["secs"] = round(time.time() - t0, 1)
                if s.get("vmid"):
                    touched.add(s["vmid"])
                audit(j["user"], "%s [%s] %s: %s%s" % (j["plan"]["title"], s["node"], s["label"], st["state"],
                                                       (" - " + st["msg"]) if st["msg"] else ""))
            list(ex.map(one, range(len(grp))))
    inv.forget(touched)
    j["state"] = "done"
    j["ended"] = time.time()


def start_job(user, pid):
    p = PLANS.pop(pid, None)
    if not p or p["user"] != user or time.time() - p["at"] > 900:
        raise ValueError("this plan has expired - make it again")
    jid = secrets.token_hex(8)
    JOBS[jid] = {"user": user, "plan": p, "state": "running", "started": time.time(),
                 "steps": [[{"label": s["label"], "node": s["node"], "state": "waiting", "msg": "", "secs": 0, "buf": s.get("buf")} for s in g] for g in p["groups"]]}
    audit(user, "run: %s (%s, %d step(s))" % (p["title"], p["course"], sum(len(g) for g in p["groups"])))
    threading.Thread(target=run_job, args=(jid,), daemon=True).start()
    return jid


# ---------------------------------------------------------------------------- HTTP
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".woff2": "font/woff2",
        ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".txt": "text/plain"}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "pve-range-gui"
    sys_version = ""

    def log_message(self, *a):
        pass

    # -- helpers
    def send(self, code, obj=None, ctype="application/json", raw=None, headers=None):
        b = raw if raw is not None else json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 1_000_000:
            raise ValueError("request too large")
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            raise ValueError("bad request")

    def client(self):
        return self.client_address[0]

    def session(self):
        c = self.headers.get("Cookie", "")
        m = re.search(r"(?:^|;\s*)pvr=([A-Za-z0-9_-]+)", c)
        if not m:
            return None
        s = SESSIONS.get(m.group(1))
        if not s or time.time() - s["last"] > IDLE:
            SESSIONS.pop(m.group(1), None)
            return None
        u = users().get(s["user"])
        if not u:
            return None
        s["last"] = time.time()
        return {"token": m.group(1), "user": s["user"], "role": u.get("role", "viewer"), "u": u,
                "perms": perms_of(u.get("role", "viewer"))}

    def need(self, s, perm):
        if perm not in s["perms"]:
            raise PermissionError("your role can't do this")

    # -- routing
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        url = urllib.parse.urlparse(self.path)
        p = url.path
        try:
            if method == "GET" and not p.startswith("/api/"):
                return self.static(p)
            if method != "GET" and self.headers.get("X-PVR") != "1":   # only our own page may change things
                return self.send(403, {"error": "missing request header"})
            q = dict(urllib.parse.parse_qsl(url.query))
            if p == "/api/session" and method == "GET":
                return self.api_session()
            if p == "/api/setup" and method == "POST":
                return self.api_setup()
            if p == "/api/login" and method == "POST":
                return self.api_login()
            s = self.session()
            if not s:
                return self.send(401, {"error": "Sign in again - your session ended."})
            if p == "/api/logout" and method == "POST":
                SESSIONS.pop(s["token"], None)
                return self.send(200, {"ok": True}, headers={"Set-Cookie": "pvr=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict" + COOKIE_FLAGS})
            h = getattr(self, "api_" + p[5:].split("/")[0].replace("-", "_"), None)
            if not h:
                return self.send(404, {"error": "not found"})
            return h(s, method, p.split("/")[3:], q)
        except PermissionError as e:
            return self.send(403, {"error": str(e)})
        except (ValueError, KeyError) as e:
            return self.send(400, {"error": str(e).strip("'")})
        except PVEError as e:
            return self.send(502, {"error": str(e)})
        except Exception as e:   # noqa
            traceback.print_exc()
            return self.send(500, {"error": "internal error: %s" % e})

    def static(self, p):
        if p in ("", "/"):
            p = "/index.html"
        f = os.path.normpath(os.path.join(STATIC, p.lstrip("/")))
        if not f.startswith(STATIC) or not os.path.isfile(f):
            f = os.path.join(STATIC, "index.html")
        with open(f, "rb") as fh:
            raw = fh.read()
        return self.send(200, raw=raw, ctype=MIME.get(os.path.splitext(f)[1], "application/octet-stream"))

    # -- sign-in
    def api_session(self):
        s = self.session()
        if not s:
            return self.send(200, {"signed_in": False, "setup": not users(), "version": VERSION})
        return self.send(200, {"signed_in": True, "user": s["user"], "role": s["role"], "perms": s["perms"],
                               "twofa": bool(s["u"].get("totp")), "version": VERSION,
                               "perm_names": PERMS, "settings": {k: settings()[k] for k in ("default_snapshot", "show_guide", "default_theme")},
                               "themes": load_json("themes.json", {})})

    def start_session(self, name):
        tok = secrets.token_urlsafe(32)
        SESSIONS[tok] = {"user": name, "last": time.time()}
        return {"Set-Cookie": "pvr=%s; Path=/; HttpOnly; SameSite=Strict%s" % (tok, COOKIE_FLAGS)}

    def api_setup(self):
        with LOCK:
            if users():
                raise PermissionError("already set up - sign in")
            b = self.body()
            name, pw = (b.get("user") or "").strip(), b.get("password") or ""
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                raise ValueError("user names: letters, digits, . _ -")
            if len(pw) < 10:
                raise ValueError("use at least 10 characters for the password")
            save_json("users.json", {name: {"hash": hash_pw(pw), "role": "admin", "courses": "*", "totp": ""}})
        audit(name, "first admin created")
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    def api_login(self):
        b = self.body()
        name, pw, code = (b.get("user") or "").strip(), b.get("password") or "", b.get("code") or ""
        key = name.lower() + "|" + self.client()
        if failed_recently(key):
            return self.send(429, {"error": "Too many wrong attempts. Wait 10 minutes, or ask an admin to unlock you."})
        u = users().get(name)
        if not u or not check_pw(pw, u.get("hash", "")):
            FAILS.setdefault(key, []).append(time.time())
            audit(name, "sign-in FAILED from %s" % self.client())
            return self.send(401, {"error": "That name and password don't match."})
        if u.get("totp"):
            if not code:
                return self.send(200, {"need_code": True})
            if not totp_ok(u["totp"], code):
                FAILS.setdefault(key, []).append(time.time())
                audit(name, "sign-in FAILED (2FA code) from %s" % self.client())
                return self.send(401, {"error": "That code doesn't match. Check the time on your phone.", "need_code": True})
        FAILS.pop(key, None)
        audit(name, "signed in from %s" % self.client())
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    # -- courses and guests
    def api_courses(self, s, method, parts, q):
        inv.refresh()
        allow = allowed_courses(s["u"])
        m, _ = load_map()
        out = {}
        for g in inv.guests.values():
            c = g["course"]
            if allow is not None and c not in allow:
                continue
            o = out.setdefault(c, {"name": c, "count": 0, "running": 0})
            o["count"] += 1
            o["running"] += g["status"] == "running"
        order = {v: k for k, v in m["folder"].items()}
        for c in out.values():
            aa = order.get(c["name"])
            c["desc"] = m["desc"].get(aa, "VMID below 100000" if c["name"] == "Management" else "")
            c["order"] = -1 if c["name"] == "Management" else (aa if aa is not None else 1000)
        return self.send(200, sorted(out.values(), key=lambda c: (c["order"], c["name"])))

    def api_course(self, s, method, parts, q):
        course = urllib.parse.unquote(parts[0]) if parts else ""
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        inv.refresh(force=q.get("fresh") == "1")
        ids = inv.course_ids(course)
        snaps = inv.snapshots(ids)
        guests = []
        for v in ids:
            g = dict(inv.guests[v])
            g["snapshots"] = snaps.get(v, [])
            guests.append(g)
        summary = {}
        for g in guests:
            for sn in g["snapshots"]:
                o = summary.setdefault(sn["name"], {"name": sn["name"], "count": 0, "ram": 0})
                o["count"] += 1
                o["ram"] += sn["ram"]
        return self.send(200, {"course": course, "guests": guests, "nodes": inv.nodes,
                               "snapshots": sorted(summary.values(), key=lambda x: (-x["count"], x["name"]))})

    # -- plans and jobs
    def api_plan(self, s, method, parts, q):
        if method == "POST" and not parts:
            pid = build_plan(s["user"], self.body())
            return self.send(200, plan_view(pid))
        if method == "POST" and len(parts) == 2 and parts[1] == "run":
            return self.send(200, {"job": start_job(s["user"], parts[0])})
        raise ValueError("bad request")

    def api_job(self, s, method, parts, q):
        j = JOBS.get(parts[0] if parts else "")
        if not j or (j["user"] != s["user"] and s["role"] != "admin"):
            raise KeyError("no such job")
        flat = [st for g in j["steps"] for st in g]
        groups = [[dict({k: v for k, v in st.items() if k != "buf"}, out="".join(st["buf"])[-30000:] if st.get("buf") is not None else None) for st in g] for g in j["steps"]]
        return self.send(200, {"title": j["plan"]["title"], "state": j["state"], "groups": groups,
                               "notes": j["plan"]["notes"],
                               "ok": sum(st["state"] == "ok" for st in flat), "failed": sum(st["state"] == "failed" for st in flat),
                               "total": len(flat), "secs": round((j.get("ended") or time.time()) - j["started"], 1)})

    # -- mirrors
    def api_mirrors(self, s, method, parts, q):
        if method == "GET":
            self.need(s, "mirror_status")
            course = q.get("course", "")
            inv.refresh()
            ids = set(inv.course_ids(course))
            saved = [m for m in mirrors() if any(e.get("vmid") in ids for e in m.get("entries", []))] if course else mirrors()
            with cf.ThreadPoolExecutor(4) as ex:
                live = list(ex.map(lambda m: mirror_status(m["node"], m["bridge"]), saved))
            for m, l in zip(saved, live):
                l["entries"] = [dict(e, name=inv.guests.get(e["vmid"], {}).get("name", "?"),
                                     status=inv.guests.get(e["vmid"], {}).get("status", "missing"),
                                     port=nic_dev(inv.guests[e["vmid"]], e["nic"]) if e["vmid"] in inv.guests else "")
                                for e in m.get("entries", [])]
            return self.send(200, live)
        self.need(s, "mirror_setup")
        b = self.body()   # {node, bridge, entries:[{vmid,nic}]}  (empty entries = remove)
        node, bridge = b.get("node", ""), b.get("bridge", "")
        if not re.match(r"^[A-Za-z0-9_.-]+$", node) or not re.match(r"^[A-Za-z0-9_.-]+$", bridge):
            raise ValueError("pick a node and a bridge")
        ents = [{"vmid": int(e["vmid"]), "nic": e["nic"]} for e in b.get("entries", []) if re.match(r"^net\d+$", e.get("nic", ""))]
        with LOCK:
            ms = [m for m in mirrors() if not (m["node"] == node and m["bridge"] == bridge)]
            if ents:
                ms.append({"node": node, "bridge": bridge, "entries": ents})
            save_json("mirrors.json", ms)
        autosave(s["user"], "Mirrors on %s/%s changed" % (node, bridge))
        if not ents:
            try:
                ovs(node, "clear", "bridge", bridge, "mirrors")
            except PVEError:
                pass
        audit(s["user"], "mirrors on %s/%s: %s" % (node, bridge, ", ".join("%d:%s" % (e["vmid"], e["nic"]) for e in ents) or "removed"))
        return self.send(200, {"ok": True})

    def api_nics(self, s, method, parts, q):   # sensor NICs on OVS bridges, for setting up mirrors
        self.need(s, "mirror_setup")
        course = q.get("course", "")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        bridges = {}
        for n in inv.nodes:
            try:
                bridges[n] = [b["iface"] for b in pve.call("GET", "/nodes/%s/network" % n, {"type": "OVSBridge"}) or []]
            except PVEError:
                bridges[n] = []
        out = []
        for v in ids:
            g = inv.guests[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not re.match(r"^net\d+$", k):
                    continue
                br = (re.search(r"bridge=([^,]+)", val) or [None, ""])[1]
                out.append({"vmid": v, "name": g["name"], "node": g["node"], "nic": k, "bridge": br,
                            "ovs": br in bridges.get(g["node"], []), "firewall": "firewall=1" in val.split(","),
                            "sensor": "sensor" in g["tags"] or bool(re.search(r"dragos|sensor|tenable|zeek|suricata|snort|onion|nsm", g["name"], re.I))})
        return self.send(200, {"nics": out, "bridges": bridges})

    # -- storage and disks
    def api_overview(self, s, method, parts, q):
        self.need(s, "overview")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use this course")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        disks = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$", k) and "media=cdrom" not in val:
                    vol = val.split(",")[0]
                    if ":" not in vol:
                        continue
                    size = (re.search(r"size=([^,]+)", val) or [None, ""])[1]
                    fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                    disks.append({"vmid": v, "name": inv.guests[v]["name"], "disk": k, "storage": vol.split(":")[0], "format": fmt, "size": size})
        st = []
        for x in pve.call("GET", "/storage") or []:
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "shared": bool(x.get("shared")),
                       "formats": "qcow2 raw vmdk" if t in ("dir", "nfs", "cifs", "glusterfs", "cephfs") else "raw",
                       "content": x.get("content", "")})
        return self.send(200, {"storages": st, "disks": disks})

    # -- users (admin)
    def api_users(self, s, method, parts, q):
        self.need(s, "users")
        with LOCK:
            us = users()
            if method == "GET":
                return self.send(200, [{"name": n, "role": u.get("role"), "courses": u.get("courses", "*"), "twofa": bool(u.get("totp"))}
                                       for n, u in sorted(us.items())])
            b = self.body() if method in ("POST", "PUT") else {}
            if method == "POST" and not parts:   # add
                name = (b.get("name") or "").strip()
                if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                    raise ValueError("user names: letters, digits, . _ - (max 32)")
                if name in us:
                    raise ValueError("%s already exists" % name)
                pw = b.get("password") or gen_password()
                if len(pw) < 10:
                    raise ValueError("use at least 10 characters for the password")
                us[name] = {"hash": hash_pw(pw), "role": self.valid_role(b.get("role")), "courses": self.valid_courses(b.get("courses")), "totp": ""}
                save_json("users.json", us)
                audit(s["user"], "user %s added (%s)" % (name, us[name]["role"]))
                return self.send(200, {"ok": True, "password": None if b.get("password") else pw})
            name = parts[0] if parts else ""
            if name not in us:
                raise KeyError("no user %s" % name)
            admins = [n for n, u in us.items() if u.get("role") == "admin"]
            if method == "DELETE":
                if name == s["user"]:
                    raise ValueError("you can't delete yourself")
                if us[name].get("role") == "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin" % name)
                del us[name]
                save_json("users.json", us)
                audit(s["user"], "user %s deleted" % name)
                return self.send(200, {"ok": True})
            if method == "PUT":
                role = self.valid_role(b.get("role", us[name].get("role")))
                if us[name].get("role") == "admin" and role != "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin - make another admin first" % name)
                us[name]["role"] = role
                us[name]["courses"] = self.valid_courses(b.get("courses", us[name].get("courses", "*")))
                if b.get("twofa") is False:
                    us[name]["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "user %s changed: %s, courses %s" % (name, role, us[name]["courses"]))
                return self.send(200, {"ok": True})
            if method == "POST" and len(parts) == 2 and parts[1] == "password":
                pw = gen_password()
                us[name]["hash"] = hash_pw(pw)
                save_json("users.json", us)
                for t, ss in list(SESSIONS.items()):
                    if ss["user"] == name:
                        SESSIONS.pop(t, None)
                audit(s["user"], "new password for %s" % name)
                return self.send(200, {"password": pw})
            if method == "POST" and len(parts) == 2 and parts[1] == "unlock":
                for k in [k for k in FAILS if k.startswith(name.lower() + "|")]:
                    FAILS.pop(k, None)
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    def valid_role(self, r):
        if r != "admin" and r not in roles():
            raise ValueError("no role %s" % r)
        return r

    def valid_courses(self, c):
        if c == "*" or c is None:
            return "*"
        if not isinstance(c, list) or not c or not all(isinstance(x, str) and re.match(r"^[A-Za-z0-9_.-]+$", x) for x in c):
            raise ValueError("pick at least one course")
        return sorted(set(c))

    # -- own account: password, 2FA
    def api_me(self, s, method, parts, q):
        with LOCK:
            us = users()
            me = us[s["user"]]
            b = self.body() if method != "GET" else {}
            what = parts[0] if parts else ""
            if method == "POST" and what == "password":
                if not check_pw(b.get("old", ""), me["hash"]):
                    raise ValueError("your current password doesn't match")
                if len(b.get("new", "")) < 10:
                    raise ValueError("use at least 10 characters")
                me["hash"] = hash_pw(b["new"])
                save_json("users.json", us)
                audit(s["user"], "changed own password")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-start":
                secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
                SESSIONS[s["token"]]["pending_totp"] = secret
                return self.send(200, {"secret": secret, "uri": "otpauth://totp/pve-range:%s?secret=%s&issuer=pve-range" % (urllib.parse.quote(s["user"]), secret)})
            if method == "POST" and what == "2fa-confirm":
                secret = SESSIONS[s["token"]].get("pending_totp")
                if not secret or not totp_ok(secret, b.get("code", "")):
                    raise ValueError("that code doesn't match - check the time on your phone")
                me["totp"] = secret
                save_json("users.json", us)
                audit(s["user"], "2FA turned on")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-off":
                if not check_pw(b.get("password", ""), me["hash"]):
                    raise ValueError("your password doesn't match")
                me["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "2FA turned off")
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    # -- roles, VMID map, audit (admin)
    def api_roles(self, s, method, parts, q):
        if method == "GET":
            return self.send(200, {"roles": roles(), "perms": PERMS})
        self.need(s, "settings")
        b = self.body()   # {roles: {name: [perms]}}
        new = {}
        for name, ps in (b.get("roles") or {}).items():
            if name == "admin":
                continue
            if not re.match(r"^[a-z][a-z0-9_-]{0,23}$", name):
                raise ValueError("role names: small letters, digits, - and _")
            new[name] = sorted(p for p in ps if p in PERMS)
        used = {u.get("role") for u in users().values()}
        gone = [r for r in roles() if r not in new and r in used]
        if gone:
            raise ValueError("users still have the role %s - give them another role first" % ", ".join(gone))
        save_json("roles.json", new)
        autosave(s["user"], "Roles changed")
        audit(s["user"], "roles: " + "; ".join("%s=%s" % (k, ",".join(v)) for k, v in new.items()))
        return self.send(200, {"ok": True})

    def api_vmidmap(self, s, method, parts, q):
        self.need(s, "settings")
        if method == "GET":
            return self.send(200, {"text": load_map()[1]})
        text = self.body().get("text", "")
        if len(text) > 100000:
            raise ValueError("too long")
        with open(path("vmid-map.conf"), "w") as f:
            f.write(text)
        inv.forget(list(inv.guests))
        autosave(s["user"], "Course map changed")
        audit(s["user"], "VMID map changed")
        return self.send(200, {"ok": True})

    def api_audit(self, s, method, parts, q):
        self.need(s, "users")
        try:
            with open(path("audit.log")) as f:
                lines = f.readlines()[-300:]
        except OSError:
            lines = []
        return self.send(200, {"lines": [x.rstrip("\n") for x in reversed(lines)]})


# ---------------------------------------------------------------------------- more endpoints
def _course_ok(self, s, course):
    allow = allowed_courses(s["u"])
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)


def api_settings(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, {"settings": settings(), "defaults": DEFAULT_SETTINGS})
    self.need(s, "settings")
    b = self.body()
    cur = load_json("settings.json", {})
    for k, v in b.items():
        if k not in DEFAULT_SETTINGS:
            continue
        d = DEFAULT_SETTINGS[k]
        if isinstance(d, bool):
            v = bool(v)
        elif isinstance(d, int):
            v = int(v)
            if k == "max_parallel" and not 1 <= v <= 32:
                raise ValueError("steps at once: 1 to 32")
            if k == "shutdown_timeout" and not 10 <= v <= 3600:
                raise ValueError("shutdown timeout: 10 to 3600 seconds")
            if k == "backup_keep" and not 0 <= v <= 500:
                raise ValueError("backups to keep: 0 to 500")
            if k == "start_delay" and not 0 <= v <= 600:
                raise ValueError("pause between starts: 0 to 600 seconds")
        else:
            v = str(v).strip()
            if k == "default_snapshot" and not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", v):
                raise ValueError("snapshot names start with a letter")
            if k == "protected" and v and not re.match(r"^[\d\s,-]+$", v):
                raise ValueError("protected guests: VMIDs and ranges like 100-105, 9001")
            if k == "sensor_pattern":
                try:
                    re.compile(v)
                except re.error:
                    raise ValueError("sensor names: not a valid pattern")
        cur[k] = v
    save_json("settings.json", cur)
    inv.forget(list(inv.guests))
    autosave(s["user"], "Settings changed")
    audit(s["user"], "settings: " + ", ".join("%s=%s" % kv for kv in sorted(b.items())))
    return self.send(200, {"ok": True})


def api_guide(self, s, method, parts, q):
    course = urllib.parse.unquote(parts[0]) if parts else ""
    _course_ok(self, s, course)
    f = guide_file(course)
    if method == "GET":
        self.need(s, "guide_read")
        text = read_text(f)
        if text is None:   # pve-range keeps its class guides as <course>.txt
            text = read_text(f[:-3] + ".txt")
        return self.send(200, {"course": course, "text": text})
    self.need(s, "guide_edit")
    if method == "DELETE":
        for x in (f, f[:-3] + ".txt"):
            try:
                os.remove(x)
            except OSError:
                pass
        autosave(s["user"], "Class guide for %s deleted" % course)
        audit(s["user"], "class guide %s deleted" % course)
        return self.send(200, {"ok": True})
    b = self.body()
    text = fetch_url(b["url"]) if b.get("url") else b.get("text", "")
    if len(text) > 1_000_000:
        raise ValueError("a guide can be at most 1 MB")
    write_text(f, text)
    try:
        os.remove(f[:-3] + ".txt")   # the .md replaces a guide brought over from pve-range
    except OSError:
        pass
    autosave(s["user"], "Class guide for %s saved" % course)
    audit(s["user"], "class guide %s saved (%d characters)" % (course, len(text)))
    return self.send(200, {"ok": True, "text": text})


def api_addons(self, s, method, parts, q):
    course = q.get("course", "")
    if method == "GET" and not parts:
        self.need(s, "addons_run")
        _course_ok(self, s, course)
        return self.send(200, {"addons": list_addons(course), "template": ADDON_TEMPLATE if "addons_edit" in s["perms"] else ""})
    scope, f = (parts + ["", ""])[:2]
    if scope != "_all":
        _course_ok(self, s, scope)
    if not ADDON_RE.match(f or ""):
        raise ValueError("add-on file names end in .sh: letters, digits, . _ -")
    full = os.path.join(addon_dir(scope), f)
    if method == "GET":
        self.need(s, "addons_run")
        t = read_text(full)
        if t is None:
            raise KeyError("no such add-on")
        return self.send(200, {"text": t, "meta": addon_meta(t, f)})
    self.need(s, "addons_edit")
    if method == "DELETE":
        try:
            os.remove(full)
        except OSError:
            pass
        autosave(s["user"], "Add-on %s/%s deleted" % (scope, f))
        audit(s["user"], "add-on %s/%s deleted" % (scope, f))
        return self.send(200, {"ok": True})
    b = self.body()
    text = fetch_url(b["url"]) if b.get("url") else b.get("text", "")
    if len(text) > 1_000_000:
        raise ValueError("an add-on can be at most 1 MB")
    if b.get("move_to") and b["move_to"] != scope:   # move to another course (or all)
        dest = b["move_to"]
        if dest != "_all":
            _course_ok(self, s, dest)
        write_text(os.path.join(addon_dir(dest), f), text, 0o750)
        try:
            os.remove(full)
        except OSError:
            pass
    else:
        write_text(full, text.replace("\r\n", "\n"), 0o750)
    autosave(s["user"], "Add-on %s/%s saved" % (scope, f))
    audit(s["user"], "add-on %s/%s saved" % (b.get("move_to") or scope, f))
    return self.send(200, {"ok": True, "text": text})


def api_groups(self, s, method, parts, q):
    g = load_json("groups.json", {})
    if method == "GET":
        return self.send(200, g if isinstance(g, dict) else {})
    self.need(s, "settings")
    b = self.body()
    new = {}
    for k, v in (b.get("groups") or {}).items():
        if not re.match(r"^[A-Za-z0-9 _.-]{1,40}$", k) or not re.match(r"^[\d\s,-]+$", v or ""):
            raise ValueError("group names: letters, digits, spaces; members: VMIDs and ranges")
        new[k.strip()] = v.strip()
    save_json("groups.json", new)
    autosave(s["user"], "Saved groups changed")
    return self.send(200, {"ok": True})


def api_themes(self, s, method, parts, q):
    if method == "GET":
        return self.send(200, load_json("themes.json", {}))
    self.need(s, "settings")
    b = self.body()
    new = {}
    for name, cols in (b.get("themes") or {}).items():
        if not re.match(r"^[A-Za-z0-9 _-]{1,24}$", name):
            raise ValueError("theme names: letters, digits, spaces")
        c = {k: v for k, v in cols.items() if k in ("canvas", "panel", "ink", "line", "action", "dark") and (k == "dark" or re.match(r"^#[0-9a-fA-F]{6}$", str(v)))}
        if len([k for k in c if k != "dark"]) != 5:
            raise ValueError("each theme needs five colours as #rrggbb")
        new[name] = c
    save_json("themes.json", new)
    autosave(s["user"], "Colour themes changed")
    return self.send(200, {"ok": True})


def api_git(self, s, method, parts, q):
    self.need(s, "save")
    what = parts[0] if parts else ""
    if method == "GET" and what == "":
        c = git_conf()
        hist = []
        if os.path.isdir(os.path.join(REPO, ".git")):
            out = git("log", "-50", "--format=%h%x09%an%x09%ar%x09%s", check=False)
            hist = [dict(zip(("id", "who", "when", "what"), ln.split("\t", 3))) for ln in out.splitlines() if ln.count("\t") >= 3]
        try:
            backups = sorted((f for f in os.listdir(BACKUPS) if f.startswith("backup-")), reverse=True)
        except OSError:
            backups = []
        return self.send(200, {"url": c.get("url", ""), "user": c.get("user", ""), "branch": c.get("branch", "main"),
                               "insecure": bool(c.get("insecure")), "history": hist, "backups": backups,
                               "has_token": os.path.exists(path("priv/git-token")),
                               "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "GET" and what == "backup" and len(parts) == 2:
        f = os.path.join(BACKUPS, parts[1])
        if not re.match(r"^backup-\d{8}-\d{6}\.tar\.gz$", parts[1]) or not os.path.exists(f):
            raise KeyError("no such backup")
        with open(f, "rb") as fh:
            return self.send(200, raw=fh.read(), ctype="application/gzip",
                             headers={"Content-Disposition": 'attachment; filename="%s"' % parts[1]})
    b = self.body() if method in ("POST", "PUT") else {}
    if method == "PUT" and what == "connect":
        url = (b.get("url") or "").strip()
        if url and not re.match(r"^(https?://[^\s/]+/\S+|git@[^\s:]+:\S+|ssh://\S+)$", url):
            raise ValueError("give the repository address, e.g. https://gitea.lab/team/pve-range.git")
        c = {"url": url, "user": (b.get("user") or "").strip(), "branch": (b.get("branch") or "main").strip(), "insecure": bool(b.get("insecure"))}
        if not re.match(r"^[A-Za-z0-9._/-]{1,60}$", c["branch"]):
            raise ValueError("bad branch name")
        old = git_conf()
        save_json("git.json", c)
        os.makedirs(path("priv"), exist_ok=True)
        if b.get("token"):
            write_text(path("priv/git-token"), b["token"].strip() + "\n", 0o600)
        if url.startswith(("git@", "ssh://")) and not os.path.exists(path("ssh/git_ed25519")):
            subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "pve-range-gui-git", "-f", path("ssh/git_ed25519")], check=False)
        if url:
            with GIT_LOCK:
                repo_init()
            p_ = subprocess.run(["git"] + (["-c", "http.sslVerify=false"] if c["insecure"] else []) + ["ls-remote", remote_url(c)],
                                env=git_env(), capture_output=True, text=True, timeout=40)
            if p_.returncode:
                save_json("git.json", old)
                err = (p_.stderr or "").strip().splitlines()
                raise ValueError("can't connect: %s" % (err[-1] if err else "check the address, user and token"))
        audit(s["user"], "repository: %s" % (url or "disconnected"))
        try:
            r = repo_save(s["user"], "Connected to %s" % url) if url else "Disconnected."
        except PVEError as e:
            raise ValueError("connected, but the upload failed: %s" % e)
        return self.send(200, {"ok": True, "report": r, "ssh_key": read_text(path("ssh/git_ed25519.pub")) or ""})
    if method == "POST" and what == "save":
        r = repo_save(s["user"], b.get("message") or "Saved from the GUI")
        audit(s["user"], "save: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "pull":
        r = repo_pull(s["user"])
        audit(s["user"], "get latest: " + r)
        return self.send(200, {"report": r})
    if method == "POST" and what == "backup":
        name = make_backup()
        audit(s["user"], "backup %s" % name)
        return self.send(200, {"report": "Backup %s made." % name})
    if method == "POST" and what == "restore":
        make_backup()
        restore_backup(b.get("name", ""))
        audit(s["user"], "restored backup %s" % b.get("name"))
        autosave(s["user"], "Restored backup %s" % b.get("name"))
        return self.send(200, {"report": "Restored %s (a backup of the state before was made first)." % b.get("name")})
    raise ValueError("bad request")


def api_storages(self, s, method, parts, q):   # for Move / convert disks
    self.need(s, "disks")
    st = []
    for x in pve.call("GET", "/storage") or []:
        if "images" in (x.get("content") or "") or "rootdir" in (x.get("content") or ""):
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "raw_only": t in RAW_ONLY})
    return self.send(200, st)


def api_bridges(self, s, method, parts, q):   # for Network settings
    self.need(s, "network")
    out = {}
    for n in inv.nodes or [r["node"] for r in pve.call("GET", "/nodes") or []]:
        try:
            out[n] = sorted({b["iface"] for b in pve.call("GET", "/nodes/%s/network" % n) or [] if b.get("type") in ("bridge", "OVSBridge")})
        except PVEError:
            out[n] = []
    return self.send(200, out)


for _f in (api_settings, api_guide, api_addons, api_groups, api_themes, api_git, api_storages, api_bridges):
    setattr(Handler, _f.__name__, _f)


# ---------------------------------------------------------------------------- command line
def cli(argv):
    """docker compose exec pve-range-gui pvr ...  (no sign-in: whoever can run this is the admin)"""
    import getpass
    if not argv or argv[0] in ("-h", "--help", "help"):
        print("""pvr users                          list web users
pvr users add NAME --role R [--courses 613,NetWars] [--password P]
pvr users passwd NAME              new generated password
pvr users role NAME ROLE           change the role
pvr users courses NAME 613,NetWars|*
pvr users unlock NAME              clear a lock-out (restart not needed)
pvr users del NAME
pvr roles                          roles and what they may do
pvr courses                        courses and guest counts
pvr list --course C                guests of a course: status, node, snapshots
pvr storage --course C             storages and the course's disks
pvr mirror-status [--course C]     saved mirrors and whether they run
pvr guide --course C               print the class guide
pvr run ACTION --course C [--snapshot S] [--ids 510101,510102] [--yes] [--hard]
    ACTION: class_start class_end power_on power_off snap_take snap_restore snap_delete mirror_apply
    snap_restore also takes --after leave|start|off
pvr save "message"                 save to the history / your repository
pvr pull                           get the latest from your repository
pvr backup                         make a backup""")
        return 0
    cmd, rest = argv[0], argv[1:]
    def opt(name, default=None):
        if name in rest:
            i = rest.index(name)
            return rest[i + 1] if i + 1 < len(rest) else default
        return default
    if cmd == "users":
        us = users()
        if not rest:
            for n, u in sorted(us.items()):
                print("%-20s %-12s %-28s 2FA %s" % (n, u.get("role"), u.get("courses") if u.get("courses") == "*" else ",".join(u.get("courses", [])), "on" if u.get("totp") else "off"))
            return 0
        sub, name = rest[0], (rest[1] if len(rest) > 1 else "")
        if sub == "add":
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name) or name in us:
                print("bad or existing name"); return 1
            pw = opt("--password") or gen_password()
            role = opt("--role", "instructor")
            if role != "admin" and role not in roles():
                print("no role %s" % role); return 1
            c = opt("--courses", "*")
            us[name] = {"hash": hash_pw(pw), "role": role, "courses": "*" if c == "*" else sorted(c.split(",")), "totp": ""}
            save_json("users.json", us)
            print("User %s added (%s). Password: %s" % (name, role, pw if not opt("--password") else "(as given)"))
        elif name not in us:
            print("no user %s" % name); return 1
        elif sub == "passwd":
            pw = gen_password()
            us[name]["hash"] = hash_pw(pw)
            save_json("users.json", us)
            print("New password for %s: %s" % (name, pw))
        elif sub == "role":
            r = rest[2] if len(rest) > 2 else ""
            if r != "admin" and r not in roles():
                print("no role %s" % r); return 1
            us[name]["role"] = r
            save_json("users.json", us)
            print("%s is now %s" % (name, r))
        elif sub == "courses":
            c = rest[2] if len(rest) > 2 else "*"
            us[name]["courses"] = "*" if c == "*" else sorted(c.split(","))
            save_json("users.json", us)
            print("%s may use: %s" % (name, c))
        elif sub == "unlock":
            print("Lock-outs are kept in memory - restart to clear them: docker compose restart")
        elif sub == "del":
            del us[name]
            save_json("users.json", us)
            print("%s deleted" % name)
        audit("cli", "users %s %s" % (sub, name))
        return 0
    if cmd == "roles":
        print("%-14s %s" % ("admin", "(everything)"))
        for r, ps in roles().items():
            print("%-14s %s" % (r, " ".join(ps)))
        return 0
    if cmd == "courses":
        inv.refresh(force=True)
        cnt = {}
        for g in inv.guests.values():
            cnt.setdefault(g["course"], [0, 0])
            cnt[g["course"]][0] += 1
            cnt[g["course"]][1] += g["status"] == "running"
        for c, (n, r) in sorted(cnt.items()):
            print("%-14s %3d guests, %d running" % (c, n, r))
        return 0
    if cmd == "list":
        course = opt("--course", "")
        inv.refresh(force=True)
        ids = inv.course_ids(course)
        if not ids:
            print("no guests in %r - pvr courses" % course); return 1
        snaps = inv.snapshots(ids)
        print("%-8s %-4s %-12s %-8s %-24s %-34s %s" % ("VMID", "TYPE", "NODE", "STATUS", "NAME", "GROUP", "SNAPSHOTS"))
        for v in ids:
            g = inv.guests[v]
            print("%-8d %-4s %-12s %-8s %-24s %-34s %s" % (v, "CT" if g["type"] == "lxc" else "VM", g["node"], g["status"], g["name"][:24], g["label"][:34],
                                                         " ".join(x["name"] + ("+mem" if x["ram"] else "") for x in snaps.get(v, []))))
        return 0
    if cmd == "storage":
        course = opt("--course", "")
        inv.refresh(force=True)
        cfgs = inv.configs(inv.course_ids(course))
        print("STORAGES")
        for x in pve.call("GET", "/storage") or []:
            print("  %-16s %-10s %s" % (x["storage"], x.get("type", ""), "raw only" if x.get("type") in RAW_ONLY else "qcow2 raw vmdk"))
        print("DISKS IN %s" % course)
        for v, c in sorted(cfgs.items()):
            for k, val in sorted(c.items()):
                if DISK_RE.match(k) and "media=cdrom" not in val and ":" in val.split(",")[0]:
                    vol = val.split(",")[0]
                    print("  %-8d %-10s %-16s %s" % (v, k, vol.split(":")[0], "qcow2" if vol.endswith(".qcow2") else "raw"))
        return 0
    if cmd == "mirror-status":
        course = opt("--course")
        inv.refresh(force=True)
        ids = set(inv.course_ids(course)) if course else None
        for m in mirrors():
            if ids is not None and not any(e.get("vmid") in ids for e in m.get("entries", [])):
                continue
            st = mirror_status(m["node"], m["bridge"])
            print("%s on %s%s" % (m["bridge"], m["node"], ("  - " + st["error"]) if st["error"] else ""))
            live = {x["port"]: x for x in st["mirrors"]}
            for e in m.get("entries", []):
                g = inv.guests.get(e["vmid"])
                port = nic_dev(g, e["nic"]) if g else "?"
                x = live.get(port)
                print("  %-8d %-6s %-14s %s" % (e["vmid"], e["nic"], port, ("mirrored, %s packets" % x["packets"]) if x else "NOT mirrored"))
        return 0
    if cmd == "guide":
        t = read_text(guide_file(opt("--course", "")))
        if t is None:
            t = read_text(guide_file(opt("--course", ""))[:-3] + ".txt")
        print(t if t is not None else "No class guide for this course.")
        return 0
    if cmd == "run":
        action = rest[0] if rest else ""
        course = opt("--course", "")
        inv.refresh(force=True)
        ids = [int(x) for x in (opt("--ids") or "").split(",") if x.strip().isdigit()] or inv.course_ids(course)
        snap = opt("--snapshot") or settings()["default_snapshot"]
        body = {"action": action, "course": course, "ids": ids, "snapshot": snap, "restore": ids, "start": ids, "off": ids,
                "after": opt("--after", "leave"),
                "mode": "stop" if "--hard" in rest else "shutdown", "title": "%s %s (command line)" % (action, course)}
        us = users()
        admin = next((n for n, u in us.items() if u.get("role") == "admin"), None)
        if not admin:
            print("create the first admin first (open the web page)"); return 1
        pid = build_plan(admin, body)
        v = plan_view(pid)
        for i, g in enumerate(v["groups"]):
            print("Stage %d:" % (i + 1))
            for st in g:
                print("  [%s] %s" % (st["node"], st["label"]))
        for n in v["notes"]:
            print("  note: " + n)
        if not v["count"]:
            print("Nothing to do."); return 0
        if "--yes" not in rest and input("Run %d step(s)? [y/N] " % v["count"]).lower() not in ("y", "yes"):
            return 1
        jid = start_job(admin, pid)
        while JOBS[jid]["state"] != "done":
            time.sleep(0.5)
        bad = 0
        for g in JOBS[jid]["steps"]:
            for st in g:
                print("  %-7s %s %s" % (st["state"], st["label"], st["msg"]))
                bad += st["state"] == "failed"
        return 1 if bad else 0
    if cmd == "save":
        print(repo_save("cli", " ".join(rest) or "Saved from the command line")); return 0
    if cmd == "pull":
        print(repo_pull("cli")); return 0
    if cmd == "backup":
        print("Backup %s made." % make_backup()); return 0
    del getpass
    print("unknown command - pvr help")
    return 1


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True


def main():
    os.makedirs(DATA, exist_ok=True)
    srv = Server(("0.0.0.0", PORT), Handler)
    cert, key = path("tls/cert.pem"), path("tls/key.pem")
    if os.path.exists(cert) and os.path.exists(key):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        print("pve-range GUI %s on https://0.0.0.0:%d" % (VERSION, PORT), flush=True)
    else:
        global COOKIE_FLAGS
        COOKIE_FLAGS = ""
        print("pve-range GUI %s on http://0.0.0.0:%d (no certificate - testing only)" % (VERSION, PORT), flush=True)
    try:
        if API_URLS:
            v = pve.call("GET", "/version")
            print("Proxmox API OK - version %s" % v.get("version"), flush=True)
    except PVEError as e:
        print("Proxmox API: %s" % e, flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(cli(sys.argv[1:]))
    main()
