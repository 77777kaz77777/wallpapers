#!/usr/bin/env python3
"""pve-range GUI - a web console for running Proxmox training ranges.

Talks to Proxmox only through its API (token), plus one optional SSH key that may run
nothing but ovs-vsctl (port mirroring). Python standard library only.
"""
import base64
import concurrent.futures as cf
import hashlib
import hmac
import http.server
import json
import os
import re
import secrets
import ssl
import struct
import subprocess
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

VERSION = "1.0"
DATA = os.environ.get("DATA_DIR", "/data")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
PORT = int(os.environ.get("PORT", "8443"))
API_URLS = [u.rstrip("/") for u in os.environ.get("PVE_API_URL", "").replace(",", " ").split() if u]
API_TOKEN = os.environ.get("PVE_API_TOKEN", "")
PARALLEL = int(os.environ.get("MAX_PARALLEL", "8"))
SHUTDOWN_TIMEOUT = int(os.environ.get("SHUTDOWN_TIMEOUT", "180"))
IDLE = int(os.environ.get("SESSION_IDLE", "900"))
OVS_KEY = os.path.join(DATA, "ssh", "ovs_ed25519")

PERMS = {
    "class_run": "Start class / End class",
    "power": "Power on / off",
    "snap_take": "Take snapshots",
    "snap_restore": "Restore snapshots",
    "snap_delete": "Delete snapshots",
    "mirror_status": "See port-mirror status",
    "mirror_apply": "Re-apply port mirrors",
    "mirror_setup": "Set up port mirrors",
    "overview": "Storage and disks",
    "users": "Manage users",
    "settings": "Roles, courses and settings",
}
DEFAULT_ROLES = {
    "instructor": ["class_run", "power", "mirror_status", "mirror_apply"],
    "viewer": ["overview", "mirror_status"],
}
DEFAULT_MAP = """\
folder 10 Mgmt      Management
folder 11 Office    Office
folder 12 Security  Security
folder 20 Lab       Lab
folder 40 SANS      SANS
folder 50 612       ICS612
folder 51 613       ICS613
folder 52 NetWars   NetWars v5
folder 53 727       ICS727 (draft)
folder 99 Templates Templates
sub 50 0 Mgmt
sub 50 1 Lvl 3 Servers
sub 50 2 Lvl 3 EWS
sub 50 3 Lvl 3 OWS
sub 50 4 iDMZ File Servers
sub 50 5 iDMZ Jump Hosts
sub 50 6 NSM
sub 51 0 Mgmt
sub 51 1 Enterprise Servers
sub 51 2 ICS Servers
sub 51 3 ABB Servers
sub 51 4 Enterprise Clients
sub 51 5 JumpHost Clients
sub 51 6 ICS EWS
sub 51 7 ABB OWS
module 52 0 Mgmt
module 52 1 Grid
module 52 2 Cookie
module 52 3 Injection
sub 52 0 Servers
sub 52 1 Clients L3
sub 52 2 Clients L4
sub 53 0 Mgmt
sub 53 1 Enterprise
sub 53 2 DMZ
sub 53 3 ICS
"""
LOCK = threading.RLock()


# ---------------------------------------------------------------------------- files
def path(name):
    return os.path.join(DATA, name)


def load_json(name, default):
    try:
        with open(path(name)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, value):
    tmp = path(name + ".new")
    with open(tmp, "w") as f:
        json.dump(value, f, indent=2, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path(name))


def audit(user, text):
    line = "%s  %-14s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), user or "-", text)
    with LOCK, open(path("audit.log"), "a") as f:
        f.write(line)


# ---------------------------------------------------------------------------- Proxmox API
class PVEError(Exception):
    pass


class PVE:
    def __init__(self):
        ca = path("pve-root-ca.pem")
        if os.path.exists(ca):
            self.ctx = ssl.create_default_context(cafile=ca)
            self.ctx.check_hostname = False
        else:   # the nodes' own self-signed certificate
            self.ctx = ssl._create_unverified_context()
        self.good = 0

    def call(self, method, api_path, params=None):
        if not API_URLS or not API_TOKEN:
            raise PVEError("PVE_API_URL and PVE_API_TOKEN must be set in .env")
        params = {k: v for k, v in (params or {}).items() if v is not None}
        body = None
        query = ""
        if method == "GET":
            query = ("?" + urllib.parse.urlencode(params)) if params else ""
        else:
            body = urllib.parse.urlencode(params).encode()
        last = None
        order = API_URLS[self.good:] + API_URLS[:self.good]
        for url in order:
            req = urllib.request.Request(url + "/api2/json" + api_path + query, data=body, method=method)
            req.add_header("Authorization", "PVEAPIToken=" + API_TOKEN)
            if body is not None:
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
            try:
                with urllib.request.urlopen(req, timeout=20, context=self.ctx if url.startswith("https") else None) as r:
                    self.good = API_URLS.index(url)
                    return json.load(r).get("data")
            except urllib.error.HTTPError as e:   # Proxmox answered - no point trying another node
                detail = ""
                try:
                    j = json.loads(e.read() or b"{}")
                    detail = "; ".join("%s: %s" % kv for kv in (j.get("errors") or {}).items())
                except ValueError:
                    pass
                raise PVEError("%s %s -> HTTP %s %s%s" % (method, api_path, e.code, e.reason, (" (" + detail + ")") if detail else ""))
            except (urllib.error.URLError, OSError) as e:
                last = e
        raise PVEError("can't reach the Proxmox API (%s): %s" % (" ".join(API_URLS), last))

    def wait(self, upid):
        node = upid.split(":")[1]
        q = urllib.parse.quote(upid, safe="")
        polls = 0
        while True:
            st = self.call("GET", "/nodes/%s/tasks/%s/status" % (node, q))
            if st.get("status") == "stopped":
                break
            polls += 1
            time.sleep(0.25 if polls <= 8 else 1)
        es = st.get("exitstatus") or ""
        if es == "OK" or es.startswith("WARNINGS"):
            return "" if es == "OK" else es
        log = self.call("GET", "/nodes/%s/tasks/%s/log" % (node, q), {"limit": 500}) or []
        tail = " / ".join(x.get("t", "") for x in log[-4:])
        raise PVEError("task failed: %s%s" % (es or "unknown", (" - " + tail) if tail else ""))

    def task(self, method, api_path, params=None):
        r = self.call(method, api_path, params)
        if isinstance(r, str) and r.startswith("UPID:"):
            return self.wait(r)
        return ""


pve = PVE()


# ---------------------------------------------------------------------------- VMID map
def load_map():
    text = ""
    try:
        with open(path("vmid-map.conf")) as f:
            text = f.read()
    except OSError:
        text = DEFAULT_MAP
    m = {"folder": {}, "desc": {}, "sub": {}, "module": {}}
    for line in text.splitlines():
        p = line.split("#", 1)[0].split()
        if len(p) >= 3 and p[0] == "folder" and p[1].isdigit():
            m["folder"][int(p[1])] = p[2]
            m["desc"][int(p[1])] = " ".join(p[3:])
        elif len(p) >= 4 and p[0] in ("sub", "module") and p[1].isdigit() and p[2].isdigit():
            m[p[0]][(int(p[1]), int(p[2]))] = " ".join(p[3:])
    return m, text


def course_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa = vmid // 10000
    return m["folder"].get(aa, "Group-%d" % aa)


def label_of(vmid, m):
    if vmid < 100000:
        return "Management"
    aa, b, c, dd = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10, vmid % 100
    name = m["folder"].get(aa, str(aa))
    sub = m["sub"].get((aa, c), "sub %d" % c)
    if any(k[0] == aa for k in m["module"]):
        return "%s %s %s #%02d" % (name, m["module"].get((aa, b), "module %d" % b), sub, dd)
    return "%s v%d %s #%02d" % (name, b, sub, dd)


def group_of(vmid, m):   # the sub-group heading the GUI groups guests under
    if vmid < 100000:
        return "Management"
    aa, b, c = vmid // 10000, (vmid // 1000) % 10, (vmid // 100) % 10
    sub = m["sub"].get((aa, c), "Sub-group %d" % c)
    if any(k[0] == aa for k in m["module"]):
        return "%s - %s" % (m["module"].get((aa, b), "Module %d" % b), sub)
    return sub


# ---------------------------------------------------------------------------- inventory
class Inventory:
    def __init__(self):
        self.lock = threading.Lock()
        self.res_at = 0
        self.guests = {}
        self.nodes = []
        self.snaps = {}       # vmid -> (time, [ {name, ram} ])
        self.cfgs = {}        # vmid -> (time, {config})

    def refresh(self, force=False):
        with self.lock:
            if not force and time.time() - self.res_at < 3:
                return
            res = pve.call("GET", "/cluster/resources")
            m, _ = load_map()
            guests, nodes = {}, []
            for r in res:
                if r.get("type") == "node" and r.get("status") == "online":
                    nodes.append(r["node"])
                elif r.get("type") in ("qemu", "lxc") and not r.get("template"):
                    v = int(r["vmid"])
                    guests[v] = {
                        "vmid": v, "type": r["type"], "node": r["node"], "name": r.get("name") or "-",
                        "status": r.get("status", "unknown"),
                        "tags": [t for t in (r.get("tags") or "").replace(",", ";").split(";") if t],
                        "course": course_of(v, m), "label": label_of(v, m), "group": group_of(v, m),
                    }
            # the live state (the cluster overview can lag a few seconds)
            def live(n_t):
                n, t = n_t
                try:
                    return pve.call("GET", "/nodes/%s/%s" % (n, t)) or []
                except PVEError:
                    return []
            with cf.ThreadPoolExecutor(8) as ex:
                for lst in ex.map(live, [(n, t) for n in nodes for t in ("qemu", "lxc")]):
                    for g in lst:
                        v = int(g["vmid"])
                        if v in guests:
                            guests[v]["status"] = g.get("status", guests[v]["status"])
            self.guests, self.nodes, self.res_at = guests, sorted(nodes), time.time()

    def forget(self, ids):
        for v in ids:
            self.snaps.pop(v, None)
            self.cfgs.pop(v, None)
        self.res_at = 0

    def _snap(self, v):
        g = self.guests[v]
        try:
            lst = pve.call("GET", "/nodes/%s/%s/%d/snapshot" % (g["node"], g["type"], v)) or []
        except PVEError:
            lst = []
        out = [{"name": s["name"], "ram": bool(s.get("vmstate")), "time": s.get("snaptime", 0)}
               for s in lst if s.get("name") != "current"]
        out.sort(key=lambda s: s["time"])
        self.snaps[v] = (time.time(), out)

    def snapshots(self, ids, max_age=300):
        need = [v for v in ids if v in self.guests and (v not in self.snaps or time.time() - self.snaps[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(16) as ex:
                list(ex.map(self._snap, need))
        return {v: self.snaps.get(v, (0, []))[1] for v in ids}

    def _cfg(self, v):
        g = self.guests[v]
        try:
            self.cfgs[v] = (time.time(), pve.call("GET", "/nodes/%s/%s/%d/config" % (g["node"], g["type"], v)) or {})
        except PVEError:
            self.cfgs[v] = (time.time(), {})

    def configs(self, ids, max_age=120):
        need = [v for v in ids if v in self.guests and (v not in self.cfgs or time.time() - self.cfgs[v][0] > max_age)]
        if need:
            with cf.ThreadPoolExecutor(16) as ex:
                list(ex.map(self._cfg, need))
        return {v: self.cfgs.get(v, (0, {}))[1] for v in ids}

    def course_ids(self, course):
        return sorted(v for v, g in self.guests.items() if g["course"] == course)


inv = Inventory()


# ---------------------------------------------------------------------------- users, roles
def roles():
    r = load_json("roles.json", None)
    if not isinstance(r, dict):
        r = {k: list(v) for k, v in DEFAULT_ROLES.items()}
    r.pop("admin", None)
    return r


def perms_of(role):
    if role == "admin":
        return list(PERMS)
    return [p for p in roles().get(role, []) if p in PERMS]


def users():
    u = load_json("users.json", {})
    return u if isinstance(u, dict) else {}


def hash_pw(pw, salt=None, n=310000):
    salt = salt or secrets.token_hex(16)
    return "pbkdf2_sha256$%d$%s$%s" % (n, salt, hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), n).hex())


def check_pw(pw, stored):
    try:
        _, n, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, salt, int(n)).split("$")[3], h)
    except (ValueError, AttributeError):
        return False


def totp(secret, t=None):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    c = int((t or time.time()) // 30)
    d = hmac.new(key, struct.pack(">Q", c), "sha1").digest()
    o = d[-1] & 15
    return "%06d" % ((struct.unpack(">I", d[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_ok(secret, code):
    code = re.sub(r"\s", "", code or "")
    now = time.time()
    return any(hmac.compare_digest(totp(secret, now + 30 * w), code) for w in (-1, 0, 1))


def gen_password():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(14))


def allowed_courses(u):
    c = u.get("courses", "*")
    return None if c == "*" or u.get("role") == "admin" else set(c)


SESSIONS = {}
FAILS = {}


def failed_recently(key):
    now = time.time()
    FAILS[key] = [t for t in FAILS.get(key, []) if now - t < 600]
    return len(FAILS[key]) >= 5


# ---------------------------------------------------------------------------- port mirroring (ovs-vsctl over the restricted key)
def node_ip(node):
    for s in pve.call("GET", "/cluster/status") or []:
        if s.get("type") == "node" and s.get("name") == node:
            return s.get("ip")
    raise PVEError("no IP for node %s" % node)


def ovs(node, *args):
    if not os.path.exists(OVS_KEY):
        raise PVEError("port mirroring isn't set up (no key) - see the README")
    cmd = ["ssh", "-n", "-i", OVS_KEY, "-o", "BatchMode=yes", "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=8",
           "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=accept-new",
           "-o", "UserKnownHostsFile=" + os.path.join(DATA, "ssh", "known_hosts"),
           "root@" + node_ip(node), "ovs-vsctl"] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if p.returncode:
        raise PVEError((p.stderr or p.stdout).strip() or "ovs-vsctl failed")
    return p.stdout


def mirrors():
    m = load_json("mirrors.json", [])
    return m if isinstance(m, list) else []


def nic_dev(g, nic):
    n = nic[3:]
    return ("veth%di%s" if g["type"] == "lxc" else "tap%di%s") % (g["vmid"], n)


def mirror_status(node, bridge):
    """The mirrors on a bridge, each with its output port and packets sent."""
    out = {"node": node, "bridge": bridge, "mirrors": [], "error": ""}
    try:
        on = set(re.findall(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", ovs(node, "get", "bridge", bridge, "mirrors")))
        if on:
            ports = json.loads(ovs(node, "--format=json", "--columns=_uuid,name", "list", "port"))["data"]
            pmap = {r[0][1]: r[1] for r in ports}
            rows = json.loads(ovs(node, "--format=json", "--columns=_uuid,name,output_port,statistics", "list", "mirror"))["data"]
            for r in rows:
                if r[0][1] not in on:
                    continue
                port = pmap.get(r[2][1], "?") if r[2][0] == "uuid" else "-"
                stats = dict(r[3][1]) if r[3][0] == "map" else {}
                out["mirrors"].append({"name": r[1], "port": port, "packets": stats.get("tx_packets", 0)})
    except (PVEError, ValueError, KeyError, IndexError, TypeError, subprocess.TimeoutExpired) as e:
        out["error"] = str(e)
    return out


# ---------------------------------------------------------------------------- plans and jobs
PLANS = {}
JOBS = {}


def step(label, node, fn, vmid=None):
    return {"label": label, "node": node, "fn": fn, "vmid": vmid}


def gpath(g):
    return "/nodes/%s/%s/%d" % (g["node"], g["type"], g["vmid"])


def st_rollback(g, snap):
    return step("Restore %d %s to %s" % (g["vmid"], g["name"], snap), g["node"],
                lambda: pve.task("POST", gpath(g) + "/snapshot/%s/rollback" % urllib.parse.quote(snap, safe="")), g["vmid"])


def st_start(g):
    return step("Start %d %s" % (g["vmid"], g["name"]), g["node"], lambda: pve.task("POST", gpath(g) + "/status/start"), g["vmid"])


def st_stop(g, mode):
    if mode == "stop":
        return step("Power off %d %s (hard)" % (g["vmid"], g["name"]), g["node"],
                    lambda: pve.task("POST", gpath(g) + "/status/stop"), g["vmid"])
    return step("Shut down %d %s" % (g["vmid"], g["name"]), g["node"],
                lambda: pve.task("POST", gpath(g) + "/status/shutdown", {"timeout": SHUTDOWN_TIMEOUT, "forceStop": 1}), g["vmid"])


def ct_first(gs):
    return [g for g in gs if g["type"] == "lxc"], [g for g in gs if g["type"] == "qemu"]


def build_plan(user, body):
    a = body.get("action")
    course = body.get("course")
    u = users().get(user, {})
    allow = allowed_courses(u)
    if allow is not None and course not in allow:
        raise PermissionError("you can't use the course %s" % course)
    inv.refresh()
    in_course = set(inv.course_ids(course))
    pick = lambda key: [int(x) for x in body.get(key, []) if int(x) in in_course]
    ids = pick("ids")
    G = inv.guests
    groups, notes = [], []
    need = {"class_start": "class_run", "class_end": "class_run", "power_on": "power", "power_off": "power",
            "snap_take": "snap_take", "snap_restore": "snap_restore", "snap_delete": "snap_delete",
            "mirror_apply": "mirror_apply"}.get(a)
    if not need or need not in perms_of(u.get("role")):
        raise PermissionError("your role can't do this")

    snap = (body.get("snapshot") or "").strip()
    if a in ("class_start", "class_end", "snap_restore", "snap_delete", "snap_take"):
        if not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,39}$", snap):
            raise ValueError("snapshot names start with a letter: letters, digits, - and _")

    if a in ("class_start", "class_end"):
        # restore = guests to roll back; start / off = guests to power on / switch off
        restore, power = pick("restore"), pick("start" if a == "class_start" else "off")
        ids = sorted(set(restore) | set(power))
        snaps = inv.snapshots(ids)
        has = {v: {s["name"]: s for s in snaps.get(v, [])} for v in ids}
        restore = [v for v in restore if snap in has[v]]
        ram = {v for v in restore if G[v]["type"] == "qemu" and has[v][snap]["ram"]}
        if restore:
            groups.append([st_rollback(G[v], snap) for v in restore])
        if a == "class_start":
            start = []
            for v in power:
                if v in ram:
                    notes.append("%d %s: its snapshot includes memory, so the restore brings it back running" % (v, G[v]["name"]))
                elif v not in restore and G[v]["status"] == "running":
                    notes.append("%d %s is already running" % (v, G[v]["name"]))
                else:
                    start.append(G[v])
            cts, vms = ct_first(start)
            if cts:
                groups.append([st_start(g) for g in cts])
            if vms:
                groups.append([st_start(g) for g in vms])
        else:
            mode = "stop" if body.get("mode") == "stop" else "shutdown"
            restored_on = [G[v] for v in power if v in ram]
            kept_on = [G[v] for v in power if v not in restore and G[v]["status"] == "running"]
            if restored_on:
                groups.append([st_stop(g, "stop") for g in restored_on])
                notes.append("Guests just restored are switched off at once - their state is the snapshot")
            if kept_on:
                groups.append([st_stop(g, mode) for g in kept_on])
            if restore and len(ram) < len(restore):
                notes.append("A restore to a snapshot without memory already leaves the guest off")
    elif a == "power_on":
        todo = [G[v] for v in ids if G[v]["status"] != "running"]
        skipped = len(ids) - len(todo)
        if skipped:
            notes.append("%d already running" % skipped)
        cts, vms = ct_first(todo)
        if cts:
            groups.append([st_start(g) for g in cts])
        if vms:
            groups.append([st_start(g) for g in vms])
    elif a == "power_off":
        mode = "stop" if body.get("mode") == "stop" else "shutdown"
        todo = [G[v] for v in ids if G[v]["status"] == "running"]
        if len(todo) < len(ids):
            notes.append("%d already off" % (len(ids) - len(todo)))
        cts, vms = ct_first(todo)
        if vms:
            groups.append([st_stop(g, mode) for g in vms])
        if cts:
            groups.append([st_stop(g, mode) for g in cts])
    elif a == "snap_take":
        ram = bool(body.get("ram"))
        existing = inv.snapshots(ids)
        clash = [v for v in ids if any(s["name"] == snap for s in existing.get(v, []))]
        if clash:
            raise ValueError("%d guest(s) already have a snapshot called %s" % (len(clash), snap))
        groups.append([step("Snapshot %d %s as %s%s" % (v, G[v]["name"], snap, " with memory" if ram and G[v]["type"] == "qemu" and G[v]["status"] == "running" else ""),
                            G[v]["node"],
                            (lambda g=G[v]: pve.task("POST", gpath(g) + "/snapshot",
                                                     {"snapname": snap, "vmstate": 1 if ram and g["type"] == "qemu" and g["status"] == "running" else None})),
                            v) for v in ids])
    elif a == "snap_restore":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if len(todo) < len(ids):
            notes.append("%d guest(s) don't have %s" % (len(ids) - len(todo), snap))
        if todo:
            groups.append([st_rollback(g, snap) for g in todo])
    elif a == "snap_delete":
        snaps = inv.snapshots(ids)
        todo = [G[v] for v in ids if any(s["name"] == snap for s in snaps.get(v, []))]
        if todo:
            groups.append([step("Delete snapshot %s of %d %s" % (snap, g["vmid"], g["name"]), g["node"],
                                (lambda g=g: pve.task("DELETE", gpath(g) + "/snapshot/%s" % urllib.parse.quote(snap, safe=""))),
                                g["vmid"]) for g in todo])
    elif a == "mirror_apply":
        for mr in mirrors():
            ents = [e for e in mr.get("entries", []) if e.get("vmid") in in_course or body.get("all_saved")]
            if not ents:
                continue
            node, bridge = mr["node"], mr["bridge"]
            all_ents = [e for e in mr.get("entries", []) if e.get("vmid") in G]
            cfgs = inv.configs([e["vmid"] for e in all_ents], max_age=0)
            fw, ovs_args, names = [], [], []
            for k, e in enumerate(all_ents):
                g = G[e["vmid"]]
                cur = cfgs.get(g["vmid"], {}).get(e["nic"], "")
                if not cur:
                    notes.append("%d has no %s - skipped" % (g["vmid"], e["nic"]))
                    continue
                if g["node"] != node:
                    notes.append("%d is on %s, not %s - skipped" % (g["vmid"], g["node"], node))
                    continue
                if g["status"] != "running":
                    notes.append("%d %s isn't running - its port doesn't exist; start it first" % (g["vmid"], g["name"]))
                if "firewall=1" in cur.split(","):
                    new = ",".join("firewall=0" if p == "firewall=1" else p for p in cur.split(","))
                    fw.append(step("Turn the firewall off on %d %s" % (g["vmid"], e["nic"]), node,
                                   (lambda g=g, nic=e["nic"], new=new: pve.task("PUT", gpath(g) + "/config", {nic: new})), g["vmid"]))
                ovs_args += ["--", "--id=@p%d" % k, "get", "port", nic_dev(g, e["nic"]),
                             "--", "--id=@m%d" % k, "create", "mirror", "name=m-%d-%s" % (g["vmid"], e["nic"]),
                             "select-all=true", "output-port=@p%d" % k]
                names.append("@m%d" % k)
            if fw:
                groups.append(fw)
            if names:
                args = ovs_args + ["--", "set", "bridge", bridge, "mirrors=" + ",".join(names)]
                groups.append([step("Mirror %s on %s to %d sensor port(s)" % (bridge, node, len(names)), node,
                                    (lambda node=node, args=args: (time.sleep(1 if fw else 0), ovs(node, *args))[1] and "")),
                               None])
        if not groups and not notes:
            notes.append("No saved mirrors for this course - an admin sets them up under Mirrors")
    groups = [g for g in groups if g]
    pid = secrets.token_hex(8)
    PLANS[pid] = {"user": user, "title": body.get("title") or a, "groups": groups, "notes": notes,
                  "action": a, "course": course, "at": time.time()}
    return pid


def plan_view(pid):
    p = PLANS[pid]
    return {"id": pid, "title": p["title"], "notes": p["notes"],
            "groups": [[{"label": s["label"], "node": s["node"]} for s in g] for g in p["groups"]],
            "count": sum(len(g) for g in p["groups"])}


def run_job(jid):
    j = JOBS[jid]
    touched = set()
    with cf.ThreadPoolExecutor(PARALLEL) as ex:
        for gi, grp in enumerate(j["plan"]["groups"]):
            def one(si, s=None):
                s = grp[si]
                st = j["steps"][gi][si]
                st["state"] = "running"
                t0 = time.time()
                try:
                    msg = s["fn"]() or ""
                    st["state"], st["msg"] = "ok", msg
                except Exception as e:   # noqa - show every failure in the GUI
                    st["state"], st["msg"] = "failed", str(e)
                st["secs"] = round(time.time() - t0, 1)
                if s.get("vmid"):
                    touched.add(s["vmid"])
                audit(j["user"], "%s [%s] %s: %s%s" % (j["plan"]["title"], s["node"], s["label"], st["state"],
                                                       (" - " + st["msg"]) if st["msg"] else ""))
            list(ex.map(one, range(len(grp))))
    inv.forget(touched)
    j["state"] = "done"
    j["ended"] = time.time()


def start_job(user, pid):
    p = PLANS.pop(pid, None)
    if not p or p["user"] != user or time.time() - p["at"] > 900:
        raise ValueError("this plan has expired - make it again")
    jid = secrets.token_hex(8)
    JOBS[jid] = {"user": user, "plan": p, "state": "running", "started": time.time(),
                 "steps": [[{"label": s["label"], "node": s["node"], "state": "waiting", "msg": "", "secs": 0} for s in g] for g in p["groups"]]}
    audit(user, "run: %s (%s, %d step(s))" % (p["title"], p["course"], sum(len(g) for g in p["groups"])))
    threading.Thread(target=run_job, args=(jid,), daemon=True).start()
    return jid


# ---------------------------------------------------------------------------- HTTP
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".woff2": "font/woff2",
        ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".txt": "text/plain"}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "pve-range-gui"
    sys_version = ""

    def log_message(self, *a):
        pass

    # -- helpers
    def send(self, code, obj=None, ctype="application/json", raw=None, headers=None):
        b = raw if raw is not None else json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 1_000_000:
            raise ValueError("request too large")
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            raise ValueError("bad request")

    def client(self):
        return self.client_address[0]

    def session(self):
        c = self.headers.get("Cookie", "")
        m = re.search(r"(?:^|;\s*)pvr=([A-Za-z0-9_-]+)", c)
        if not m:
            return None
        s = SESSIONS.get(m.group(1))
        if not s or time.time() - s["last"] > IDLE:
            SESSIONS.pop(m.group(1), None)
            return None
        u = users().get(s["user"])
        if not u:
            return None
        s["last"] = time.time()
        return {"token": m.group(1), "user": s["user"], "role": u.get("role", "viewer"), "u": u,
                "perms": perms_of(u.get("role", "viewer"))}

    def need(self, s, perm):
        if perm not in s["perms"]:
            raise PermissionError("your role can't do this")

    # -- routing
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        url = urllib.parse.urlparse(self.path)
        p = url.path
        try:
            if method == "GET" and not p.startswith("/api/"):
                return self.static(p)
            if method != "GET" and self.headers.get("X-PVR") != "1":   # only our own page may change things
                return self.send(403, {"error": "missing request header"})
            q = dict(urllib.parse.parse_qsl(url.query))
            if p == "/api/session" and method == "GET":
                return self.api_session()
            if p == "/api/setup" and method == "POST":
                return self.api_setup()
            if p == "/api/login" and method == "POST":
                return self.api_login()
            s = self.session()
            if not s:
                return self.send(401, {"error": "Sign in again - your session ended."})
            if p == "/api/logout" and method == "POST":
                SESSIONS.pop(s["token"], None)
                return self.send(200, {"ok": True}, headers={"Set-Cookie": "pvr=; Path=/; Max-Age=0; Secure; HttpOnly; SameSite=Strict"})
            h = getattr(self, "api_" + p[5:].split("/")[0].replace("-", "_"), None)
            if not h:
                return self.send(404, {"error": "not found"})
            return h(s, method, p.split("/")[3:], q)
        except PermissionError as e:
            return self.send(403, {"error": str(e)})
        except (ValueError, KeyError) as e:
            return self.send(400, {"error": str(e).strip("'")})
        except PVEError as e:
            return self.send(502, {"error": str(e)})
        except Exception as e:   # noqa
            traceback.print_exc()
            return self.send(500, {"error": "internal error: %s" % e})

    def static(self, p):
        if p in ("", "/"):
            p = "/index.html"
        f = os.path.normpath(os.path.join(STATIC, p.lstrip("/")))
        if not f.startswith(STATIC) or not os.path.isfile(f):
            f = os.path.join(STATIC, "index.html")
        with open(f, "rb") as fh:
            raw = fh.read()
        return self.send(200, raw=raw, ctype=MIME.get(os.path.splitext(f)[1], "application/octet-stream"))

    # -- sign-in
    def api_session(self):
        s = self.session()
        if not s:
            return self.send(200, {"signed_in": False, "setup": not users(), "version": VERSION})
        return self.send(200, {"signed_in": True, "user": s["user"], "role": s["role"], "perms": s["perms"],
                               "twofa": bool(s["u"].get("totp")), "version": VERSION,
                               "perm_names": PERMS})

    def start_session(self, name):
        tok = secrets.token_urlsafe(32)
        SESSIONS[tok] = {"user": name, "last": time.time()}
        return {"Set-Cookie": "pvr=%s; Path=/; Secure; HttpOnly; SameSite=Strict" % tok}

    def api_setup(self):
        with LOCK:
            if users():
                raise PermissionError("already set up - sign in")
            b = self.body()
            name, pw = (b.get("user") or "").strip(), b.get("password") or ""
            if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                raise ValueError("user names: letters, digits, . _ -")
            if len(pw) < 10:
                raise ValueError("use at least 10 characters for the password")
            save_json("users.json", {name: {"hash": hash_pw(pw), "role": "admin", "courses": "*", "totp": ""}})
        audit(name, "first admin created")
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    def api_login(self):
        b = self.body()
        name, pw, code = (b.get("user") or "").strip(), b.get("password") or "", b.get("code") or ""
        key = name.lower() + "|" + self.client()
        if failed_recently(key):
            return self.send(429, {"error": "Too many wrong attempts. Wait 10 minutes, or ask an admin to unlock you."})
        u = users().get(name)
        if not u or not check_pw(pw, u.get("hash", "")):
            FAILS.setdefault(key, []).append(time.time())
            audit(name, "sign-in FAILED from %s" % self.client())
            return self.send(401, {"error": "That name and password don't match."})
        if u.get("totp"):
            if not code:
                return self.send(200, {"need_code": True})
            if not totp_ok(u["totp"], code):
                FAILS.setdefault(key, []).append(time.time())
                audit(name, "sign-in FAILED (2FA code) from %s" % self.client())
                return self.send(401, {"error": "That code doesn't match. Check the time on your phone.", "need_code": True})
        FAILS.pop(key, None)
        audit(name, "signed in from %s" % self.client())
        return self.send(200, {"ok": True}, headers=self.start_session(name))

    # -- courses and guests
    def api_courses(self, s, method, parts, q):
        inv.refresh()
        allow = allowed_courses(s["u"])
        m, _ = load_map()
        out = {}
        for g in inv.guests.values():
            c = g["course"]
            if allow is not None and c not in allow:
                continue
            o = out.setdefault(c, {"name": c, "count": 0, "running": 0})
            o["count"] += 1
            o["running"] += g["status"] == "running"
        order = {v: k for k, v in m["folder"].items()}
        for c in out.values():
            aa = order.get(c["name"])
            c["desc"] = m["desc"].get(aa, "VMID below 100000" if c["name"] == "Management" else "")
            c["order"] = -1 if c["name"] == "Management" else (aa if aa is not None else 1000)
        return self.send(200, sorted(out.values(), key=lambda c: (c["order"], c["name"])))

    def api_course(self, s, method, parts, q):
        course = urllib.parse.unquote(parts[0]) if parts else ""
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use the course %s" % course)
        inv.refresh(force=q.get("fresh") == "1")
        ids = inv.course_ids(course)
        snaps = inv.snapshots(ids)
        guests = []
        for v in ids:
            g = dict(inv.guests[v])
            g["snapshots"] = snaps.get(v, [])
            guests.append(g)
        summary = {}
        for g in guests:
            for sn in g["snapshots"]:
                o = summary.setdefault(sn["name"], {"name": sn["name"], "count": 0, "ram": 0})
                o["count"] += 1
                o["ram"] += sn["ram"]
        return self.send(200, {"course": course, "guests": guests, "nodes": inv.nodes,
                               "snapshots": sorted(summary.values(), key=lambda x: (-x["count"], x["name"]))})

    # -- plans and jobs
    def api_plan(self, s, method, parts, q):
        if method == "POST" and not parts:
            pid = build_plan(s["user"], self.body())
            return self.send(200, plan_view(pid))
        if method == "POST" and len(parts) == 2 and parts[1] == "run":
            return self.send(200, {"job": start_job(s["user"], parts[0])})
        raise ValueError("bad request")

    def api_job(self, s, method, parts, q):
        j = JOBS.get(parts[0] if parts else "")
        if not j or (j["user"] != s["user"] and s["role"] != "admin"):
            raise KeyError("no such job")
        flat = [st for g in j["steps"] for st in g]
        return self.send(200, {"title": j["plan"]["title"], "state": j["state"], "groups": j["steps"],
                               "notes": j["plan"]["notes"],
                               "ok": sum(st["state"] == "ok" for st in flat), "failed": sum(st["state"] == "failed" for st in flat),
                               "total": len(flat), "secs": round((j.get("ended") or time.time()) - j["started"], 1)})

    # -- mirrors
    def api_mirrors(self, s, method, parts, q):
        if method == "GET":
            self.need(s, "mirror_status")
            course = q.get("course", "")
            inv.refresh()
            ids = set(inv.course_ids(course))
            saved = [m for m in mirrors() if any(e.get("vmid") in ids for e in m.get("entries", []))] if course else mirrors()
            with cf.ThreadPoolExecutor(4) as ex:
                live = list(ex.map(lambda m: mirror_status(m["node"], m["bridge"]), saved))
            for m, l in zip(saved, live):
                l["entries"] = [dict(e, name=inv.guests.get(e["vmid"], {}).get("name", "?"),
                                     status=inv.guests.get(e["vmid"], {}).get("status", "missing"),
                                     port=nic_dev(inv.guests[e["vmid"]], e["nic"]) if e["vmid"] in inv.guests else "")
                                for e in m.get("entries", [])]
            return self.send(200, live)
        self.need(s, "mirror_setup")
        b = self.body()   # {node, bridge, entries:[{vmid,nic}]}  (empty entries = remove)
        node, bridge = b.get("node", ""), b.get("bridge", "")
        if not re.match(r"^[A-Za-z0-9_.-]+$", node) or not re.match(r"^[A-Za-z0-9_.-]+$", bridge):
            raise ValueError("pick a node and a bridge")
        ents = [{"vmid": int(e["vmid"]), "nic": e["nic"]} for e in b.get("entries", []) if re.match(r"^net\d+$", e.get("nic", ""))]
        with LOCK:
            ms = [m for m in mirrors() if not (m["node"] == node and m["bridge"] == bridge)]
            if ents:
                ms.append({"node": node, "bridge": bridge, "entries": ents})
            save_json("mirrors.json", ms)
        if not ents:
            try:
                ovs(node, "clear", "bridge", bridge, "mirrors")
            except PVEError:
                pass
        audit(s["user"], "mirrors on %s/%s: %s" % (node, bridge, ", ".join("%d:%s" % (e["vmid"], e["nic"]) for e in ents) or "removed"))
        return self.send(200, {"ok": True})

    def api_nics(self, s, method, parts, q):   # sensor NICs on OVS bridges, for setting up mirrors
        self.need(s, "mirror_setup")
        course = q.get("course", "")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        bridges = {}
        for n in inv.nodes:
            try:
                bridges[n] = [b["iface"] for b in pve.call("GET", "/nodes/%s/network" % n, {"type": "OVSBridge"}) or []]
            except PVEError:
                bridges[n] = []
        out = []
        for v in ids:
            g = inv.guests[v]
            for k, val in sorted(cfgs.get(v, {}).items()):
                if not re.match(r"^net\d+$", k):
                    continue
                br = (re.search(r"bridge=([^,]+)", val) or [None, ""])[1]
                out.append({"vmid": v, "name": g["name"], "node": g["node"], "nic": k, "bridge": br,
                            "ovs": br in bridges.get(g["node"], []), "firewall": "firewall=1" in val.split(","),
                            "sensor": "sensor" in g["tags"] or bool(re.search(r"dragos|sensor|tenable|zeek|suricata|snort|onion|nsm", g["name"], re.I))})
        return self.send(200, {"nics": out, "bridges": bridges})

    # -- storage and disks
    def api_overview(self, s, method, parts, q):
        self.need(s, "overview")
        course = q.get("course", "")
        allow = allowed_courses(s["u"])
        if allow is not None and course not in allow:
            raise PermissionError("you can't use this course")
        inv.refresh()
        ids = inv.course_ids(course)
        cfgs = inv.configs(ids)
        disks = []
        for v in ids:
            for k, val in sorted(cfgs.get(v, {}).items()):
                if re.match(r"^(scsi|sata|virtio|ide|efidisk|tpmstate)\d+$|^rootfs$|^mp\d+$", k) and "media=cdrom" not in val:
                    vol = val.split(",")[0]
                    if ":" not in vol:
                        continue
                    size = (re.search(r"size=([^,]+)", val) or [None, ""])[1]
                    fmt = "qcow2" if vol.endswith(".qcow2") else "vmdk" if vol.endswith(".vmdk") else "raw"
                    disks.append({"vmid": v, "name": inv.guests[v]["name"], "disk": k, "storage": vol.split(":")[0], "format": fmt, "size": size})
        st = []
        for x in pve.call("GET", "/storage") or []:
            t = x.get("type", "")
            st.append({"storage": x["storage"], "type": t, "shared": bool(x.get("shared")),
                       "formats": "qcow2 raw vmdk" if t in ("dir", "nfs", "cifs", "glusterfs", "cephfs") else "raw",
                       "content": x.get("content", "")})
        return self.send(200, {"storages": st, "disks": disks})

    # -- users (admin)
    def api_users(self, s, method, parts, q):
        self.need(s, "users")
        with LOCK:
            us = users()
            if method == "GET":
                return self.send(200, [{"name": n, "role": u.get("role"), "courses": u.get("courses", "*"), "twofa": bool(u.get("totp"))}
                                       for n, u in sorted(us.items())])
            b = self.body() if method in ("POST", "PUT") else {}
            if method == "POST" and not parts:   # add
                name = (b.get("name") or "").strip()
                if not re.match(r"^[A-Za-z0-9_.-]{1,32}$", name):
                    raise ValueError("user names: letters, digits, . _ - (max 32)")
                if name in us:
                    raise ValueError("%s already exists" % name)
                pw = b.get("password") or gen_password()
                if len(pw) < 10:
                    raise ValueError("use at least 10 characters for the password")
                us[name] = {"hash": hash_pw(pw), "role": self.valid_role(b.get("role")), "courses": self.valid_courses(b.get("courses")), "totp": ""}
                save_json("users.json", us)
                audit(s["user"], "user %s added (%s)" % (name, us[name]["role"]))
                return self.send(200, {"ok": True, "password": None if b.get("password") else pw})
            name = parts[0] if parts else ""
            if name not in us:
                raise KeyError("no user %s" % name)
            admins = [n for n, u in us.items() if u.get("role") == "admin"]
            if method == "DELETE":
                if name == s["user"]:
                    raise ValueError("you can't delete yourself")
                if us[name].get("role") == "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin" % name)
                del us[name]
                save_json("users.json", us)
                audit(s["user"], "user %s deleted" % name)
                return self.send(200, {"ok": True})
            if method == "PUT":
                role = self.valid_role(b.get("role", us[name].get("role")))
                if us[name].get("role") == "admin" and role != "admin" and len(admins) <= 1:
                    raise ValueError("%s is the last admin - make another admin first" % name)
                us[name]["role"] = role
                us[name]["courses"] = self.valid_courses(b.get("courses", us[name].get("courses", "*")))
                if b.get("twofa") is False:
                    us[name]["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "user %s changed: %s, courses %s" % (name, role, us[name]["courses"]))
                return self.send(200, {"ok": True})
            if method == "POST" and len(parts) == 2 and parts[1] == "password":
                pw = gen_password()
                us[name]["hash"] = hash_pw(pw)
                save_json("users.json", us)
                for t, ss in list(SESSIONS.items()):
                    if ss["user"] == name:
                        SESSIONS.pop(t, None)
                audit(s["user"], "new password for %s" % name)
                return self.send(200, {"password": pw})
            if method == "POST" and len(parts) == 2 and parts[1] == "unlock":
                for k in [k for k in FAILS if k.startswith(name.lower() + "|")]:
                    FAILS.pop(k, None)
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    def valid_role(self, r):
        if r != "admin" and r not in roles():
            raise ValueError("no role %s" % r)
        return r

    def valid_courses(self, c):
        if c == "*" or c is None:
            return "*"
        if not isinstance(c, list) or not c or not all(isinstance(x, str) and re.match(r"^[A-Za-z0-9_.-]+$", x) for x in c):
            raise ValueError("pick at least one course")
        return sorted(set(c))

    # -- own account: password, 2FA
    def api_me(self, s, method, parts, q):
        with LOCK:
            us = users()
            me = us[s["user"]]
            b = self.body() if method != "GET" else {}
            what = parts[0] if parts else ""
            if method == "POST" and what == "password":
                if not check_pw(b.get("old", ""), me["hash"]):
                    raise ValueError("your current password doesn't match")
                if len(b.get("new", "")) < 10:
                    raise ValueError("use at least 10 characters")
                me["hash"] = hash_pw(b["new"])
                save_json("users.json", us)
                audit(s["user"], "changed own password")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-start":
                secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
                SESSIONS[s["token"]]["pending_totp"] = secret
                return self.send(200, {"secret": secret, "uri": "otpauth://totp/pve-range:%s?secret=%s&issuer=pve-range" % (urllib.parse.quote(s["user"]), secret)})
            if method == "POST" and what == "2fa-confirm":
                secret = SESSIONS[s["token"]].get("pending_totp")
                if not secret or not totp_ok(secret, b.get("code", "")):
                    raise ValueError("that code doesn't match - check the time on your phone")
                me["totp"] = secret
                save_json("users.json", us)
                audit(s["user"], "2FA turned on")
                return self.send(200, {"ok": True})
            if method == "POST" and what == "2fa-off":
                if not check_pw(b.get("password", ""), me["hash"]):
                    raise ValueError("your password doesn't match")
                me["totp"] = ""
                save_json("users.json", us)
                audit(s["user"], "2FA turned off")
                return self.send(200, {"ok": True})
        raise ValueError("bad request")

    # -- roles, VMID map, audit (admin)
    def api_roles(self, s, method, parts, q):
        if method == "GET":
            return self.send(200, {"roles": roles(), "perms": PERMS})
        self.need(s, "settings")
        b = self.body()   # {roles: {name: [perms]}}
        new = {}
        for name, ps in (b.get("roles") or {}).items():
            if name == "admin":
                continue
            if not re.match(r"^[a-z][a-z0-9_-]{0,23}$", name):
                raise ValueError("role names: small letters, digits, - and _")
            new[name] = sorted(p for p in ps if p in PERMS)
        used = {u.get("role") for u in users().values()}
        gone = [r for r in roles() if r not in new and r in used]
        if gone:
            raise ValueError("users still have the role %s - give them another role first" % ", ".join(gone))
        save_json("roles.json", new)
        audit(s["user"], "roles: " + "; ".join("%s=%s" % (k, ",".join(v)) for k, v in new.items()))
        return self.send(200, {"ok": True})

    def api_vmidmap(self, s, method, parts, q):
        self.need(s, "settings")
        if method == "GET":
            return self.send(200, {"text": load_map()[1]})
        text = self.body().get("text", "")
        if len(text) > 100000:
            raise ValueError("too long")
        with open(path("vmid-map.conf"), "w") as f:
            f.write(text)
        inv.forget(list(inv.guests))
        audit(s["user"], "VMID map changed")
        return self.send(200, {"ok": True})

    def api_audit(self, s, method, parts, q):
        self.need(s, "users")
        try:
            with open(path("audit.log")) as f:
                lines = f.readlines()[-300:]
        except OSError:
            lines = []
        return self.send(200, {"lines": [x.rstrip("\n") for x in reversed(lines)]})


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True


def main():
    os.makedirs(DATA, exist_ok=True)
    srv = Server(("0.0.0.0", PORT), Handler)
    cert, key = path("tls/cert.pem"), path("tls/key.pem")
    if os.path.exists(cert) and os.path.exists(key):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        print("pve-range GUI %s on https://0.0.0.0:%d" % (VERSION, PORT), flush=True)
    else:
        print("pve-range GUI %s on http://0.0.0.0:%d (no certificate - testing only)" % (VERSION, PORT), flush=True)
    try:
        if API_URLS:
            v = pve.call("GET", "/version")
            print("Proxmox API OK - version %s" % v.get("version"), flush=True)
    except PVEError as e:
        print("Proxmox API: %s" % e, flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
