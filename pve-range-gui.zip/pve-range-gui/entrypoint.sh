#!/bin/sh
# Start-up: HTTPS certificate and the port-mirroring key on first start, then the server.
set -e
if [ ! -f /app/server.py ]; then
    echo "entrypoint.sh starts pve-range GUI inside its container - don't run it by hand."
    echo "Start it with:  ./setup.sh   (or: docker compose up -d --build)"
    exit 1
fi
D=${DATA_DIR:-/data}
mkdir -p "$D/tls" "$D/ssh"
chmod 700 "$D/ssh"
if [ ! -s "$D/tls/cert.pem" ]; then
    san="DNS:pve-range,DNS:localhost"
    [ -n "$KEY_FROM" ] && san="$san,IP:$KEY_FROM"
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -subj "/CN=pve-range" \
        -addext "subjectAltName=$san" -keyout "$D/tls/key.pem" -out "$D/tls/cert.pem" 2>/dev/null
    chmod 600 "$D/tls/key.pem"
    echo "Made an HTTPS certificate for this page (self-signed)."
fi
if [ ! -s "$D/ssh/ovs_ed25519" ]; then
    ssh-keygen -q -t ed25519 -N "" -C "pve-range-gui-ovs" -f "$D/ssh/ovs_ed25519" ||
        echo "Couldn't make the port-mirroring key - mirroring stays off."
fi
if [ -s "$D/ssh/ovs_ed25519.pub" ]; then
from=""
[ -n "$KEY_FROM" ] && from="from=\"$KEY_FROM\","
echo "------------------------------------------------------------------------------"
echo " Optional - port mirroring (the API can't do it). On ANY node, once:"
echo "echo '${from}restrict,command=\"case \\\"\$SSH_ORIGINAL_COMMAND\\\" in '\\''ovs-vsctl '\\''*) exec \$SSH_ORIGINAL_COMMAND ;; *) echo only ovs-vsctl >&2; exit 1 ;; esac\" $(cat "$D/ssh/ovs_ed25519.pub")' >>/etc/pve/priv/authorized_keys"
echo " (that key can ONLY run ovs-vsctl - nothing else)"
echo "------------------------------------------------------------------------------"
fi
exec python3 /app/server.py
