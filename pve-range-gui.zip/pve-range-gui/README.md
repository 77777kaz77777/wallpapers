# pve-range GUI

A web console for running the Proxmox training ranges – a real web application, separate
from pve-range's terminal menu. It talks to Proxmox only through the API with a token;
nothing is installed on the nodes.

Everything pve-range does, in a browser:

| Area | What you get |
|---|---|
| **Courses** | Found from the VMIDs (AABCDD: 50 = 612, 51 = 613, 52 = NetWars …; below 100000 = Management); one course at a time |
| **Class** | Start class / End class: restore the class snapshot, then power on or switch off. The class guide is shown first; every step is reviewed before it runs and shown live |
| **Guests** | Grouped by sub-group with live status lamps and snapshots. Select by ticking, VMID range, group, tag, name, node or a saved group |
| **Power and snapshots** | Power on / off (graceful or hard); take snapshots (leave running, shut down first or after, with memory, replace), restore, delete |
| **Sensors** | Mirror status with packet counts, Re-apply mirrors, Set up and remove mirrors |
| **Class guides** | Read, write, upload, import from GitHub / Gitea, download |
| **Add-ons** | Scripts per course or for all courses: run with live output on the selected guests, write, upload, import, download, move. `qm`, `pct`, `pvesh` work in them, so pve-range's add-ons run unchanged |
| **Build** | Network settings (bridge, VLAN, firewall, NIC model – MAC kept), move / convert disks, migrate |
| **Storage and disks** | Storages and every disk with its format and size |
| **Save & share** | Every change goes into a history and – once connected – to your Gitea / GitHub; Get latest; backups after every change, download and restore |
| **Users and roles** | admin, instructor, viewer – change what each may do, make new roles; courses per user; generated passwords; 2FA; lock-out after 5 wrong tries |
| **Settings** | Class snapshot, protected guests, shutdown timeout, steps at once, sensor names, backups to keep, saved groups, colour themes |
| **Help** | Only explains what your role can do |
| **Activity** | Every sign-in and every step that ran, with the user's name |

Instructors see only what their role allows (by default: Start / End class, power on / off,
mirror status and Re-apply mirrors) in their own courses.

Not possible through the Proxmox API, so not here either: enrolling EFI keys and `qm unlock`
(use the node's shell).

## Set up

Needs a Linux host with Docker or Podman that reaches the nodes on port 8006 (in the
lab: CT 105 – the same host as pve-range-docker can run both).

```bash
cd /opt && unzip -o pve-range-gui.zip && cd pve-range-gui
./setup.sh
```

It asks for the node addresses and the **API token**, tests it, builds and starts the
container. Then open `https://<docker-host>:8443` – the first visit creates the first
admin. Admins add everyone else under **Users**.

**The token** – the one pve-range-docker uses works. To make a new one by hand, on any node:

```bash
pveum user add pverange@pve --comment "pve-range"
pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users pverange@pve --roles PVESDNUser
pveum user token add pverange@pve gui --privsep 0
```

## Port mirroring (optional)

The API can't change Open vSwitch, so mirroring uses one SSH key that may run **only
`ovs-vsctl`**. The container prints the line to add at start-up:

```bash
docker compose logs pve-range-gui | grep -A2 'port mirroring'
```

Run that line once on any node. The bridge (e.g. `vmbr2`) must be an **OVS bridge**. Then,
as admin: course → **Sensors → Set up** → pick the bridge and the sensor NICs.

## Everyday

| Task | Command |
|---|---|
| Start / stop | `docker compose up -d` / `docker compose down` |
| Log | `docker compose logs pve-range-gui` |
| Update | unzip the new version over it, then `docker compose up -d --build` |
| Change the token | `./setup.sh token` |
| Command line | `docker compose exec pve-range-gui pvr help` |

**Command line** (`pvr`) – for scripts and emergencies:

```bash
docker compose exec pve-range-gui pvr users                         # list
docker compose exec pve-range-gui pvr users add amy --role instructor --courses 613,NetWars
docker compose exec pve-range-gui pvr users passwd kaz               # forgot the admin password
docker compose exec pve-range-gui pvr run class_start --course 612 --yes
docker compose exec pve-range-gui pvr save "before the exam"
```

All data – users, roles, course map, saved mirrors, add-ons, class guides, the history,
backups, the activity log, the certificate – lives in the `pve-range-gui-data` volume, so
updates keep it.

**Bringing over pve-range's add-ons and class guides:** connect the same repository under
**Save & share** and press **Get latest** – or upload them one by one on the Add-ons and
Class guide tabs.

## How it's built

- `app/server.py` – the server, Python standard library only (no packages to download).
  Passwords are stored as PBKDF2-SHA256 hashes, sessions are HTTP-only cookies that end
  after 15 minutes idle, and every change needs the page's own request header.
- `api/` – `qm`, `pct`, `pvesh`, `pvesm` that work through the API, for add-ons.
- `app/static/` – the page: plain JavaScript, no framework, the Barlow typeface bundled
  so it works without internet. Light and dark follow the computer (or Account → Colours).
- Runs as an unprivileged user with all Linux capabilities dropped.
