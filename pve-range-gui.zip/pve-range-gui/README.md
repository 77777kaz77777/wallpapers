# pve-range GUI

A web console for running the Proxmox training ranges – a real web application, separate
from pve-range's terminal menu. It talks to Proxmox only through the API with a token;
nothing is installed on the nodes.

| | |
|---|---|
| **Courses** | Found from the VMIDs (AABCDD: 50 = 612, 51 = 613, 52 = NetWars …; below 100000 = Management) |
| **Class** | Start class / End class: restore the class snapshot, then power on or switch off – with a review of every step before it runs, and live progress |
| **Guests** | Grouped by sub-group, with live status lamps, snapshots, filter; power on / off and snapshots for the selected ones |
| **Sensors** | Port-mirror status with packet counts, Re-apply mirrors, Set up (admins) |
| **Users** | Roles (admin, instructor, viewer – editable, new ones possible), courses per user, generated passwords, optional 2FA, lock-out after 5 wrong tries |
| **Activity** | Every sign-in and every step that ran, with the user's name |

Instructors see only what they need: the class buttons, power on / off, mirror status
and Re-apply mirrors – in their own courses.

## Set up

Needs a Linux host with Docker or Podman that reaches the nodes on port 8006 (in the
lab: CT 105 – the same host as pve-range-docker can run both).

```bash
cd /opt && unzip -o pve-range-gui.zip && cd pve-range-gui
./setup.sh
```

It asks for the node addresses and the **API token**, tests it, builds and starts the
container. Then open `https://<docker-host>:8443` – the first visit creates the first
admin. Admins add everyone else under **Users**.

**The token** – the one pve-range-docker uses works. To make a new one by hand, on any node:

```bash
pveum user add pverange@pve --comment "pve-range"
pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users pverange@pve --roles PVESDNUser
pveum user token add pverange@pve gui --privsep 0
```

## Port mirroring (optional)

The API can't change Open vSwitch, so mirroring uses one SSH key that may run **only
`ovs-vsctl`**. The container prints the line to add at start-up:

```bash
docker compose logs pve-range-gui | grep -A2 'port mirroring'
```

Run that line once on any node. The bridge (e.g. `vmbr2`) must be an **OVS bridge**. Then,
as admin: course → **Sensors → Set up** → pick the bridge and the sensor NICs.

## Everyday

| Task | Command |
|---|---|
| Start / stop | `docker compose up -d` / `docker compose down` |
| Log | `docker compose logs pve-range-gui` |
| Update | unzip the new version over it, then `docker compose up -d --build` |
| Change the token | `./setup.sh token` |

All data – users, roles, course map, saved mirrors, the activity log, the certificate –
lives in the `pve-range-gui-data` volume, so updates keep it.

## How it's built

- `app/server.py` – the server, Python standard library only (no packages to download).
  Passwords are stored as PBKDF2-SHA256 hashes, sessions are HTTP-only cookies that end
  after 15 minutes idle, and every change needs the page's own request header.
- `app/static/` – the page: plain JavaScript, no framework, the Barlow typeface bundled
  so it works without internet. Light and dark follow the computer (or Account → Colours).
- Runs as an unprivileged user with all Linux capabilities dropped.
