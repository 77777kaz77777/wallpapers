# pve-lab-web (Docker)

The pve-lab menu in a browser: per-user sign-in with 2FA, lock-out, audit log,
idle sign-out and the dark theme - in one container.

## Start

```bash
cp .env.example .env          # set PVE_NODES and KEY_FROM
docker compose up -d --build
docker compose logs pve-lab-web
```

The log prints one `echo '...' >> /etc/pve/priv/authorized_keys` line.
Run it once on any Proxmox node. pve-lab must be installed on every node
as `/usr/local/bin/pve-lab`.

## Users

```bash
docker compose exec pve-lab-web pve-lab-web-users add alice
docker compose exec pve-lab-web pve-lab-web-users list
docker compose exec pve-lab-web pve-lab-web-users passwd alice
docker compose exec pve-lab-web pve-lab-web-users 2fa alice on|off
docker compose exec pve-lab-web pve-lab-web-users del alice
docker compose exec pve-lab-web pve-lab-web-users unlock
```

Open `https://<docker-host>:7681`.

## Data

Everything lives in the `pve-lab-web-data` volume (`/data`): users, SSH key,
known node host keys, TLS certificate, sign-in log (`auth.log`).
To use your own certificate, copy it to `/data/tls/cert.pem` and `/data/tls/key.pem`
and restart.

Back up the volume: the SSH key in it is what the nodes trust.
