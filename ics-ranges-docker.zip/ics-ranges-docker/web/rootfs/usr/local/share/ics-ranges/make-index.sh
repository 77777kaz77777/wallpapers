#!/bin/sh
# Build step: take ttyd's own page and give it the ICS Ranges title and logo (browser tab icon).
# If anything goes wrong, nothing is written and ttyd's normal page is used.
set -u
D=/usr/local/share/ics-ranges
ttyd -p 7999 -i lo true >/dev/null 2>&1 &
pid=$!
sleep 2
if curl -fsS http://127.0.0.1:7999/ -o /tmp/ttyd.html; then
    FAV=$(base64 -w0 "$D/favicon.png") perl -0pi -e '
        s#<link[^>]*rel="icon"[^>]*>##g;
        s#<title>.*?</title>#<title>ICS Ranges</title><link rel="icon" type="image/png" href="data:image/png;base64,$ENV{FAV}">#s' /tmp/ttyd.html &&
        grep -q '<title>ICS Ranges</title>' /tmp/ttyd.html && mv /tmp/ttyd.html "$D/index.html" && echo "ICS Ranges page ready"
fi
kill "$pid" 2>/dev/null
exit 0
