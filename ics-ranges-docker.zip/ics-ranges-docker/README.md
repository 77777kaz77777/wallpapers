# ICS Ranges Docker

The range menu (pve-range) in a browser terminal, branded **ICS Ranges** – the same name and logo
as the ICS Ranges web app. Runs in Docker or Podman; nothing is installed on the Proxmox nodes.

| Container | What |
|---|---|
| `ics-ranges-term` | The menu in the browser: `https://<docker-host>:7681` |
| `ics-ranges-dist` | Download page and user guide: `http://<docker-host>:8080` |
| `ics-ranges-gitea` | Optional Git server |

Commands inside: `ics-ranges` (the menu / command line, also `pve-range`) and
`ics-ranges-users` (web users, also `pve-range-web-users`).

| Service | Port | What |
|---|---|---|
| `ics-ranges-term` | 7681 (https) | The pve-range menu in a browser – per-user sign-in (optional 2FA), lock-out, sign-in log, idle sign-out, dark theme |
| `ics-ranges-dist` | 8080 (http) | Download page: user guide, changelog (and the node installer for node mode) |
| `gitea` (optional) | 3000 | Your own Git server for add-ons and class guides |

**Colours:** black background with white text (`WEB_THEME=mono` in `.env`);
`./setup.sh theme` switches to `midnight` (dark blue). Admins make their own themes with
any colours in the menu: **Settings → Colour theme → Create a new theme**.

## Two ways to run it

| | **Container mode** (recommended) | Node mode (older) |
|---|---|---|
| Where pve-range runs | In this container | On every Proxmox node |
| Installed on the nodes | **Nothing** – only an API user and token | `pve-range` script, `git`, `lrzsz`, an SSH key |
| How it talks to Proxmox | Proxmox API (HTTPS, port 8006) with an API token | SSH, then `qm` / `pct` on the node |
| Set in `.env` | `PVE_API_URL`, `PVE_API_TOKEN` | `PVE_NODES` |

## Container mode – step by step

### 1. On ONE Proxmox node: an API user and token (once)

This is configuration only – nothing is installed:

```bash
pveum user add icsranges@pve --comment "ICS Ranges"
pveum acl modify / --users icsranges@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum acl modify /sdn/zones --users icsranges@pve --roles PVESDNUser
pveum user token add icsranges@pve term --privsep 0
```

The last command shows the token **once** – copy the `value`. The full token is
`icsranges@pve!term=<value>`.

| Role | Why |
|---|---|
| PVEVMAdmin | start / stop, snapshots, network and disk settings, migration, guest agent |
| PVEDatastoreUser | moving and converting disks |
| PVEAuditor | reading nodes, storages and networks |
| PVESDNUser on `/sdn/zones` | using the bridges when a NIC's bridge, VLAN or firewall changes (Proxmox 8) |

The token can't open a shell, manage users or change the nodes themselves.

### 2. Configure and start – `setup.sh`

```bash
./setup.sh
```

It writes `.env` for you, step by step:

1. **Proxmox API addresses** – plain IPs are fine (`192.168.77.77 192.168.77.78`
   becomes `https://…:8006`)
2. **API token** – paste one you have (hidden input), **or let it create one** on a node
   over SSH (asks for root's password once; runs the three `pveum` commands from step 1)
3. The Docker host's IP and the download page address
4. Tests the token against every address, saves `.env` readable by root only, and
   offers to (re)start the containers

Later:

```bash
./setup.sh token    # change only the API token
./setup.sh test     # test the API connection with what's in .env
./setup.sh user     # add a web user (the first one is created by ./setup.sh)
./setup.sh gitea    # set up the bundled Gitea and connect pve-range to it
```

Prefer editing by hand? `cp .env.example .env`, set `PVE_API_URL` and `PVE_API_TOKEN`,
`chmod 600 .env`, then `docker compose up -d --build` (Podman: `podman compose up -d --build`).

Open `https://<docker-host>:7681` and sign in.

### 3. Optional: port mirroring

The Proxmox API can't manage Open vSwitch mirrors. `docker compose logs ics-ranges-term`
prints one `echo '...' >> /etc/pve/priv/authorized_keys` line for a key that can **only
run `ovs-vsctl`** – nothing else, not even a shell. Run it on one node if you want
the Sensors menu. Without it, everything else still works.

### 4. Optional: check the node certificate

By default the container accepts the nodes' self-signed certificate. To check it,
copy the cluster CA into the volume:

```bash
scp root@<node>:/etc/pve/pve-root-ca.pem .
docker compose cp pve-root-ca.pem ics-ranges-term:/data/priv/pve-root-ca.pem
docker compose exec ics-ranges-term chown pverange: /data/priv/pve-root-ca.pem
```

### What needs the node's shell (not available in container mode)

| Feature | Instead |
|---|---|
| Enroll EFI keys (`qm enroll-efi-keys`) | Node shell in the Proxmox web UI |
| *Unlock guests* add-on (`qm unlock`) | Node shell in the Proxmox web UI |
| `pct exec` in add-ons | The Proxmox API (`pvesh`) – see the *Show IP addresses* add-on |
| Port mirroring | Optional key limited to `ovs-vsctl` (step 3) |

Backups go to the container volume (`/data/backups`) instead of a Proxmox
storage. Mount a share there if you want them off the Docker host.

### Command line in container mode

```bash
docker compose exec ics-ranges-term pve-range list --course 613
docker compose exec ics-ranges-term pve-range --yes class-start --course 612 --cluster
```

### Testing container mode

`docker-test.sh` (in this course) tests the whole container setup from the Docker host:
the containers and web pages, the API connection and token rights, failover to the next
node address, a wrong token, sign-in, and every pve-range action on the fake range from
`range-seed.sh` (class 613 guests) – all from inside the container.

```bash
./docker-test.sh                    # compose folder /opt/ics-ranges-docker
./docker-test.sh /path/to/folder
```

It removes its snapshots, test markers and test user at the end. Works with Docker
and Podman.

## Node mode (older)

Set `PVE_NODES` (and leave `PVE_API_URL` empty), start the containers, install
pve-range on every node (from one node):
`curl -fsSL http://<docker-host>:8080/install.sh | PVE_RANGE_ALL_NODES=1 bash`
and run the `echo '...' >> /etc/pve/priv/authorized_keys` line from the log on one node.

## Users, roles and courses

Every web user has a **role** and the **courses** (classes) they may use:

| Role | May |
|---|---|
| admin | everything, including Settings, Save & share and Users |
| instructor | run classes in their courses: start / end class, power, take / restore snapshots, mirrors, class guides, run add-ons |
| viewer | look only: overview, class guides, storage, mirror status |

These are the starting roles – admins change them and create new ones in the menu
(**Settings → Roles and permissions**) or with `./setup.sh roles`. A user can be given
**several** courses (e.g. 613 and NetWars).

Easiest ways to add someone:

- In the web menu as an admin: **General → Users → Add a user** (generates a password)
- `./setup.sh user` – step by step
- `docker compose exec ics-ranges-term ics-ranges-users add alice --role instructor --courses 613 --generate`

```bash
docker compose exec ics-ranges-term ics-ranges-users list
docker compose exec ics-ranges-term ics-ranges-users role alice viewer
docker compose exec ics-ranges-term ics-ranges-users courses alice 613,NetWars
docker compose exec ics-ranges-term ics-ranges-users passwd alice --generate
docker compose exec ics-ranges-term ics-ranges-users del alice
```

## Connect your Git repository (Gitea, GitHub, GitLab …)

pve-range saves add-ons, class guides and settings to a Git repository. To use one you
already have:

1. Create an **empty** repository (a README is fine), e.g. `pve-range`.
2. Create a token that may **write** to it:
   - Gitea: your user → Settings → Applications → token, *repository: Read and Write*
   - GitHub: Settings → Developer settings → Fine-grained token → *Contents: Read and write*
   - GitLab: Project → Settings → Access tokens → *write_repository*
3. Run:
   ```bash
   ./setup.sh repo
   ```
   Give the address (`https://gitea.lab/team/pve-range.git`), the branch, your user
   name and the token. It tests the connection first – if it fails, nothing is changed –
   then **uploads everything** (add-ons, class guides, settings and their history).
   From then on every change is sent there automatically.

- **Self-signed HTTPS** on your Gitea: it offers to connect without checking the
  certificate.
- **SSH address** (`git@host:team/pve-range.git`): it shows a key to add to the
  repository as a *deploy key with write access* – no token needed.
- `./setup.sh` (the full setup) offers this too.

**Test the backup:** `./gitea-backup-test.sh` saves a test script and test class notes,
checks they arrive in the repository byte for byte (with history), deletes them and
gets them back with `pve-range pull`, brings in a change made in Gitea, and removes
everything again. (On a Proxmox node in node mode: `./gitea-backup-test.sh --node`.)

## Optional: run a new Gitea here (bundled)

The easy way – everything is done for you:

```bash
./setup.sh gitea
```

It starts Gitea (already configured – no web installer), creates a Gitea **admin
account**, makes an **access token**, connects pve-range to it and does the first save,
which creates the private repository `<admin>/pve-range`. Then browse it at
`http://<docker-host>:3000` and sign in with that admin account.

`./setup.sh` (the full setup) also offers this as its last step. Gitea keeps running
with the other containers from then on (`COMPOSE_PROFILES=gitea` in `.env`).

## Updating

Replace `dist/pve-range.sh`, then `docker compose restart ics-ranges-dist` and run the
installer line on a node again.

### Uploads in the browser (version 2.3+)

The web page needs ttyd's upload option (`-t enableZmodem=true`) - included in this
zip. For an existing setup, rebuild with the new files: `docker compose up -d --build`.
The nodes need `lrzsz` (pve-range offers to install it) and `git` for the repository:
`apt-get install -y lrzsz git` on each node.

## Data and certificate

Everything lives in the `ics-ranges-term-data` volume: users, the SSH key the nodes
trust, known node host keys, the TLS certificate and `auth.log`. Back it up.

No browser warning: sign a certificate with the cluster's CA on a node and copy it in:

```bash
openssl req -new -newkey rsa:2048 -nodes -subj "/CN=ics-ranges-term" -keyout web.key -out web.csr
openssl x509 -req -in web.csr -CA /etc/pve/pve-root-ca.pem -CAkey /etc/pve/priv/pve-root-ca.key \
  -set_serial 0x$(openssl rand -hex 8) -days 397 -out web.crt \
  -extfile <(printf 'subjectAltName=IP:<docker-host-ip>\nextendedKeyUsage=serverAuth')
docker cp web.crt ics-ranges-term:/data/tls/cert.pem
docker cp web.key ics-ranges-term:/data/tls/key.pem
docker compose restart ics-ranges-term
```

Then import `/etc/pve/pve-root-ca.pem` into the browser as a trusted authority.

## Coming from pve-range-docker

Before this version the same thing was called pve-range-docker (containers `pve-range-web`,
`pve-range-dist`, volume `pve-range-docker_pve-range-web-data`). To move over with all users,
settings, add-ons, guides and history:

```bash
cd /opt && sudo unzip -o /tmp/ics-ranges-docker.zip
sudo cp /opt/pve-range-docker/.env /opt/ics-ranges-docker/.env
sudo chown -R $USER: /opt/ics-ranges-docker && cd /opt/ics-ranges-docker
./setup.sh migrate
```

It builds ICS Ranges Docker, stops the old containers, copies the old volumes into the new
ones and starts `ics-ranges-term`. The old volumes stay until you remove them. Your old token
(`pverange@pve!range=…`) keeps working.

It can run next to the ICS Ranges web app on the same host: the web app uses port 8443, this
one 7681 and 8080.
