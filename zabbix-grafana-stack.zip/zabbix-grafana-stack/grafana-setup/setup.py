#!/usr/bin/env python3
"""
One-time Grafana setup through its HTTP API. Safe to re-run:
    docker compose run --rm grafana-setup

  - creates (or updates) the instructor account as a Viewer
  - "Lab" folder (tabs 1-4): visible to admins and editors only
  - "ICS range" folder (tab 5): visible to the instructor, built from
    ics-range.template.json with ICS_RANGE_MATCH from .env
  - home dashboards: admins land on "1. Overview", the instructor on "5. ICS range"
"""
import base64, json, os, sys, time, urllib.request, urllib.error

GRAFANA = "http://grafana:3000"


def env(name):
    v = os.environ.get(name, "")
    if not v:
        sys.exit(f"[grafana-setup] ERROR: {name} is empty. Add it to .env")
    return v


ADMIN = (env("GRAFANA_ADMIN_USER"), env("GRAFANA_ADMIN_PASSWORD"))
INSTRUCTOR = (env("INSTRUCTOR_USER"), env("INSTRUCTOR_PASSWORD"))
ICS_MATCH = env("ICS_RANGE_MATCH")


def log(msg):
    print(f"[grafana-setup] {msg}", flush=True)


def api(method, path, body=None, auth=ADMIN, ok404=False):
    req = urllib.request.Request(GRAFANA + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None)
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Basic " + base64.b64encode(f"{auth[0]}:{auth[1]}".encode()).decode())
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        if ok404 and e.code == 404:
            return None
        sys.exit(f"[grafana-setup] ERROR: {method} {path} -> {e.code} {e.read().decode()[:300]}")


# ---------------------------------------------------------------- wait for Grafana
log("Waiting for Grafana...")
for _ in range(60):
    try:
        with urllib.request.urlopen(GRAFANA + "/api/health", timeout=5):
            break
    except Exception:
        time.sleep(5)
else:
    sys.exit("[grafana-setup] ERROR: Grafana did not start within 5 minutes")

# the provisioned "Lab" folder appears shortly after startup
for _ in range(30):
    if api("GET", "/api/folders/lab", ok404=True):
        break
    time.sleep(2)
else:
    sys.exit("[grafana-setup] ERROR: the provisioned 'Lab' folder never appeared. Check: docker compose logs grafana")

# ---------------------------------------------------------------- instructor account
user = api("GET", f"/api/users/lookup?loginOrEmail={INSTRUCTOR[0]}", ok404=True)
if user:
    uid = user["id"]
    api("PUT", f"/api/admin/users/{uid}/password", {"password": INSTRUCTOR[1]})
    log(f"Instructor '{INSTRUCTOR[0]}' exists; password synced from .env")
else:
    uid = api("POST", "/api/admin/users", {"name": "Instructor", "login": INSTRUCTOR[0],
                                           "password": INSTRUCTOR[1]})["id"]
    log(f"Created instructor account '{INSTRUCTOR[0]}'")
api("PATCH", f"/api/org/users/{uid}", {"role": "Viewer"})

# ---------------------------------------------------------------- folders and permissions
# Lab: admins (always) + editors. No general Viewer access, so the instructor can't see it.
api("POST", "/api/folders/lab/permissions", {"items": [{"role": "Editor", "permission": 2}]})
log("Lab folder: restricted to admins and editors")

if not api("GET", "/api/folders/ics-range", ok404=True):
    api("POST", "/api/folders", {"uid": "ics-range", "title": "ICS range"})
    log("Created 'ICS range' folder")
api("POST", "/api/folders/ics-range/permissions", {"items": [
    {"role": "Editor", "permission": 2},
    {"userId": uid, "permission": 1},          # view only
]})
log(f"ICS range folder: admins, editors and '{INSTRUCTOR[0]}' (view only)")

# ---------------------------------------------------------------- ICS range dashboard
template = open("/setup/ics-range.template.json").read()
dash = json.loads(template.replace("__ICS__", json.dumps(ICS_MATCH)[1:-1]))

if "apiVersion" in dash and "spec" in dash:
    # newer dashboard format (tabs layout), installed through Grafana's dashboards API
    base = f"/apis/{dash['apiVersion']}/namespaces/default/dashboards"
    dash["metadata"] = {"name": "ics-range", "annotations": {"grafana.app/folder": "ics-range"}}
    existing = api("GET", f"{base}/ics-range", ok404=True)
    if existing and existing.get("metadata", {}).get("resourceVersion"):
        dash["metadata"]["resourceVersion"] = existing["metadata"]["resourceVersion"]
        api("PUT", f"{base}/ics-range", dash)
    else:
        if api("GET", "/api/dashboards/uid/ics-range", ok404=True):
            api("DELETE", "/api/dashboards/uid/ics-range")      # old classic copy
        api("POST", base, dash)
else:
    api("POST", "/api/dashboards/db", {"dashboard": dash, "folderUid": "ics-range", "overwrite": True,
                                        "message": "grafana-setup"})
log(f"ICS range dashboard updated (guests whose name matches: {ICS_MATCH})")

# ---------------------------------------------------------------- home dashboards
try:
    HOME = open("/setup/home-dashboard.uid").read().strip() or "lab-overview"
except FileNotFoundError:
    HOME = "lab-overview"
api("PUT", "/api/org/preferences", {"homeDashboardUID": HOME})
api("PUT", "/api/user/preferences", {"homeDashboardUID": HOME})
api("PUT", "/api/user/preferences", {"homeDashboardUID": "ics-range"}, auth=INSTRUCTOR)
log(f"Home dashboards set: admins -> {HOME}, instructor -> ics-range")
log("Setup complete.")
