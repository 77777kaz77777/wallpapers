#!/bin/sh
# One-time Zabbix configuration through the API. Safe to run again:
#   docker compose run --rm zabbix-setup
#
# It creates or updates:
#   - the agentless "pve-cluster" host (Proxmox VE by HTTP + API token macros)
#   - autoregistration actions for Linux (linux-lab) and Windows (windows-lab)
#   - a read-only "grafana" Zabbix account used by the Grafana data source
#   - the built-in "Zabbix server" host, pointed at the agent container

set -u
API="http://zabbix-web:8080/api_jsonrpc.php"
TOKEN=""

log()  { echo "[setup] $*" >&2; }
fail() { log "ERROR: $*"; kill -TERM $$; exit 1; }

apk add --no-cache curl jq >/dev/null 2>&1 || fail "could not install curl and jq (no internet?)"

call() {  # call <method> <params-json>  -> raw JSON response
  body=$(jq -cn --arg m "$1" --argjson p "$2" '{jsonrpc:"2.0", method:$m, params:$p, id:1}')
  if [ -n "$TOKEN" ]; then
    curl -s -m 30 -H 'Content-Type: application/json-rpc' -H "Authorization: Bearer $TOKEN" -d "$body" "$API"
  else
    curl -s -m 30 -H 'Content-Type: application/json-rpc' -d "$body" "$API"
  fi
}

api() {   # api <method> <params-json>  -> .result, or abort
  out=$(call "$1" "$2")
  echo "$out" | jq -e 'has("result")' >/dev/null 2>&1 \
    || fail "$1 failed: $(echo "$out" | jq -c '.error' 2>/dev/null || echo "$out")"
  echo "$out" | jq -c '.result'
}

# ---------------------------------------------------------------- login
log "Waiting for the Zabbix API (first start can take a few minutes)..."
login=$(jq -cn --arg u "$ZBX_ADMIN_USER" --arg p "$ZBX_ADMIN_PASSWORD" '{username:$u, password:$p}')
i=0
while :; do
  out=$(call user.login "$login")
  if echo "$out" | jq -e '.result' >/dev/null 2>&1; then break; fi
  if echo "$out" | jq -r '.error.data // ""' 2>/dev/null | grep -qi 'password\|user name'; then
    fail "Zabbix rejected $ZBX_ADMIN_USER's password. Check ZBX_ADMIN_PASSWORD in .env."
  fi
  i=$((i + 1))
  [ "$i" -ge 60 ] && fail "the Zabbix API did not come up within 5 minutes. Last reply: $out"
  sleep 5
done
TOKEN=$(echo "$out" | jq -r '.result')
log "Logged in to Zabbix."

# ---------------------------------------------------------------- helpers
group_id() {   # name -> groupid, created if missing
  id=$(api hostgroup.get "$(jq -cn --arg n "$1" '{output:["groupid"], filter:{name:[$n]}}')" | jq -r '.[0].groupid // empty')
  if [ -z "$id" ]; then
    id=$(api hostgroup.create "$(jq -cn --arg n "$1" '{name:$n}')" | jq -r '.groupids[0]')
    log "Created host group '$1'"
  fi
  echo "$id"
}

template_id() {  # name -> templateid
  id=$(api template.get "$(jq -cn --arg n "$1" '{output:["templateid"], filter:{name:[$n]}}')" | jq -r '.[0].templateid // empty')
  [ -n "$id" ] || fail "template '$1' not found in Zabbix"
  echo "$id"
}

ensure_action() {  # name metadata groupid templates-json
  have=$(api action.get "$(jq -cn --arg n "$1" '{output:["actionid"], filter:{name:[$n]}}')" | jq -r '.[0].actionid // empty')
  if [ -n "$have" ]; then log "Action '$1' already exists"; return; fi
  api action.create "$(jq -cn --arg n "$1" --arg m "$2" --arg g "$3" --argjson t "$4" '{
      name:$n, eventsource:2, status:0,
      filter:{evaltype:0, conditions:[{conditiontype:24, operator:2, value:$m}]},
      operations:[
        {operationtype:2},
        {operationtype:4, opgroup:[{groupid:$g}]},
        {operationtype:6, optemplate:$t}
      ]}')" >/dev/null
  log "Created autoregistration action '$1' (host metadata contains '$2')"
}

# ---------------------------------------------------------------- groups and templates
PVE_GID=$(group_id "Proxmox")
LINUX_GID=$(group_id "Linux servers")
WIN_GID=$(group_id "Windows servers")

T_PVE=$(template_id "Proxmox VE by HTTP")
T_LINUX=$(template_id "Linux by Zabbix agent active")
T_SYSTEMD=$(template_id "Systemd by Zabbix agent 2")
T_WIN=$(template_id "Windows by Zabbix agent active")

# ---------------------------------------------------------------- Zabbix server host -> agent container
iface=$(api host.get '{"output":["hostid"],"filter":{"host":["Zabbix server"]},"selectInterfaces":["interfaceid"]}' \
        | jq -r '.[0].interfaces[0].interfaceid // empty')
if [ -n "$iface" ]; then
  api hostinterface.update "$(jq -cn --arg i "$iface" '{interfaceid:$i, useip:0, dns:"zabbix-agent"}')" >/dev/null
  log "Pointed the 'Zabbix server' host at the zabbix-agent container"
fi

# ---------------------------------------------------------------- Proxmox (agentless)
if [ -n "${PVE_HOST:-}" ] && [ -n "${PVE_TOKEN_SECRET:-}" ]; then
  macros=$(jq -cn --arg h "$PVE_HOST" --arg p "${PVE_PORT:-8006}" --arg id "$PVE_TOKEN_ID" --arg s "$PVE_TOKEN_SECRET" '[
      {macro:"{$PVE.URL.HOST}",     value:$h},
      {macro:"{$PVE.URL.PORT}",     value:$p},
      {macro:"{$PVE.TOKEN.ID}",     value:$id},
      {macro:"{$PVE.TOKEN.SECRET}", value:$s, type:1}]')
  hostid=$(api host.get '{"output":["hostid"],"filter":{"host":["pve-cluster"]}}' | jq -r '.[0].hostid // empty')
  if [ -z "$hostid" ]; then
    api host.create "$(jq -cn --arg g "$PVE_GID" --arg t "$T_PVE" --argjson m "$macros" '{
        host:"pve-cluster", groups:[{groupid:$g}], templates:[{templateid:$t}], macros:$m}')" >/dev/null
    log "Created host 'pve-cluster' (Proxmox API at $PVE_HOST:${PVE_PORT:-8006})"
  else
    api host.update "$(jq -cn --arg h "$hostid" --argjson m "$macros" '{hostid:$h, macros:$m}')" >/dev/null
    log "Updated 'pve-cluster' macros from .env"
  fi
else
  log "PVE_HOST or PVE_TOKEN_SECRET is empty in .env; skipping the Proxmox host."
fi

# ---------------------------------------------------------------- autoregistration
ensure_action "Auto-register Linux"   "linux-lab"   "$LINUX_GID" "[{\"templateid\":\"$T_LINUX\"},{\"templateid\":\"$T_SYSTEMD\"}]"
ensure_action "Auto-register Windows" "windows-lab" "$WIN_GID"   "[{\"templateid\":\"$T_WIN\"}]"

# ---------------------------------------------------------------- read-only account for Grafana
rights=$(api hostgroup.get '{"output":["groupid"]}' | jq -c '[.[] | {id:.groupid, permission:2}]')
ugid=$(api usergroup.get '{"output":["usrgrpid"],"filter":{"name":["Grafana"]}}' | jq -r '.[0].usrgrpid // empty')
if [ -z "$ugid" ]; then
  ugid=$(api usergroup.create "$(jq -cn --argjson r "$rights" '{name:"Grafana", hostgroup_rights:$r}')" | jq -r '.usrgrpids[0]')
  log "Created user group 'Grafana' with read access to all host groups"
else
  api usergroup.update "$(jq -cn --arg u "$ugid" --argjson r "$rights" '{usrgrpid:$u, hostgroup_rights:$r}')" >/dev/null
  log "Refreshed 'Grafana' read access to all current host groups"
fi

uid=$(api user.get "$(jq -cn --arg n "$ZBX_GRAFANA_USER" '{output:["userid"], filter:{username:[$n]}}')" | jq -r '.[0].userid // empty')
if [ -z "$uid" ]; then
  api user.create "$(jq -cn --arg n "$ZBX_GRAFANA_USER" --arg p "$ZBX_GRAFANA_PASSWORD" --arg g "$ugid" '{
      username:$n, passwd:$p, roleid:"1", usrgrps:[{usrgrpid:$g}]}')" >/dev/null
  log "Created read-only Zabbix user '$ZBX_GRAFANA_USER' for Grafana"
else
  log "Zabbix user '$ZBX_GRAFANA_USER' already exists"
fi

call user.logout '[]' >/dev/null 2>&1 || true
log "Setup complete."
