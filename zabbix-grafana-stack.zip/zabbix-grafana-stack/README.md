# Zabbix + Grafana lab stack

A complete, ready-to-run monitoring stack:

- **Zabbix 7.0 LTS**: server, web UI, PostgreSQL, and an agent that monitors the Zabbix server itself
- **Grafana** with the Zabbix plugin, data source and the *Proxmox overview (agentless)* dashboard preloaded
- **Tabbed dashboards** in Grafana, plus a default **instructor** account limited to the ICS range
- **Automatic Zabbix setup**: agentless Proxmox host, autoregistration for Linux and Windows agents, and a read-only account for Grafana
- **Optional InfluxDB** for high-resolution Proxmox metrics

## Requirements

- A Linux machine (VM or LXC) with Docker and Docker Compose v2.
  - In a Proxmox LXC, tick **Options → Features → nesting** and **keyctl**.
  - 2 CPU cores and 4 GB RAM is a good start.
- Internet access on first start, to download images and the Grafana plugin.
- Ports **8080** (Zabbix web), **3000** (Grafana) and **10051** (agents) free on that machine.

Run this on a **new** machine, not on your existing Zabbix LXC: both would try to use port 10051.

## 1. Create a Proxmox API token

On any Proxmox node's shell:

```bash
pveum user add zabbix@pve --comment "Zabbix monitoring"
pveum aclmod / -user zabbix@pve -role PVEAuditor
pveum user token add zabbix@pve monitoring --privsep 0
```

Copy the secret it prints. Proxmox only shows it once.

## 2. Edit `.env`

Open `.env` and set:

- every value containing `CHANGE_ME` (including `INSTRUCTOR_PASSWORD`)
- `ICS_RANGE_MATCH` if your ICS servers aren't named `612-...` / `613-...`
- `PVE_HOST`: the IP of any Proxmox node
- `PVE_TOKEN_SECRET`: the secret from step 1

Don't use the `$` character in passwords.

## 3. Start it

```bash
docker compose up -d
docker compose logs -f zabbix-setup
```

The first start takes a few minutes while Zabbix creates its database. Wait for `[setup] Setup complete.`, then press Ctrl+C.

| | Address | Login |
|---|---|---|
| Zabbix | `http://<this-host>:8080` | `Admin` / `zabbix` |
| Grafana | `http://<this-host>:3000` | `GRAFANA_ADMIN_USER` / `GRAFANA_ADMIN_PASSWORD` from `.env` |

**Change the Zabbix Admin password** in the web UI (User settings → Profile), then update `ZBX_ADMIN_PASSWORD` in `.env` so re-running setup still works.

Grafana opens on the **Proxmox overview** dashboard. Proxmox data appears within a few minutes, once Zabbix's discovery has run.

## 4. Add agents (optional)

Point agents at **this machine's IP**:

```ini
Server=<this-host-ip>
ServerActive=<this-host-ip>
Hostname=<unique-name>
HostMetadata=linux-lab        # or windows-lab
```

They register automatically:

- **Linux** hosts get *Linux by Zabbix agent active* and *Systemd by Zabbix agent 2*, in the *Linux servers* group.
- **Windows** hosts get *Windows by Zabbix agent active*, in the *Windows servers* group.

## 5. Optional: high-resolution metrics with InfluxDB

```bash
docker compose --profile influx up -d
```

Then, in the Proxmox web UI, go to **Datacenter → Metric Server → Add → InfluxDB**:

| Field | Value |
|---|---|
| Server | this machine's IP |
| Port | `8086` |
| Protocol | HTTP |
| Organization | `INFLUX_ORG` from `.env` |
| Bucket | `INFLUX_BUCKET` from `.env` |
| Token | `INFLUX_TOKEN` from `.env` |

Grafana already has an **InfluxDB (Proxmox)** data source pointing at it.

## The dashboards (tab view)

Grafana uses its built-in tabs layout.

**Proxmox overview** (admins and editors; the admin home page):

| Tab | Shows |
|---|---|
| **Is anything wrong?** | Current Zabbix problems and the running state of every guest |
| **Proxmox nodes** | Node CPU, memory and uptime |
| **VMs and containers** | Per-guest CPU, memory, network in/out and disk I/O, with a **Guest** dropdown |
| **Storage** | Space used per storage pool |

**ICS range** (instructor, admins and editors; the instructor's home page):

| Tab | Shows |
|---|---|
| **Is anything wrong?** | Problems and running state for ICS range servers only |
| **ICS servers** | CPU, memory, network and disk for ICS range servers, with an **ICS server** dropdown |

Red markers on graphs show when Zabbix problems started. **Ctrl+click** any graph to add your own note, such as "capture started".

**If the tabbed dashboard fails to load** (check `docker compose logs grafana | grep -i dashboard`), a classic non-tabbed version is kept in `grafana/dashboards-classic/`. Copy its `*.json` files into `grafana/dashboards/`, remove `proxmox-overview.json`, and restart Grafana.

## The instructor account

Created automatically as a Grafana **Viewer**, using `INSTRUCTOR_USER` and `INSTRUCTOR_PASSWORD` from `.env`.

- Lands on the **ICS range** dashboard and can't open **Proxmox overview**.
- Can't edit dashboards or use Explore.

**Which servers count as the ICS range** is set by `ICS_RANGE_MATCH` in `.env`, a pattern matched against guest names. The default, `61[23]-`, matches names starting with `612-` or `613-`. After changing it, run:

```bash
docker compose run --rm grafana-setup
```

**What the restriction covers:** in Grafana's free edition, permissions apply to dashboards and folders, not to data sources. The instructor can't browse or open the other dashboards, but someone calling Grafana's API directly could still query any Proxmox data. Data-source-level permissions need Grafana Enterprise.

## Upgrading from the previous version

1. Copy the new files over your stack folder, **keeping your existing `.env`**. If your `.env` doesn't yet have `INSTRUCTOR_USER`, `INSTRUCTOR_PASSWORD` and `ICS_RANGE_MATCH`, add them from the new one.
2. Remove the old dashboard files so only the tabbed one is loaded:
   ```bash
   rm -f grafana/dashboards/1-*.json grafana/dashboards/2-*.json grafana/dashboards/3-*.json grafana/dashboards/4-*.json
   rm -f grafana/dashboards/proxmox-overview.json.bak capture-tabs.py
   ls grafana/dashboards/        # should list only proxmox-overview.json
   ```
3. Apply:
   ```bash
   docker compose up -d
   docker compose restart grafana
   docker compose run --rm grafana-setup
   ```
4. In Grafana, delete any leftover dashboards from earlier versions, such as **Proxmox overview (agentless)** or **1. Overview**.

## Everyday commands

```bash
docker compose ps                          # status
docker compose logs -f zabbix-server       # Zabbix server log
docker compose run --rm zabbix-setup       # re-run Zabbix setup (after editing .env)
docker compose run --rm grafana-setup      # re-run Grafana setup (instructor, ICS range)
docker compose pull && docker compose up -d   # update images
docker compose down                        # stop (data is kept)
```

### Back up

```bash
docker compose exec postgres pg_dump -U zabbix zabbix | gzip > zabbix-$(date +%F).sql.gz
```

## Troubleshooting

| Symptom | What to check |
|---|---|
| Setup says Zabbix rejected the password | `ZBX_ADMIN_PASSWORD` in `.env` must match the real Admin password. |
| `pve-cluster` items show errors | Test from this machine: `curl -k -H 'Authorization: PVEAPIToken=<ID>=<SECRET>' https://<PVE_HOST>:8006/api2/json/cluster/resources`. An empty `data` list means the token lacks permissions. |
| Grafana panels are empty | Check Zabbix first: Monitoring → Latest data → `pve-cluster` should show recent values. Then in Grafana, open a panel's **⋮ → Inspect → Query** and look at the response. |
| A new host group isn't visible in Grafana | Re-run setup. It refreshes the Grafana account's read access to all host groups. |
| Agents don't register | Port 10051 must be reachable on this machine, and `HostMetadata` must contain `linux-lab` or `windows-lab`. |
