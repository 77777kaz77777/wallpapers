# Zabbix + Grafana lab stack

A complete, ready-to-run monitoring stack:

- **Zabbix 7.0 LTS**: server, web UI, PostgreSQL, and an agent that monitors the Zabbix server itself
- **Grafana** with the Zabbix plugin, data source and the *Proxmox overview (agentless)* dashboard preloaded
- **Automatic Zabbix setup**: agentless Proxmox host, autoregistration for Linux and Windows agents, and a read-only account for Grafana
- **Optional InfluxDB** for high-resolution Proxmox metrics

## Requirements

- A Linux machine (VM or LXC) with Docker and Docker Compose v2.
  - In a Proxmox LXC, tick **Options → Features → nesting** and **keyctl**.
  - 2 CPU cores and 4 GB RAM is a good start.
- Internet access on first start, to download images and the Grafana plugin.
- Ports **8080** (Zabbix web), **3000** (Grafana) and **10051** (agents) free on that machine.

Run this on a **new** machine, not on your existing Zabbix LXC: both would try to use port 10051.

## 1. Create a Proxmox API token

On any Proxmox node's shell:

```bash
pveum user add zabbix@pve --comment "Zabbix monitoring"
pveum aclmod / -user zabbix@pve -role PVEAuditor
pveum user token add zabbix@pve monitoring --privsep 0
```

Copy the secret it prints. Proxmox only shows it once.

## 2. Edit `.env`

Open `.env` and set:

- every value containing `CHANGE_ME`
- `PVE_HOST`: the IP of any Proxmox node
- `PVE_TOKEN_SECRET`: the secret from step 1

Don't use the `$` character in passwords.

## 3. Start it

```bash
docker compose up -d
docker compose logs -f zabbix-setup
```

The first start takes a few minutes while Zabbix creates its database. Wait for `[setup] Setup complete.`, then press Ctrl+C.

| | Address | Login |
|---|---|---|
| Zabbix | `http://<this-host>:8080` | `Admin` / `zabbix` |
| Grafana | `http://<this-host>:3000` | `GRAFANA_ADMIN_USER` / `GRAFANA_ADMIN_PASSWORD` from `.env` |

**Change the Zabbix Admin password** in the web UI (User settings → Profile), then update `ZBX_ADMIN_PASSWORD` in `.env` so re-running setup still works.

Grafana opens straight onto the dashboard. Proxmox data appears within a few minutes, once Zabbix's discovery has run.

## 4. Add agents (optional)

Point agents at **this machine's IP**:

```ini
Server=<this-host-ip>
ServerActive=<this-host-ip>
Hostname=<unique-name>
HostMetadata=linux-lab        # or windows-lab
```

They register automatically:

- **Linux** hosts get *Linux by Zabbix agent active* and *Systemd by Zabbix agent 2*, in the *Linux servers* group.
- **Windows** hosts get *Windows by Zabbix agent active*, in the *Windows servers* group.

## 5. Optional: high-resolution metrics with InfluxDB

```bash
docker compose --profile influx up -d
```

Then, in the Proxmox web UI, go to **Datacenter → Metric Server → Add → InfluxDB**:

| Field | Value |
|---|---|
| Server | this machine's IP |
| Port | `8086` |
| Protocol | HTTP |
| Organization | `INFLUX_ORG` from `.env` |
| Bucket | `INFLUX_BUCKET` from `.env` |
| Token | `INFLUX_TOKEN` from `.env` |

Grafana already has an **InfluxDB (Proxmox)** data source pointing at it.

## The dashboard

- **Is anything wrong?** Current Zabbix problems and the running state of every VM and container.
- **Proxmox nodes:** CPU, memory and uptime.
- **VMs and containers:** CPU, memory, network in/out and disk I/O, as measured by the hypervisor (no agents in the guests).
- **Storage:** space used per storage pool.
- **Guest dropdown** at the top: pick one VM or container, or *All*.
- **Red markers** on graphs: when Zabbix problems started.
- **Ctrl+click** on any graph to add your own note, for example "capture started".

The dashboard is in the **Lab** folder. You can edit and save it in Grafana. To reset it, delete it in Grafana and restart the `grafana` service.

## Everyday commands

```bash
docker compose ps                          # status
docker compose logs -f zabbix-server       # Zabbix server log
docker compose run --rm zabbix-setup       # re-run setup (after editing .env)
docker compose pull && docker compose up -d   # update images
docker compose down                        # stop (data is kept)
```

### Back up

```bash
docker compose exec postgres pg_dump -U zabbix zabbix | gzip > zabbix-$(date +%F).sql.gz
```

## Troubleshooting

| Symptom | What to check |
|---|---|
| Setup says Zabbix rejected the password | `ZBX_ADMIN_PASSWORD` in `.env` must match the real Admin password. |
| `pve-cluster` items show errors | Test from this machine: `curl -k -H 'Authorization: PVEAPIToken=<ID>=<SECRET>' https://<PVE_HOST>:8006/api2/json/cluster/resources`. An empty `data` list means the token lacks permissions. |
| Grafana panels are empty | Check Zabbix first: Monitoring → Latest data → `pve-cluster` should show recent values. Then in Grafana, open a panel's **⋮ → Inspect → Query** and look at the response. |
| A new host group isn't visible in Grafana | Re-run setup. It refreshes the Grafana account's read access to all host groups. |
| Agents don't register | Port 10051 must be reachable on this machine, and `HostMetadata` must contain `linux-lab` or `windows-lab`. |
