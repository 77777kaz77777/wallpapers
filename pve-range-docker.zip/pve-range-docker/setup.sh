#!/usr/bin/env bash
# setup.sh - set up or change .env for pve-range in Docker / Podman (container mode)
#
#   ./setup.sh          step by step: API, token, addresses, start, first user, Gitea
#   ./setup.sh token    only change the API token
#   ./setup.sh test     only test the API connection with what's in .env
#   ./setup.sh user     add a web user: role and the class folders they may use
#   ./setup.sh roles    see / create / change roles (what each role may do)
#   ./setup.sh theme    colours: sans (SANS-style navy and red) or midnight
#   ./setup.sh repo     connect pve-range to YOUR Git repository (Gitea, GitHub, GitLab ...)
#                       with an access token, and upload everything to it
#   ./setup.sh gitea    alternative: run a bundled Gitea in Docker and connect to that
set -u
cd "$(dirname "$0")" || exit 1
ENVF=.env
[[ -f $ENVF ]] || { cp .env.example "$ENVF" 2>/dev/null || : >"$ENVF"; echo "Created $ENVF from .env.example"; }
chmod 600 "$ENVF"

B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'
[[ -t 1 ]] || B="" G="" R="" Y="" Z=""

getv() { grep -m1 "^$1=" "$ENVF" | cut -d= -f2-; }
setv() {   # KEY VALUE  - replace or add, no matter what characters the value has
    local tmp
    tmp=$(mktemp)
    awk -v k="$1" -v v="$2" 'BEGIN {done = 0}
        index($0, k "=") == 1 {print k "=" v; done = 1; next} {print}
        END {if (!done) print k "=" v}' "$ENVF" >"$tmp" && cat "$tmp" >"$ENVF"
    rm -f "$tmp"
}
ask() {    # PROMPT DEFAULT -> answer (default on Enter)
    local a
    read -rp "$1 [${2}]: " a
    echo "${a:-$2}"
}
host_ip() {
    local a
    a=$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)
    [[ -n $a ]] || a=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "${a:-127.0.0.1}"
}
compose() {
    if docker compose version >/dev/null 2>&1; then docker compose "$@"
    elif podman compose version >/dev/null 2>&1; then podman compose "$@"
    else docker-compose "$@"; fi
}

cexec() { if [[ -t 0 ]]; then compose exec "$@"; else compose exec -T "$@"; fi; }   # interactive when possible
has_users() { compose exec -T pve-range-web sh -c '[ -s /data/users ]' 2>/dev/null; }
startup_log() { compose logs pve-range-web 2>/dev/null | grep -v ' N: ' | tail -n "${1:-30}"; }

# test_api TOKEN URLS -> 0 if one of the addresses accepts the token
test_api() {
    local tok=$1 url out code
    for url in ${2//,/ }; do
        out=$(curl -sk --connect-timeout 5 --max-time 15 -w '\n%{http_code}' \
            -H "Authorization: PVEAPIToken=$tok" "${url%/}/api2/json/version" 2>&1)
        code=${out##*$'\n'}
        case $code in
            200) echo "  ${G}OK${Z}  $url - Proxmox $(sed -n 's/.*"version" *: *"\([^"]*\)".*/\1/p' <<<"${out%$'\n'*}")"; return 0 ;;
            401) echo "  ${R}token refused${Z} by $url (wrong token, or it was deleted)" ;;
            000) echo "  ${Y}no answer${Z} from $url (wrong address, or port 8006 blocked)" ;;
            *) echo "  ${R}HTTP $code${Z} from $url" ;;
        esac
    done
    return 1
}

# Make the API user, rights and token on a node over SSH (asks for root's password)
create_token() {
    local node out tid val
    node=$(ask "  Node to create it on (IP or name)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    echo "  Connecting to root@$node - it may ask for root's password once."
    echo "  ${Y}If a 'range' token already exists for pverange@pve it is replaced (the old one stops working).${Z}"
    read -rp "  Continue? [y/N] " a
    [[ $a == [yY]* ]] || return 1
    out=$(ssh -o ConnectTimeout=10 "root@$node" '
        pveum user add pverange@pve --comment "pve-range container" 2>/dev/null
        pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor || exit 1
        pveum user token remove pverange@pve range 2>/dev/null
        pveum user token add pverange@pve range --privsep 0 --output-format json') || {
        echo "  ${R}Could not create the token on $node.${Z}"; return 1; }
    tid=$(grep -o '"full-tokenid" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    val=$(grep -o '"value" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    [[ -n $tid && -n $val ]] || { echo "  ${R}Unexpected answer:${Z} $out"; return 1; }
    TOKEN="$tid=$val"
    echo "  ${G}Created${Z} $tid"
}

set_token() {
    local cur choice
    cur=$(getv PVE_API_TOKEN)
    echo
    local shown="not set"
    [[ -n $cur ]] && shown="${cur%%=*}=****"
    echo "${B}Proxmox API token${Z}  (now: $shown)"
    echo "  1) Paste a token I already have   (looks like  pverange@pve!range=xxxxxxxx-xxxx-...)"
    echo "  2) Create one now on a node over SSH (needs root's password once)"
    echo "  3) Keep the current one"
    read -rp "Choose [1-3]: " choice
    TOKEN=""
    case $choice in
        1)
            read -rsp "  Paste the token (hidden): " TOKEN; echo
            TOKEN=$(tr -d '[:space:]' <<<"$TOKEN")
            [[ $TOKEN =~ ^[^@!=]+@[^!=]+![^=]+=.+$ ]] || {
                echo "  ${R}That doesn't look like USER@REALM!NAME=SECRET.${Z}"; return 1; }
            ;;
        2) create_token || return 1 ;;
        *) return 0 ;;
    esac
    echo "  Testing it ..."
    if ! test_api "$TOKEN" "$(getv PVE_API_URL)"; then
        read -rp "  It didn't work with the addresses in .env. Save it anyway? [y/N] " a
        [[ $a == [yY]* ]] || return 1
    fi
    setv PVE_API_TOKEN "$TOKEN"
    chmod 600 "$ENVF"
    echo "  ${G}Saved in $ENVF${Z} (readable by root only)"
    CHANGED=1
}

apply() {
    ((CHANGED)) || return 0
    read -rp "Start / restart the containers now so the change is used? [Y/n] " a
    [[ $a == [nN]* ]] && { echo "Later: docker compose up -d"; return 1; }
    compose up -d --build || return 1
    sleep 4
    startup_log 25
}

# The first (or another) sign-in for the browser menu
web_user() {
    local name
    echo
    if has_users; then
        echo "${B}New web user${Z} - pick a role (instructor / viewer / admin) and their folders"
        cexec pve-range-web pve-range-web-users new
    else
        echo "${B}First web user${Z} - an ${B}admin${Z}; admins can add more users from the menu (General -> Users)"
        name=$(ask "  User name" "admin")
        [[ $name =~ ^[A-Za-z0-9_.-]{1,32}$ ]] || { echo "  ${R}Letters, digits, . _ - only.${Z}"; return 1; }
        cexec pve-range-web pve-range-web-users add "$name" --role admin
    fi
    compose exec -T pve-range-web pve-range-web-users list
}

theme_setup() {
    local v
    v=$(ask "Colour theme - sans (SANS-style navy and red) or midnight (dark)" "$(getv WEB_THEME | sed 's/^$/sans/')")
    [[ $v == sans || $v == midnight ]] || { echo "  Use sans or midnight."; return 1; }
    [[ $v != "$(getv WEB_THEME)" ]] && { setv WEB_THEME "$v"; CHANGED=1; }
    # the menu's own theme setting too (Settings -> Colour theme)
    compose exec -T -u pverange pve-range-web sh -c "f=/data/conf/settings.conf; mkdir -p /data/conf; touch \$f
        grep -v '^THEME=' \$f >\$f.n; echo THEME=$v >>\$f.n; mv \$f.n \$f" 2>/dev/null || true
}

roles_setup() {
    local c n
    while :; do
        echo
        compose exec -T pve-range-web pve-range roles list
        echo
        echo "  1) New role     2) Change a role     3) Show a role     4) Delete a role     5) Done"
        read -rp "  Choose [5]: " c
        case ${c:-5} in
            1) cexec pve-range-web pve-range roles new ;;
            2) read -rp "  Role name: " n; cexec pve-range-web pve-range roles edit "$n" ;;
            3) read -rp "  Role name: " n; compose exec -T pve-range-web pve-range roles show "$n" ;;
            4) read -rp "  Role name: " n; compose exec -T pve-range-web pve-range roles del "$n" ;;
            *) return 0 ;;
        esac
    done
}

# Run a command in the web container as the service user
cxs() { compose exec -T -u pverange pve-range-web sh -c "$1"; }

# An existing repository: address + token -> test -> upload everything
repo_external() {
    local cur url user tok branch auth test_out a insecure=0 key
    echo
    echo "${B}Git repository${Z} - pve-range saves add-ons, class guides and settings there"
    echo "  Works with Gitea, GitHub, GitLab or any Git server. Create an EMPTY repository first"
    echo "  (or one with just a README) and a token that may write to it:"
    echo "    Gitea : your user -> Settings -> Applications -> token, repository: Read and Write"
    echo "    GitHub: Settings -> Developer settings -> Fine-grained token -> Contents: Read and write"
    echo "    GitLab: Project -> Settings -> Access tokens -> write_repository"
    echo
    cur=$(cxs 'grep -h "^REPO_URL=" /data/share/save.conf 2>/dev/null' | cut -d= -f2-)
    url=$(ask "  Repository address (https://gitea.lab/team/pve-range.git or git@host:team/pve-range.git)" "$cur")
    url=$(tr -d '[:space:]' <<<"$url")
    [[ $url =~ ^(https?://[^/]+/.+|git@[^:]+:.+|ssh://.+)$ ]] || { echo "  ${R}That doesn't look like a repository address.${Z}"; return 1; }
    branch=$(ask "  Branch" "main")

    # keep the old settings until the new ones work
    cxs 'mkdir -p /data/share /data/priv; touch /data/share/save.conf
         cp /data/share/save.conf /data/share/save.conf.before
         cp /data/priv/pve-range-repo.token /data/priv/repo.token.before 2>/dev/null || rm -f /data/priv/repo.token.before'

    if [[ $url == http* ]]; then
        user=$(ask "  User name on that server (GitLab: any name, e.g. oauth2)" "$(cxs 'grep -h "^REPO_USER=" /data/share/save.conf 2>/dev/null' | cut -d= -f2-)")
        [[ -n $user ]] || { echo "  ${R}A user name is needed.${Z}"; return 1; }
        read -rsp "  Access token (hidden): " tok; echo
        tok=$(tr -d '[:space:]' <<<"$tok")
        [[ -n $tok ]] || { echo "  ${R}No token given.${Z}"; return 1; }
        printf '%s\n' "$tok" | cxs 'umask 077; cat >/data/priv/pve-range-repo.token'
        auth="${url%%://*}://$user@${url#*://}"
    else
        user=""
        key=$(cxs '[ -f /data/ssh/git_ed25519 ] || ssh-keygen -q -t ed25519 -N "" -C pve-range-git -f /data/ssh/git_ed25519; cat /data/ssh/git_ed25519.pub')
        echo
        echo "  Add this key to the repository as a ${B}deploy key with write access${Z}:"
        echo
        echo "  $key"
        echo
        read -rp "  Press Enter when it's added ... " _
        auth=$url
    fi

    save_repo_conf() {   # insecure
        cxs "f=/data/share/save.conf
             for kv in 'REPO_URL=$url' 'REPO_USER=$user' 'REPO_BRANCH=$branch' 'AUTO_PUSH=1' 'REPO_INSECURE=$1'; do
                 k=\${kv%%=*}; grep -v \"^\$k=\" \"\$f\" >\"\$f.new\"; echo \"\$kv\" >>\"\$f.new\"; mv \"\$f.new\" \"\$f\"
             done"
    }
    test_repo() {   # insecure -> prints git's answer, 0 = token and address work
        cxs "a=\$(mktemp); printf '#!/bin/sh\\ncat /data/priv/pve-range-repo.token\\n' >\$a; chmod 700 \$a
             GIT_TERMINAL_PROMPT=0 GIT_ASKPASS=\$a \
             GIT_SSH_COMMAND='ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o IdentitiesOnly=yes -i /data/ssh/git_ed25519' \
             git -c http.sslVerify=\$([ $1 = 1 ] && echo false || echo true) ls-remote '$auth' 2>&1; r=\$?; rm -f \$a; exit \$r"
    }

    echo "  Testing the connection ..."
    if ! test_out=$(test_repo 0); then
        if grep -qi 'certificate' <<<"$test_out"; then
            echo "  ${Y}The server's HTTPS certificate isn't trusted (self-signed?).${Z}"
            read -rp "  Connect anyway without checking the certificate (lab use)? [y/N] " a
            [[ $a == [yY]* ]] && insecure=1 && test_out=$(test_repo 1)
        fi
    fi
    if ! test_repo "$insecure" >/dev/null 2>&1; then
        echo "  ${R}Can't connect:${Z}"
        tail -3 <<<"$test_out" | sed 's/^/    /'
        echo "  Check the address, user name and token (it needs WRITE access). Nothing was changed."
        cxs 'mv -f /data/share/save.conf.before /data/share/save.conf
             if [ -f /data/priv/repo.token.before ]; then mv -f /data/priv/repo.token.before /data/priv/pve-range-repo.token; else rm -f /data/priv/pve-range-repo.token; fi'
        return 1
    fi
    echo "  ${G}Connection OK${Z}$( ((insecure)) && echo ' (certificate not checked)')"
    save_repo_conf "$insecure"
    cxs 'rm -f /data/share/save.conf.before /data/priv/repo.token.before'

    echo "  Uploading everything (add-ons, class guides, settings, history) ..."
    out=$(compose exec -T pve-range-web pve-range save "Connected to $url" 2>&1)
    echo "$out" | sed 's/^/    /'
    if grep -q '^Pushed to' <<<"$out"; then
        echo "  ${G}Done.${Z} From now on every change is sent there automatically."
    else
        echo "  ${R}The upload failed${Z} - the settings are kept; fix the problem and run: ./setup.sh repo"
        return 1
    fi
}

# Bundled Gitea: start it, admin user, token, connect pve-range, first save
gitea_setup() {
    local ip port url gu gp gp2 ge tok out
    ip=$(host_ip)
    port=$(getv GITEA_PORT); port=${port:-3000}
    echo
    echo "${B}Gitea${Z} - your own Git server for add-ons, class guides and settings"
    [[ $(getv COMPOSE_PROFILES) == *gitea* ]] || setv COMPOSE_PROFILES gitea
    [[ -n $(getv GITEA_URL) && $(getv GITEA_URL) != *192.168.77.91* ]] || setv GITEA_URL "http://$ip:$port/"
    setv GITEA_DOMAIN "$ip"
    echo "  Starting Gitea ..."
    compose up -d gitea || { echo "  ${R}Gitea didn't start.${Z}"; return 1; }
    for _ in $(seq 1 60); do
        curl -sf "http://127.0.0.1:$port/api/healthz" >/dev/null 2>&1 && break
        sleep 2
    done
    curl -sf "http://127.0.0.1:$port/api/healthz" >/dev/null 2>&1 || { echo "  ${R}Gitea isn't answering on port $port.${Z}"; return 1; }
    echo "  ${G}Gitea is up${Z} at http://$ip:$port"

    echo "  Gitea admin account (you sign in to Gitea with it; 'admin' is reserved by Gitea):"
    gu=$(ask "    User name" "range-admin")
    [[ $gu =~ ^[A-Za-z0-9_.-]{2,40}$ && $gu != admin ]] || { echo "  ${R}Choose another name.${Z}"; return 1; }
    if compose exec -T -u git gitea gitea admin user list 2>/dev/null | awk 'NR > 1 {print $2}' | grep -qx "$gu"; then
        echo "  $gu already exists in Gitea - keeping its password."
    else
        while :; do
            read -rsp "    Password (min. 8): " gp; echo
            read -rsp "    Repeat: " gp2; echo
            [[ ${#gp} -ge 8 && $gp == "$gp2" ]] && break
            echo "    Too short or not the same."
        done
        ge=$(ask "    E-mail (only used inside Gitea)" "$gu@pve-range.local")
        if ! out=$(compose exec -T -u git gitea gitea admin user create --username "$gu" --password "$gp" \
            --email "$ge" --admin --must-change-password=false 2>&1); then
            echo "  ${R}Could not create the user:${Z} $out"; return 1
        fi
        echo "  ${G}Created${Z} Gitea admin $gu"
    fi

    tok=$(compose exec -T -u git gitea gitea admin user generate-access-token --username "$gu" \
        --token-name "pve-range-$(date +%Y%m%d-%H%M%S)" --scopes write:repository --raw 2>&1 | tail -1 | tr -d '\r ')
    [[ $tok =~ ^[0-9a-f]{40}$ ]] || { echo "  ${R}Could not create a token:${Z} $tok"; return 1; }
    echo "  ${G}Created${Z} an access token (repository read/write)"

    # Connect pve-range (inside the Docker network Gitea is "gitea:3000")
    url="http://gitea:3000/$gu/pve-range.git"
    compose exec -T -u pverange pve-range-web sh -c '
        f=/data/share/save.conf; mkdir -p /data/share; touch "$f"
        for kv in "REPO_URL='"$url"'" "REPO_USER='"$gu"'" "REPO_BRANCH=main" "AUTO_PUSH=1"; do
            k=${kv%%=*}; grep -v "^$k=" "$f" >"$f.new"; echo "$kv" >>"$f.new"; mv "$f.new" "$f"
        done' || { echo "  ${R}Could not save the repository settings.${Z}"; return 1; }
    printf '%s\n' "$tok" | compose exec -T -u pverange pve-range-web sh -c 'umask 077; cat >/data/priv/pve-range-repo.token'
    echo "  First save (creates the private repository $gu/pve-range) ..."
    out=$(compose exec -T pve-range-web pve-range save "Connected to Gitea" 2>&1)
    echo "$out" | sed 's/^/    /'
    if curl -sf -H "Authorization: token $tok" "http://127.0.0.1:$port/api/v1/repos/$gu/pve-range" >/dev/null; then
        echo "  ${G}Connected.${Z} Browse it: http://$ip:$port/$gu/pve-range  (sign in as $gu)"
    else
        echo "  ${R}The repository wasn't created - see the save output above.${Z}"; return 1
    fi
}

CHANGED=0
PORT=$(getv PORT)
case ${1:-all} in
    user) web_user; exit ;;
    roles) roles_setup; exit ;;
    theme) theme_setup && apply; exit ;;
    repo) repo_external; exit ;;
    gitea) gitea_setup; exit ;;
    test)
        test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
        exit $?
        ;;
    token)
        set_token
        apply
        exit 0
        ;;
esac

echo "${B}pve-range - container mode setup${Z}  (writes $ENVF; Enter keeps the value in brackets)"
echo
ipd=$(host_ip)
v=$(ask "Proxmox API address(es), space-separated" "$(getv PVE_API_URL)")
w=""
for u in ${v//,/ }; do   # 192.168.77.77 -> https://192.168.77.77:8006
    if [[ $u != *://* ]]; then if [[ $u == *:* ]]; then u="https://$u"; else u="https://$u:8006"; fi; fi
    w+="$u "
done
v=${w% }
[[ $v != "$(getv PVE_API_URL)" ]] && { setv PVE_API_URL "$v"; CHANGED=1; }
set_token
v=$(ask "This Docker host's IP (the nodes see connections from it)" "$(getv KEY_FROM | sed "s/^$/$ipd/")")
[[ $v != "$(getv KEY_FROM)" ]] && { setv KEY_FROM "$v"; CHANGED=1; }
v=$(ask "Download page address" "$(getv DIST_URL | sed "s#^\$#http://$ipd:8080#")")
[[ $v != "$(getv DIST_URL)" ]] && { setv DIST_URL "$v"; CHANGED=1; }
theme_setup
if [[ -n $(getv PVE_NODES) ]]; then
    read -rp "Node mode is also set (PVE_NODES). Clear it so container mode is used? [Y/n] " a
    [[ $a == [nN]* ]] || { setv PVE_NODES ""; CHANGED=1; }
fi
echo
echo "${B}Git repository${Z} for add-ons, class guides and settings (optional, can be done later):"
echo "  1) Connect to MY repository (Gitea, GitHub, GitLab ...) with a token - upload everything"
echo "  2) Run a new Gitea here in Docker and connect to that"
echo "  3) Not now"
read -rp "Choose [1-3]: " a
want_repo=0 want_gitea=0
case $a in
    1) want_repo=1 ;;
    2) want_gitea=1; setv COMPOSE_PROFILES gitea; CHANGED=1 ;;
esac
echo
echo "${B}Check:${Z}"
test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
echo
apply || true
if compose ps --status running 2>/dev/null | grep -q pve-range-web; then
    if has_users; then
        read -rp "Add another web user? [y/N] " a
        [[ $a == [yY]* ]] && web_user
    else
        echo "${Y}No web users yet - you need one to sign in.${Z}"
        web_user
    fi
    ((want_repo)) && repo_external
    ((want_gitea)) && gitea_setup
    ip=$(host_ip)
    echo
    echo "${B}Done.${Z}"
    echo "  pve-range menu : https://$ip:${PORT:-7681}"
    echo "  User guide     : $(getv DIST_URL)"
    ((want_gitea)) && echo "  Gitea          : http://$ip:$(getv GITEA_PORT | sed 's/^$/3000/')"
    echo "  Test everything: ./docker-test.sh"
fi
