#!/usr/bin/env bash
# setup.sh - set up or change .env for pve-range in Docker / Podman (container mode)
#
#   ./setup.sh          step by step: API address, API token, addresses, start
#   ./setup.sh token    only change the API token
#   ./setup.sh test     only test the API connection with what's in .env
set -u
cd "$(dirname "$0")" || exit 1
ENVF=.env
[[ -f $ENVF ]] || { cp .env.example "$ENVF" 2>/dev/null || : >"$ENVF"; echo "Created $ENVF from .env.example"; }
chmod 600 "$ENVF"

B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'
[[ -t 1 ]] || B="" G="" R="" Y="" Z=""

getv() { grep -m1 "^$1=" "$ENVF" | cut -d= -f2-; }
setv() {   # KEY VALUE  - replace or add, no matter what characters the value has
    local tmp
    tmp=$(mktemp)
    awk -v k="$1" -v v="$2" 'BEGIN {done = 0}
        index($0, k "=") == 1 {print k "=" v; done = 1; next} {print}
        END {if (!done) print k "=" v}' "$ENVF" >"$tmp" && cat "$tmp" >"$ENVF"
    rm -f "$tmp"
}
ask() {    # PROMPT DEFAULT -> answer (default on Enter)
    local a
    read -rp "$1 [${2}]: " a
    echo "${a:-$2}"
}
host_ip() { ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1; }
compose() {
    if docker compose version >/dev/null 2>&1; then docker compose "$@"
    elif podman compose version >/dev/null 2>&1; then podman compose "$@"
    else docker-compose "$@"; fi
}

# test_api TOKEN URLS -> 0 if one of the addresses accepts the token
test_api() {
    local tok=$1 url out code
    for url in ${2//,/ }; do
        out=$(curl -sk --connect-timeout 5 --max-time 15 -w '\n%{http_code}' \
            -H "Authorization: PVEAPIToken=$tok" "${url%/}/api2/json/version" 2>&1)
        code=${out##*$'\n'}
        case $code in
            200) echo "  ${G}OK${Z}  $url - Proxmox $(sed -n 's/.*"version" *: *"\([^"]*\)".*/\1/p' <<<"${out%$'\n'*}")"; return 0 ;;
            401) echo "  ${R}token refused${Z} by $url (wrong token, or it was deleted)" ;;
            000) echo "  ${Y}no answer${Z} from $url (wrong address, or port 8006 blocked)" ;;
            *) echo "  ${R}HTTP $code${Z} from $url" ;;
        esac
    done
    return 1
}

# Make the API user, rights and token on a node over SSH (asks for root's password)
create_token() {
    local node out tid val
    node=$(ask "  Node to create it on (IP or name)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    echo "  Connecting to root@$node - it may ask for root's password once."
    echo "  ${Y}If a 'range' token already exists for pverange@pve it is replaced (the old one stops working).${Z}"
    read -rp "  Continue? [y/N] " a
    [[ $a == [yY]* ]] || return 1
    out=$(ssh -o ConnectTimeout=10 "root@$node" '
        pveum user add pverange@pve --comment "pve-range container" 2>/dev/null
        pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor || exit 1
        pveum user token remove pverange@pve range 2>/dev/null
        pveum user token add pverange@pve range --privsep 0 --output-format json') || {
        echo "  ${R}Could not create the token on $node.${Z}"; return 1; }
    tid=$(grep -o '"full-tokenid" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    val=$(grep -o '"value" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    [[ -n $tid && -n $val ]] || { echo "  ${R}Unexpected answer:${Z} $out"; return 1; }
    TOKEN="$tid=$val"
    echo "  ${G}Created${Z} $tid"
}

set_token() {
    local cur choice
    cur=$(getv PVE_API_TOKEN)
    echo
    local shown="not set"
    [[ -n $cur ]] && shown="${cur%%=*}=****"
    echo "${B}Proxmox API token${Z}  (now: $shown)"
    echo "  1) Paste a token I already have   (looks like  pverange@pve!range=xxxxxxxx-xxxx-...)"
    echo "  2) Create one now on a node over SSH (needs root's password once)"
    echo "  3) Keep the current one"
    read -rp "Choose [1-3]: " choice
    TOKEN=""
    case $choice in
        1)
            read -rsp "  Paste the token (hidden): " TOKEN; echo
            TOKEN=$(tr -d '[:space:]' <<<"$TOKEN")
            [[ $TOKEN =~ ^[^@!=]+@[^!=]+![^=]+=.+$ ]] || {
                echo "  ${R}That doesn't look like USER@REALM!NAME=SECRET.${Z}"; return 1; }
            ;;
        2) create_token || return 1 ;;
        *) return 0 ;;
    esac
    echo "  Testing it ..."
    if ! test_api "$TOKEN" "$(getv PVE_API_URL)"; then
        read -rp "  It didn't work with the addresses in .env. Save it anyway? [y/N] " a
        [[ $a == [yY]* ]] || return 1
    fi
    setv PVE_API_TOKEN "$TOKEN"
    chmod 600 "$ENVF"
    echo "  ${G}Saved in $ENVF${Z} (readable by root only)"
    CHANGED=1
}

apply() {
    ((CHANGED)) || return 0
    read -rp "Start / restart the containers now so the change is used? [Y/n] " a
    [[ $a == [nN]* ]] && { echo "Later: docker compose up -d"; return; }
    compose up -d --build && sleep 3 && compose logs --tail 25 pve-range-web
}

CHANGED=0
case ${1:-all} in
    test)
        test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
        exit $?
        ;;
    token)
        set_token
        apply
        exit 0
        ;;
esac

echo "${B}pve-range - container mode setup${Z}  (writes $ENVF; Enter keeps the value in brackets)"
echo
ipd=$(host_ip)
v=$(ask "Proxmox API address(es), space-separated" "$(getv PVE_API_URL)")
w=""
for u in ${v//,/ }; do   # 192.168.77.77 -> https://192.168.77.77:8006
    if [[ $u != *://* ]]; then if [[ $u == *:* ]]; then u="https://$u"; else u="https://$u:8006"; fi; fi
    w+="$u "
done
v=${w% }
[[ $v != "$(getv PVE_API_URL)" ]] && { setv PVE_API_URL "$v"; CHANGED=1; }
set_token
v=$(ask "This Docker host's IP (the nodes see connections from it)" "$(getv KEY_FROM | sed "s/^$/$ipd/")")
[[ $v != "$(getv KEY_FROM)" ]] && { setv KEY_FROM "$v"; CHANGED=1; }
v=$(ask "Download page address" "$(getv DIST_URL | sed "s#^\$#http://$ipd:8080#")")
[[ $v != "$(getv DIST_URL)" ]] && { setv DIST_URL "$v"; CHANGED=1; }
if [[ -n $(getv PVE_NODES) ]]; then
    read -rp "Node mode is also set (PVE_NODES). Clear it so container mode is used? [Y/n] " a
    [[ $a == [nN]* ]] || { setv PVE_NODES ""; CHANGED=1; }
fi
echo
echo "${B}Check:${Z}"
test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
echo
apply
