#!/usr/bin/env bash
# setup.sh - set up or change .env for pve-range in Docker / Podman (container mode)
#
#   ./setup.sh          step by step: API, token, addresses, start, first user, Gitea
#   ./setup.sh token    only change the API token
#   ./setup.sh test     only test the API connection with what's in .env
#   ./setup.sh user     add a web user (sign-in for the browser menu)
#   ./setup.sh gitea    set up the bundled Gitea and connect pve-range to it
set -u
cd "$(dirname "$0")" || exit 1
ENVF=.env
[[ -f $ENVF ]] || { cp .env.example "$ENVF" 2>/dev/null || : >"$ENVF"; echo "Created $ENVF from .env.example"; }
chmod 600 "$ENVF"

B=$'\e[1m' G=$'\e[32m' R=$'\e[31m' Y=$'\e[33m' Z=$'\e[0m'
[[ -t 1 ]] || B="" G="" R="" Y="" Z=""

getv() { grep -m1 "^$1=" "$ENVF" | cut -d= -f2-; }
setv() {   # KEY VALUE  - replace or add, no matter what characters the value has
    local tmp
    tmp=$(mktemp)
    awk -v k="$1" -v v="$2" 'BEGIN {done = 0}
        index($0, k "=") == 1 {print k "=" v; done = 1; next} {print}
        END {if (!done) print k "=" v}' "$ENVF" >"$tmp" && cat "$tmp" >"$ENVF"
    rm -f "$tmp"
}
ask() {    # PROMPT DEFAULT -> answer (default on Enter)
    local a
    read -rp "$1 [${2}]: " a
    echo "${a:-$2}"
}
host_ip() {
    local a
    a=$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)
    [[ -n $a ]] || a=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "${a:-127.0.0.1}"
}
compose() {
    if docker compose version >/dev/null 2>&1; then docker compose "$@"
    elif podman compose version >/dev/null 2>&1; then podman compose "$@"
    else docker-compose "$@"; fi
}

cexec() { if [[ -t 0 ]]; then compose exec "$@"; else compose exec -T "$@"; fi; }   # interactive when possible
has_users() { compose exec -T pve-range-web sh -c '[ -s /data/users ]' 2>/dev/null; }
startup_log() { compose logs pve-range-web 2>/dev/null | grep -v ' N: ' | tail -n "${1:-30}"; }

# test_api TOKEN URLS -> 0 if one of the addresses accepts the token
test_api() {
    local tok=$1 url out code
    for url in ${2//,/ }; do
        out=$(curl -sk --connect-timeout 5 --max-time 15 -w '\n%{http_code}' \
            -H "Authorization: PVEAPIToken=$tok" "${url%/}/api2/json/version" 2>&1)
        code=${out##*$'\n'}
        case $code in
            200) echo "  ${G}OK${Z}  $url - Proxmox $(sed -n 's/.*"version" *: *"\([^"]*\)".*/\1/p' <<<"${out%$'\n'*}")"; return 0 ;;
            401) echo "  ${R}token refused${Z} by $url (wrong token, or it was deleted)" ;;
            000) echo "  ${Y}no answer${Z} from $url (wrong address, or port 8006 blocked)" ;;
            *) echo "  ${R}HTTP $code${Z} from $url" ;;
        esac
    done
    return 1
}

# Make the API user, rights and token on a node over SSH (asks for root's password)
create_token() {
    local node out tid val
    node=$(ask "  Node to create it on (IP or name)" "$(getv PVE_API_URL | awk '{print $1}' | sed -E 's#https?://##; s#:.*##')")
    echo "  Connecting to root@$node - it may ask for root's password once."
    echo "  ${Y}If a 'range' token already exists for pverange@pve it is replaced (the old one stops working).${Z}"
    read -rp "  Continue? [y/N] " a
    [[ $a == [yY]* ]] || return 1
    out=$(ssh -o ConnectTimeout=10 "root@$node" '
        pveum user add pverange@pve --comment "pve-range container" 2>/dev/null
        pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor || exit 1
        pveum user token remove pverange@pve range 2>/dev/null
        pveum user token add pverange@pve range --privsep 0 --output-format json') || {
        echo "  ${R}Could not create the token on $node.${Z}"; return 1; }
    tid=$(grep -o '"full-tokenid" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    val=$(grep -o '"value" *: *"[^"]*"' <<<"$out" | sed 's/.*: *"//; s/"$//')
    [[ -n $tid && -n $val ]] || { echo "  ${R}Unexpected answer:${Z} $out"; return 1; }
    TOKEN="$tid=$val"
    echo "  ${G}Created${Z} $tid"
}

set_token() {
    local cur choice
    cur=$(getv PVE_API_TOKEN)
    echo
    local shown="not set"
    [[ -n $cur ]] && shown="${cur%%=*}=****"
    echo "${B}Proxmox API token${Z}  (now: $shown)"
    echo "  1) Paste a token I already have   (looks like  pverange@pve!range=xxxxxxxx-xxxx-...)"
    echo "  2) Create one now on a node over SSH (needs root's password once)"
    echo "  3) Keep the current one"
    read -rp "Choose [1-3]: " choice
    TOKEN=""
    case $choice in
        1)
            read -rsp "  Paste the token (hidden): " TOKEN; echo
            TOKEN=$(tr -d '[:space:]' <<<"$TOKEN")
            [[ $TOKEN =~ ^[^@!=]+@[^!=]+![^=]+=.+$ ]] || {
                echo "  ${R}That doesn't look like USER@REALM!NAME=SECRET.${Z}"; return 1; }
            ;;
        2) create_token || return 1 ;;
        *) return 0 ;;
    esac
    echo "  Testing it ..."
    if ! test_api "$TOKEN" "$(getv PVE_API_URL)"; then
        read -rp "  It didn't work with the addresses in .env. Save it anyway? [y/N] " a
        [[ $a == [yY]* ]] || return 1
    fi
    setv PVE_API_TOKEN "$TOKEN"
    chmod 600 "$ENVF"
    echo "  ${G}Saved in $ENVF${Z} (readable by root only)"
    CHANGED=1
}

apply() {
    ((CHANGED)) || return 0
    read -rp "Start / restart the containers now so the change is used? [Y/n] " a
    [[ $a == [nN]* ]] && { echo "Later: docker compose up -d"; return 1; }
    compose up -d --build || return 1
    sleep 4
    startup_log 25
}

# The first (or another) sign-in for the browser menu
web_user() {
    local name
    echo
    echo "${B}Web user${Z} - the sign-in for https://<this host>:${PORT:-7681}"
    name=$(ask "  User name" "admin")
    [[ $name =~ ^[A-Za-z0-9_.-]{1,32}$ ]] || { echo "  ${R}Letters, digits, . _ - only.${Z}"; return 1; }
    read -rp "  Also require a 2FA code from an authenticator app? [y/N] " a
    if [[ $a == [yY]* ]]; then cexec pve-range-web pve-range-web-users add "$name" --2fa
    else cexec pve-range-web pve-range-web-users add "$name"; fi
    compose exec -T pve-range-web pve-range-web-users list
}

# Bundled Gitea: start it, admin user, token, connect pve-range, first save
gitea_setup() {
    local ip port url gu gp gp2 ge tok out
    ip=$(host_ip)
    port=$(getv GITEA_PORT); port=${port:-3000}
    echo
    echo "${B}Gitea${Z} - your own Git server for add-ons, class guides and settings"
    [[ $(getv COMPOSE_PROFILES) == *gitea* ]] || setv COMPOSE_PROFILES gitea
    [[ -n $(getv GITEA_URL) && $(getv GITEA_URL) != *192.168.77.91* ]] || setv GITEA_URL "http://$ip:$port/"
    setv GITEA_DOMAIN "$ip"
    echo "  Starting Gitea ..."
    compose up -d gitea || { echo "  ${R}Gitea didn't start.${Z}"; return 1; }
    for _ in $(seq 1 60); do
        curl -sf "http://127.0.0.1:$port/api/healthz" >/dev/null 2>&1 && break
        sleep 2
    done
    curl -sf "http://127.0.0.1:$port/api/healthz" >/dev/null 2>&1 || { echo "  ${R}Gitea isn't answering on port $port.${Z}"; return 1; }
    echo "  ${G}Gitea is up${Z} at http://$ip:$port"

    echo "  Gitea admin account (you sign in to Gitea with it; 'admin' is reserved by Gitea):"
    gu=$(ask "    User name" "range-admin")
    [[ $gu =~ ^[A-Za-z0-9_.-]{2,40}$ && $gu != admin ]] || { echo "  ${R}Choose another name.${Z}"; return 1; }
    if compose exec -T -u git gitea gitea admin user list 2>/dev/null | awk 'NR > 1 {print $2}' | grep -qx "$gu"; then
        echo "  $gu already exists in Gitea - keeping its password."
    else
        while :; do
            read -rsp "    Password (min. 8): " gp; echo
            read -rsp "    Repeat: " gp2; echo
            [[ ${#gp} -ge 8 && $gp == "$gp2" ]] && break
            echo "    Too short or not the same."
        done
        ge=$(ask "    E-mail (only used inside Gitea)" "$gu@pve-range.local")
        if ! out=$(compose exec -T -u git gitea gitea admin user create --username "$gu" --password "$gp" \
            --email "$ge" --admin --must-change-password=false 2>&1); then
            echo "  ${R}Could not create the user:${Z} $out"; return 1
        fi
        echo "  ${G}Created${Z} Gitea admin $gu"
    fi

    tok=$(compose exec -T -u git gitea gitea admin user generate-access-token --username "$gu" \
        --token-name "pve-range-$(date +%Y%m%d-%H%M%S)" --scopes write:repository --raw 2>&1 | tail -1 | tr -d '\r ')
    [[ $tok =~ ^[0-9a-f]{40}$ ]] || { echo "  ${R}Could not create a token:${Z} $tok"; return 1; }
    echo "  ${G}Created${Z} an access token (repository read/write)"

    # Connect pve-range (inside the Docker network Gitea is "gitea:3000")
    url="http://gitea:3000/$gu/pve-range.git"
    compose exec -T -u pverange pve-range-web sh -c '
        f=/data/share/save.conf; mkdir -p /data/share; touch "$f"
        for kv in "REPO_URL='"$url"'" "REPO_USER='"$gu"'" "REPO_BRANCH=main" "AUTO_PUSH=1"; do
            k=${kv%%=*}; grep -v "^$k=" "$f" >"$f.new"; echo "$kv" >>"$f.new"; mv "$f.new" "$f"
        done' || { echo "  ${R}Could not save the repository settings.${Z}"; return 1; }
    printf '%s\n' "$tok" | compose exec -T -u pverange pve-range-web sh -c 'umask 077; cat >/data/priv/pve-range-repo.token'
    echo "  First save (creates the private repository $gu/pve-range) ..."
    out=$(compose exec -T pve-range-web pve-range save "Connected to Gitea" 2>&1)
    echo "$out" | sed 's/^/    /'
    if curl -sf -H "Authorization: token $tok" "http://127.0.0.1:$port/api/v1/repos/$gu/pve-range" >/dev/null; then
        echo "  ${G}Connected.${Z} Browse it: http://$ip:$port/$gu/pve-range  (sign in as $gu)"
    else
        echo "  ${R}The repository wasn't created - see the save output above.${Z}"; return 1
    fi
}

CHANGED=0
PORT=$(getv PORT)
case ${1:-all} in
    user) web_user; exit ;;
    gitea) gitea_setup; exit ;;
    test)
        test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
        exit $?
        ;;
    token)
        set_token
        apply
        exit 0
        ;;
esac

echo "${B}pve-range - container mode setup${Z}  (writes $ENVF; Enter keeps the value in brackets)"
echo
ipd=$(host_ip)
v=$(ask "Proxmox API address(es), space-separated" "$(getv PVE_API_URL)")
w=""
for u in ${v//,/ }; do   # 192.168.77.77 -> https://192.168.77.77:8006
    if [[ $u != *://* ]]; then if [[ $u == *:* ]]; then u="https://$u"; else u="https://$u:8006"; fi; fi
    w+="$u "
done
v=${w% }
[[ $v != "$(getv PVE_API_URL)" ]] && { setv PVE_API_URL "$v"; CHANGED=1; }
set_token
v=$(ask "This Docker host's IP (the nodes see connections from it)" "$(getv KEY_FROM | sed "s/^$/$ipd/")")
[[ $v != "$(getv KEY_FROM)" ]] && { setv KEY_FROM "$v"; CHANGED=1; }
v=$(ask "Download page address" "$(getv DIST_URL | sed "s#^\$#http://$ipd:8080#")")
[[ $v != "$(getv DIST_URL)" ]] && { setv DIST_URL "$v"; CHANGED=1; }
if [[ -n $(getv PVE_NODES) ]]; then
    read -rp "Node mode is also set (PVE_NODES). Clear it so container mode is used? [Y/n] " a
    [[ $a == [nN]* ]] || { setv PVE_NODES ""; CHANGED=1; }
fi
read -rp "Also set up Gitea (your own Git server for add-ons and guides)? [y/N] " a
want_gitea=0
[[ $a == [yY]* ]] && { want_gitea=1; setv COMPOSE_PROFILES gitea; CHANGED=1; }
echo
echo "${B}Check:${Z}"
test_api "$(getv PVE_API_TOKEN)" "$(getv PVE_API_URL)"
echo
apply || true
if compose ps --status running 2>/dev/null | grep -q pve-range-web; then
    if has_users; then
        read -rp "Add another web user? [y/N] " a
        [[ $a == [yY]* ]] && web_user
    else
        echo "${Y}No web users yet - you need one to sign in.${Z}"
        web_user
    fi
    ((want_gitea)) && gitea_setup
    ip=$(host_ip)
    echo
    echo "${B}Done.${Z}"
    echo "  pve-range menu : https://$ip:${PORT:-7681}"
    echo "  User guide     : $(getv DIST_URL)"
    ((want_gitea)) && echo "  Gitea          : http://$ip:$(getv GITEA_PORT | sed 's/^$/3000/')"
    echo "  Test everything: ./docker-test.sh"
fi
