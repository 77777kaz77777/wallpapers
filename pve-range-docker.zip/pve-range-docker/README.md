# pve-range in Docker

Two services:

| Service | Port | What |
|---|---|---|
| `pve-range-web` | 7681 (https) | The pve-range menu in a browser – per-user sign-in with 2FA, lock-out, sign-in log, idle sign-out, dark theme |
| `pve-range-dist` | 8080 (http) | Download page: user guide, `pve-range.sh` and a one-line installer for the nodes |

pve-range itself must run **on the Proxmox nodes** (it drives `qm`, `pct` and Open vSwitch).
The web menu signs in over SSH with a key that can only open that menu.

## Start

```bash
cp .env.example .env          # PVE_NODES, KEY_FROM (Docker host IP), DIST_URL
docker compose up -d --build
docker compose logs pve-range-web
```

1. Install pve-range on every node (from one node):
   `curl -fsSL http://<docker-host>:8080/install.sh | PVE_RANGE_ALL_NODES=1 bash`
2. Run the `echo '...' >> /etc/pve/priv/authorized_keys` line from the log on one node.
3. Add users: `docker compose exec pve-range-web pve-range-web-users add alice`
4. Open `https://<docker-host>:7681`. The guide is at `http://<docker-host>:8080/`.

## Users

```bash
docker compose exec pve-range-web pve-range-web-users add alice      # with 2FA
docker compose exec pve-range-web pve-range-web-users list
docker compose exec pve-range-web pve-range-web-users passwd alice
docker compose exec pve-range-web pve-range-web-users 2fa alice on|off
docker compose exec pve-range-web pve-range-web-users del alice
docker compose exec pve-range-web pve-range-web-users unlock
```

## Updating pve-range

Replace `dist/pve-range.sh`, then `docker compose restart pve-range-dist` and run the
installer line on a node again.

## Data and certificate

Everything lives in the `pve-range-web-data` volume: users, the SSH key the nodes
trust, known node host keys, the TLS certificate and `auth.log`. Back it up.

No browser warning: sign a certificate with the cluster's CA on a node and copy it in:

```bash
openssl req -new -newkey rsa:2048 -nodes -subj "/CN=pve-range-web" -keyout web.key -out web.csr
openssl x509 -req -in web.csr -CA /etc/pve/pve-root-ca.pem -CAkey /etc/pve/priv/pve-root-ca.key \
  -set_serial 0x$(openssl rand -hex 8) -days 397 -out web.crt \
  -extfile <(printf 'subjectAltName=IP:<docker-host-ip>\nextendedKeyUsage=serverAuth')
docker cp web.crt pve-range-web:/data/tls/cert.pem
docker cp web.key pve-range-web:/data/tls/key.pem
docker compose restart pve-range-web
```

Then import `/etc/pve/pve-root-ca.pem` into the browser as a trusted authority.
