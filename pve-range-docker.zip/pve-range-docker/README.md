# pve-range in Docker / Podman

| Service | Port | What |
|---|---|---|
| `pve-range-web` | 7681 (https) | The pve-range menu in a browser – per-user sign-in (optional 2FA), lock-out, sign-in log, idle sign-out, dark theme |
| `pve-range-dist` | 8080 (http) | Download page: user guide, changelog (and the node installer for node mode) |
| `gitea` (optional) | 3000 | Your own Git server for add-ons and class guides |

## Two ways to run it

| | **Container mode** (recommended) | Node mode (older) |
|---|---|---|
| Where pve-range runs | In this container | On every Proxmox node |
| Installed on the nodes | **Nothing** – only an API user and token | `pve-range` script, `git`, `lrzsz`, an SSH key |
| How it talks to Proxmox | Proxmox API (HTTPS, port 8006) with an API token | SSH, then `qm` / `pct` on the node |
| Set in `.env` | `PVE_API_URL`, `PVE_API_TOKEN` | `PVE_NODES` |

## Container mode – step by step

### 1. On ONE Proxmox node: an API user and token (once)

This is configuration only – nothing is installed:

```bash
pveum user add pverange@pve --comment "pve-range container"
pveum acl modify / --users pverange@pve --roles PVEVMAdmin,PVEDatastoreUser,PVEAuditor
pveum user token add pverange@pve range --privsep 0
```

The last command shows the token **once** – copy the `value`. The full token is
`pverange@pve!range=<value>`.

| Role | Why |
|---|---|
| PVEVMAdmin | start / stop, snapshots, network and disk settings, migration, guest agent |
| PVEDatastoreUser | moving and converting disks |
| PVEAuditor | reading nodes, storages and networks |

The token can't open a shell, manage users or change the nodes themselves.

### 2. Configure and start – `setup.sh`

```bash
./setup.sh
```

It writes `.env` for you, step by step:

1. **Proxmox API addresses** – plain IPs are fine (`192.168.77.77 192.168.77.78`
   becomes `https://…:8006`)
2. **API token** – paste one you have (hidden input), **or let it create one** on a node
   over SSH (asks for root's password once; runs the three `pveum` commands from step 1)
3. The Docker host's IP and the download page address
4. Tests the token against every address, saves `.env` readable by root only, and
   offers to (re)start the containers

Later:

```bash
./setup.sh token    # change only the API token
./setup.sh test     # test the API connection with what's in .env
./setup.sh user     # add a web user (the first one is created by ./setup.sh)
./setup.sh gitea    # set up the bundled Gitea and connect pve-range to it
```

Prefer editing by hand? `cp .env.example .env`, set `PVE_API_URL` and `PVE_API_TOKEN`,
`chmod 600 .env`, then `docker compose up -d --build` (Podman: `podman compose up -d --build`).

Open `https://<docker-host>:7681` and sign in.

### 3. Optional: port mirroring

The Proxmox API can't manage Open vSwitch mirrors. `docker compose logs pve-range-web`
prints one `echo '...' >> /etc/pve/priv/authorized_keys` line for a key that can **only
run `ovs-vsctl`** – nothing else, not even a shell. Run it on one node if you want
the Sensors menu. Without it, everything else still works.

### 4. Optional: check the node certificate

By default the container accepts the nodes' self-signed certificate. To check it,
copy the cluster CA into the volume:

```bash
scp root@<node>:/etc/pve/pve-root-ca.pem .
docker compose cp pve-root-ca.pem pve-range-web:/data/priv/pve-root-ca.pem
docker compose exec pve-range-web chown pverange: /data/priv/pve-root-ca.pem
```

### What needs the node's shell (not available in container mode)

| Feature | Instead |
|---|---|
| Enroll EFI keys (`qm enroll-efi-keys`) | Node shell in the Proxmox web UI |
| *Unlock guests* add-on (`qm unlock`) | Node shell in the Proxmox web UI |
| `pct exec` in add-ons | The Proxmox API (`pvesh`) – see the *Show IP addresses* add-on |
| Port mirroring | Optional key limited to `ovs-vsctl` (step 3) |

Backups go to the container volume (`/data/backups`) instead of a Proxmox
storage. Mount a share there if you want them off the Docker host.

### Command line in container mode

```bash
docker compose exec pve-range-web pve-range list --folder 613
docker compose exec pve-range-web pve-range --yes class-start --folder 612 --cluster
```

### Testing container mode

`docker-test.sh` (in this folder) tests the whole container setup from the Docker host:
the containers and web pages, the API connection and token rights, failover to the next
node address, a wrong token, sign-in, and every pve-range action on the fake range from
`range-seed.sh` (class 613 guests) – all from inside the container.

```bash
./docker-test.sh                    # compose folder /opt/pve-range-docker
./docker-test.sh /path/to/folder
```

It removes its snapshots, test markers and test user at the end. Works with Docker
and Podman.

## Node mode (older)

Set `PVE_NODES` (and leave `PVE_API_URL` empty), start the containers, install
pve-range on every node (from one node):
`curl -fsSL http://<docker-host>:8080/install.sh | PVE_RANGE_ALL_NODES=1 bash`
and run the `echo '...' >> /etc/pve/priv/authorized_keys` line from the log on one node.

## Users

```bash
docker compose exec pve-range-web pve-range-web-users add alice      # password only
docker compose exec pve-range-web pve-range-web-users add bob --2fa  # with a 2FA code
docker compose exec pve-range-web pve-range-web-users list
docker compose exec pve-range-web pve-range-web-users passwd alice
docker compose exec pve-range-web pve-range-web-users 2fa alice on|off
docker compose exec pve-range-web pve-range-web-users del alice
docker compose exec pve-range-web pve-range-web-users unlock
```

## Connect your Git repository (Gitea, GitHub, GitLab …)

pve-range saves add-ons, class guides and settings to a Git repository. To use one you
already have:

1. Create an **empty** repository (a README is fine), e.g. `pve-range`.
2. Create a token that may **write** to it:
   - Gitea: your user → Settings → Applications → token, *repository: Read and Write*
   - GitHub: Settings → Developer settings → Fine-grained token → *Contents: Read and write*
   - GitLab: Project → Settings → Access tokens → *write_repository*
3. Run:
   ```bash
   ./setup.sh repo
   ```
   Give the address (`https://gitea.lab/team/pve-range.git`), the branch, your user
   name and the token. It tests the connection first – if it fails, nothing is changed –
   then **uploads everything** (add-ons, class guides, settings and their history).
   From then on every change is sent there automatically.

- **Self-signed HTTPS** on your Gitea: it offers to connect without checking the
  certificate.
- **SSH address** (`git@host:team/pve-range.git`): it shows a key to add to the
  repository as a *deploy key with write access* – no token needed.
- `./setup.sh` (the full setup) offers this too.

## Optional: run a new Gitea here (bundled)

The easy way – everything is done for you:

```bash
./setup.sh gitea
```

It starts Gitea (already configured – no web installer), creates a Gitea **admin
account**, makes an **access token**, connects pve-range to it and does the first save,
which creates the private repository `<admin>/pve-range`. Then browse it at
`http://<docker-host>:3000` and sign in with that admin account.

`./setup.sh` (the full setup) also offers this as its last step. Gitea keeps running
with the other containers from then on (`COMPOSE_PROFILES=gitea` in `.env`).

## Updating pve-range

Replace `dist/pve-range.sh`, then `docker compose restart pve-range-dist` and run the
installer line on a node again.

### Uploads in the browser (version 2.3+)

The web page needs ttyd's upload option (`-t enableZmodem=true`) - included in this
zip. For an existing setup, rebuild with the new files: `docker compose up -d --build`.
The nodes need `lrzsz` (pve-range offers to install it) and `git` for the repository:
`apt-get install -y lrzsz git` on each node.

## Data and certificate

Everything lives in the `pve-range-web-data` volume: users, the SSH key the nodes
trust, known node host keys, the TLS certificate and `auth.log`. Back it up.

No browser warning: sign a certificate with the cluster's CA on a node and copy it in:

```bash
openssl req -new -newkey rsa:2048 -nodes -subj "/CN=pve-range-web" -keyout web.key -out web.csr
openssl x509 -req -in web.csr -CA /etc/pve/pve-root-ca.pem -CAkey /etc/pve/priv/pve-root-ca.key \
  -set_serial 0x$(openssl rand -hex 8) -days 397 -out web.crt \
  -extfile <(printf 'subjectAltName=IP:<docker-host-ip>\nextendedKeyUsage=serverAuth')
docker cp web.crt pve-range-web:/data/tls/cert.pem
docker cp web.key pve-range-web:/data/tls/key.pem
docker compose restart pve-range-web
```

Then import `/etc/pve/pve-root-ca.pem` into the browser as a trusted authority.
